import * as i0 from '@angular/core';
import { EventEmitter, Output, Input, ChangeDetectionStrategy, Component, inject, ElementRef, Renderer2, Directive, ChangeDetectorRef, ViewChild, HostBinding, DestroyRef, input, ViewContainerRef, ComponentRef, forwardRef, ViewChildren, Injector, InjectionToken } from '@angular/core';
import * as i1 from '@angular/material/chips';
import { MatChipsModule } from '@angular/material/chips';
import * as i2 from '@angular/material/icon';
import { MatIconModule, MatIcon } from '@angular/material/icon';
import * as i5 from '@angular/material/select';
import { MatSelectModule } from '@angular/material/select';
import * as i2$1 from '@angular/forms';
import { FormControl, ReactiveFormsModule, NgControl, FormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import { ReplaySubject, zip, take, Subject } from 'rxjs';
import * as i1$2 from '@angular/common';
import { CommonModule, AsyncPipe, NgTemplateOutlet, NgClass } from '@angular/common';
import { debounceTime } from 'rxjs/operators';
import * as i1$1 from '@angular/material/tooltip';
import { MatTooltipModule, MatTooltip } from '@angular/material/tooltip';
import { MatInputModule } from '@angular/material/input';
import * as i6 from '@angular/material/button';
import { MatButtonModule, MatIconButton, MatButton } from '@angular/material/button';
import { MatMenuModule, MatMenuTrigger, MatMenu } from '@angular/material/menu';
import * as i7 from '@angular/material/core';
import { MatPseudoCheckboxModule, MatRippleModule } from '@angular/material/core';
import * as i8 from '@angular/material/expansion';
import { MatExpansionModule } from '@angular/material/expansion';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { PickerComponent } from '@ctrl/ngx-emoji-mart';
import { MatFormFieldControl } from '@angular/material/form-field';
import { Overlay } from '@angular/cdk/overlay';
import { ComponentPortal } from '@angular/cdk/portal';

class CustomChipComponent {
    constructor() {
        this.closeBtn = true;
        this.close = new EventEmitter();
        this.click = new EventEmitter();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: CustomChipComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.16", type: CustomChipComponent, isStandalone: true, selector: "atom-custom-chip", inputs: { value: "value", closeBtn: "closeBtn" }, outputs: { close: "close", click: "click" }, ngImport: i0, template: "<mat-chip class=\"mat-chip-custom\" (click)=\"click.emit()\"\r\n>{{ value }}\r\n    <button matChipRemove [attr.aria-label]=\"'remove'\" (click)=\"close.emit()\">\r\n        <mat-icon fontSet=\"material-icons-outlined\">close</mat-icon>\r\n    </button>\r\n</mat-chip>\r\n", styles: [":host{display:inline-block}:host::ng-deep .mat-chip-custom{--mat-chip-container-shape-radius: 5px;background:#f3f2f2;margin:0 .5ch;border:.5px solid #C3C1C0;height:18px;min-width:fit-content}:host::ng-deep .mat-chip-custom ::ng-deep mat-icon{color:#645e5b;font-size:12px;width:12px;display:flex;align-items:center;justify-content:center}:host::ng-deep .mat-chip-custom ::ng-deep button{width:12px}:host::ng-deep .mat-chip-custom ::ng-deep .mdc-evolution-chip__action--primary{padding-left:4px!important}:host::ng-deep .mat-chip-custom ::ng-deep .mdc-evolution-chip__action--trailing{padding-right:4px!important;padding-left:8px!important}:host::ng-deep .mat-chip-custom ::ng-deep span{font-weight:400;color:#2d2b29;font-size:12px!important;line-height:14.52px!important}\n"], dependencies: [{ kind: "ngmodule", type: MatChipsModule }, { kind: "component", type: i1.MatChip, selector: "mat-basic-chip, [mat-basic-chip], mat-chip, [mat-chip]", inputs: ["role", "id", "aria-label", "aria-description", "value", "color", "removable", "highlighted", "disableRipple", "disabled"], outputs: ["removed", "destroyed"], exportAs: ["matChip"] }, { kind: "directive", type: i1.MatChipRemove, selector: "[matChipRemove]" }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: CustomChipComponent, decorators: [{
            type: Component,
            args: [{ selector: 'atom-custom-chip', changeDetection: ChangeDetectionStrategy.OnPush, imports: [MatChipsModule, MatIconModule], template: "<mat-chip class=\"mat-chip-custom\" (click)=\"click.emit()\"\r\n>{{ value }}\r\n    <button matChipRemove [attr.aria-label]=\"'remove'\" (click)=\"close.emit()\">\r\n        <mat-icon fontSet=\"material-icons-outlined\">close</mat-icon>\r\n    </button>\r\n</mat-chip>\r\n", styles: [":host{display:inline-block}:host::ng-deep .mat-chip-custom{--mat-chip-container-shape-radius: 5px;background:#f3f2f2;margin:0 .5ch;border:.5px solid #C3C1C0;height:18px;min-width:fit-content}:host::ng-deep .mat-chip-custom ::ng-deep mat-icon{color:#645e5b;font-size:12px;width:12px;display:flex;align-items:center;justify-content:center}:host::ng-deep .mat-chip-custom ::ng-deep button{width:12px}:host::ng-deep .mat-chip-custom ::ng-deep .mdc-evolution-chip__action--primary{padding-left:4px!important}:host::ng-deep .mat-chip-custom ::ng-deep .mdc-evolution-chip__action--trailing{padding-right:4px!important;padding-left:8px!important}:host::ng-deep .mat-chip-custom ::ng-deep span{font-weight:400;color:#2d2b29;font-size:12px!important;line-height:14.52px!important}\n"] }]
        }], propDecorators: { value: [{
                type: Input
            }], closeBtn: [{
                type: Input
            }], close: [{
                type: Output
            }], click: [{
                type: Output
            }] } });

class StickyPanelHeaderDirective {
    constructor() {
        this.elementRef = inject(ElementRef);
        this.renderer = inject(Renderer2);
    }
    ngAfterViewInit() {
        const panel = this.elementRef.nativeElement;
        const container = this.renderer.parentNode(panel);
        this.header = panel?.querySelector('mat-expansion-panel-header');
        if (this.header) {
            this.renderer.setStyle(this.header, 'position', 'sticky');
            this.renderer.setStyle(this.header, 'background', 'white');
            this.renderer.setStyle(this.header, 'top', '0');
            this.renderer.setStyle(this.header, 'z-index', '2');
            this.renderer.insertBefore(container, this.header, panel, true);
        }
    }
    ngOnDestroy() {
        this.header?.remove();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: StickyPanelHeaderDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.16", type: StickyPanelHeaderDirective, isStandalone: true, selector: "[stickyPanelHeader]", ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: StickyPanelHeaderDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[stickyPanelHeader]',
                    standalone: true,
                }]
        }] });

const nameof = (name) => name;

/**
 * A standalone component that truncates text with an ellipsis and optionally displays a tooltip with the full text on hover.
 * This component reacts dynamically to changes in the text content and the maximum width of the text span.
 * Is OnPush and ViewEncapsulation.None to optimize performance and allow global styling.
 */
class SpanEllipseComponent {
    constructor() {
        /** The maximum width of the text span, beyond which the text will be truncated. */
        this.maxWidthCssExpr = "100%";
        /** The preferred position of the tooltip. */
        this.tooltipPosition = "below";
        /** The delay in milliseconds before showing the tooltip after mouse enter. */
        this.tooltipShowDelay = 0;
        /** The delay in milliseconds before hiding the tooltip after mouse leave. */
        this.tooltipHideDelay = 0;
        this.tooltipClass = "";
        this._showTooltip = false;
        this._tooltipEnabled = false;
        this._cdr = inject(ChangeDetectorRef);
    }
    get text() {
        return this._textSpan.nativeElement.innerText.trim();
    }
    /**
     * Sets up the ResizeObserver on the text span element after the view initializes.
     */
    ngAfterViewInit() {
        this.setupResizeObserver();
    }
    /**
     * Checks if the tooltip is necessary whenever the input text or maximum width changes.
     * @param changes An object of changes.
     */
    ngOnChanges(changes) {
        if (changes["text"] || changes["maxWidthCssExpr"]) {
            this.checkTooltipNecessity();
        }
    }
    /**
     * Disconnects the ResizeObserver when the component is destroyed to prevent memory leaks.
     */
    ngOnDestroy() {
        this._resizeObserver?.disconnect();
    }
    /**
     * Sets up a ResizeObserver on the text span to determine if the text overflows its container.
     */
    setupResizeObserver() {
        this._resizeObserver = new ResizeObserver(() => {
            this.checkTooltipNecessity();
        });
        this._resizeObserver.observe(this._textSpan.nativeElement);
    }
    /**
     * Checks if the text overflows its container and enables or disables the tooltip accordingly.
     */
    checkTooltipNecessity() {
        const condition = this._textSpan?.nativeElement.offsetWidth < this._textSpan?.nativeElement.scrollWidth;
        if (condition !== this._tooltipEnabled) {
            this._tooltipEnabled = condition;
            this._showTooltip = this._tooltipEnabled;
            this._cdr.markForCheck();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: SpanEllipseComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.16", type: SpanEllipseComponent, isStandalone: true, selector: "atom-span-ellipse", inputs: { maxWidthCssExpr: "maxWidthCssExpr", tooltipPosition: "tooltipPosition", tooltipShowDelay: "tooltipShowDelay", tooltipHideDelay: "tooltipHideDelay", tooltipClass: "tooltipClass" }, host: { properties: { "style.width": "this.maxWidthCssExpr" } }, viewQueries: [{ propertyName: "_textSpan", first: true, predicate: ["textSpan"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<span\r\n  #textSpan\r\n  class=\"atom-text-ellipse\"\r\n  [matTooltip]=\"_showTooltip ? text : ''\"\r\n  [matTooltipPosition]=\"tooltipPosition\"\r\n  [matTooltipShowDelay]=\"tooltipShowDelay\"\r\n  [matTooltipHideDelay]=\"tooltipHideDelay\"\r\n  [matTooltipClass]=\"tooltipClass\"\r\n  (mouseenter)=\"_showTooltip = _tooltipEnabled\"\r\n  (mouseleave)=\"_showTooltip = false\"\r\n  [attr.aria-label]=\"_showTooltip ? text : null\"\r\n><ng-content/></span>\r\n", styles: [":host{display:inline-block;width:100%;overflow:hidden}.atom-text-ellipse{width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:block}\n"], dependencies: [{ kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i1$1.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: SpanEllipseComponent, decorators: [{
            type: Component,
            args: [{ selector: "atom-span-ellipse", imports: [
                        MatTooltipModule
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<span\r\n  #textSpan\r\n  class=\"atom-text-ellipse\"\r\n  [matTooltip]=\"_showTooltip ? text : ''\"\r\n  [matTooltipPosition]=\"tooltipPosition\"\r\n  [matTooltipShowDelay]=\"tooltipShowDelay\"\r\n  [matTooltipHideDelay]=\"tooltipHideDelay\"\r\n  [matTooltipClass]=\"tooltipClass\"\r\n  (mouseenter)=\"_showTooltip = _tooltipEnabled\"\r\n  (mouseleave)=\"_showTooltip = false\"\r\n  [attr.aria-label]=\"_showTooltip ? text : null\"\r\n><ng-content/></span>\r\n", styles: [":host{display:inline-block;width:100%;overflow:hidden}.atom-text-ellipse{width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:block}\n"] }]
        }], propDecorators: { maxWidthCssExpr: [{
                type: Input
            }, {
                type: HostBinding,
                args: ["style.width"]
            }], tooltipPosition: [{
                type: Input
            }], tooltipShowDelay: [{
                type: Input
            }], tooltipHideDelay: [{
                type: Input
            }], tooltipClass: [{
                type: Input
            }], _textSpan: [{
                type: ViewChild,
                args: ["textSpan"]
            }] } });

// TODO: Migrate to form control
class SelectSearchV2Component {
    constructor() {
        this.cdr = inject(ChangeDetectorRef);
        this._elementRef = inject(ElementRef);
        this.onDestroyRef$ = inject(DestroyRef);
        this.afterViewInitRef$ = new ReplaySubject(1);
        this.clearSearchText = '';
        this.selectAllTooltipText = '';
        this.selectAllMessage = '';
        this.allSelectedText = '';
        this.searchNoResultsText = '';
        this.noItemsText = '';
        this.searchPlaceholderText = '';
        this.disabledTooltipText = '';
        this.isRequiredText = '';
        this.label = '';
        this.required = false;
        this.disabled = false;
        this.hideEmptySearchResult = false;
        this.showLabel = true;
        this.tooltipMaxLength = 20;
        this.enableSearch = true;
        this.focusSearchOnOpen = false;
        this.searchCharsMaxLength = 50;
        this.floatLabel = 'auto';
        this.considerMissingOptionsInList = false;
        this.valueEqualFn = (first, second) => first === second;
        // TODO Rename the actual field
        this.valueOf = (option) => {
            if (this.valueKey && option !== null && option !== undefined) {
                return option[this.valueKey];
            }
            return option;
        };
        this.labelOf = (option) => {
            if (this.labelKey && option !== null && option !== undefined) {
                return option[this.labelKey];
            }
            return option;
        };
        this.disabledStateValue = true; // For compatibility, This and disabledKey can be changed by a predicate input
        this.enabledTooltip = false; // For compatibility, This and disabledKey can be changed by a predicate input
        this.options = [];
        this.excludedOptions = [];
        this.showError = false;
        this.customPanelCssCls = '';
        this.multiple = false;
        this.enableSelectAll = false;
        this.rowNumber = 6;
        this.rowHeightCssExpr = '35px';
        this.panelVerticalOffsetCssExpr = '-20px';
        this.panelMinWidth = 'unset';
        this.panelHorizontalOffsetCssExpr = '0';
        this.alreadyTouched = false;
        this.selectedOptionChange = new EventEmitter();
        this.hoverOption = new EventEmitter();
        this.blurOption = new EventEmitter();
        this.panelOpen = new EventEmitter();
        this.panelClose = new EventEmitter();
        this.optionCtrl = new FormControl(null);
        this.searchFilterCtrl = new FormControl();
        this.filteredGroups$ = new ReplaySubject(1);
        this._uniqueId = 'select-search-v2-' + Date.now();
    }
    get selectedOption() {
        return this.optionCtrl.value;
    }
    set selectedOption(optionsToSelect) {
        this._optionToSelect = optionsToSelect;
        this.selectedOptionSubscription?.unsubscribe();
        this.selectedOptionSubscription = this.filteredGroups$
            .pipe(takeUntilDestroyed(this.onDestroyRef$))
            .subscribe(() => {
            const selectedVal = (Array.isArray(optionsToSelect)
                ? optionsToSelect
                : [optionsToSelect]).filter(Boolean);
            let artificialOptionsAdded = false;
            let projectedValue = selectedVal
                .map((option) => {
                const foundOption = this.options.find((opt) => this.valueEqualFn(this.valueOf(opt), this.valueOf(option)));
                if (!foundOption && this.considerMissingOptionsInList) {
                    this.options.push(option);
                    artificialOptionsAdded = true;
                    return option;
                }
                return foundOption ?? null;
            })
                .filter(Boolean);
            switch (projectedValue.length) {
                case 0:
                    projectedValue = null;
                    break;
                case 1:
                    if (!this.multiple) {
                        projectedValue = projectedValue[0];
                    }
                    break;
            }
            if (artificialOptionsAdded) {
                this.filterOptions();
            }
            this.optionCtrl.setValue(projectedValue, {
                emitEvent: false,
            });
            this.cdr.detectChanges();
        });
    }
    open() {
        this.matSelect?.open();
    }
    close() {
        this.matSelect?.close();
    }
    get triggerValue() {
        if (!this.multiple && this.optionCtrl.value) {
            return (this.labelOf(this.optionCtrl.value) ||
                this.valueOf(this.optionCtrl.value) ||
                this.label ||
                this.placeholder);
        }
        if (this.multiple &&
            Boolean(this.optionCtrl.value?.length) &&
            Boolean(this.options?.length)) {
            if (this.enableSelectAll &&
                this.optionCtrl.value.length === this.options.length) {
                return this.allSelectedText;
            }
            return this.optionCtrl.value
                .map((option) => this.labelOf(option) || this.valueOf(option))
                .join(', ');
        }
        return (this.label || this.placeholder);
    }
    ngOnInit() {
        this.searchFilterCtrl.valueChanges
            .pipe(takeUntilDestroyed(this.onDestroyRef$))
            .subscribe(() => {
            this.filterOptions();
        });
        this.optionCtrl.valueChanges
            .pipe(takeUntilDestroyed(this.onDestroyRef$), debounceTime(100))
            .subscribe((element) => {
            if (element) {
                this.selectedOption = element;
                this.selectedOptionChange.emit(element);
            }
        });
    }
    ngAfterViewInit() {
        if (!this.matSelect) {
            return;
        }
        this.matSelect.compareWith = (option1, option2) => option1 &&
            option2 &&
            this.valueOf(option1) === this.valueOf(option2);
        // this._setupOverFlowCorrector();
        // patch the open and close methods
        const originalOpen = this.matSelect.open;
        this.matSelect.open = () => {
            zip(this.afterViewInitRef$, this.filteredGroups$)
                .pipe(take(1))
                .subscribe(() => {
                this._setPanelDynamicConfig();
                this.cdr.detectChanges();
                originalOpen.call(this.matSelect);
                this.cdr.detectChanges();
                if (this.enableSearch && this.focusSearchOnOpen) {
                    setTimeout(() => {
                        this.searchInput?.nativeElement.focus();
                    }, 0);
                }
            });
        };
        const originalClose = this.matSelect.close;
        this.matSelect.close = () => {
            zip(this.afterViewInitRef$, this.filteredGroups$)
                .pipe(take(1))
                .subscribe(() => {
                originalClose.call(this.matSelect);
                this.cdr.detectChanges();
                this.customPanelCssConfig?.remove();
            });
        };
        if (this.alreadyTouched)
            this.optionCtrl.markAllAsTouched();
        this.afterViewInitRef$.next();
    }
    _setupOverFlowCorrector() {
        this.matSelect?.openedChange
            .pipe(takeUntilDestroyed(this.onDestroyRef$))
            .subscribe(() => {
            if (!this.matSelect?.panel?.nativeElement) {
                return;
            }
            const panel = this.matSelect.panel.nativeElement
                .parentElement;
            const panelRect = panel.getBoundingClientRect();
            const screenRect = document.body.getBoundingClientRect();
            const width = panel.firstChild.getBoundingClientRect().width;
            panel.style.transition = 'top 0.3s, left 0.3s';
            panel.style.top = panel.offsetTop + 'px';
            setTimeout(() => {
                if (screenRect.width - panelRect.left < width) {
                    //add animation to avoid abrupt correction experience
                    panel.style.left = `${screenRect.width - width}px`;
                }
                // same for top
                if (panelRect.top < 64) {
                    // for it to be below the nav bar
                    panel.style.bottom = 'unset';
                    panel.style.top = '44px'; // 64px navbar - 20translate'
                }
                // same for bottom
                if (panelRect.bottom > screenRect.height) {
                    panel.style.top = `${screenRect.height - panelRect.height}px`;
                }
                // same for left
                if (panelRect.left < 0) {
                    panel.style.left = '0';
                }
            }, 0);
        });
    }
    _setPanelDynamicConfig() {
        this.customPanelCssConfig?.remove();
        this.customPanelCssConfig =
            this._elementRef.nativeElement.ownerDocument.createElement('style');
        // TODO: Refactor this to use Defined Stylesheets
        this.customPanelCssConfig.innerHTML = `.custom-panel-configs-${this._uniqueId} { --row-number: ${this.rowNumber}; --row-height: ${this.rowHeightCssExpr}; --panel-min-width: ${this.panelMinWidth};}`;
        this._elementRef.nativeElement.ownerDocument.head.appendChild(this.customPanelCssConfig);
    }
    ngOnChanges(changes) {
        if (changes[nameof('options')] ||
            changes[nameof('excludedOptions')]) {
            this.filterOptions();
        }
        if (changes[nameof('disabled')]) {
            changes[nameof('disabled')].currentValue
                ? this.optionCtrl.disable({ emitEvent: false })
                : this.optionCtrl.enable({ emitEvent: false });
        }
    }
    get _selectedAllCheckboxState() {
        const selectedLength = this.selectedOption?.length ?? 0;
        const optionsLength = this.options?.length ?? 0;
        if (selectedLength === 0) {
            return 'unchecked';
        }
        return selectedLength === optionsLength ? 'checked' : 'indeterminate';
    }
    onPanelOpen() {
        this.panelOpen.emit();
    }
    onPanelClose() {
        this.clearSearch();
        this.matSelect?._onBlur();
        this.panelClose.emit();
    }
    ngOnDestroy() {
        this.afterViewInitRef$.complete();
    }
    filterOptions() {
        if (!this.options) {
            return;
        }
        let options = this.options.slice();
        // Filter out excluded options which are not selected
        if (this.excludedOptions) {
            options = options.filter((option) => {
                const isSelected = Array.isArray(this._optionToSelect)
                    ? this._optionToSelect.some((selected) => this.valueEqualFn(this.valueOf(option), this.valueOf(selected)))
                    : this._optionToSelect &&
                        this.valueEqualFn(this.valueOf(option), this.valueOf(this._optionToSelect));
                const isExcluded = this.excludedOptions.some((excludedOption) => this.valueEqualFn(this.valueOf(option), this.valueOf(excludedOption)));
                return isSelected || !isExcluded;
            });
        }
        // sort options by name
        if (this.labelOrdering === 'asc' || this.labelOrdering === 'dsc') {
            options.sort((option1, option2) => {
                if (this.labelOf(option1) < this.labelOf(option2)) {
                    return this.labelOrdering === 'asc' ? -1 : 1;
                }
                if (this.labelOf(option1) > this.labelOf(option2)) {
                    return this.labelOrdering === 'asc' ? 1 : -1;
                }
                return 0;
            });
        }
        const search = this.searchFilterCtrl.value?.toLowerCase().trim();
        if (search) {
            options = this.options.filter((option) => this.labelOf(option).toLowerCase().trim().indexOf(search) >
                -1);
        }
        if (options.length === 0) {
            this.filteredGroups$.next([]);
            return;
        }
        const groupByKey = this.groupByKey;
        if (groupByKey !== undefined) {
            const groupsMap = options.reduce((acc, option) => {
                const group = option[groupByKey];
                if (!acc[group]) {
                    acc[group] = [];
                }
                acc[group].push(option);
                return acc;
            }, {});
            const groups = Object.values(groupsMap);
            // sort groups by name
            groups.sort((item1, item2) => {
                if (this.groupsConfig) {
                    const groupA = item1[0][groupByKey];
                    const groupB = item2[0][groupByKey];
                    const configA = this.groupsConfig.get(groupA);
                    const configB = this.groupsConfig.get(groupB);
                    const orderA = configA ? configA.orderPriority : undefined;
                    const orderB = configB ? configB.orderPriority : undefined;
                    if (orderA !== undefined && orderB !== undefined) {
                        return orderA - orderB;
                    }
                }
                if (this.labelOrdering === 'asc' ||
                    this.labelOrdering === 'dsc') {
                    if (item1[0][groupByKey] < item2[0][groupByKey]) {
                        return this.labelOrdering === 'asc' ? -1 : 1;
                    }
                    if (item1[0][groupByKey] > item2[0][groupByKey]) {
                        return this.labelOrdering === 'asc' ? 1 : -1;
                    }
                }
                return 0;
            });
            this.filteredGroups$.next(groups);
            return;
        }
        this.filteredGroups$.next([options]);
    }
    clearSearch() {
        this.searchFilterCtrl.setValue('');
    }
    trackByItems(index, item) {
        return this.valueOf(item);
    }
    getGroupRepresentation(group) {
        const groupByKey = this.groupByKey;
        const main = group[0][groupByKey];
        if (this.groupsConfig) {
            const config = this.groupsConfig.get(main);
            if (config) {
                return config.alternativeName;
            }
        }
        return main;
    }
    toggleSelectAll(state) {
        const newOpts = state !== 'checked' ? [].concat(this.options) : [];
        this.selectedOption = newOpts;
        this.selectedOptionChange.emit(this.selectedOption);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: SelectSearchV2Component, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.16", type: SelectSearchV2Component, isStandalone: true, selector: "atom-select-search-v2", inputs: { clearSearchText: "clearSearchText", selectAllTooltipText: "selectAllTooltipText", selectAllMessage: "selectAllMessage", allSelectedText: "allSelectedText", searchNoResultsText: "searchNoResultsText", noItemsText: "noItemsText", searchPlaceholderText: "searchPlaceholderText", disabledTooltipText: "disabledTooltipText", isRequiredText: "isRequiredText", label: "label", placeholder: "placeholder", required: "required", disabled: "disabled", hideEmptySearchResult: "hideEmptySearchResult", showLabel: "showLabel", tooltipMaxLength: "tooltipMaxLength", enableSearch: "enableSearch", focusSearchOnOpen: "focusSearchOnOpen", searchCharsMaxLength: "searchCharsMaxLength", floatLabel: "floatLabel", labelOrdering: "labelOrdering", considerMissingOptionsInList: "considerMissingOptionsInList", valueKey: "valueKey", labelKey: "labelKey", valueEqualFn: "valueEqualFn", valueOf: ["valueOfFn", "valueOf"], labelOf: ["labelOfFn", "labelOf"], disabledKey: "disabledKey", disabledStateValue: "disabledStateValue", enabledTooltip: "enabledTooltip", groupByKey: "groupByKey", groupsConfig: "groupsConfig", options: "options", excludedOptions: "excludedOptions", showError: "showError", customPanelCssCls: "customPanelCssCls", selectedOption: "selectedOption", multiple: "multiple", enableSelectAll: "enableSelectAll", leftDetailSpan: "leftDetailSpan", rightDetailSpan: "rightDetailSpan", customTrigger: "customTrigger", extraAction: "extraAction", rowNumber: "rowNumber", rowHeightCssExpr: "rowHeightCssExpr", panelVerticalOffsetCssExpr: "panelVerticalOffsetCssExpr", panelMinWidth: "panelMinWidth", panelHorizontalOffsetCssExpr: "panelHorizontalOffsetCssExpr", alreadyTouched: "alreadyTouched" }, outputs: { selectedOptionChange: "selectedOptionChange", hoverOption: "hoverOption", blurOption: "blurOption", panelOpen: "panelOpen", panelClose: "panelClose" }, host: { properties: { "style.--row-number": "this.rowNumber", "style.--row-height": "this.rowHeightCssExpr", "style.--panel-v-offset": "this.panelVerticalOffsetCssExpr", "style.--panel-min-width": "this.panelMinWidth", "style.--panel-h-offset": "this.panelHorizontalOffsetCssExpr" } }, viewQueries: [{ propertyName: "formField", first: true, predicate: ["formField"], descendants: true }, { propertyName: "searchInput", first: true, predicate: ["searchInput"], descendants: true }, { propertyName: "matSelect", first: true, predicate: ["matSelect"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "@if (customTrigger) {\r\n  <div>\r\n    <ng-container *ngTemplateOutlet=\"customTrigger\"/>\r\n  </div>\r\n}\r\n\r\n<mat-form-field\r\n  #formField\r\n  class=\"extended-from\"\r\n  [class.hidden-trigger]=\"customTrigger\"\r\n  appearance=\"outline\"\r\n  subscriptSizing=\"dynamic\"\r\n  [floatLabel]=\"floatLabel\"\r\n>\r\n  @if (showLabel) {\r\n    <mat-label>{{ label }}</mat-label>\r\n  }\r\n  <mat-select\r\n    #matSelect\r\n    [formControl]=\"optionCtrl\"\r\n    [id]=\"_uniqueId\"\r\n    [required]=\"required\"\r\n    [placeholder]=\"placeholder ?? ''\"\r\n    matTooltipPosition=\"before\"\r\n    [matTooltip]=\"labelOf(optionCtrl?.value)\"\r\n    [matTooltipDisabled]=\"(labelOf(optionCtrl?.value)?.length ?? 0) <= tooltipMaxLength\"\r\n    (closed)=\"onPanelClose()\"\r\n    (opened)=\"onPanelOpen()\"\r\n    [panelClass]=\"['custom-panel','flowbuilder-global-panel', 'custom-panel-configs-' + _uniqueId, customPanelCssCls]\"\r\n    hideSingleSelectionIndicator\r\n    [multiple]=\"multiple\"\r\n  >\r\n\r\n    <mat-select-trigger>\r\n      <span>{{ triggerValue }}</span>\r\n    </mat-select-trigger>\r\n\r\n    @if (enableSearch) {\r\n      <div class=\"search-container\">\r\n        <mat-icon>search</mat-icon>\r\n\r\n        <input\r\n          #searchInput\r\n          [maxlength]=\"searchCharsMaxLength\"\r\n          (keydown)=\"$event.stopPropagation()\"\r\n          (keyup)=\"$event.stopPropagation()\"\r\n          [formControl]=\"searchFilterCtrl\"\r\n          [placeholder]=\"searchPlaceholderText\"\r\n          class=\"search-input w-100\"\r\n        />\r\n\r\n        <button\r\n          mat-icon-button\r\n          [matTooltip]=\"clearSearchText\"\r\n          [matTooltipDisabled]=\"!searchFilterCtrl.value?.length\"\r\n          [hidden]=\"!searchFilterCtrl.value?.length\"\r\n          [disabled]=\"!searchFilterCtrl.value?.length\"\r\n          (click)=\"$event.stopPropagation(); clearSearch()\"\r\n        >\r\n          <mat-icon>close</mat-icon>\r\n        </button>\r\n      </div>\r\n    }\r\n\r\n    <div class=\"results-container\">\r\n\r\n      <!--Select All Indicator-->\r\n      @if (multiple && enableSelectAll && (!searchFilterCtrl.value || searchFilterCtrl.value.length === 0)) {\r\n        <div\r\n\r\n          (click)=\"toggleSelectAll(checkbox.state)\"\r\n          class=\"mat-mdc-option mdc-list-item mat-mdc-tooltip-trigger mat-mdc-option-multiple section-element\"\r\n        >\r\n          <mat-pseudo-checkbox\r\n            #checkbox\r\n            [state]=\"_selectedAllCheckboxState\"\r\n            matTooltipPosition=\"right\"\r\n            [matTooltip]=\"selectAllTooltipText\"\r\n          />\r\n          <span class=\"mdc-list-item__primary-text\">\r\n                {{ selectAllMessage }}\r\n                </span>\r\n        </div>\r\n      }\r\n\r\n      <!--Case no Items-->\r\n      @if (!(!!options?.length && (filteredGroups$ | async)?.[0]?.length) && !(searchFilterCtrl?.value?.length)) {\r\n        <mat-option disabled\r\n                    class=\"option-none none-opacity\">\r\n          <span>{{ noItemsText }}</span>\r\n        </mat-option>\r\n      }\r\n\r\n      <!-- Case no results-->\r\n      @if (enableSearch && !hideEmptySearchResult && !!searchFilterCtrl.value && (!!options?.length && (filteredGroups$ | async)?.length === 0)) {\r\n        <mat-option disabled\r\n                    class=\"option-none none-opacity\">\r\n          <span>{{ searchNoResultsText }}</span>\r\n        </mat-option>\r\n      }\r\n\r\n      <div class=\"items-container\">\r\n        @for (group of (filteredGroups$ | async); track group) {\r\n\r\n\r\n          @if (groupByKey) {\r\n\r\n            <mat-expansion-panel stickyPanelHeader [class.indented-row]=\"(multiple && enableSelectAll)\"\r\n                                 [expanded]=\"true\">\r\n              <mat-expansion-panel-header>\r\n                <mat-panel-title>\r\n                  <atom-span-ellipse\r\n                    [tooltipClass]=\"'atom-select-v2-tooltip'\">\r\n                    {{ getGroupRepresentation(group) }}\r\n                  </atom-span-ellipse>\r\n                </mat-panel-title>\r\n              </mat-expansion-panel-header>\r\n              <ng-container *ngTemplateOutlet=\"groupTemplate; context: { $implicit: group }\"/>\r\n            </mat-expansion-panel>\r\n\r\n          } @else {\r\n\r\n            <ng-container *ngTemplateOutlet=\"groupTemplate; context: { $implicit: group }\"/>\r\n\r\n          }\r\n\r\n\r\n        }\r\n\r\n        <!-- Filtered out options for mat select to maintain the selection-->\r\n        @if (multiple) {\r\n\r\n          @for (option of options; track trackByItems($index, option)) {\r\n\r\n            @if (!((filteredGroups$ | async)?.flat()?.includes(option))) {\r\n              <mat-option\r\n                [value]=\"option\"\r\n\r\n                [style.display]=\"'none'\"\r\n              />\r\n            }\r\n\r\n          }\r\n\r\n        }\r\n\r\n        <ng-template #groupTemplate let-group>\r\n          @for (option of group; track trackByItems($index, option)) {\r\n\r\n            <mat-option\r\n              [class.indented-row]=\"!!groupByKey !== (multiple && enableSelectAll)\"\r\n              class=\"option section-element\"\r\n              [value]=\"option\"\r\n              [disabled]=\"(option[disabledKey] && (!!(option[disabledKey]) === disabledStateValue))\"\r\n              [matTooltip]=\"(option[disabledKey] && (!!(option[disabledKey]) === disabledStateValue)) || enabledTooltip ? disabledTooltipText : ''\"\r\n              [matTooltipPosition]=\"'right'\"\r\n              (mouseenter)=\"hoverOption.emit(option)\"\r\n              (mouseleave)=\"blurOption.emit(null)\"\r\n            >\r\n              <ng-container>\r\n                <div class=\"section-element\">\r\n\r\n                  @if (leftDetailSpan) {\r\n                    <div class=\"section-element-left\">\r\n                      <ng-container\r\n                        *ngTemplateOutlet=\"leftDetailSpan; context: { $implicit: option, selectSearchV2:this }\"/>\r\n                    </div>\r\n                  }\r\n                  <atom-span-ellipse\r\n                    [class.atom-select-v2-item-in-group]=\"groupByKey\"\r\n                    [tooltipClass]=\"'atom-select-v2-tooltip'\">{{ labelOf(option) }}\r\n                  </atom-span-ellipse>\r\n\r\n                  @if (rightDetailSpan) {\r\n                    <div class=\"section-element-right d-flex\">\r\n                      <ng-container\r\n                        *ngTemplateOutlet=\"rightDetailSpan; context: { $implicit: option, selectSearchV2:this }\"/>\r\n                    </div>\r\n                  }\r\n                </div>\r\n              </ng-container>\r\n            </mat-option>\r\n\r\n          }\r\n        </ng-template>\r\n        <ng-container *ngTemplateOutlet=\"extraAction; context: { $implicit: this }\"/>\r\n      </div>\r\n\r\n    </div>\r\n  </mat-select>\r\n  @if (showError) {\r\n    <mat-error>\r\n      {{ isRequiredText }}\r\n    </mat-error>\r\n  }\r\n</mat-form-field>\r\n", styles: [":host ::ng-deep{width:100%;min-width:0;display:inline-block;position:relative}:host ::ng-deep .mat-mdc-form-field-subscript-wrapper{position:absolute;bottom:-18px}:host ::ng-deep .mat-mdc-text-field-wrapper.mdc-text-field--outlined .mat-mdc-form-field-infix{padding-top:0;padding-bottom:0;min-height:36px}.extended-from{width:100%!important;position:relative}::ng-deep .custom-panel.mdc-menu-surface.mat-mdc-select-panel{max-height:calc((var(--row-number) + 2) * var(--row-height) + 2px)!important;min-width:var(--panel-min-width);overflow:hidden}::ng-deep .custom-panel.mdc-menu-surface.mat-mdc-select-panel .search-container{height:var(--row-height);display:flex;align-items:center;gap:8px;border-radius:4px;padding:0 8px}::ng-deep .custom-panel.mdc-menu-surface.mat-mdc-select-panel .search-container button{width:16px;height:16px;display:flex}::ng-deep .custom-panel.mdc-menu-surface.mat-mdc-select-panel .search-container mat-icon{width:16px;height:16px;font-size:16px;color:#645e5b}::ng-deep .custom-panel.mdc-menu-surface.mat-mdc-select-panel .search-input{height:auto;padding:0;border:none;font-size:12px}::ng-deep .custom-panel.mdc-menu-surface.mat-mdc-select-panel .search-input:focus{outline:none;border:none}::ng-deep .custom-panel.mdc-menu-surface.mat-mdc-select-panel .items-container{overflow:auto;max-height:calc(var(--row-number) * var(--row-height))}::ng-deep .custom-panel.mdc-menu-surface.mat-mdc-select-panel .items-container .option{height:var(--row-height);font-size:12px}::ng-deep .custom-panel.mdc-menu-surface.mat-mdc-select-panel .mat-mdc-icon-button .mat-mdc-button-persistent-ripple,::ng-deep .custom-panel.mdc-menu-surface.mat-mdc-select-panel .mat-mdc-icon-button .mat-mdc-button-ripple{display:none}::ng-deep .atom-select-v2-item-in-group span{font-weight:400}.section-element{display:flex;flex-direction:row;align-items:center;justify-content:space-between;font-size:12px;line-height:15px;gap:4px}.section-element .section-element-right{align-items:center;justify-content:end;font-size:12px;width:fit-content;text-align:right}.section-element .section-element-left{align-items:center;justify-content:end;font-size:12px;width:fit-content;text-align:left}::ng-deep .atom-select-v2-tooltip *{font-size:12px!important;line-height:15px!important;height:var(--row-height)!important;max-width:none!important;display:flex;align-items:center;padding:8px 12px}::ng-deep .custom-panel .results-container{margin:4px}::ng-deep .custom-panel .results-container .option-none{height:var(--row-height);display:flex;align-items:center;justify-content:center;text-align:center}::ng-deep .custom-panel .results-container .option-none ::ng-deep mat-pseudo-checkbox{display:none}::ng-deep .custom-panel .results-container .option-none span{font-size:12px;font-weight:400;color:#000}::ng-deep .custom-panel .results-container .none-opacity{opacity:1!important}::ng-deep .custom-panel .indented-row{padding-left:16px!important}::ng-deep .custom-panel .mat-mdc-option{padding:8px 0 8px 8px;height:var(--row-height)!important;min-height:var(--row-height)!important;max-height:var(--row-height)!important}::ng-deep .custom-panel .mat-expansion-panel{box-shadow:unset!important}::ng-deep .custom-panel .mat-expansion-panel-header{border-top:.5px solid #C3C1C0!important;border-radius:unset!important;height:var(--row-height)!important;padding:10px 8px!important}::ng-deep .custom-panel .mat-expansion-panel-header .mat-expansion-indicator:after{padding:2px;border-color:#645e5b;background:#645e5b;clip-path:polygon(100% 0%,0% 100%,100% 100%)}::ng-deep .custom-panel .mat-expansion-panel-header *{text-transform:uppercase;font-size:12px;font-weight:500;letter-spacing:.01em;color:#2d2b29;line-height:18.6px}::ng-deep .custom-panel .mat-expansion-panel-body{padding:0!important}.hidden-trigger{position:absolute;left:var(--panel-h-offset);top:var(--panel-v-offset);visibility:hidden!important}.hidden-trigger ::ng-deep *{opacity:0!important;visibility:hidden!important;width:0!important;min-width:0!important}:host ::ng-deep .mat-mdc-select-arrow{visibility:hidden;position:relative}:host ::ng-deep .mat-mdc-select-arrow:after{visibility:visible;content:\"\";width:6px;display:inline-block;height:6px;transform:rotate(-135deg) translatey(3px);border-top:2px solid #645E5B;border-left:2px solid #645E5B;position:absolute}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1$2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i2$1.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { kind: "directive", type: i2$1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i1$1.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i5.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i5.MatLabel, selector: "mat-label" }, { kind: "directive", type: i5.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "component", type: i5.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth", "canSelectNullableOptions"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "directive", type: i5.MatSelectTrigger, selector: "mat-select-trigger" }, { kind: "component", type: i5.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i6.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: MatPseudoCheckboxModule }, { kind: "component", type: i7.MatPseudoCheckbox, selector: "mat-pseudo-checkbox", inputs: ["state", "disabled", "appearance"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "ngmodule", type: MatChipsModule }, { kind: "ngmodule", type: MatExpansionModule }, { kind: "component", type: i8.MatExpansionPanel, selector: "mat-expansion-panel", inputs: ["hideToggle", "togglePosition"], outputs: ["afterExpand", "afterCollapse"], exportAs: ["matExpansionPanel"] }, { kind: "component", type: i8.MatExpansionPanelHeader, selector: "mat-expansion-panel-header", inputs: ["expandedHeight", "collapsedHeight", "tabIndex"] }, { kind: "directive", type: i8.MatExpansionPanelTitle, selector: "mat-panel-title" }, { kind: "directive", type: StickyPanelHeaderDirective, selector: "[stickyPanelHeader]" }, { kind: "component", type: SpanEllipseComponent, selector: "atom-span-ellipse", inputs: ["maxWidthCssExpr", "tooltipPosition", "tooltipShowDelay", "tooltipHideDelay", "tooltipClass"] }, { kind: "pipe", type: i1$2.AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: SelectSearchV2Component, decorators: [{
            type: Component,
            args: [{ selector: 'atom-select-search-v2', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        CommonModule,
                        ReactiveFormsModule,
                        AsyncPipe,
                        MatTooltipModule,
                        MatIconModule,
                        MatSelectModule,
                        MatInputModule,
                        MatButtonModule,
                        MatPseudoCheckboxModule,
                        MatMenuModule,
                        MatChipsModule,
                        MatExpansionModule,
                        StickyPanelHeaderDirective,
                        SpanEllipseComponent,
                    ], template: "@if (customTrigger) {\r\n  <div>\r\n    <ng-container *ngTemplateOutlet=\"customTrigger\"/>\r\n  </div>\r\n}\r\n\r\n<mat-form-field\r\n  #formField\r\n  class=\"extended-from\"\r\n  [class.hidden-trigger]=\"customTrigger\"\r\n  appearance=\"outline\"\r\n  subscriptSizing=\"dynamic\"\r\n  [floatLabel]=\"floatLabel\"\r\n>\r\n  @if (showLabel) {\r\n    <mat-label>{{ label }}</mat-label>\r\n  }\r\n  <mat-select\r\n    #matSelect\r\n    [formControl]=\"optionCtrl\"\r\n    [id]=\"_uniqueId\"\r\n    [required]=\"required\"\r\n    [placeholder]=\"placeholder ?? ''\"\r\n    matTooltipPosition=\"before\"\r\n    [matTooltip]=\"labelOf(optionCtrl?.value)\"\r\n    [matTooltipDisabled]=\"(labelOf(optionCtrl?.value)?.length ?? 0) <= tooltipMaxLength\"\r\n    (closed)=\"onPanelClose()\"\r\n    (opened)=\"onPanelOpen()\"\r\n    [panelClass]=\"['custom-panel','flowbuilder-global-panel', 'custom-panel-configs-' + _uniqueId, customPanelCssCls]\"\r\n    hideSingleSelectionIndicator\r\n    [multiple]=\"multiple\"\r\n  >\r\n\r\n    <mat-select-trigger>\r\n      <span>{{ triggerValue }}</span>\r\n    </mat-select-trigger>\r\n\r\n    @if (enableSearch) {\r\n      <div class=\"search-container\">\r\n        <mat-icon>search</mat-icon>\r\n\r\n        <input\r\n          #searchInput\r\n          [maxlength]=\"searchCharsMaxLength\"\r\n          (keydown)=\"$event.stopPropagation()\"\r\n          (keyup)=\"$event.stopPropagation()\"\r\n          [formControl]=\"searchFilterCtrl\"\r\n          [placeholder]=\"searchPlaceholderText\"\r\n          class=\"search-input w-100\"\r\n        />\r\n\r\n        <button\r\n          mat-icon-button\r\n          [matTooltip]=\"clearSearchText\"\r\n          [matTooltipDisabled]=\"!searchFilterCtrl.value?.length\"\r\n          [hidden]=\"!searchFilterCtrl.value?.length\"\r\n          [disabled]=\"!searchFilterCtrl.value?.length\"\r\n          (click)=\"$event.stopPropagation(); clearSearch()\"\r\n        >\r\n          <mat-icon>close</mat-icon>\r\n        </button>\r\n      </div>\r\n    }\r\n\r\n    <div class=\"results-container\">\r\n\r\n      <!--Select All Indicator-->\r\n      @if (multiple && enableSelectAll && (!searchFilterCtrl.value || searchFilterCtrl.value.length === 0)) {\r\n        <div\r\n\r\n          (click)=\"toggleSelectAll(checkbox.state)\"\r\n          class=\"mat-mdc-option mdc-list-item mat-mdc-tooltip-trigger mat-mdc-option-multiple section-element\"\r\n        >\r\n          <mat-pseudo-checkbox\r\n            #checkbox\r\n            [state]=\"_selectedAllCheckboxState\"\r\n            matTooltipPosition=\"right\"\r\n            [matTooltip]=\"selectAllTooltipText\"\r\n          />\r\n          <span class=\"mdc-list-item__primary-text\">\r\n                {{ selectAllMessage }}\r\n                </span>\r\n        </div>\r\n      }\r\n\r\n      <!--Case no Items-->\r\n      @if (!(!!options?.length && (filteredGroups$ | async)?.[0]?.length) && !(searchFilterCtrl?.value?.length)) {\r\n        <mat-option disabled\r\n                    class=\"option-none none-opacity\">\r\n          <span>{{ noItemsText }}</span>\r\n        </mat-option>\r\n      }\r\n\r\n      <!-- Case no results-->\r\n      @if (enableSearch && !hideEmptySearchResult && !!searchFilterCtrl.value && (!!options?.length && (filteredGroups$ | async)?.length === 0)) {\r\n        <mat-option disabled\r\n                    class=\"option-none none-opacity\">\r\n          <span>{{ searchNoResultsText }}</span>\r\n        </mat-option>\r\n      }\r\n\r\n      <div class=\"items-container\">\r\n        @for (group of (filteredGroups$ | async); track group) {\r\n\r\n\r\n          @if (groupByKey) {\r\n\r\n            <mat-expansion-panel stickyPanelHeader [class.indented-row]=\"(multiple && enableSelectAll)\"\r\n                                 [expanded]=\"true\">\r\n              <mat-expansion-panel-header>\r\n                <mat-panel-title>\r\n                  <atom-span-ellipse\r\n                    [tooltipClass]=\"'atom-select-v2-tooltip'\">\r\n                    {{ getGroupRepresentation(group) }}\r\n                  </atom-span-ellipse>\r\n                </mat-panel-title>\r\n              </mat-expansion-panel-header>\r\n              <ng-container *ngTemplateOutlet=\"groupTemplate; context: { $implicit: group }\"/>\r\n            </mat-expansion-panel>\r\n\r\n          } @else {\r\n\r\n            <ng-container *ngTemplateOutlet=\"groupTemplate; context: { $implicit: group }\"/>\r\n\r\n          }\r\n\r\n\r\n        }\r\n\r\n        <!-- Filtered out options for mat select to maintain the selection-->\r\n        @if (multiple) {\r\n\r\n          @for (option of options; track trackByItems($index, option)) {\r\n\r\n            @if (!((filteredGroups$ | async)?.flat()?.includes(option))) {\r\n              <mat-option\r\n                [value]=\"option\"\r\n\r\n                [style.display]=\"'none'\"\r\n              />\r\n            }\r\n\r\n          }\r\n\r\n        }\r\n\r\n        <ng-template #groupTemplate let-group>\r\n          @for (option of group; track trackByItems($index, option)) {\r\n\r\n            <mat-option\r\n              [class.indented-row]=\"!!groupByKey !== (multiple && enableSelectAll)\"\r\n              class=\"option section-element\"\r\n              [value]=\"option\"\r\n              [disabled]=\"(option[disabledKey] && (!!(option[disabledKey]) === disabledStateValue))\"\r\n              [matTooltip]=\"(option[disabledKey] && (!!(option[disabledKey]) === disabledStateValue)) || enabledTooltip ? disabledTooltipText : ''\"\r\n              [matTooltipPosition]=\"'right'\"\r\n              (mouseenter)=\"hoverOption.emit(option)\"\r\n              (mouseleave)=\"blurOption.emit(null)\"\r\n            >\r\n              <ng-container>\r\n                <div class=\"section-element\">\r\n\r\n                  @if (leftDetailSpan) {\r\n                    <div class=\"section-element-left\">\r\n                      <ng-container\r\n                        *ngTemplateOutlet=\"leftDetailSpan; context: { $implicit: option, selectSearchV2:this }\"/>\r\n                    </div>\r\n                  }\r\n                  <atom-span-ellipse\r\n                    [class.atom-select-v2-item-in-group]=\"groupByKey\"\r\n                    [tooltipClass]=\"'atom-select-v2-tooltip'\">{{ labelOf(option) }}\r\n                  </atom-span-ellipse>\r\n\r\n                  @if (rightDetailSpan) {\r\n                    <div class=\"section-element-right d-flex\">\r\n                      <ng-container\r\n                        *ngTemplateOutlet=\"rightDetailSpan; context: { $implicit: option, selectSearchV2:this }\"/>\r\n                    </div>\r\n                  }\r\n                </div>\r\n              </ng-container>\r\n            </mat-option>\r\n\r\n          }\r\n        </ng-template>\r\n        <ng-container *ngTemplateOutlet=\"extraAction; context: { $implicit: this }\"/>\r\n      </div>\r\n\r\n    </div>\r\n  </mat-select>\r\n  @if (showError) {\r\n    <mat-error>\r\n      {{ isRequiredText }}\r\n    </mat-error>\r\n  }\r\n</mat-form-field>\r\n", styles: [":host ::ng-deep{width:100%;min-width:0;display:inline-block;position:relative}:host ::ng-deep .mat-mdc-form-field-subscript-wrapper{position:absolute;bottom:-18px}:host ::ng-deep .mat-mdc-text-field-wrapper.mdc-text-field--outlined .mat-mdc-form-field-infix{padding-top:0;padding-bottom:0;min-height:36px}.extended-from{width:100%!important;position:relative}::ng-deep .custom-panel.mdc-menu-surface.mat-mdc-select-panel{max-height:calc((var(--row-number) + 2) * var(--row-height) + 2px)!important;min-width:var(--panel-min-width);overflow:hidden}::ng-deep .custom-panel.mdc-menu-surface.mat-mdc-select-panel .search-container{height:var(--row-height);display:flex;align-items:center;gap:8px;border-radius:4px;padding:0 8px}::ng-deep .custom-panel.mdc-menu-surface.mat-mdc-select-panel .search-container button{width:16px;height:16px;display:flex}::ng-deep .custom-panel.mdc-menu-surface.mat-mdc-select-panel .search-container mat-icon{width:16px;height:16px;font-size:16px;color:#645e5b}::ng-deep .custom-panel.mdc-menu-surface.mat-mdc-select-panel .search-input{height:auto;padding:0;border:none;font-size:12px}::ng-deep .custom-panel.mdc-menu-surface.mat-mdc-select-panel .search-input:focus{outline:none;border:none}::ng-deep .custom-panel.mdc-menu-surface.mat-mdc-select-panel .items-container{overflow:auto;max-height:calc(var(--row-number) * var(--row-height))}::ng-deep .custom-panel.mdc-menu-surface.mat-mdc-select-panel .items-container .option{height:var(--row-height);font-size:12px}::ng-deep .custom-panel.mdc-menu-surface.mat-mdc-select-panel .mat-mdc-icon-button .mat-mdc-button-persistent-ripple,::ng-deep .custom-panel.mdc-menu-surface.mat-mdc-select-panel .mat-mdc-icon-button .mat-mdc-button-ripple{display:none}::ng-deep .atom-select-v2-item-in-group span{font-weight:400}.section-element{display:flex;flex-direction:row;align-items:center;justify-content:space-between;font-size:12px;line-height:15px;gap:4px}.section-element .section-element-right{align-items:center;justify-content:end;font-size:12px;width:fit-content;text-align:right}.section-element .section-element-left{align-items:center;justify-content:end;font-size:12px;width:fit-content;text-align:left}::ng-deep .atom-select-v2-tooltip *{font-size:12px!important;line-height:15px!important;height:var(--row-height)!important;max-width:none!important;display:flex;align-items:center;padding:8px 12px}::ng-deep .custom-panel .results-container{margin:4px}::ng-deep .custom-panel .results-container .option-none{height:var(--row-height);display:flex;align-items:center;justify-content:center;text-align:center}::ng-deep .custom-panel .results-container .option-none ::ng-deep mat-pseudo-checkbox{display:none}::ng-deep .custom-panel .results-container .option-none span{font-size:12px;font-weight:400;color:#000}::ng-deep .custom-panel .results-container .none-opacity{opacity:1!important}::ng-deep .custom-panel .indented-row{padding-left:16px!important}::ng-deep .custom-panel .mat-mdc-option{padding:8px 0 8px 8px;height:var(--row-height)!important;min-height:var(--row-height)!important;max-height:var(--row-height)!important}::ng-deep .custom-panel .mat-expansion-panel{box-shadow:unset!important}::ng-deep .custom-panel .mat-expansion-panel-header{border-top:.5px solid #C3C1C0!important;border-radius:unset!important;height:var(--row-height)!important;padding:10px 8px!important}::ng-deep .custom-panel .mat-expansion-panel-header .mat-expansion-indicator:after{padding:2px;border-color:#645e5b;background:#645e5b;clip-path:polygon(100% 0%,0% 100%,100% 100%)}::ng-deep .custom-panel .mat-expansion-panel-header *{text-transform:uppercase;font-size:12px;font-weight:500;letter-spacing:.01em;color:#2d2b29;line-height:18.6px}::ng-deep .custom-panel .mat-expansion-panel-body{padding:0!important}.hidden-trigger{position:absolute;left:var(--panel-h-offset);top:var(--panel-v-offset);visibility:hidden!important}.hidden-trigger ::ng-deep *{opacity:0!important;visibility:hidden!important;width:0!important;min-width:0!important}:host ::ng-deep .mat-mdc-select-arrow{visibility:hidden;position:relative}:host ::ng-deep .mat-mdc-select-arrow:after{visibility:visible;content:\"\";width:6px;display:inline-block;height:6px;transform:rotate(-135deg) translatey(3px);border-top:2px solid #645E5B;border-left:2px solid #645E5B;position:absolute}\n"] }]
        }], propDecorators: { formField: [{
                type: ViewChild,
                args: ['formField']
            }], clearSearchText: [{
                type: Input
            }], selectAllTooltipText: [{
                type: Input
            }], selectAllMessage: [{
                type: Input
            }], allSelectedText: [{
                type: Input
            }], searchNoResultsText: [{
                type: Input
            }], noItemsText: [{
                type: Input
            }], searchPlaceholderText: [{
                type: Input
            }], disabledTooltipText: [{
                type: Input
            }], isRequiredText: [{
                type: Input
            }], label: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], required: [{
                type: Input
            }], disabled: [{
                type: Input
            }], hideEmptySearchResult: [{
                type: Input
            }], showLabel: [{
                type: Input
            }], tooltipMaxLength: [{
                type: Input
            }], enableSearch: [{
                type: Input
            }], focusSearchOnOpen: [{
                type: Input
            }], searchCharsMaxLength: [{
                type: Input
            }], floatLabel: [{
                type: Input
            }], labelOrdering: [{
                type: Input
            }], considerMissingOptionsInList: [{
                type: Input
            }], valueKey: [{
                type: Input
            }], labelKey: [{
                type: Input
            }], valueEqualFn: [{
                type: Input
            }], valueOf: [{
                type: Input,
                args: ['valueOfFn']
            }], labelOf: [{
                type: Input,
                args: ['labelOfFn']
            }], disabledKey: [{
                type: Input
            }], disabledStateValue: [{
                type: Input
            }], enabledTooltip: [{
                type: Input
            }], groupByKey: [{
                type: Input
            }], groupsConfig: [{
                type: Input
            }], options: [{
                type: Input
            }], excludedOptions: [{
                type: Input
            }], showError: [{
                type: Input
            }], customPanelCssCls: [{
                type: Input
            }], selectedOption: [{
                type: Input
            }], multiple: [{
                type: Input
            }], enableSelectAll: [{
                type: Input
            }], leftDetailSpan: [{
                type: Input
            }], rightDetailSpan: [{
                type: Input
            }], customTrigger: [{
                type: Input
            }], extraAction: [{
                type: Input
            }], rowNumber: [{
                type: Input
            }, {
                type: HostBinding,
                args: ['style.--row-number']
            }], rowHeightCssExpr: [{
                type: Input
            }, {
                type: HostBinding,
                args: ['style.--row-height']
            }], panelVerticalOffsetCssExpr: [{
                type: Input
            }, {
                type: HostBinding,
                args: ['style.--panel-v-offset']
            }], panelMinWidth: [{
                type: Input
            }, {
                type: HostBinding,
                args: ['style.--panel-min-width']
            }], panelHorizontalOffsetCssExpr: [{
                type: Input
            }, {
                type: HostBinding,
                args: ['style.--panel-h-offset']
            }], alreadyTouched: [{
                type: Input
            }], selectedOptionChange: [{
                type: Output
            }], hoverOption: [{
                type: Output
            }], blurOption: [{
                type: Output
            }], panelOpen: [{
                type: Output
            }], panelClose: [{
                type: Output
            }], searchInput: [{
                type: ViewChild,
                args: ['searchInput']
            }], matSelect: [{
                type: ViewChild,
                args: ['matSelect']
            }] } });

class EmojiPickerComponent {
    constructor() {
        this.darkMode = false;
        this.loseFocusOnSelect = false;
        this.emojiSelected = new EventEmitter();
        this.lostFocus = new EventEmitter();
        this.elementRef = inject(ElementRef);
        this._uniqueId = `atom-emoji-picker-${Date.now()}`;
        this.handleClick = (event) => {
            const target = event.target;
            if (!this.elementRef.nativeElement.contains(target))
                this.lostFocus.emit();
        };
        document.addEventListener('mousedown', this.handleClick);
    }
    ngOnDestroy() {
        document.removeEventListener('mousedown', this.handleClick);
    }
    addEmoji(event) {
        this.emojiSelected.emit(event.emoji.native);
        if (this.loseFocusOnSelect) {
            this.lostFocus.emit();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EmojiPickerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.16", type: EmojiPickerComponent, isStandalone: true, selector: "atom-emoji-picker", inputs: { darkMode: "darkMode", loseFocusOnSelect: "loseFocusOnSelect" }, outputs: { emojiSelected: "emojiSelected", lostFocus: "lostFocus" }, ngImport: i0, template: "<emoji-mart\r\n  class=\"emoji-mart\"\r\n  [id]=\"_uniqueId\"\r\n  [isNative]=\"true\"\r\n  [showPreview]=\"false\"\r\n  [autoFocus]=\"true\"\r\n  [darkMode]=\"darkMode\"\r\n  [color]=\"'#ff6600'\"\r\n  (emojiClick)=\"addEmoji($event)\"\r\n/>\r\n", styles: [".emoji-mart{position:relative}\n"], dependencies: [{ kind: "component", type: PickerComponent, selector: "emoji-mart", inputs: ["perLine", "totalFrequentLines", "i18n", "style", "title", "emoji", "darkMode", "color", "hideObsolete", "categories", "activeCategories", "set", "skin", "isNative", "emojiSize", "sheetSize", "emojisToShowFilter", "showPreview", "emojiTooltip", "autoFocus", "custom", "hideRecent", "imageUrlFn", "include", "exclude", "notFoundEmoji", "categoriesIcons", "searchIcons", "useButton", "enableFrequentEmojiSort", "enableSearch", "showSingleCategory", "virtualize", "virtualizeOffset", "recent", "backgroundImageFn"], outputs: ["emojiClick", "emojiSelect", "skinChange"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EmojiPickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'atom-emoji-picker', changeDetection: ChangeDetectionStrategy.OnPush, imports: [PickerComponent], template: "<emoji-mart\r\n  class=\"emoji-mart\"\r\n  [id]=\"_uniqueId\"\r\n  [isNative]=\"true\"\r\n  [showPreview]=\"false\"\r\n  [autoFocus]=\"true\"\r\n  [darkMode]=\"darkMode\"\r\n  [color]=\"'#ff6600'\"\r\n  (emojiClick)=\"addEmoji($event)\"\r\n/>\r\n", styles: [".emoji-mart{position:relative}\n"] }]
        }], ctorParameters: () => [], propDecorators: { darkMode: [{
                type: Input
            }], loseFocusOnSelect: [{
                type: Input
            }], emojiSelected: [{
                type: Output
            }], lostFocus: [{
                type: Output
            }] } });

class EtaErrorDisplayComponent {
    constructor() {
        this.contentTpl = input(null, ...(ngDevMode ? [{ debugName: "contentTpl" }] : []));
        this.largeMode = input(false, ...(ngDevMode ? [{ debugName: "largeMode" }] : []));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EtaErrorDisplayComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.16", type: EtaErrorDisplayComponent, isStandalone: true, selector: "atom-eta-error-display", inputs: { contentTpl: { classPropertyName: "contentTpl", publicName: "contentTpl", isSignal: true, isRequired: false, transformFunction: null }, largeMode: { classPropertyName: "largeMode", publicName: "largeMode", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<div class=\"helper-container\">\r\n  @if (largeMode()) {\r\n    <button class=\"helper-button\"\r\n            #largeMenuTrigger=\"matMenuTrigger\"\r\n            (mouseleave)=\"largeMenuTrigger.closeMenu()\"\r\n            mat-flat-button [matMenuTriggerFor]=\"menu\"\r\n            aria-label=\"Example icon-button with a menu\">\r\n      <mat-icon>error_outline</mat-icon>\r\n      Error(s)\r\n    </button>\r\n  } @else {\r\n    <button class=\"helper-button\"\r\n            #shortMenuTrigger=\"matMenuTrigger\"\r\n            (mouseleave)=\"shortMenuTrigger.closeMenu()\"\r\n            mat-icon-button [matMenuTriggerFor]=\"menu\"\r\n            aria-label=\"Example icon-button with a menu\">\r\n      <mat-icon>error</mat-icon>\r\n    </button>\r\n  }\r\n  <mat-menu [hasBackdrop]=\"false\" class=\"helper-mat-menu\" yPosition=\"above\" #menu=\"matMenu\">\r\n    @if (contentTpl()) {\r\n      <ng-container *ngTemplateOutlet=\"contentTpl()\"></ng-container>\r\n    }\r\n  </mat-menu>\r\n\r\n</div>\r\n", styles: [".helper-container{position:relative}::ng-deep .helper-button .mat-mdc-button-persistent-ripple{border-radius:8px!important}:host{height:20px!important}:host button{display:flex;align-items:center;justify-content:center;height:20px!important;padding:2px!important;font-size:12px!important;width:100%;color:var(--mat-form-field-error-text-color)!important}:host button mat-icon{height:20px!important;width:22px!important;line-height:20px!important;font-size:22px!important}::ng-deep .helper-mat-menu.mat-mdc-menu-panel{padding:8px;margin-bottom:12px}::ng-deep .helper-mat-menu .mat-mdc-menu-content{max-width:160px;line-height:normal;font-size:10px;padding:0;word-break:break-word;overflow-wrap:break-word;white-space:normal}::ng-deep .helper-mat-menu .mat-mdc-menu-content .mat-mdc-form-field-error{color:#e42525!important}\n"], dependencies: [{ kind: "component", type: MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "directive", type: MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EtaErrorDisplayComponent, decorators: [{
            type: Component,
            args: [{ selector: "atom-eta-error-display", imports: [MatIconButton, MatMenuTrigger, MatIcon, MatMenu, NgTemplateOutlet, MatButton, NgClass], template: "<div class=\"helper-container\">\r\n  @if (largeMode()) {\r\n    <button class=\"helper-button\"\r\n            #largeMenuTrigger=\"matMenuTrigger\"\r\n            (mouseleave)=\"largeMenuTrigger.closeMenu()\"\r\n            mat-flat-button [matMenuTriggerFor]=\"menu\"\r\n            aria-label=\"Example icon-button with a menu\">\r\n      <mat-icon>error_outline</mat-icon>\r\n      Error(s)\r\n    </button>\r\n  } @else {\r\n    <button class=\"helper-button\"\r\n            #shortMenuTrigger=\"matMenuTrigger\"\r\n            (mouseleave)=\"shortMenuTrigger.closeMenu()\"\r\n            mat-icon-button [matMenuTriggerFor]=\"menu\"\r\n            aria-label=\"Example icon-button with a menu\">\r\n      <mat-icon>error</mat-icon>\r\n    </button>\r\n  }\r\n  <mat-menu [hasBackdrop]=\"false\" class=\"helper-mat-menu\" yPosition=\"above\" #menu=\"matMenu\">\r\n    @if (contentTpl()) {\r\n      <ng-container *ngTemplateOutlet=\"contentTpl()\"></ng-container>\r\n    }\r\n  </mat-menu>\r\n\r\n</div>\r\n", styles: [".helper-container{position:relative}::ng-deep .helper-button .mat-mdc-button-persistent-ripple{border-radius:8px!important}:host{height:20px!important}:host button{display:flex;align-items:center;justify-content:center;height:20px!important;padding:2px!important;font-size:12px!important;width:100%;color:var(--mat-form-field-error-text-color)!important}:host button mat-icon{height:20px!important;width:22px!important;line-height:20px!important;font-size:22px!important}::ng-deep .helper-mat-menu.mat-mdc-menu-panel{padding:8px;margin-bottom:12px}::ng-deep .helper-mat-menu .mat-mdc-menu-content{max-width:160px;line-height:normal;font-size:10px;padding:0;word-break:break-word;overflow-wrap:break-word;white-space:normal}::ng-deep .helper-mat-menu .mat-mdc-menu-content .mat-mdc-form-field-error{color:#e42525!important}\n"] }]
        }], propDecorators: { contentTpl: [{ type: i0.Input, args: [{ isSignal: true, alias: "contentTpl", required: false }] }], largeMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "largeMode", required: false }] }] } });

class EtaInfoComponent {
    constructor() {
        this.message = input(...(ngDevMode ? [undefined, { debugName: "message" }] : []));
        this.position = input("top-right", ...(ngDevMode ? [{ debugName: "position" }] : []));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EtaInfoComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "20.3.16", type: EtaInfoComponent, isStandalone: true, selector: "atom-eta-info", inputs: { message: { classPropertyName: "message", publicName: "message", isSignal: true, isRequired: false, transformFunction: null }, position: { classPropertyName: "position", publicName: "position", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<div class=\"eta-helper-container\" [ngClass]=\"position() === 'top-left' ? 'left-position' : 'right-position'\">\r\n  <mat-icon [matTooltip]=\"message()\"\r\n            matTooltipPosition=\"above\"\r\n            aria-hidden=\"false\"\r\n            aria-label=\"Helper\">\r\n    error_outline\r\n  </mat-icon>\r\n</div>\r\n", styles: [".eta-helper-container{position:absolute}mat-icon{color:#645e5b;height:21px!important;width:20px!important;font-size:21px!important}.right-position{top:8px;right:6px}.left-position{top:8px;left:6px}\n"], dependencies: [{ kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EtaInfoComponent, decorators: [{
            type: Component,
            args: [{ selector: "atom-eta-info", imports: [MatIcon, MatTooltip, NgClass], template: "<div class=\"eta-helper-container\" [ngClass]=\"position() === 'top-left' ? 'left-position' : 'right-position'\">\r\n  <mat-icon [matTooltip]=\"message()\"\r\n            matTooltipPosition=\"above\"\r\n            aria-hidden=\"false\"\r\n            aria-label=\"Helper\">\r\n    error_outline\r\n  </mat-icon>\r\n</div>\r\n", styles: [".eta-helper-container{position:absolute}mat-icon{color:#645e5b;height:21px!important;width:20px!important;font-size:21px!important}.right-position{top:8px;right:6px}.left-position{top:8px;left:6px}\n"] }]
        }], propDecorators: { message: [{ type: i0.Input, args: [{ isSignal: true, alias: "message", required: false }] }], position: [{ type: i0.Input, args: [{ isSignal: true, alias: "position", required: false }] }] } });

class ViewContainerExporterDirective {
    constructor() {
        this.container = inject(ViewContainerRef);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: ViewContainerExporterDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.16", type: ViewContainerExporterDirective, isStandalone: true, selector: "[viewContainer]", exportAs: ["viewContainer"], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: ViewContainerExporterDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[viewContainer]',
                    exportAs: 'viewContainer',
                    standalone: true,
                }]
        }] });

class EtaEditorComponent {
    constructor() {
        this.etbRef = inject(ViewContainerRef);
        this.cdr = inject(ChangeDetectorRef);
        this.plugins = [];
        this.singleLineMode = false;
        this.spellCheck = true;
        this.required = false;
        this.autofilled = false;
        this.toolbarActionType = input('button', ...(ngDevMode ? [{ debugName: "toolbarActionType" }] : []));
        this.toolbarEnabled = input(true, ...(ngDevMode ? [{ debugName: "toolbarEnabled" }] : []));
        this.helperMessage = input(...(ngDevMode ? [undefined, { debugName: "helperMessage" }] : []));
        this.helperPosition = input('top-right', ...(ngDevMode ? [{ debugName: "helperPosition" }] : []));
        this.errorContentTpl = input(null, ...(ngDevMode ? [{ debugName: "errorContentTpl" }] : []));
        this.errorLargeMode = input(false, ...(ngDevMode ? [{ debugName: "errorLargeMode" }] : []));
        this.toolbarActionTpl = input(null, ...(ngDevMode ? [{ debugName: "toolbarActionTpl" }] : []));
        this.stateChanges = new Subject();
        this.id = `etb-${Date.now()}`;
        this.focused = false;
        this.errorState = false;
        this.controlType = "extended-text-area";
        this.changes$ = new Subject();
        this.constructedCss = new CSSStyleSheet();
        // Intended to be populated by plugins initialization function
        this.toolBarItems = [];
        // Intended to be populated by plugins initialization function
        this.customHTMLElSaver = new Map();
        this.toolbarItemsNum = 1;
        this.afterViewInitRef$ = new ReplaySubject(1);
        this.onDestroyRef$ = inject(DestroyRef);
        this.WRAPPER_TAG_NAME = "ET-PARAM-WRAPPER";
        this.insertedComponents = new Map();
        this._currentSelectionRange = null;
        this.textEditionMode = "plaintext-only";
        this._disabled = false;
        this.selectionChange$ = new EventEmitter();
        this.onChangeFn = (value) => {
        };
        this.onTouchedFn = () => {
        };
        this.onGlobalSelectionChange = () => {
            const allWrappers = Array.from(this.bufferContainer.element.nativeElement.querySelectorAll("et-param-wrapper"));
            for (const wrapper of allWrappers) {
                wrapper.removeAttribute("et-selected");
            }
            const selection = window.getSelection();
            if (selection && (selection.rangeCount <= 0 ||
                !this.bufferContainer.element.nativeElement.contains(selection.getRangeAt(0).commonAncestorContainer))) {
                return;
            }
            const range = selection.getRangeAt(0);
            this._currentSelectionRange = range;
            for (const wrapper of allWrappers) {
                if (range.intersectsNode(wrapper)) {
                    wrapper.setAttribute("et-selected", "");
                }
            }
            this.selectionChange$.next();
        };
    }
    get injector() {
        return this.etbRef.injector;
    }
    get disabled() {
        return this._disabled;
    }
    set disabled(value) {
        this._disabled = value;
        if (this.setDisabledState)
            this.setDisabledState(value);
    }
    get empty() {
        return !this.value;
    }
    get shouldLabelFloat() {
        return Boolean(this.placeholder) || !this.empty || this.focused;
    }
    get _lineBreakNode() {
        const textNode = document.createTextNode("\n");
        return textNode;
    }
    ngOnChanges(changes) {
        if (changes["plugins"] && this.toolbarEnabled()) {
            for (const plugin of this.plugins) {
                plugin.initialize(this);
            }
            this.toolbarItemsNum = this.toolBarItems.length;
        }
    }
    setDescribedByIds(ids) {
        if (ids.length) {
            const newId = `-eid-${ids.join("-eid-")}`;
            const id = this.id.split("-eid-");
            this.id = id[0] + newId;
        }
    }
    onContainerClick(event) {
        const bufferContainer = this.bufferContainer.element.nativeElement;
        // Focus the buffer if is not already focused
        if (!bufferContainer.contains(document.activeElement)) {
            this.bufferContainer.element.nativeElement.focus({ preventScroll: true });
        }
        event?.stopPropagation();
    }
    // ControlValueAccessor interface implementation
    writeValue(obj) {
        this.afterViewInitRef$.pipe(take(1)).subscribe(() => {
            this.value = obj;
            this.clearBuffer();
            this.insertSerializedContent(this.value);
        });
    }
    setDisabledState(isDisabled) {
        this._disabled = isDisabled;
        for (const [, componentRef] of this.insertedComponents.values()) {
            componentRef.instance.setDisabledState(isDisabled);
        }
        this.stateChanges.next();
    }
    registerOnChange(fn) {
        this.onChangeFn = fn;
    }
    registerOnTouched(fn) {
        this.onTouchedFn = fn;
    }
    ngOnDestroy() {
        this._bufferMutationObserver.disconnect();
        document.removeEventListener("selectionchange", this.onGlobalSelectionChange);
        document.adoptedStyleSheets = document.adoptedStyleSheets.filter((s) => s !== this.constructedCss);
    }
    ngOnInit() {
        this.ngControl = this.injector.get(NgControl, null);
        this.componentFactoryFn = this.etbRef.createComponent.bind(this.etbRef);
        document.adoptedStyleSheets = [...document.adoptedStyleSheets, this.constructedCss];
    }
    ngAfterViewInit() {
        this.btnsRef.forEach((btnRef, index) => {
            const command = this.toolBarItems.find((item) => item.id === btnRef.element.nativeElement.id);
            if (command) {
                command.btnViewRef = btnRef;
            }
        });
        const bufferNativeElem = this.bufferContainer.element.nativeElement;
        this._setupBufferObserver();
        document.addEventListener("selectionchange", this.onGlobalSelectionChange);
        const copyAsSerialized = (event) => {
            const selection = window.getSelection();
            if (selection) {
                // serialize the content of the selection
                const cloned = selection.getRangeAt(0).cloneContents();
                const nodes = Array.from(cloned.childNodes);
                const serializedContent = this.serializeNodesContent(nodes);
                event.clipboardData?.setData("text/plain", serializedContent);
            }
        };
        bufferNativeElem.addEventListener("copy", (event) => {
            copyAsSerialized(event);
            event.preventDefault();
        });
        bufferNativeElem.addEventListener("cut", (event) => {
            copyAsSerialized(event);
            window.getSelection()?.getRangeAt(0).deleteContents();
            event.preventDefault();
        });
        bufferNativeElem.addEventListener("paste", (event) => {
            const text = event.clipboardData?.getData("text/plain");
            this.insertSerializedContent(text);
            event.preventDefault();
        });
        bufferNativeElem.addEventListener("focus", () => {
            this.focused = true;
            // restore the selection with the saved range
            const selection = window.getSelection();
            if (selection && this._currentSelectionRange) {
                selection.removeAllRanges();
                selection.addRange(this._currentSelectionRange);
            }
            this.onTouchedFn();
            this.stateChanges.next();
        });
        bufferNativeElem.addEventListener("blur", (ev) => {
            this.focused = false;
            this.onTouchedFn();
            if (this.ngControl?.pristine)
                this.errorState = this.ngControl?.errors != null;
            this.stateChanges.next();
        });
        bufferNativeElem.addEventListener("drop", (event) => {
            event.preventDefault();
            const data = event.dataTransfer?.getData("text/plain");
            this.insertSerializedContent(data);
        });
        this.changes$.pipe(debounceTime(100), takeUntilDestroyed(this.onDestroyRef$)).subscribe(() => {
            const elements = Array.from(bufferNativeElem.childNodes);
            this.value = this.serializeNodesContent(elements);
            this.onChangeFn(this.value);
            this.errorState = this.ngControl?.errors != null;
            this.stateChanges.next();
        });
        this.stateChanges.pipe(takeUntilDestroyed(this.onDestroyRef$)).subscribe(() => {
            this.cdr.detectChanges();
        });
        this.afterViewInitRef$.next();
    }
    onKeyDown(event) {
        // Managing the enter key manually
        if (event.key == "Enter") {
            if (!this.singleLineMode) {
                this.insertNodeInSelection(this._lineBreakNode);
            }
            event.preventDefault();
            return;
        }
        // TODO: implement undo redo
        if (event.ctrlKey && event.key === "z") {
            event.preventDefault();
            return;
        }
        if (event.ctrlKey && event.key === "y") {
            event.preventDefault();
            return;
        }
    }
    serializeNodesContent(elements) {
        let finalString = "";
        for (const element of elements) {
            if (element instanceof Text) {
                finalString += element.data;
                continue;
            }
            if (element instanceof HTMLElement &&
                element.tagName === this.WRAPPER_TAG_NAME &&
                element.id) {
                const componentData = this.insertedComponents.get(element.id);
                if (componentData) {
                    const [, componentRef] = componentData;
                    finalString = componentRef.instance.saveInstanceIn(finalString);
                }
                continue;
            }
            if (element instanceof HTMLElement) {
                const saverFn = this.customHTMLElSaver.get(element.tagName);
                if (saverFn) {
                    finalString = saverFn(element, finalString);
                }
            }
        }
        return finalString;
    }
    deSerializeContent(content, excludedPlugins = []) {
        let contentArray = [content];
        const sortedPlugins = this.plugins
            .filter((p) => !excludedPlugins.includes(p))
            //@ts-ignore
            .toSorted((a, b) => {
            return a.deserializationPriority - b.deserializationPriority;
        });
        for (const plugin of sortedPlugins) {
            plugin.applyOverContent(contentArray);
        }
        return contentArray;
    }
    insertSerializedContent(text) {
        const content = this.deSerializeContent(text || "");
        this.insertContentOnSelection(content);
    }
    insertContentOnSelection(content) {
        for (const item of content) {
            if (typeof item === "string") {
                this.insertTextInSelection(item);
            }
            else if (item instanceof ComponentRef) {
                this.insertComponentInSelection(item);
            }
            else if (item instanceof HTMLElement && this.customHTMLElSaver.has(item.tagName)) {
                this.insertNodeInSelection(item);
            }
        }
    }
    insertTextInSelection(text) {
        if (!text) {
            return;
        }
        if (this.singleLineMode) {
            text = text.replace(/\r?\n/g, " ");
        }
        const textNode = document.createTextNode(text);
        this.insertNodeInSelection(textNode);
    }
    insertComponentInSelection(component) {
        const wrapperHtml = this.wrapComponentForInsertion(component);
        this.insertNodeInSelection(wrapperHtml);
    }
    wrapComponentForInsertion(component) {
        const hostHtmlElement = component.location.nativeElement;
        const wrapperHtml = document.createElement(this.WRAPPER_TAG_NAME);
        wrapperHtml.contentEditable = "false";
        wrapperHtml.id = `et-${Date.now()}`;
        this.insertedComponents.set(wrapperHtml.id, [wrapperHtml, component]);
        component.instance.removeRequest$
            .pipe(takeUntilDestroyed(this.onDestroyRef$), take(1))
            .subscribe(() => {
            wrapperHtml.remove();
        });
        component.instance.updateRequest$
            .pipe(takeUntilDestroyed(this.onDestroyRef$), take(1))
            .subscribe(() => {
            this.changes$.next();
        });
        wrapperHtml.appendChild(hostHtmlElement);
        component.instance.initialize(this);
        component.changeDetectorRef.detectChanges();
        return wrapperHtml;
    }
    insertNodeInSelection(htmlNode) {
        let range = this._currentSelectionRange;
        if (!range ||
            !this.bufferContainer.element.nativeElement.contains(range.commonAncestorContainer)) {
            range = document.createRange();
            range.selectNodeContents(this.bufferContainer.element.nativeElement);
            range.collapse(false);
        }
        range.deleteContents();
        range.insertNode(htmlNode);
        range.setStartAfter(htmlNode);
        range.setEndAfter(htmlNode);
        const selection = window.getSelection();
        if (selection) {
            selection.removeAllRanges();
            selection.addRange(range);
        }
        this.stateChanges.next();
    }
    setComponentActive(comp, params = undefined, exclusive = true) {
        if (exclusive) {
            this.insertedComponents.forEach(([wrapper, compRef]) => {
                if (compRef !== comp) {
                    compRef.instance.deactivateAction();
                }
            });
        }
        if (comp) {
            comp.instance.activateAction(params);
        }
    }
    clearBuffer() {
        this.bufferContainer.element.nativeElement.innerHTML = "";
    }
    _setupBufferObserver() {
        const options = {
            characterData: true,
            attributes: false,
            childList: true,
            subtree: true,
        };
        this._bufferMutationObserver = new MutationObserver((mutationsList) => {
            this._bufferMutationObserver.disconnect();
            this.changes$.next();
            for (const mutation of mutationsList) {
                for (const node of Array.from(mutation.removedNodes)) {
                    if (node instanceof HTMLElement && node.tagName === this.WRAPPER_TAG_NAME && node.id) {
                        // Run Garbage collection on removed components in the next MacroTask to avoid blocking the ui
                        const componentGC = () => {
                            // @ts-ignore
                            const [_wrapperHtml, componentRef] = this.insertedComponents.get(node.id);
                            if (componentRef) {
                                componentRef.instance.deactivateAction();
                                componentRef.destroy();
                                this.insertedComponents.delete(node.id);
                            }
                        };
                        setTimeout(componentGC, 0);
                    }
                }
            }
            this._toggleBrHack(false);
            this._toggleBrHack(true);
            // Restore the observer
            this._bufferMutationObserver.observe(this.bufferContainer.element.nativeElement, options);
        });
        this._bufferMutationObserver.observe(this.bufferContainer.element.nativeElement, options);
    }
    _toggleBrHack(add) {
        if (add) {
            const br = document.createElement("br");
            br.setAttribute("trail", "");
            this.bufferContainer.element.nativeElement.appendChild(br);
        }
        else {
            this.bufferContainer.element.nativeElement.querySelector("br[trail]")?.remove();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EtaEditorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.16", type: EtaEditorComponent, isStandalone: true, selector: "atom-eta-editor", inputs: { plugins: { classPropertyName: "plugins", publicName: "plugins", isSignal: false, isRequired: false, transformFunction: null }, maxBufferHeightCssExpr: { classPropertyName: "maxBufferHeightCssExpr", publicName: "maxBufferHeightCssExpr", isSignal: false, isRequired: false, transformFunction: null }, minBufferHeightCssExpr: { classPropertyName: "minBufferHeightCssExpr", publicName: "minBufferHeightCssExpr", isSignal: false, isRequired: false, transformFunction: null }, singleLineMode: { classPropertyName: "singleLineMode", publicName: "singleLineMode", isSignal: false, isRequired: false, transformFunction: null }, spellCheck: { classPropertyName: "spellCheck", publicName: "spellCheck", isSignal: false, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: false, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: false, isRequired: false, transformFunction: null }, autofilled: { classPropertyName: "autofilled", publicName: "autofilled", isSignal: false, isRequired: false, transformFunction: null }, userAriaDescribedBy: { classPropertyName: "userAriaDescribedBy", publicName: "userAriaDescribedBy", isSignal: false, isRequired: false, transformFunction: null }, toolbarActionType: { classPropertyName: "toolbarActionType", publicName: "toolbarActionType", isSignal: true, isRequired: false, transformFunction: null }, toolbarEnabled: { classPropertyName: "toolbarEnabled", publicName: "toolbarEnabled", isSignal: true, isRequired: false, transformFunction: null }, helperMessage: { classPropertyName: "helperMessage", publicName: "helperMessage", isSignal: true, isRequired: false, transformFunction: null }, helperPosition: { classPropertyName: "helperPosition", publicName: "helperPosition", isSignal: true, isRequired: false, transformFunction: null }, errorContentTpl: { classPropertyName: "errorContentTpl", publicName: "errorContentTpl", isSignal: true, isRequired: false, transformFunction: null }, errorLargeMode: { classPropertyName: "errorLargeMode", publicName: "errorLargeMode", isSignal: true, isRequired: false, transformFunction: null }, toolbarActionTpl: { classPropertyName: "toolbarActionTpl", publicName: "toolbarActionTpl", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: false, isRequired: false, transformFunction: null } }, host: { properties: { "style.--max-container-height": "this.maxBufferHeightCssExpr", "style.--min-container-height": "this.minBufferHeightCssExpr", "id": "this.id", "style.--menu-items-num": "this.toolbarItemsNum" } }, providers: [
            {
                provide: MatFormFieldControl,
                useExisting: EtaEditorComponent,
            },
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => EtaEditorComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "bufferContainer", first: true, predicate: ["content"], descendants: true, read: ViewContainerRef, static: true }, { propertyName: "btnsRef", predicate: ["iconRef"], descendants: true, read: ViewContainerRef }], usesOnChanges: true, ngImport: i0, template: "<div (mousedown)=\"$event.preventDefault()\" class=\"main-eta-container\"\r\n     [ngClass]=\"{\r\n     'main-eta--single-line': singleLineMode,\r\n     'disabled-overlay':disabled,\r\n     'extra-right-shift': helperMessage() && helperPosition() === 'top-right',\r\n     'extra-left-shift': helperMessage() && helperPosition() === 'top-left',\r\n     }\">\r\n  @if (placeholder && !focused && empty) {\r\n    <mat-label class=\"floating-placeholder\">{{ placeholder }}</mat-label>\r\n  }\r\n  @if (helperMessage()) {\r\n    <atom-eta-info [message]=\"helperMessage()\"\r\n                   [position]=\"helperPosition()\">\r\n    </atom-eta-info>\r\n  }\r\n  <!-- BUFFER AREA - CONTENT EDITABLE -->\r\n  <div [contentEditable]=\"disabled ? false : textEditionMode\"\r\n       [spellcheck]=\"spellCheck\"\r\n       class=\"buffer-area insertion-config\"\r\n       (mousedown)=\"onContainerClick($event)\"\r\n       (keydown)=\"onKeyDown($event)\"\r\n       #content></div>\r\n\r\n  @if (toolbarEnabled()) {\r\n    <div>\r\n      @if (toolbarActionTpl()) {\r\n        <div class=\"toolbar-action-container\"\r\n             [ngClass]=\"{'eta-custom-button': toolbarActionType() === 'button'}\">\r\n          <ng-container *ngTemplateOutlet=\"toolbarActionTpl()\"></ng-container>\r\n        </div>\r\n      }\r\n\r\n      <div class=\"toolbar\" (mousedown)=\"$event.preventDefault()\">\r\n        @for (item of toolBarItems; track item) {\r\n\r\n          <mat-icon viewContainer\r\n                    [class.active-mat-icon]=\"item.focused !== undefined && item.focused()\"\r\n                    [matTooltip]=\"item.tooltip\"\r\n                    (click)=\"item.action()\"\r\n                    #iconRef=\"viewContainer\"\r\n                    [id]=\"item.id\"\r\n                    [class.icon-disabled]=\"item.disabled()\"\r\n                    mat-ripple\r\n                    [svgIcon]=\"item.icon.startsWith('svg:') ? item.icon.replace('svg:','') : ''\"\r\n                    class=\"clickable-mat-icon\"\r\n                    fontSet=\"material-icons-outlined\">\r\n            {{ !item.icon.startsWith('svg:') ? item.icon : '' }}\r\n          </mat-icon>\r\n        }\r\n        @if (errorState) {\r\n          <atom-eta-error-display [contentTpl]=\"errorContentTpl()\" [largeMode]=\"errorLargeMode()\">\r\n          </atom-eta-error-display>\r\n        }\r\n      </div>\r\n    </div>\r\n\r\n  }\r\n\r\n</div>\r\n", styles: [":host{display:inline-block;width:100%;height:100%}:host::ng-deep et-param-wrapper{display:inline-block;vertical-align:top;position:relative;overflow:hidden;height:19px;max-height:19px;min-height:19px}:host::ng-deep et-param-wrapper *{max-height:19px!important}:host::ng-deep et-param-wrapper[et-selected]:before{content:\"\";position:absolute;top:0;left:0;width:100%;height:100%;z-index:-1;background-color:#0000ffb3}.main-eta-container{display:inline-block;position:relative;height:100%;min-height:var(--min-container-height, calc(40px*max(var(--menu-items-num), 2)) );max-height:var(--max-container-height, 100%);width:100%;padding:8px 0 8px 16px}.main-eta-container .toolbar{height:45px;display:inline-flex;vertical-align:top;flex-direction:row;gap:6px;align-items:flex-start;max-height:100%;position:absolute;bottom:-43px;border:1px solid var(--mat-form-field-outlined-outline-color);border-radius:0 0 8px 8px;border-top:unset;left:0;width:100%;padding:12px}.main-eta-container .toolbar .clickable-mat-icon{height:20px;width:20px;color:#645e5b;fill:#645e5b;display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:20px!important}.main-eta-container .toolbar .clickable-mat-icon ::ng-deep *{max-height:20px!important;max-width:20px!important}.main-eta-container .toolbar .clickable-mat-icon:hover,.main-eta-container .toolbar .clickable-mat-icon.active-mat-icon{background:#dbdad9;border-radius:2px}.main-eta-container .toolbar .icon-disabled{opacity:.5;cursor:not-allowed}.main-eta-container .buffer-area{font-size:12px;line-height:19px;font-weight:400;letter-spacing:.01em;color:#645e5b;width:100%;min-height:calc(var(--min-container-height, calc(40px*max(var(--menu-items-num), 2)) ) - 0px - 20px * var(--menu-items-num) / max(var(--menu-items-num),1));max-height:calc(var(--max-container-height, 100%) - 16px - 20px * var(--menu-items-num) / max(var(--menu-items-num),1));outline:none;overflow-y:auto;overflow-x:clip;padding-right:16px}.main-eta-container .buffer-area ::selection{background-color:#0000ffb3}.insertion-config{display:inline-block;vertical-align:middle;white-space:pre-wrap;word-wrap:break-word}.floating-placeholder{position:absolute;color:var(--mat-select-placeholder-text-color);top:6px;padding-right:16px;height:calc(100% - 12.5px);overflow:hidden}.toolbar-action-container{position:absolute;bottom:-43px;left:0;height:45px;width:100%;display:flex;align-items:center;justify-content:end;padding:12px}:host ::ng-deep .eta-custom-button .mdc-button__label{display:flex;align-items:center;gap:4px;font-weight:500}:host ::ng-deep .eta-custom-button .mdc-button__ripple{background-color:#ffd8c0!important}:host ::ng-deep .eta-custom-button button{z-index:10;height:32px;padding:4px 8px;background-color:#ffe8d9!important;color:#f60!important;transition:background-color .1s ease,box-shadow .1s ease}:host ::ng-deep .eta-custom-button button:hover{background-color:#ffe3d0!important;box-shadow:0 1px 4px #0000001a}:host ::ng-deep .eta-custom-button button:active:not(:disabled){--mat-button-filled-state-layer-color: #ffd8c0}.main-eta--single-line{max-height:40px!important;min-height:40px!important}.main-eta--single-line .floating-placeholder{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:calc(100% - 16px);height:auto}.main-eta--single-line .toolbar{bottom:-43px;min-height:45px}.main-eta--single-line .buffer-area{padding-right:unset;padding-bottom:12px;min-height:19px;overflow-y:hidden;white-space:nowrap;max-width:calc(100% - 16px);margin-top:unset!important;outline:none}.main-eta--single-line mat-label{margin-top:unset!important}.disabled-overlay{opacity:.6}.disabled-overlay ::ng-deep *{pointer-events:none!important}.main-eta-container.extra-right-shift .buffer-area{padding-right:30px!important;outline:none}.main-eta-container.extra-left-shift{padding-left:30px!important}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i1$1.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i5.MatLabel, selector: "mat-label" }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: MatRippleModule }, { kind: "directive", type: i7.MatRipple, selector: "[mat-ripple], [matRipple]", inputs: ["matRippleColor", "matRippleUnbounded", "matRippleCentered", "matRippleRadius", "matRippleAnimation", "matRippleDisabled", "matRippleTrigger"], exportAs: ["matRipple"] }, { kind: "directive", type: ViewContainerExporterDirective, selector: "[viewContainer]", exportAs: ["viewContainer"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: EtaErrorDisplayComponent, selector: "atom-eta-error-display", inputs: ["contentTpl", "largeMode"] }, { kind: "component", type: EtaInfoComponent, selector: "atom-eta-info", inputs: ["message", "position"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EtaEditorComponent, decorators: [{
            type: Component,
            args: [{ selector: "atom-eta-editor", changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        FormsModule,
                        MatIconModule,
                        MatTooltipModule,
                        MatInputModule,
                        NgClass,
                        MatRippleModule,
                        ViewContainerExporterDirective,
                        NgTemplateOutlet,
                        EtaErrorDisplayComponent,
                        EtaInfoComponent,
                    ], providers: [
                        {
                            provide: MatFormFieldControl,
                            useExisting: EtaEditorComponent,
                        },
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => EtaEditorComponent),
                            multi: true,
                        },
                    ], template: "<div (mousedown)=\"$event.preventDefault()\" class=\"main-eta-container\"\r\n     [ngClass]=\"{\r\n     'main-eta--single-line': singleLineMode,\r\n     'disabled-overlay':disabled,\r\n     'extra-right-shift': helperMessage() && helperPosition() === 'top-right',\r\n     'extra-left-shift': helperMessage() && helperPosition() === 'top-left',\r\n     }\">\r\n  @if (placeholder && !focused && empty) {\r\n    <mat-label class=\"floating-placeholder\">{{ placeholder }}</mat-label>\r\n  }\r\n  @if (helperMessage()) {\r\n    <atom-eta-info [message]=\"helperMessage()\"\r\n                   [position]=\"helperPosition()\">\r\n    </atom-eta-info>\r\n  }\r\n  <!-- BUFFER AREA - CONTENT EDITABLE -->\r\n  <div [contentEditable]=\"disabled ? false : textEditionMode\"\r\n       [spellcheck]=\"spellCheck\"\r\n       class=\"buffer-area insertion-config\"\r\n       (mousedown)=\"onContainerClick($event)\"\r\n       (keydown)=\"onKeyDown($event)\"\r\n       #content></div>\r\n\r\n  @if (toolbarEnabled()) {\r\n    <div>\r\n      @if (toolbarActionTpl()) {\r\n        <div class=\"toolbar-action-container\"\r\n             [ngClass]=\"{'eta-custom-button': toolbarActionType() === 'button'}\">\r\n          <ng-container *ngTemplateOutlet=\"toolbarActionTpl()\"></ng-container>\r\n        </div>\r\n      }\r\n\r\n      <div class=\"toolbar\" (mousedown)=\"$event.preventDefault()\">\r\n        @for (item of toolBarItems; track item) {\r\n\r\n          <mat-icon viewContainer\r\n                    [class.active-mat-icon]=\"item.focused !== undefined && item.focused()\"\r\n                    [matTooltip]=\"item.tooltip\"\r\n                    (click)=\"item.action()\"\r\n                    #iconRef=\"viewContainer\"\r\n                    [id]=\"item.id\"\r\n                    [class.icon-disabled]=\"item.disabled()\"\r\n                    mat-ripple\r\n                    [svgIcon]=\"item.icon.startsWith('svg:') ? item.icon.replace('svg:','') : ''\"\r\n                    class=\"clickable-mat-icon\"\r\n                    fontSet=\"material-icons-outlined\">\r\n            {{ !item.icon.startsWith('svg:') ? item.icon : '' }}\r\n          </mat-icon>\r\n        }\r\n        @if (errorState) {\r\n          <atom-eta-error-display [contentTpl]=\"errorContentTpl()\" [largeMode]=\"errorLargeMode()\">\r\n          </atom-eta-error-display>\r\n        }\r\n      </div>\r\n    </div>\r\n\r\n  }\r\n\r\n</div>\r\n", styles: [":host{display:inline-block;width:100%;height:100%}:host::ng-deep et-param-wrapper{display:inline-block;vertical-align:top;position:relative;overflow:hidden;height:19px;max-height:19px;min-height:19px}:host::ng-deep et-param-wrapper *{max-height:19px!important}:host::ng-deep et-param-wrapper[et-selected]:before{content:\"\";position:absolute;top:0;left:0;width:100%;height:100%;z-index:-1;background-color:#0000ffb3}.main-eta-container{display:inline-block;position:relative;height:100%;min-height:var(--min-container-height, calc(40px*max(var(--menu-items-num), 2)) );max-height:var(--max-container-height, 100%);width:100%;padding:8px 0 8px 16px}.main-eta-container .toolbar{height:45px;display:inline-flex;vertical-align:top;flex-direction:row;gap:6px;align-items:flex-start;max-height:100%;position:absolute;bottom:-43px;border:1px solid var(--mat-form-field-outlined-outline-color);border-radius:0 0 8px 8px;border-top:unset;left:0;width:100%;padding:12px}.main-eta-container .toolbar .clickable-mat-icon{height:20px;width:20px;color:#645e5b;fill:#645e5b;display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:20px!important}.main-eta-container .toolbar .clickable-mat-icon ::ng-deep *{max-height:20px!important;max-width:20px!important}.main-eta-container .toolbar .clickable-mat-icon:hover,.main-eta-container .toolbar .clickable-mat-icon.active-mat-icon{background:#dbdad9;border-radius:2px}.main-eta-container .toolbar .icon-disabled{opacity:.5;cursor:not-allowed}.main-eta-container .buffer-area{font-size:12px;line-height:19px;font-weight:400;letter-spacing:.01em;color:#645e5b;width:100%;min-height:calc(var(--min-container-height, calc(40px*max(var(--menu-items-num), 2)) ) - 0px - 20px * var(--menu-items-num) / max(var(--menu-items-num),1));max-height:calc(var(--max-container-height, 100%) - 16px - 20px * var(--menu-items-num) / max(var(--menu-items-num),1));outline:none;overflow-y:auto;overflow-x:clip;padding-right:16px}.main-eta-container .buffer-area ::selection{background-color:#0000ffb3}.insertion-config{display:inline-block;vertical-align:middle;white-space:pre-wrap;word-wrap:break-word}.floating-placeholder{position:absolute;color:var(--mat-select-placeholder-text-color);top:6px;padding-right:16px;height:calc(100% - 12.5px);overflow:hidden}.toolbar-action-container{position:absolute;bottom:-43px;left:0;height:45px;width:100%;display:flex;align-items:center;justify-content:end;padding:12px}:host ::ng-deep .eta-custom-button .mdc-button__label{display:flex;align-items:center;gap:4px;font-weight:500}:host ::ng-deep .eta-custom-button .mdc-button__ripple{background-color:#ffd8c0!important}:host ::ng-deep .eta-custom-button button{z-index:10;height:32px;padding:4px 8px;background-color:#ffe8d9!important;color:#f60!important;transition:background-color .1s ease,box-shadow .1s ease}:host ::ng-deep .eta-custom-button button:hover{background-color:#ffe3d0!important;box-shadow:0 1px 4px #0000001a}:host ::ng-deep .eta-custom-button button:active:not(:disabled){--mat-button-filled-state-layer-color: #ffd8c0}.main-eta--single-line{max-height:40px!important;min-height:40px!important}.main-eta--single-line .floating-placeholder{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:calc(100% - 16px);height:auto}.main-eta--single-line .toolbar{bottom:-43px;min-height:45px}.main-eta--single-line .buffer-area{padding-right:unset;padding-bottom:12px;min-height:19px;overflow-y:hidden;white-space:nowrap;max-width:calc(100% - 16px);margin-top:unset!important;outline:none}.main-eta--single-line mat-label{margin-top:unset!important}.disabled-overlay{opacity:.6}.disabled-overlay ::ng-deep *{pointer-events:none!important}.main-eta-container.extra-right-shift .buffer-area{padding-right:30px!important;outline:none}.main-eta-container.extra-left-shift{padding-left:30px!important}\n"] }]
        }], propDecorators: { btnsRef: [{
                type: ViewChildren,
                args: ["iconRef", { read: ViewContainerRef }]
            }], bufferContainer: [{
                type: ViewChild,
                args: ["content", { read: ViewContainerRef, static: true }]
            }], plugins: [{
                type: Input
            }], maxBufferHeightCssExpr: [{
                type: Input
            }, {
                type: HostBinding,
                args: ["style.--max-container-height"]
            }], minBufferHeightCssExpr: [{
                type: Input
            }, {
                type: HostBinding,
                args: ["style.--min-container-height"]
            }], singleLineMode: [{
                type: Input
            }], spellCheck: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], required: [{
                type: Input
            }], autofilled: [{
                type: Input
            }], userAriaDescribedBy: [{
                type: Input
            }], toolbarActionType: [{ type: i0.Input, args: [{ isSignal: true, alias: "toolbarActionType", required: false }] }], toolbarEnabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "toolbarEnabled", required: false }] }], helperMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "helperMessage", required: false }] }], helperPosition: [{ type: i0.Input, args: [{ isSignal: true, alias: "helperPosition", required: false }] }], errorContentTpl: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorContentTpl", required: false }] }], errorLargeMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorLargeMode", required: false }] }], toolbarActionTpl: [{ type: i0.Input, args: [{ isSignal: true, alias: "toolbarActionTpl", required: false }] }], id: [{
                type: HostBinding,
                args: ["id"]
            }], toolbarItemsNum: [{
                type: HostBinding,
                args: ["style.--menu-items-num"]
            }], disabled: [{
                type: Input
            }] } });

class ExtendedTextAreaComponent {
    constructor() {
        this.injector = inject(Injector);
        this.ngControl = null;
        this.singleLineMode = false;
        this.plugins = [];
        this.required = false;
        this.disabled = false;
        this.spellCheck = false;
        this.toolbarEnabled = input(true, ...(ngDevMode ? [{ debugName: "toolbarEnabled" }] : []));
        this.helperMessage = input(...(ngDevMode ? [undefined, { debugName: "helperMessage" }] : []));
        this.helperPosition = input('top-right', ...(ngDevMode ? [{ debugName: "helperPosition" }] : []));
        this.toolbarActionType = input('button', ...(ngDevMode ? [{ debugName: "toolbarActionType" }] : []));
        this.errorLargeMode = input(false, ...(ngDevMode ? [{ debugName: "errorLargeMode" }] : []));
    }
    ngOnInit() {
        this.ngControl = this.injector.get(NgControl, null);
        if (this.ngControl) {
            this.ngControl.valueAccessor = this;
        }
    }
    writeValue(obj) {
        this.buffer.writeValue(obj);
    }
    registerOnChange(fn) {
        this.buffer.registerOnChange(fn);
    }
    registerOnTouched(fn) {
        this.buffer.registerOnTouched(fn);
    }
    setDisabledState(isDisabled) {
        // @ts-ignore
        this.buffer.setDisabledState(isDisabled);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: ExtendedTextAreaComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.16", type: ExtendedTextAreaComponent, isStandalone: true, selector: "atom-extended-text-area", inputs: { singleLineMode: { classPropertyName: "singleLineMode", publicName: "singleLineMode", isSignal: false, isRequired: false, transformFunction: null }, plugins: { classPropertyName: "plugins", publicName: "plugins", isSignal: false, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: false, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: false, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: false, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: false, isRequired: false, transformFunction: null }, maxHeightCssExpr: { classPropertyName: "maxHeightCssExpr", publicName: "maxHeightCssExpr", isSignal: false, isRequired: false, transformFunction: null }, minHeightCssExpr: { classPropertyName: "minHeightCssExpr", publicName: "minHeightCssExpr", isSignal: false, isRequired: false, transformFunction: null }, spellCheck: { classPropertyName: "spellCheck", publicName: "spellCheck", isSignal: false, isRequired: false, transformFunction: null }, toolbarEnabled: { classPropertyName: "toolbarEnabled", publicName: "toolbarEnabled", isSignal: true, isRequired: false, transformFunction: null }, helperMessage: { classPropertyName: "helperMessage", publicName: "helperMessage", isSignal: true, isRequired: false, transformFunction: null }, helperPosition: { classPropertyName: "helperPosition", publicName: "helperPosition", isSignal: true, isRequired: false, transformFunction: null }, toolbarActionType: { classPropertyName: "toolbarActionType", publicName: "toolbarActionType", isSignal: true, isRequired: false, transformFunction: null }, errorLargeMode: { classPropertyName: "errorLargeMode", publicName: "errorLargeMode", isSignal: true, isRequired: false, transformFunction: null } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => ExtendedTextAreaComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "buffer", first: true, predicate: EtaEditorComponent, descendants: true, static: true }], ngImport: i0, template: "<mat-form-field appearance=\"outline\"\r\n                [ngClass]=\"{ 'single-line': singleLineMode, 'toolbar-disabled': !toolbarEnabled()}\"\r\n                subscriptSizing=\"dynamic\"\r\n                class=\"main-eta-container\">\r\n  @if (label) {\r\n    <mat-label>{{ label }}</mat-label>\r\n  }\r\n  <atom-eta-editor [singleLineMode]=\"singleLineMode\"\r\n                   [placeholder]=\"placeholder\"\r\n                   [required]=\"required\"\r\n                   [disabled]=\"disabled\"\r\n                   [plugins]=\"plugins\"\r\n                   [spellCheck]=\"spellCheck\"\r\n                   [maxBufferHeightCssExpr]=\"maxHeightCssExpr\"\r\n                   [minBufferHeightCssExpr]=\"minHeightCssExpr\"\r\n                   [toolbarActionTpl]=\"toolbarActionTpl\"\r\n                   [errorContentTpl]=\"errorContentTpl\"\r\n                   [toolbarActionType]=\"toolbarActionType()\"\r\n                   [helperMessage]=\"helperMessage()\"\r\n                   [helperPosition]=\"helperPosition()\"\r\n                   [toolbarEnabled]=\"toolbarEnabled()\"\r\n                   [errorLargeMode]=\"errorLargeMode()\"/>\r\n</mat-form-field>\r\n\r\n<ng-template #errorContentTpl>\r\n  <ng-content select=\"[atom-eta-errors]\"></ng-content>\r\n</ng-template>\r\n<ng-template #toolbarActionTpl>\r\n  <ng-content select=\"[atom-eta-toolbar-action]\"></ng-content>\r\n</ng-template>\r\n", styles: [":host{display:inline-block;position:relative;width:100%}:host::ng-deep :not(atom-eta-editor *).mat-mdc-form-field.toolbar-disabled .mat-mdc-text-field-wrapper{margin-bottom:0!important}:host::ng-deep .mat-mdc-form-field{--form-field-border-color--focused: #7d7d7d}:host::ng-deep :not(atom-eta-editor *).mat-mdc-form-field-subscript-wrapper{position:absolute;bottom:-18px}:host::ng-deep :not(atom-eta-editor *).mat-mdc-form-field{width:100%!important}:host::ng-deep :not(atom-eta-editor *).mat-mdc-text-field-wrapper{padding-right:0!important;padding-left:0!important;margin-bottom:43px!important}:host::ng-deep :not(atom-eta-editor *).mat-mdc-form-field-infix{padding-top:0!important;padding-bottom:0!important;height:fit-content;width:fit-content;position:relative}:host::ng-deep :not(atom-eta-editor *).mat-mdc-floating-label{--mat-mdc-form-field-floating-label-top: 18px}:host::ng-deep :not(atom-eta-editor *).mat-mdc-floating-label mat-label{font-size:12px!important;font-weight:300!important;letter-spacing:.01em!important}.single-line::ng-deep :not(atom-eta-editor *).mat-mdc-text-field-wrapper{padding-right:0!important;margin-bottom:44px!important}.single-line::ng-deep :not(atom-eta-editor *).mat-mdc-form-field-infix{padding-top:0!important;padding-bottom:0!important;min-height:fit-content}\n"], dependencies: [{ kind: "ngmodule", type: MatInputModule }, { kind: "component", type: i5.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i5.MatLabel, selector: "mat-label" }, { kind: "component", type: EtaEditorComponent, selector: "atom-eta-editor", inputs: ["plugins", "maxBufferHeightCssExpr", "minBufferHeightCssExpr", "singleLineMode", "spellCheck", "placeholder", "required", "autofilled", "userAriaDescribedBy", "toolbarActionType", "toolbarEnabled", "helperMessage", "helperPosition", "errorContentTpl", "errorLargeMode", "toolbarActionTpl", "disabled"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: ExtendedTextAreaComponent, decorators: [{
            type: Component,
            args: [{ selector: 'atom-extended-text-area', changeDetection: ChangeDetectionStrategy.OnPush, imports: [MatInputModule, EtaEditorComponent, NgClass], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => ExtendedTextAreaComponent),
                            multi: true,
                        },
                    ], template: "<mat-form-field appearance=\"outline\"\r\n                [ngClass]=\"{ 'single-line': singleLineMode, 'toolbar-disabled': !toolbarEnabled()}\"\r\n                subscriptSizing=\"dynamic\"\r\n                class=\"main-eta-container\">\r\n  @if (label) {\r\n    <mat-label>{{ label }}</mat-label>\r\n  }\r\n  <atom-eta-editor [singleLineMode]=\"singleLineMode\"\r\n                   [placeholder]=\"placeholder\"\r\n                   [required]=\"required\"\r\n                   [disabled]=\"disabled\"\r\n                   [plugins]=\"plugins\"\r\n                   [spellCheck]=\"spellCheck\"\r\n                   [maxBufferHeightCssExpr]=\"maxHeightCssExpr\"\r\n                   [minBufferHeightCssExpr]=\"minHeightCssExpr\"\r\n                   [toolbarActionTpl]=\"toolbarActionTpl\"\r\n                   [errorContentTpl]=\"errorContentTpl\"\r\n                   [toolbarActionType]=\"toolbarActionType()\"\r\n                   [helperMessage]=\"helperMessage()\"\r\n                   [helperPosition]=\"helperPosition()\"\r\n                   [toolbarEnabled]=\"toolbarEnabled()\"\r\n                   [errorLargeMode]=\"errorLargeMode()\"/>\r\n</mat-form-field>\r\n\r\n<ng-template #errorContentTpl>\r\n  <ng-content select=\"[atom-eta-errors]\"></ng-content>\r\n</ng-template>\r\n<ng-template #toolbarActionTpl>\r\n  <ng-content select=\"[atom-eta-toolbar-action]\"></ng-content>\r\n</ng-template>\r\n", styles: [":host{display:inline-block;position:relative;width:100%}:host::ng-deep :not(atom-eta-editor *).mat-mdc-form-field.toolbar-disabled .mat-mdc-text-field-wrapper{margin-bottom:0!important}:host::ng-deep .mat-mdc-form-field{--form-field-border-color--focused: #7d7d7d}:host::ng-deep :not(atom-eta-editor *).mat-mdc-form-field-subscript-wrapper{position:absolute;bottom:-18px}:host::ng-deep :not(atom-eta-editor *).mat-mdc-form-field{width:100%!important}:host::ng-deep :not(atom-eta-editor *).mat-mdc-text-field-wrapper{padding-right:0!important;padding-left:0!important;margin-bottom:43px!important}:host::ng-deep :not(atom-eta-editor *).mat-mdc-form-field-infix{padding-top:0!important;padding-bottom:0!important;height:fit-content;width:fit-content;position:relative}:host::ng-deep :not(atom-eta-editor *).mat-mdc-floating-label{--mat-mdc-form-field-floating-label-top: 18px}:host::ng-deep :not(atom-eta-editor *).mat-mdc-floating-label mat-label{font-size:12px!important;font-weight:300!important;letter-spacing:.01em!important}.single-line::ng-deep :not(atom-eta-editor *).mat-mdc-text-field-wrapper{padding-right:0!important;margin-bottom:44px!important}.single-line::ng-deep :not(atom-eta-editor *).mat-mdc-form-field-infix{padding-top:0!important;padding-bottom:0!important;min-height:fit-content}\n"] }]
        }], propDecorators: { buffer: [{
                type: ViewChild,
                args: [EtaEditorComponent, { static: true }]
            }], singleLineMode: [{
                type: Input
            }], plugins: [{
                type: Input
            }], label: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], required: [{
                type: Input
            }], disabled: [{
                type: Input
            }], maxHeightCssExpr: [{
                type: Input
            }], minHeightCssExpr: [{
                type: Input
            }], spellCheck: [{
                type: Input
            }], toolbarEnabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "toolbarEnabled", required: false }] }], helperMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "helperMessage", required: false }] }], helperPosition: [{ type: i0.Input, args: [{ isSignal: true, alias: "helperPosition", required: false }] }], toolbarActionType: [{ type: i0.Input, args: [{ isSignal: true, alias: "toolbarActionType", required: false }] }], errorLargeMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorLargeMode", required: false }] }] } });

const FloatingEmojiInputs = new InjectionToken('FloatingEmojiInputs');
class EtaEmojiPanelComponent {
    constructor() {
        this.emojiInputs = inject(FloatingEmojiInputs);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EtaEmojiPanelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.16", type: EtaEmojiPanelComponent, isStandalone: true, selector: "atom-eta-emoji-panel", ngImport: i0, template: "<atom-emoji-picker\r\n  [loseFocusOnSelect]=\"true\"\r\n  (emojiSelected)=\"emojiInputs.emojiSelected.next($event)\"\r\n  (lostFocus)=\"emojiInputs.lostFocus.next()\"\r\n/>\r\n", dependencies: [{ kind: "component", type: EmojiPickerComponent, selector: "atom-emoji-picker", inputs: ["darkMode", "loseFocusOnSelect"], outputs: ["emojiSelected", "lostFocus"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EtaEmojiPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'atom-eta-emoji-panel', changeDetection: ChangeDetectionStrategy.OnPush, imports: [EmojiPickerComponent], template: "<atom-emoji-picker\r\n  [loseFocusOnSelect]=\"true\"\r\n  (emojiSelected)=\"emojiInputs.emojiSelected.next($event)\"\r\n  (lostFocus)=\"emojiInputs.lostFocus.next()\"\r\n/>\r\n" }]
        }] });

const defaultPluginsConfig = {
    basicRichText: {
        boldTooltip: 'Bold',
        italicTooltip: 'Italic',
        strikethroughTooltip: 'Strikethrough',
    },
    emoji: {
        tooltip: 'Emojis',
    },
    formatter: {
        tooltip: 'Format',
    },
};

//_______________________________________________ EXTENDED TEXT AREA ___________________________________________________
const ATOM_ETA_PLUGINS_CONFIG = new InjectionToken('ATOM_ETA_PLUGINS_CONFIG');

class EmojiPlugin {
    constructor() {
        this.deserializationPriority = 2;
        this._focused = false;
    }
    initialize(etaEditor) {
        if (this.etaEditorInstance) {
            return;
        }
        this.etaEditorInstance = etaEditor;
        this.overlay = this.etaEditorInstance.injector.get(Overlay);
        this._pluginsConfig = this.etaEditorInstance.injector.get(ATOM_ETA_PLUGINS_CONFIG, defaultPluginsConfig);
        const emojiBtn = {
            id: `emoji-btn-${Date.now()}`,
            icon: 'mood',
            focused: () => this._focused,
            disabled: () => false,
            tooltip: (this._pluginsConfig?.emoji?.tooltip ?? defaultPluginsConfig?.emoji?.tooltip) || '',
            action: () => {
                if (this._focused) {
                    return;
                }
                // @ts-ignore
                this.openEmojiOverlay(emojiBtn.btnViewRef.element);
            },
        };
        this.etaEditorInstance.toolBarItems.push(emojiBtn);
        this.etaEditorInstance.bufferContainer.element.nativeElement.addEventListener('keydown', (event) => {
            if (event.ctrlKey && event.key === 'e') {
                event.preventDefault();
                emojiBtn.action();
            }
        });
    }
    applyOverContent(content) {
        // Doesn't need to implement
    }
    openEmojiOverlay(attachment) {
        this._focused = true;
        this.etaEditorInstance.cdr.detectChanges();
        const positionStrategy = this.overlay
            .position()
            .flexibleConnectedTo(attachment)
            .withPositions([
            {
                originX: 'start',
                originY: 'bottom',
                overlayX: 'center',
                overlayY: 'top',
            },
        ]);
        this.overlayRef = this.overlay.create({
            disposeOnNavigation: true,
            positionStrategy,
            hasBackdrop: true,
            backdropClass: 'cdk-overlay-transparent-backdrop',
        });
        const emojiInputs = {
            emojiSelected: new ReplaySubject(),
            lostFocus: new ReplaySubject(),
        };
        emojiInputs.emojiSelected.pipe(take(1)).subscribe((emoji) => {
            this._focused = false;
            this.etaEditorInstance.cdr.detectChanges();
            this.etaEditorInstance.insertTextInSelection(emoji);
        });
        emojiInputs.lostFocus.pipe(take(1)).subscribe(() => {
            this._focused = false;
            this.etaEditorInstance.cdr.detectChanges();
            this.overlayRef.dispose();
        });
        const customOverlayPortal = new ComponentPortal(EtaEmojiPanelComponent, null, Injector.create({
            parent: this.etaEditorInstance.injector,
            providers: [
                {
                    provide: FloatingEmojiInputs,
                    useValue: emojiInputs,
                },
            ],
        }));
        this.overlayRef.attach(customOverlayPortal);
        this.overlayRef.backdropClick().subscribe(() => {
            this.overlayRef.dispose();
        });
    }
}

// @generated by Peggy 4.0.3.
//
// https://peggyjs.org/
/**
 *
 * Using the following grammar:
 *
 * {
 * function createElement(tag, content) {
 *    return {tag,content}
 * }
 * }
 *
 * Content = content:(Plugin / Bold / Italic / Strikethrough / MonoSpaced / Text /  Under / Approx / Quote / Aste)* { return content;}
 *
 * ContentNobold
 *   = Italic / Strikethrough / MonoSpaced / Plugin / Text
 *
 * ContentNoItalic
 *   = Bold / Strikethrough / MonoSpaced / Plugin / Text
 *
 * ContentNoST
 *   = Bold / Italic / MonoSpaced / Plugin / Text
 *
 * ContentNoMono = Plugin / Text /  Under / Approx / Quote / Aste
 *
 * Plugin = "​" content:[^​]+ "​" { return createElement('plugin', "​" + content.join('') + "​") }
 *
 * Bold
 *   = "*" content:ContentNobold+ "*" { return createElement('b', content); }
 *
 * Italic
 *   = "_" content:ContentNoItalic+ "_" { return createElement('i', content); }
 *
 * Strikethrough
 *   = "~" content:ContentNoST+ "~" { return createElement('s', content); }
 *
 * MonoSpaced
 *   = "```" content:ContentNoMono+ "```" { return createElement('code', content); }
 *
 * Under = char:"_" { return createElement('text', char) }
 * Approx = char:"~" { return createElement('text', char) }
 * Quote = char:"`" { return createElement('text', char) }
 * Aste = char:"*" { return createElement('text', char) }
 *
 * Text
 *   = content:[^*`~_​]+  { return createElement('text', content.join('')) }
 */
function peg$subclass(child, parent) {
    function C() {
        // @ts-ignore
        this.constructor = child;
    }
    C.prototype = parent.prototype;
    child.prototype = new C();
}
function peg$SyntaxError(message, expected, found, location) {
    // @ts-ignore
    var self = Error.call(this, message);
    // istanbul ignore next Check is a necessary evil to support older environments
    if (Object.setPrototypeOf) {
        Object.setPrototypeOf(self, peg$SyntaxError.prototype);
    }
    // @ts-ignore
    self.expected = expected;
    // @ts-ignore
    self.found = found;
    // @ts-ignore
    self.location = location;
    self.name = 'SyntaxError';
    // @ts-ignore
    return self;
}
peg$subclass(peg$SyntaxError, Error);
function peg$padEnd(str, targetLength, padString) {
    padString = padString || ' ';
    if (str.length > targetLength) {
        return str;
    }
    targetLength -= str.length;
    padString += padString.repeat(targetLength);
    return str + padString.slice(0, targetLength);
}
peg$SyntaxError.prototype.format = function (sources) {
    var str = 'Error: ' + this.message;
    if (this.location) {
        var src = null;
        var k;
        for (k = 0; k < sources.length; k++) {
            if (sources[k].source === this.location.source) {
                src = sources[k].text.split(/\r\n|\n|\r/g);
                break;
            }
        }
        var s = this.location.start;
        var offset_s = this.location.source &&
            typeof this.location.source.offset === 'function'
            ? this.location.source.offset(s)
            : s;
        var loc = this.location.source + ':' + offset_s.line + ':' + offset_s.column;
        if (src) {
            var e = this.location.end;
            var filler = peg$padEnd('', offset_s.line.toString().length, ' ');
            var line = src[s.line - 1];
            // @ts-ignore
            var last = s.line === e.line ? e.column : line.length + 1;
            var hatLen = last - s.column || 1;
            str +=
                '\n --> ' +
                    loc +
                    '\n' +
                    filler +
                    ' |\n' +
                    offset_s.line +
                    ' | ' +
                    line +
                    '\n' +
                    filler +
                    ' | ' +
                    peg$padEnd('', s.column - 1, ' ') +
                    peg$padEnd('', hatLen, '^');
        }
        else {
            str += '\n at ' + loc;
        }
    }
    return str;
};
peg$SyntaxError.buildMessage = function (expected, found) {
    var DESCRIBE_EXPECTATION_FNS = {
        literal: function (expectation) {
            return '"' + literalEscape(expectation.text) + '"';
        },
        class: function (expectation) {
            var escapedParts = expectation.parts.map(function (part) {
                return Array.isArray(part)
                    ? classEscape(part[0]) + '-' + classEscape(part[1])
                    : classEscape(part);
            });
            return ('[' +
                (expectation.inverted ? '^' : '') +
                escapedParts.join('') +
                ']');
        },
        any: function () {
            return 'any character';
        },
        end: function () {
            return 'end of input';
        },
        other: function (expectation) {
            return expectation.description;
        },
    };
    function hex(ch) {
        return ch.charCodeAt(0).toString(16).toUpperCase();
    }
    function literalEscape(s) {
        return s
            .replace(/\\/g, '\\\\')
            .replace(/"/g, '\\"')
            .replace(/\0/g, '\\0')
            .replace(/\t/g, '\\t')
            .replace(/\n/g, '\\n')
            .replace(/\r/g, '\\r')
            .replace(/[\x00-\x0F]/g, function (ch) {
            return '\\x0' + hex(ch);
        })
            .replace(/[\x10-\x1F\x7F-\x9F]/g, function (ch) {
            return '\\x' + hex(ch);
        });
    }
    function classEscape(s) {
        return s
            .replace(/\\/g, '\\\\')
            .replace(/\]/g, '\\]')
            .replace(/\^/g, '\\^')
            .replace(/-/g, '\\-')
            .replace(/\0/g, '\\0')
            .replace(/\t/g, '\\t')
            .replace(/\n/g, '\\n')
            .replace(/\r/g, '\\r')
            .replace(/[\x00-\x0F]/g, function (ch) {
            return '\\x0' + hex(ch);
        })
            .replace(/[\x10-\x1F\x7F-\x9F]/g, function (ch) {
            return '\\x' + hex(ch);
        });
    }
    function describeExpectation(expectation) {
        return DESCRIBE_EXPECTATION_FNS[expectation.type](expectation);
    }
    function describeExpected(expected) {
        var descriptions = expected.map(describeExpectation);
        var i, j;
        descriptions.sort();
        if (descriptions.length > 0) {
            for (i = 1, j = 1; i < descriptions.length; i++) {
                if (descriptions[i - 1] !== descriptions[i]) {
                    descriptions[j] = descriptions[i];
                    j++;
                }
            }
            descriptions.length = j;
        }
        switch (descriptions.length) {
            case 1:
                return descriptions[0];
            case 2:
                return descriptions[0] + ' or ' + descriptions[1];
            default:
                return (descriptions.slice(0, -1).join(', ') +
                    ', or ' +
                    descriptions[descriptions.length - 1]);
        }
    }
    function describeFound(found) {
        return found ? '"' + literalEscape(found) + '"' : 'end of input';
    }
    return ('Expected ' +
        describeExpected(expected) +
        ' but ' +
        describeFound(found) +
        ' found.');
};
function peg$parse(input, options) {
    options = options !== undefined ? options : {};
    var peg$FAILED = {};
    var peg$source = options.grammarSource;
    var peg$startRuleFunctions = { Content: peg$parseContent };
    var peg$startRuleFunction = peg$parseContent;
    var peg$c0 = '\u200B';
    var peg$c1 = '*';
    var peg$c2 = '_';
    var peg$c3 = '~';
    var peg$c4 = '```';
    var peg$c5 = '`';
    var peg$r0 = /^[^\u200B]/;
    var peg$r1 = /^[^*`~_\u200B]/;
    var peg$e0 = peg$literalExpectation('\u200B', false);
    var peg$e1 = peg$classExpectation(['\u200B'], true, false);
    var peg$e2 = peg$literalExpectation('*', false);
    var peg$e3 = peg$literalExpectation('_', false);
    var peg$e4 = peg$literalExpectation('~', false);
    var peg$e5 = peg$literalExpectation('```', false);
    var peg$e6 = peg$literalExpectation('`', false);
    var peg$e7 = peg$classExpectation(['*', '`', '~', '_', '\u200B'], true, false);
    var peg$f0 = function (content) {
        return content;
    };
    var peg$f1 = function (content) {
        // @ts-ignore
        return options.createElemFn('plugin', '\u200B' + content.join('') + '\u200B');
    };
    var peg$f2 = function (content) {
        // @ts-ignore
        return options.createElemFn('b', content);
    };
    var peg$f3 = function (content) {
        // @ts-ignore
        return options.createElemFn('i', content);
    };
    var peg$f4 = function (content) {
        // @ts-ignore
        return options.createElemFn('STRIKE', content);
    };
    var peg$f5 = function (content) {
        // @ts-ignore
        return options.createElemFn('code', content);
    };
    var peg$f6 = function (char) {
        // @ts-ignore
        return options.createElemFn('text', char);
    };
    var peg$f7 = function (char) {
        // @ts-ignore
        return options.createElemFn('text', char);
    };
    var peg$f8 = function (char) {
        // @ts-ignore
        return options.createElemFn('text', char);
    };
    var peg$f9 = function (char) {
        // @ts-ignore
        return options.createElemFn('text', char);
    };
    var peg$f10 = function (content) {
        // @ts-ignore
        return options.createElemFn('text', content.join(''));
    };
    // @ts-ignore
    var peg$currPos = options.peg$currPos | 0;
    var peg$savedPos = peg$currPos;
    var peg$posDetailsCache = [{ line: 1, column: 1 }];
    var peg$maxFailPos = peg$currPos;
    var peg$maxFailExpected = options.peg$maxFailExpected || [];
    // @ts-ignore
    var peg$silentFails = options.peg$silentFails | 0;
    var peg$result;
    if (options.startRule) {
        if (!(options.startRule in peg$startRuleFunctions)) {
            throw new Error('Can\'t start parsing from rule "' + options.startRule + '".');
        }
        peg$startRuleFunction = peg$startRuleFunctions[options.startRule];
    }
    function text() {
        return input.substring(peg$savedPos, peg$currPos);
    }
    function offset() {
        return peg$savedPos;
    }
    function range() {
        return {
            source: peg$source,
            start: peg$savedPos,
            end: peg$currPos,
        };
    }
    function location() {
        return peg$computeLocation(peg$savedPos, peg$currPos);
    }
    function expected(description, location) {
        location =
            location !== undefined
                ? location
                : peg$computeLocation(peg$savedPos, peg$currPos);
        throw peg$buildStructuredError([peg$otherExpectation(description)], input.substring(peg$savedPos, peg$currPos), location);
    }
    function error(message, location) {
        location =
            location !== undefined
                ? location
                : peg$computeLocation(peg$savedPos, peg$currPos);
        throw peg$buildSimpleError(message, location);
    }
    function peg$literalExpectation(text, ignoreCase) {
        return { type: 'literal', text: text, ignoreCase: ignoreCase };
    }
    function peg$classExpectation(parts, inverted, ignoreCase) {
        return {
            type: 'class',
            parts: parts,
            inverted: inverted,
            ignoreCase: ignoreCase,
        };
    }
    function peg$anyExpectation() {
        return { type: 'any' };
    }
    function peg$endExpectation() {
        return { type: 'end' };
    }
    function peg$otherExpectation(description) {
        return { type: 'other', description: description };
    }
    function peg$computePosDetails(pos) {
        var details = peg$posDetailsCache[pos];
        var p;
        if (details) {
            return details;
        }
        else {
            if (pos >= peg$posDetailsCache.length) {
                p = peg$posDetailsCache.length - 1;
            }
            else {
                p = pos;
                while (!peg$posDetailsCache[--p]) { }
            }
            details = peg$posDetailsCache[p];
            details = {
                line: details.line,
                column: details.column,
            };
            while (p < pos) {
                if (input.charCodeAt(p) === 10) {
                    details.line++;
                    details.column = 1;
                }
                else {
                    details.column++;
                }
                p++;
            }
            peg$posDetailsCache[pos] = details;
            return details;
        }
    }
    function peg$computeLocation(startPos, endPos, offset = undefined) {
        var startPosDetails = peg$computePosDetails(startPos);
        var endPosDetails = peg$computePosDetails(endPos);
        var res = {
            source: peg$source,
            start: {
                offset: startPos,
                line: startPosDetails.line,
                column: startPosDetails.column,
            },
            end: {
                offset: endPos,
                line: endPosDetails.line,
                column: endPosDetails.column,
            },
        };
        if (offset && peg$source && typeof peg$source.offset === 'function') {
            res.start = peg$source.offset(res.start);
            res.end = peg$source.offset(res.end);
        }
        return res;
    }
    function peg$fail(expected) {
        if (peg$currPos < peg$maxFailPos) {
            return;
        }
        if (peg$currPos > peg$maxFailPos) {
            peg$maxFailPos = peg$currPos;
            peg$maxFailExpected = [];
        }
        peg$maxFailExpected.push(expected);
    }
    function peg$buildSimpleError(message, location) {
        return new peg$SyntaxError(message, null, null, location);
    }
    function peg$buildStructuredError(expected, found, location) {
        return new peg$SyntaxError(peg$SyntaxError.buildMessage(expected, found), expected, found, location);
    }
    function peg$parseContent() {
        var s0, s1, s2;
        s0 = peg$currPos;
        s1 = [];
        s2 = peg$parsePlugin();
        if (s2 === peg$FAILED) {
            s2 = peg$parseBold();
            if (s2 === peg$FAILED) {
                s2 = peg$parseItalic();
                if (s2 === peg$FAILED) {
                    s2 = peg$parseStrikethrough();
                    if (s2 === peg$FAILED) {
                        s2 = peg$parseMonoSpaced();
                        if (s2 === peg$FAILED) {
                            s2 = peg$parseText();
                            if (s2 === peg$FAILED) {
                                s2 = peg$parseUnder();
                                if (s2 === peg$FAILED) {
                                    s2 = peg$parseApprox();
                                    if (s2 === peg$FAILED) {
                                        s2 = peg$parseQuote();
                                        if (s2 === peg$FAILED) {
                                            s2 = peg$parseAste();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        while (s2 !== peg$FAILED) {
            s1.push(s2);
            s2 = peg$parsePlugin();
            if (s2 === peg$FAILED) {
                s2 = peg$parseBold();
                if (s2 === peg$FAILED) {
                    s2 = peg$parseItalic();
                    if (s2 === peg$FAILED) {
                        s2 = peg$parseStrikethrough();
                        if (s2 === peg$FAILED) {
                            s2 = peg$parseMonoSpaced();
                            if (s2 === peg$FAILED) {
                                s2 = peg$parseText();
                                if (s2 === peg$FAILED) {
                                    s2 = peg$parseUnder();
                                    if (s2 === peg$FAILED) {
                                        s2 = peg$parseApprox();
                                        if (s2 === peg$FAILED) {
                                            s2 = peg$parseQuote();
                                            if (s2 === peg$FAILED) {
                                                s2 = peg$parseAste();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        peg$savedPos = s0;
        s1 = peg$f0(s1);
        s0 = s1;
        return s0;
    }
    function peg$parseContentNobold() {
        var s0;
        s0 = peg$parseItalic();
        if (s0 === peg$FAILED) {
            s0 = peg$parseStrikethrough();
            if (s0 === peg$FAILED) {
                s0 = peg$parseMonoSpaced();
                if (s0 === peg$FAILED) {
                    s0 = peg$parsePlugin();
                    if (s0 === peg$FAILED) {
                        s0 = peg$parseText();
                    }
                }
            }
        }
        return s0;
    }
    function peg$parseContentNoItalic() {
        var s0;
        s0 = peg$parseBold();
        if (s0 === peg$FAILED) {
            s0 = peg$parseStrikethrough();
            if (s0 === peg$FAILED) {
                s0 = peg$parseMonoSpaced();
                if (s0 === peg$FAILED) {
                    s0 = peg$parsePlugin();
                    if (s0 === peg$FAILED) {
                        s0 = peg$parseText();
                    }
                }
            }
        }
        return s0;
    }
    function peg$parseContentNoST() {
        var s0;
        s0 = peg$parseBold();
        if (s0 === peg$FAILED) {
            s0 = peg$parseItalic();
            if (s0 === peg$FAILED) {
                s0 = peg$parseMonoSpaced();
                if (s0 === peg$FAILED) {
                    s0 = peg$parsePlugin();
                    if (s0 === peg$FAILED) {
                        s0 = peg$parseText();
                    }
                }
            }
        }
        return s0;
    }
    function peg$parseContentNoMono() {
        var s0;
        s0 = peg$parsePlugin();
        if (s0 === peg$FAILED) {
            s0 = peg$parseText();
            if (s0 === peg$FAILED) {
                s0 = peg$parseUnder();
                if (s0 === peg$FAILED) {
                    s0 = peg$parseApprox();
                    if (s0 === peg$FAILED) {
                        s0 = peg$parseQuote();
                        if (s0 === peg$FAILED) {
                            s0 = peg$parseAste();
                        }
                    }
                }
            }
        }
        return s0;
    }
    function peg$parsePlugin() {
        var s0, s1, s2, s3;
        s0 = peg$currPos;
        if (input.charCodeAt(peg$currPos) === 8203) {
            s1 = peg$c0;
            peg$currPos++;
        }
        else {
            s1 = peg$FAILED;
            if (peg$silentFails === 0) {
                peg$fail(peg$e0);
            }
        }
        if (s1 !== peg$FAILED) {
            s2 = [];
            s3 = input.charAt(peg$currPos);
            if (peg$r0.test(s3)) {
                peg$currPos++;
            }
            else {
                s3 = peg$FAILED;
                if (peg$silentFails === 0) {
                    peg$fail(peg$e1);
                }
            }
            if (s3 !== peg$FAILED) {
                while (s3 !== peg$FAILED) {
                    s2.push(s3);
                    s3 = input.charAt(peg$currPos);
                    if (peg$r0.test(s3)) {
                        peg$currPos++;
                    }
                    else {
                        s3 = peg$FAILED;
                        if (peg$silentFails === 0) {
                            peg$fail(peg$e1);
                        }
                    }
                }
            }
            else {
                s2 = peg$FAILED;
            }
            if (s2 !== peg$FAILED) {
                if (input.charCodeAt(peg$currPos) === 8203) {
                    s3 = peg$c0;
                    peg$currPos++;
                }
                else {
                    s3 = peg$FAILED;
                    if (peg$silentFails === 0) {
                        peg$fail(peg$e0);
                    }
                }
                if (s3 !== peg$FAILED) {
                    peg$savedPos = s0;
                    s0 = peg$f1(s2);
                }
                else {
                    peg$currPos = s0;
                    s0 = peg$FAILED;
                }
            }
            else {
                peg$currPos = s0;
                s0 = peg$FAILED;
            }
        }
        else {
            peg$currPos = s0;
            s0 = peg$FAILED;
        }
        return s0;
    }
    function peg$parseBold() {
        var s0, s1, s2, s3;
        s0 = peg$currPos;
        if (input.charCodeAt(peg$currPos) === 42) {
            s1 = peg$c1;
            peg$currPos++;
        }
        else {
            s1 = peg$FAILED;
            if (peg$silentFails === 0) {
                peg$fail(peg$e2);
            }
        }
        if (s1 !== peg$FAILED) {
            s2 = [];
            s3 = peg$parseContentNobold();
            if (s3 !== peg$FAILED) {
                while (s3 !== peg$FAILED) {
                    s2.push(s3);
                    s3 = peg$parseContentNobold();
                }
            }
            else {
                s2 = peg$FAILED;
            }
            if (s2 !== peg$FAILED) {
                if (input.charCodeAt(peg$currPos) === 42) {
                    s3 = peg$c1;
                    peg$currPos++;
                }
                else {
                    s3 = peg$FAILED;
                    if (peg$silentFails === 0) {
                        peg$fail(peg$e2);
                    }
                }
                if (s3 !== peg$FAILED) {
                    peg$savedPos = s0;
                    s0 = peg$f2(s2);
                }
                else {
                    peg$currPos = s0;
                    s0 = peg$FAILED;
                }
            }
            else {
                peg$currPos = s0;
                s0 = peg$FAILED;
            }
        }
        else {
            peg$currPos = s0;
            s0 = peg$FAILED;
        }
        return s0;
    }
    function peg$parseItalic() {
        var s0, s1, s2, s3;
        s0 = peg$currPos;
        if (input.charCodeAt(peg$currPos) === 95) {
            s1 = peg$c2;
            peg$currPos++;
        }
        else {
            s1 = peg$FAILED;
            if (peg$silentFails === 0) {
                peg$fail(peg$e3);
            }
        }
        if (s1 !== peg$FAILED) {
            s2 = [];
            s3 = peg$parseContentNoItalic();
            if (s3 !== peg$FAILED) {
                while (s3 !== peg$FAILED) {
                    s2.push(s3);
                    s3 = peg$parseContentNoItalic();
                }
            }
            else {
                s2 = peg$FAILED;
            }
            if (s2 !== peg$FAILED) {
                if (input.charCodeAt(peg$currPos) === 95) {
                    s3 = peg$c2;
                    peg$currPos++;
                }
                else {
                    s3 = peg$FAILED;
                    if (peg$silentFails === 0) {
                        peg$fail(peg$e3);
                    }
                }
                if (s3 !== peg$FAILED) {
                    peg$savedPos = s0;
                    s0 = peg$f3(s2);
                }
                else {
                    peg$currPos = s0;
                    s0 = peg$FAILED;
                }
            }
            else {
                peg$currPos = s0;
                s0 = peg$FAILED;
            }
        }
        else {
            peg$currPos = s0;
            s0 = peg$FAILED;
        }
        return s0;
    }
    function peg$parseStrikethrough() {
        var s0, s1, s2, s3;
        s0 = peg$currPos;
        if (input.charCodeAt(peg$currPos) === 126) {
            s1 = peg$c3;
            peg$currPos++;
        }
        else {
            s1 = peg$FAILED;
            if (peg$silentFails === 0) {
                peg$fail(peg$e4);
            }
        }
        if (s1 !== peg$FAILED) {
            s2 = [];
            s3 = peg$parseContentNoST();
            if (s3 !== peg$FAILED) {
                while (s3 !== peg$FAILED) {
                    s2.push(s3);
                    s3 = peg$parseContentNoST();
                }
            }
            else {
                s2 = peg$FAILED;
            }
            if (s2 !== peg$FAILED) {
                if (input.charCodeAt(peg$currPos) === 126) {
                    s3 = peg$c3;
                    peg$currPos++;
                }
                else {
                    s3 = peg$FAILED;
                    if (peg$silentFails === 0) {
                        peg$fail(peg$e4);
                    }
                }
                if (s3 !== peg$FAILED) {
                    peg$savedPos = s0;
                    s0 = peg$f4(s2);
                }
                else {
                    peg$currPos = s0;
                    s0 = peg$FAILED;
                }
            }
            else {
                peg$currPos = s0;
                s0 = peg$FAILED;
            }
        }
        else {
            peg$currPos = s0;
            s0 = peg$FAILED;
        }
        return s0;
    }
    function peg$parseMonoSpaced() {
        var s0, s1, s2, s3;
        s0 = peg$currPos;
        if (input.substr(peg$currPos, 3) === peg$c4) {
            s1 = peg$c4;
            peg$currPos += 3;
        }
        else {
            s1 = peg$FAILED;
            if (peg$silentFails === 0) {
                peg$fail(peg$e5);
            }
        }
        if (s1 !== peg$FAILED) {
            s2 = [];
            s3 = peg$parseContentNoMono();
            if (s3 !== peg$FAILED) {
                while (s3 !== peg$FAILED) {
                    s2.push(s3);
                    s3 = peg$parseContentNoMono();
                }
            }
            else {
                s2 = peg$FAILED;
            }
            if (s2 !== peg$FAILED) {
                if (input.substr(peg$currPos, 3) === peg$c4) {
                    s3 = peg$c4;
                    peg$currPos += 3;
                }
                else {
                    s3 = peg$FAILED;
                    if (peg$silentFails === 0) {
                        peg$fail(peg$e5);
                    }
                }
                if (s3 !== peg$FAILED) {
                    peg$savedPos = s0;
                    s0 = peg$f5(s2);
                }
                else {
                    peg$currPos = s0;
                    s0 = peg$FAILED;
                }
            }
            else {
                peg$currPos = s0;
                s0 = peg$FAILED;
            }
        }
        else {
            peg$currPos = s0;
            s0 = peg$FAILED;
        }
        return s0;
    }
    function peg$parseUnder() {
        var s0, s1;
        s0 = peg$currPos;
        if (input.charCodeAt(peg$currPos) === 95) {
            s1 = peg$c2;
            peg$currPos++;
        }
        else {
            s1 = peg$FAILED;
            if (peg$silentFails === 0) {
                peg$fail(peg$e3);
            }
        }
        if (s1 !== peg$FAILED) {
            peg$savedPos = s0;
            s1 = peg$f6(s1);
        }
        s0 = s1;
        return s0;
    }
    function peg$parseApprox() {
        var s0, s1;
        s0 = peg$currPos;
        if (input.charCodeAt(peg$currPos) === 126) {
            s1 = peg$c3;
            peg$currPos++;
        }
        else {
            s1 = peg$FAILED;
            if (peg$silentFails === 0) {
                peg$fail(peg$e4);
            }
        }
        if (s1 !== peg$FAILED) {
            peg$savedPos = s0;
            s1 = peg$f7(s1);
        }
        s0 = s1;
        return s0;
    }
    function peg$parseQuote() {
        var s0, s1;
        s0 = peg$currPos;
        if (input.charCodeAt(peg$currPos) === 96) {
            s1 = peg$c5;
            peg$currPos++;
        }
        else {
            s1 = peg$FAILED;
            if (peg$silentFails === 0) {
                peg$fail(peg$e6);
            }
        }
        if (s1 !== peg$FAILED) {
            peg$savedPos = s0;
            s1 = peg$f8(s1);
        }
        s0 = s1;
        return s0;
    }
    function peg$parseAste() {
        var s0, s1;
        s0 = peg$currPos;
        if (input.charCodeAt(peg$currPos) === 42) {
            s1 = peg$c1;
            peg$currPos++;
        }
        else {
            s1 = peg$FAILED;
            if (peg$silentFails === 0) {
                peg$fail(peg$e2);
            }
        }
        if (s1 !== peg$FAILED) {
            peg$savedPos = s0;
            s1 = peg$f9(s1);
        }
        s0 = s1;
        return s0;
    }
    function peg$parseText() {
        var s0, s1, s2;
        s0 = peg$currPos;
        s1 = [];
        s2 = input.charAt(peg$currPos);
        if (peg$r1.test(s2)) {
            peg$currPos++;
        }
        else {
            s2 = peg$FAILED;
            if (peg$silentFails === 0) {
                peg$fail(peg$e7);
            }
        }
        if (s2 !== peg$FAILED) {
            while (s2 !== peg$FAILED) {
                s1.push(s2);
                s2 = input.charAt(peg$currPos);
                if (peg$r1.test(s2)) {
                    peg$currPos++;
                }
                else {
                    s2 = peg$FAILED;
                    if (peg$silentFails === 0) {
                        peg$fail(peg$e7);
                    }
                }
            }
        }
        else {
            s1 = peg$FAILED;
        }
        if (s1 !== peg$FAILED) {
            peg$savedPos = s0;
            s1 = peg$f10(s1);
        }
        s0 = s1;
        return s0;
    }
    function createElement(tag, content) {
        return { tag, content };
        const element = document.createElement(tag);
        content.forEach((item) => {
            if (typeof item === 'string') {
                element.appendChild(document.createTextNode(item));
            }
            else {
                element.appendChild(item);
            }
        });
        return element;
    }
    peg$result = peg$startRuleFunction();
    if (options.peg$library) {
        return /** @type {any} */ {
            peg$result,
            peg$currPos,
            peg$FAILED,
            peg$maxFailExpected,
            peg$maxFailPos,
        };
    }
    if (peg$result !== peg$FAILED && peg$currPos === input.length) {
        return peg$result;
    }
    else {
        if (peg$result !== peg$FAILED && peg$currPos < input.length) {
            peg$fail(peg$endExpectation());
        }
        throw peg$buildStructuredError(peg$maxFailExpected, peg$maxFailPos < input.length ? input.charAt(peg$maxFailPos) : null, peg$maxFailPos < input.length
            ? peg$computeLocation(peg$maxFailPos, peg$maxFailPos + 1)
            : peg$computeLocation(peg$maxFailPos, peg$maxFailPos));
    }
}
const peg$allowedStartRules = ['Content'];

class BasicRichTextPlugin {
    constructor() {
        this.deserializationPriority = 0;
    }
    initialize(etaEditor) {
        if (this.etaEditorInstance) {
            return;
        }
        this.etaEditorInstance = etaEditor;
        this._pluginsConfig = this.etaEditorInstance.injector.get(ATOM_ETA_PLUGINS_CONFIG, defaultPluginsConfig);
        this.etaEditorInstance.selectionChange$
            .pipe(takeUntilDestroyed(this.etaEditorInstance.onDestroyRef$))
            .subscribe(() => {
            this.etaEditorInstance.cdr.detectChanges();
        });
        this._setupEmptyTagCleaner();
        this._setupCustomHtmlSerializer();
        // We need this to preserve bold when nested
        this.etaEditorInstance.constructedCss.insertRule(`#${this.etaEditorInstance.id} .buffer-area b * { font-weight: bold !important; }`);
        this.etaEditorInstance.constructedCss.insertRule(`  #${this.etaEditorInstance.id} .buffer-area i * { font-style: italic !important; }`);
        this.etaEditorInstance.constructedCss.insertRule(`  #${this.etaEditorInstance.id} .buffer-area strike * { text-decoration: line-through !important; }`);
        this._setupToolbarButtons();
    }
    _setupEmptyTagCleaner() {
        this.etaEditorInstance.changes$
            .pipe(takeUntilDestroyed(this.etaEditorInstance.onDestroyRef$))
            .subscribe(() => {
            const buffer = this.etaEditorInstance.bufferContainer.element
                .nativeElement;
            const tags = ['b', 'i', 'strike', 'code'];
            let updateOutput = false;
            tags.forEach((tagName) => {
                const elements = buffer.querySelectorAll(tagName);
                elements.forEach((tag) => {
                    if (tag.childNodes.length === 0 ||
                        (tag.childNodes.length === 1 &&
                            tag.textContent?.trim() === '')) {
                        tag.remove();
                        updateOutput = true;
                    }
                });
            });
            if (updateOutput) {
                this.etaEditorInstance.changes$.next();
            }
        });
    }
    _setupToolbarButtons() {
        const boldBtn = {
            id: `bold-btn-${Date.now()}`,
            icon: 'format_bold',
            disabled: () => false,
            focused: () => {
                return this._queryCommandState('bold');
            },
            tooltip: (this._pluginsConfig?.basicRichText?.boldTooltip ?? defaultPluginsConfig?.basicRichText?.boldTooltip) || '',
            action: () => {
                this._executeCommand('bold');
            },
        };
        const italicBtn = {
            id: `italic-btn-${Date.now()}`,
            icon: 'format_italic',
            disabled: () => false,
            focused: () => {
                return this._queryCommandState('italic');
            },
            tooltip: (this._pluginsConfig?.basicRichText?.italicTooltip ?? defaultPluginsConfig?.basicRichText?.italicTooltip) || '',
            action: () => {
                this._executeCommand('italic');
            },
        };
        const strikeBtn = {
            id: `strikethrough-btn-${Date.now()}`,
            icon: 'format_strikethrough',
            focused: () => {
                return this._queryCommandState('strikeThrough');
            },
            disabled: () => false,
            tooltip: (this._pluginsConfig?.basicRichText?.strikethroughTooltip ?? defaultPluginsConfig?.basicRichText?.strikethroughTooltip) || '',
            action: () => {
                this._executeCommand('strikeThrough');
            },
        };
        this.etaEditorInstance.bufferContainer.element.nativeElement.addEventListener('keydown', (event) => {
            if (!event.ctrlKey) {
                return;
            }
            if (event.shiftKey && event.key === 'S') {
                strikeBtn.action();
                event.preventDefault();
                return;
            }
            switch (event.key) {
                case 'b':
                    boldBtn.action();
                    break;
                case 'i':
                    italicBtn.action();
                    break;
                default:
                    return;
            }
            event.preventDefault();
        });
        this.etaEditorInstance.toolBarItems.push(boldBtn, italicBtn, strikeBtn);
    }
    _setupCustomHtmlSerializer() {
        const serializerFn = (htmlElem, finalString) => {
            const processChildren = (elem) => {
                let result = '';
                elem.childNodes.forEach((child) => {
                    if (child.nodeType === Node.TEXT_NODE) {
                        result += child.textContent;
                    }
                    else if (child instanceof HTMLElement &&
                        child.tagName === this.etaEditorInstance.WRAPPER_TAG_NAME) {
                        // @ts-ignore
                        const [_, insertable] = this.etaEditorInstance.insertedComponents.get(child.id);
                        result += insertable.instance.saveInstanceIn('');
                    }
                    else if (child.nodeType === Node.ELEMENT_NODE) {
                        result += serializerFn(child, '');
                    }
                });
                return result;
            };
            switch (htmlElem.tagName) {
                case 'B':
                    return finalString + `*${processChildren(htmlElem)}*`;
                case 'I':
                    return finalString + `_${processChildren(htmlElem)}_`;
                case 'STRIKE':
                    return finalString + `~${processChildren(htmlElem)}~`;
                case 'CODE':
                    return (finalString + `\`\`\`${processChildren(htmlElem)}\`\`\``);
                default:
                    throw new Error(`Unknown tag {${htmlElem.tagName}}`);
            }
        };
        this.etaEditorInstance.customHTMLElSaver.set('B', serializerFn);
        this.etaEditorInstance.customHTMLElSaver.set('I', serializerFn);
        this.etaEditorInstance.customHTMLElSaver.set('STRIKE', serializerFn);
        this.etaEditorInstance.customHTMLElSaver.set('CODE', serializerFn);
    }
    applyOverContent(content) {
        for (let i = 0; i < content.length; i++) {
            if (typeof content[i] === 'string') {
                const parsedContent = peg$parse(content[i], {
                    createElemFn: (tag, cnt) => {
                        if (tag === 'text') {
                            return cnt;
                        }
                        if (tag == 'plugin') {
                            const deserialized = this.etaEditorInstance.deSerializeContent(cnt, [this]);
                            return deserialized[0];
                        }
                        const element = document.createElement(tag);
                        for (const item of cnt) {
                            if (typeof item === 'string') {
                                element.appendChild(document.createTextNode(item));
                            }
                            else if (item instanceof Node) {
                                element.appendChild(item);
                            }
                            else if (item instanceof ComponentRef) {
                                element.appendChild(this.etaEditorInstance.wrapComponentForInsertion(item));
                            }
                        }
                        return element;
                    },
                });
                content.splice(i, 1, ...parsedContent);
            }
        }
    }
    _queryCommandState(cmd) {
        return document.queryCommandState(cmd);
    }
    _executeCommand(cmd) {
        // We need to set the textEditionMode to true to allow the execCommand to work
        this.etaEditorInstance.textEditionMode = true;
        this.etaEditorInstance.cdr.detectChanges();
        // At the moment, the only way to apply style is through execCommand wich is still supported by most browsers
        document.execCommand(cmd);
        // We didsable it after in order to avoid the user to add more styles
        this.etaEditorInstance.textEditionMode = 'plaintext-only';
        this.etaEditorInstance.cdr.detectChanges();
    }
}

class EtaLimiterInfoComponent {
    constructor() {
        this.filled = 0;
        this.available = -1;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EtaLimiterInfoComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.16", type: EtaLimiterInfoComponent, isStandalone: true, selector: "atom-eta-limiter-info-plugin", inputs: { filled: "filled", available: "available" }, ngImport: i0, template: "{{ filled }}\r\n@if (available !== -1) {\r\n  / {{ available }}\r\n}\r\n", styles: [":host{display:inline-flex;align-items:center;justify-content:center;position:absolute;bottom:-30px;right:12px;height:20px;margin:0;line-height:12.5px;font-size:10px;color:#645e5b;font-weight:400}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EtaLimiterInfoComponent, decorators: [{
            type: Component,
            args: [{ selector: 'atom-eta-limiter-info-plugin', changeDetection: ChangeDetectionStrategy.OnPush, imports: [], template: "{{ filled }}\r\n@if (available !== -1) {\r\n  / {{ available }}\r\n}\r\n", styles: [":host{display:inline-flex;align-items:center;justify-content:center;position:absolute;bottom:-30px;right:12px;height:20px;margin:0;line-height:12.5px;font-size:10px;color:#645e5b;font-weight:400}\n"] }]
        }], propDecorators: { filled: [{
                type: Input
            }], available: [{
                type: Input
            }] } });

/**
 * This plugin limits the number of characters that can be inserted into the textarea.
 * It also provides a label that shows the number of characters that are filled and the number of characters that are available.
 * It can also be configured to allow only text or only components to be inserted.
 * IMPORTANT: This plugin should be used at the end of the plugin array.
 */
class TextLimiterPlugin {
    constructor(maxLength = 1024, showLabel = true, textOrComponentMutex = false) {
        this.maxLength = maxLength;
        this.showLabel = showLabel;
        this.textOrComponentMutex = textOrComponentMutex;
        this.deserializationPriority = 99;
        this.filledChars = 0;
    }
    initialize(etaEditor) {
        this.etaEditorInstance = etaEditor;
        this.etaEditorInstance.afterViewInitRef$.pipe(take(1)).subscribe(() => {
            this.etaEditorInstance.bufferContainer.element.nativeElement.addEventListener('keydown', (event) => {
                const isChar = event.key.length === 1 &&
                    !event.ctrlKey &&
                    !event.metaKey;
                if (isChar &&
                    this.textOrComponentMutex &&
                    this.etaEditorInstance.insertedComponents.size > 0) {
                    event.preventDefault();
                }
                if (this.maxLength !== -1 &&
                    isChar &&
                    this.filledChars == this.maxLength) {
                    event.preventDefault();
                }
            });
            this.etaEditorInstance.changes$
                .pipe(takeUntilDestroyed(this.etaEditorInstance.onDestroyRef$))
                .subscribe(() => {
                const textNodes = this.etaEditorInstance.bufferContainer.element
                    .nativeElement.childNodes;
                let filledChars = 0;
                for (const node of textNodes) {
                    if (node.nodeType === Node.TEXT_NODE) {
                        // @ts-ignore
                        filledChars += node.textContent.length;
                        continue;
                    }
                    if (node.nodeType === Node.ELEMENT_NODE &&
                        node.tagName !== this.etaEditorInstance.WRAPPER_TAG_NAME) {
                        const text = node.textContent;
                        if (text) {
                            filledChars += text.length;
                        }
                    }
                }
                this.filledChars = filledChars;
                if (this.showLabel) {
                    this.infoLabel.setInput(nameof('filled'), this.filledChars);
                }
            });
            if (this.showLabel) {
                this.infoLabel =
                    this.etaEditorInstance.componentFactoryFn(EtaLimiterInfoComponent);
                this.infoLabel.setInput(nameof('available'), this.maxLength);
                this.infoLabel.changeDetectorRef.detectChanges();
                const htmlElem = this.etaEditorInstance.etbRef.element
                    .nativeElement;
                htmlElem.appendChild(this.infoLabel.location.nativeElement);
            }
        });
    }
    applyOverContent(content) {
        if (this.textOrComponentMutex && this.etaEditorInstance.insertedComponents.size > 0) {
            // remove all strings from the content
            const filteredContent = content.filter((item) => typeof item !== 'string');
            content.splice(0, content.length, ...filteredContent);
        }
        if (this.maxLength === -1) {
            return;
        }
        let insertedLength = 0;
        for (const item of content) {
            if (typeof item === 'string') {
                insertedLength += item.length;
            }
        }
        if (insertedLength <= this.maxLength) {
            return;
        }
        // start trimming the content from the end if it exceeds the limit and poping if is not a string
        let i = content.length - 1;
        while (insertedLength > this.maxLength && i >= 0) {
            const item = content[i];
            if (typeof item === 'string') {
                const diff = Math.min(insertedLength - this.maxLength, item.length);
                const trimmed = item.slice(0, item.length - diff);
                if (trimmed.length === 0) {
                    content.pop();
                    continue;
                }
                content[i] = trimmed;
                insertedLength -= diff;
            }
            else if (item instanceof ComponentRef) {
                const componentRef = item;
                componentRef.destroy();
                content.pop();
            }
            i--;
        }
    }
}

class JsonFormatter {
    format(text) {
        let value = JSON.parse(text);
        let stringify = JSON.stringify(value, null, this.step);
        return stringify;
    }
    parse(text) {
        let value = JSON.parse(text);
        if (this.objectOnly && (!value || typeof value !== 'object')) {
            throw new Error('Invalid JSON');
        }
        return value;
    }
    constructor(objectOnly = true, step = 2) {
        this.objectOnly = objectOnly;
        this.step = step;
    }
}

class XmlFormatter {
    parse(text) {
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(text, 'application/xml');
        return xmlDoc;
    }
    format(text) {
        const serializer = new XMLSerializer();
        const xmlDoc = this.parse(text);
        const formattedXml = serializer.serializeToString(xmlDoc);
        const resp = this._vkbeautifyXml(formattedXml, this.step);
        return resp;
    }
    _vkbeautifyXml(text, step) {
        let minifiedText = text
            .replace(/\<![ \r\n\t]*(--([^\-]|[\r\n]|-[^\-])*--[ \r\n\t]*)\>/g, '')
            .replace(/[ \r\n\t]{1,}xmlns/g, ' xmlns')
            .replace(/>\s{0,}</g, '><');
        let ar = minifiedText
            .replace(/>\s{0,}</g, '><')
            .replace(/</g, '~::~<')
            .replace(/\s*xmlns\:/g, '~::~xmlns:')
            .replace(/\s*xmlns\=/g, '~::~xmlns=')
            .split('~::~'), len = ar.length, inComment = false, deep = 0, str = '', ix = 0;
        for (ix = 0; ix < len; ix++) {
            // start comment or <![CDATA[...]]> or <!DOCTYPE //
            if (ar[ix].search(/<!/) > -1) {
                str += this.shiftArr[deep] + ar[ix];
                inComment = true;
                // end comment  or <![CDATA[...]]> //
                if (ar[ix].search(/-->/) > -1 ||
                    ar[ix].search(/\]>/) > -1 ||
                    ar[ix].search(/!DOCTYPE/) > -1) {
                    inComment = false;
                }
            }
            // end comment  or <![CDATA[...]]> //
            else if (ar[ix].search(/-->/) > -1 || ar[ix].search(/\]>/) > -1) {
                str += ar[ix];
                inComment = false;
            }
            // <elm></elm> //
            else if (/^<\w/.exec(ar[ix - 1]) &&
                /^<\/\w/.exec(ar[ix]) &&
                //@ts-ignore
                /^<[\w:\-\.\,]+/.exec(ar[ix - 1]) ==
                    /^<\/[\w:\-\.\,]+/.exec(ar[ix])[0].replace('/', '')) {
                str += ar[ix];
                if (!inComment)
                    deep--;
            }
            // <elm> //
            else if (ar[ix].search(/<\w/) > -1 &&
                ar[ix].search(/<\//) == -1 &&
                ar[ix].search(/\/>/) == -1) {
                str = !inComment
                    ? (str += this.shiftArr[deep++] + ar[ix])
                    : (str += ar[ix]);
            }
            // <elm>...</elm> //
            else if (ar[ix].search(/<\w/) > -1 && ar[ix].search(/<\//) > -1) {
                str = !inComment
                    ? (str += this.shiftArr[deep] + ar[ix])
                    : (str += ar[ix]);
            }
            // </elm> //
            else if (ar[ix].search(/<\//) > -1) {
                str = !inComment
                    ? (str += this.shiftArr[--deep] + ar[ix])
                    : (str += ar[ix]);
            }
            // <elm/> //
            else if (ar[ix].search(/\/>/) > -1) {
                str = !inComment
                    ? (str += this.shiftArr[deep] + ar[ix])
                    : (str += ar[ix]);
            }
            // <? xml ... ?> //
            else if (ar[ix].search(/<\?/) > -1) {
                str += this.shiftArr[deep] + ar[ix];
            }
            // xmlns //
            else if (ar[ix].search(/xmlns\:/) > -1 ||
                ar[ix].search(/xmlns\=/) > -1) {
                str += this.shiftArr[deep] + ar[ix];
            }
            else {
                str += ar[ix];
            }
        }
        return str[0] == '\n' ? str.slice(1) : str;
    }
    constructor(step = 2) {
        this.step = step;
        this.shiftArr = Array.from({ length: 100 }, (_, ix) => '\n' + ' '.repeat(this.step).repeat(ix));
    }
}
// const data = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?><root><entry><name>john</name><loc>brazil</loc><age>95</age></entry><entry><foo>charles</foo><bar>france</bar><baz>65</baz></entry></root>";
//
// console.log(formatXml(data));

class FormatterPlugin {
    initialize(etaEditor) {
        if (this.etaEditorInstance) {
            return;
        }
        this.etaEditorInstance = etaEditor;
        this._pluginsConfig = this.etaEditorInstance.injector.get(ATOM_ETA_PLUGINS_CONFIG, defaultPluginsConfig);
        const formatterBtn = {
            id: `formatter-btn-${Date.now()}`,
            icon: 'data_object',
            disabled: () => false,
            tooltip: (this._pluginsConfig?.formatter?.tooltip ?? defaultPluginsConfig?.formatter?.tooltip) || '',
            action: () => {
                const htmlBuffer = this.etaEditorInstance.bufferContainer.element
                    .nativeElement;
                const nodes = Array.from(htmlBuffer.childNodes);
                const content = this.etaEditorInstance.serializeNodesContent(nodes);
                for (const formatter of this.formatters) {
                    try {
                        const formatted = formatter.format(content);
                        this.etaEditorInstance.clearBuffer();
                        this.etaEditorInstance.insertSerializedContent(formatted);
                        break;
                    }
                    catch (e) {
                        if (this.formatters.length > 1) {
                            const isLastFormatter = this.formatters.indexOf(formatter) ===
                                this.formatters.length - 1;
                            if (isLastFormatter) {
                                // console.warn('No formatter was able to format the content');
                            }
                        }
                        else {
                            // console.warn('No formatter was able to format the content');
                        }
                    }
                }
            },
        };
        this.etaEditorInstance.toolBarItems.push(formatterBtn);
    }
    applyOverContent(content) {
        // Not necessary
    }
    constructor(formatters = []) {
        this.formatters = formatters;
        this.deserializationPriority = 98;
    }
}

class AtomExtendedTextAreaPlugins {
    //*************************************************************************
    //* Text-level plugins
    //*************************************************************************
    static Emoji() {
        return new EmojiPlugin();
    }
    static BasicRichText() {
        return new BasicRichTextPlugin();
    }
    static TextLimiter(maxLength = 1024, showLabel = true) {
        return new TextLimiterPlugin(maxLength, showLabel);
    }
    //*************************************************************************
    //* Formatters
    //*************************************************************************
    static JsonContentFormatter() {
        return this.createFormatterPlugin([new JsonFormatter()]);
    }
    static XmlContentFormatter() {
        return this.createFormatterPlugin([new XmlFormatter()]);
    }
    static JsonAndXmlFormatter() {
        return this.createFormatterPlugin([
            new JsonFormatter(),
            new XmlFormatter(),
        ]);
    }
    static createFormatterPlugin(formatters) {
        return new FormatterPlugin(formatters);
    }
}

/*
 * Public API Surface of ui
 */
//************************************************* REGION: CustomChip *************************************************
//**********************************************************************************************************************
// //******************************************** REGION: AtomFlowFieldsService *******************************************
// export {AtomBaseFlowFieldsService, FlowFieldTypes, ComponentType, FlowField} from "./interfaces/atom-base-flow-fields-service";
// //**********************************************************************************************************************

/**
 * Generated bundle index. Do not edit.
 */

export { ATOM_ETA_PLUGINS_CONFIG, AtomExtendedTextAreaPlugins, CustomChipComponent, EmojiPickerComponent, EtaEditorComponent, ExtendedTextAreaComponent, SelectSearchV2Component, SpanEllipseComponent };
//# sourceMappingURL=atom-ui.mjs.map
