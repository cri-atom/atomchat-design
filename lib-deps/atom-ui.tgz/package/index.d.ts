import * as _angular_core from '@angular/core';
import { EventEmitter, OnInit, AfterViewInit, OnChanges, OnDestroy, ChangeDetectorRef, DestroyRef, TemplateRef, ElementRef, SimpleChanges, ComponentRef, ViewContainerRef, QueryList, Injector, InjectionToken } from '@angular/core';
import { MatSelect } from '@angular/material/select';
import { FormControl, ControlValueAccessor, NgControl } from '@angular/forms';
import { ReplaySubject, Subscription, Subject } from 'rxjs';
import { MatPseudoCheckboxState } from '@angular/material/core';
import { MatFormField, FloatLabelType, MatFormFieldControl } from '@angular/material/form-field';
import { TooltipPosition } from '@angular/material/tooltip';
import { EmojiEvent } from '@ctrl/ngx-emoji-mart/ngx-emoji';

declare class CustomChipComponent {
    value: string;
    closeBtn: boolean;
    close: EventEmitter<void>;
    click: EventEmitter<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CustomChipComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CustomChipComponent, "atom-custom-chip", never, { "value": { "alias": "value"; "required": false; }; "closeBtn": { "alias": "closeBtn"; "required": false; }; }, { "close": "close"; "click": "click"; }, never, never, true, never>;
}

type GroupConfig = {
    orderPriority: number;
    alternativeName: string;
};
type GroupsConfigMap = Map<object, GroupConfig>;

declare class SelectSearchV2Component implements OnInit, AfterViewInit, OnChanges, OnDestroy {
    cdr: ChangeDetectorRef;
    private _elementRef;
    readonly onDestroyRef$: DestroyRef;
    readonly afterViewInitRef$: ReplaySubject<void>;
    formField?: MatFormField;
    clearSearchText: string;
    selectAllTooltipText: string;
    selectAllMessage: string;
    allSelectedText: string;
    searchNoResultsText: string;
    noItemsText: string;
    searchPlaceholderText: string;
    disabledTooltipText: string;
    isRequiredText: string;
    label: string;
    placeholder?: string;
    required: boolean;
    disabled: boolean;
    hideEmptySearchResult: boolean;
    showLabel: boolean;
    tooltipMaxLength: number;
    enableSearch: boolean;
    focusSearchOnOpen: boolean;
    searchCharsMaxLength: number;
    floatLabel: FloatLabelType;
    labelOrdering?: 'asc' | 'dsc';
    considerMissingOptionsInList: boolean;
    valueKey?: string;
    labelKey?: string;
    valueEqualFn: (first: any, second: any) => boolean;
    valueOf: (option: any) => string;
    labelOf: (option: any) => string;
    disabledKey: string;
    disabledStateValue: boolean;
    enabledTooltip: boolean;
    groupByKey?: string;
    groupsConfig: GroupsConfigMap | undefined;
    options: any[];
    excludedOptions: any[];
    showError: boolean;
    customPanelCssCls: string;
    get selectedOption(): any | any[];
    private _optionToSelect;
    selectedOptionSubscription?: Subscription;
    set selectedOption(optionsToSelect: any | any[]);
    multiple: boolean;
    enableSelectAll: boolean;
    leftDetailSpan?: TemplateRef<any>;
    rightDetailSpan?: TemplateRef<any>;
    customTrigger?: TemplateRef<any>;
    extraAction: TemplateRef<any>;
    rowNumber: number;
    rowHeightCssExpr: string;
    panelVerticalOffsetCssExpr: string;
    panelMinWidth: string;
    panelHorizontalOffsetCssExpr: string;
    alreadyTouched: boolean;
    selectedOptionChange: EventEmitter<any>;
    hoverOption: EventEmitter<any>;
    blurOption: EventEmitter<null>;
    panelOpen: EventEmitter<void>;
    panelClose: EventEmitter<void>;
    protected optionCtrl: FormControl;
    searchInput?: ElementRef;
    searchFilterCtrl: FormControl;
    filteredGroups$: ReplaySubject<any[][]>;
    matSelect?: MatSelect;
    _uniqueId: string;
    customPanelCssConfig?: HTMLStyleElement;
    open(): void;
    close(): void;
    get triggerValue(): string;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    private _setupOverFlowCorrector;
    private _setPanelDynamicConfig;
    ngOnChanges(changes: SimpleChanges): void;
    protected get _selectedAllCheckboxState(): MatPseudoCheckboxState;
    protected onPanelOpen(): void;
    protected onPanelClose(): void;
    ngOnDestroy(): void;
    filterOptions(): void;
    clearSearch(): void;
    trackByItems(index: number, item: any): string;
    getGroupRepresentation(group: any[]): any;
    toggleSelectAll(state: MatPseudoCheckboxState): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SelectSearchV2Component, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SelectSearchV2Component, "atom-select-search-v2", never, { "clearSearchText": { "alias": "clearSearchText"; "required": false; }; "selectAllTooltipText": { "alias": "selectAllTooltipText"; "required": false; }; "selectAllMessage": { "alias": "selectAllMessage"; "required": false; }; "allSelectedText": { "alias": "allSelectedText"; "required": false; }; "searchNoResultsText": { "alias": "searchNoResultsText"; "required": false; }; "noItemsText": { "alias": "noItemsText"; "required": false; }; "searchPlaceholderText": { "alias": "searchPlaceholderText"; "required": false; }; "disabledTooltipText": { "alias": "disabledTooltipText"; "required": false; }; "isRequiredText": { "alias": "isRequiredText"; "required": false; }; "label": { "alias": "label"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "required": { "alias": "required"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "hideEmptySearchResult": { "alias": "hideEmptySearchResult"; "required": false; }; "showLabel": { "alias": "showLabel"; "required": false; }; "tooltipMaxLength": { "alias": "tooltipMaxLength"; "required": false; }; "enableSearch": { "alias": "enableSearch"; "required": false; }; "focusSearchOnOpen": { "alias": "focusSearchOnOpen"; "required": false; }; "searchCharsMaxLength": { "alias": "searchCharsMaxLength"; "required": false; }; "floatLabel": { "alias": "floatLabel"; "required": false; }; "labelOrdering": { "alias": "labelOrdering"; "required": false; }; "considerMissingOptionsInList": { "alias": "considerMissingOptionsInList"; "required": false; }; "valueKey": { "alias": "valueKey"; "required": false; }; "labelKey": { "alias": "labelKey"; "required": false; }; "valueEqualFn": { "alias": "valueEqualFn"; "required": false; }; "valueOf": { "alias": "valueOfFn"; "required": false; }; "labelOf": { "alias": "labelOfFn"; "required": false; }; "disabledKey": { "alias": "disabledKey"; "required": false; }; "disabledStateValue": { "alias": "disabledStateValue"; "required": false; }; "enabledTooltip": { "alias": "enabledTooltip"; "required": false; }; "groupByKey": { "alias": "groupByKey"; "required": false; }; "groupsConfig": { "alias": "groupsConfig"; "required": false; }; "options": { "alias": "options"; "required": false; }; "excludedOptions": { "alias": "excludedOptions"; "required": false; }; "showError": { "alias": "showError"; "required": false; }; "customPanelCssCls": { "alias": "customPanelCssCls"; "required": false; }; "selectedOption": { "alias": "selectedOption"; "required": false; }; "multiple": { "alias": "multiple"; "required": false; }; "enableSelectAll": { "alias": "enableSelectAll"; "required": false; }; "leftDetailSpan": { "alias": "leftDetailSpan"; "required": false; }; "rightDetailSpan": { "alias": "rightDetailSpan"; "required": false; }; "customTrigger": { "alias": "customTrigger"; "required": false; }; "extraAction": { "alias": "extraAction"; "required": false; }; "rowNumber": { "alias": "rowNumber"; "required": false; }; "rowHeightCssExpr": { "alias": "rowHeightCssExpr"; "required": false; }; "panelVerticalOffsetCssExpr": { "alias": "panelVerticalOffsetCssExpr"; "required": false; }; "panelMinWidth": { "alias": "panelMinWidth"; "required": false; }; "panelHorizontalOffsetCssExpr": { "alias": "panelHorizontalOffsetCssExpr"; "required": false; }; "alreadyTouched": { "alias": "alreadyTouched"; "required": false; }; }, { "selectedOptionChange": "selectedOptionChange"; "hoverOption": "hoverOption"; "blurOption": "blurOption"; "panelOpen": "panelOpen"; "panelClose": "panelClose"; }, never, never, true, never>;
}

/**
 * A standalone component that truncates text with an ellipsis and optionally displays a tooltip with the full text on hover.
 * This component reacts dynamically to changes in the text content and the maximum width of the text span.
 * Is OnPush and ViewEncapsulation.None to optimize performance and allow global styling.
 */
declare class SpanEllipseComponent implements AfterViewInit, OnChanges, OnDestroy {
    /** The maximum width of the text span, beyond which the text will be truncated. */
    maxWidthCssExpr: string;
    /** The preferred position of the tooltip. */
    tooltipPosition: TooltipPosition;
    /** The delay in milliseconds before showing the tooltip after mouse enter. */
    tooltipShowDelay: number;
    /** The delay in milliseconds before hiding the tooltip after mouse leave. */
    tooltipHideDelay: number;
    tooltipClass: string | string[] | Set<string> | {
        [p: string]: any;
    };
    protected _showTooltip: boolean;
    protected _tooltipEnabled: boolean;
    private _resizeObserver?;
    protected _textSpan: ElementRef;
    get text(): any;
    private readonly _cdr;
    /**
     * Sets up the ResizeObserver on the text span element after the view initializes.
     */
    ngAfterViewInit(): void;
    /**
     * Checks if the tooltip is necessary whenever the input text or maximum width changes.
     * @param changes An object of changes.
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Disconnects the ResizeObserver when the component is destroyed to prevent memory leaks.
     */
    ngOnDestroy(): void;
    /**
     * Sets up a ResizeObserver on the text span to determine if the text overflows its container.
     */
    private setupResizeObserver;
    /**
     * Checks if the text overflows its container and enables or disables the tooltip accordingly.
     */
    private checkTooltipNecessity;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SpanEllipseComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SpanEllipseComponent, "atom-span-ellipse", never, { "maxWidthCssExpr": { "alias": "maxWidthCssExpr"; "required": false; }; "tooltipPosition": { "alias": "tooltipPosition"; "required": false; }; "tooltipShowDelay": { "alias": "tooltipShowDelay"; "required": false; }; "tooltipHideDelay": { "alias": "tooltipHideDelay"; "required": false; }; "tooltipClass": { "alias": "tooltipClass"; "required": false; }; }, {}, never, ["*"], true, never>;
}

declare class EmojiPickerComponent implements OnDestroy {
    darkMode: boolean;
    loseFocusOnSelect: boolean;
    emojiSelected: EventEmitter<string>;
    lostFocus: EventEmitter<void>;
    elementRef: ElementRef<any>;
    protected _uniqueId: string;
    constructor();
    ngOnDestroy(): void;
    addEmoji(event: EmojiEvent): void;
    private handleClick;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<EmojiPickerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<EmojiPickerComponent, "atom-emoji-picker", never, { "darkMode": { "alias": "darkMode"; "required": false; }; "loseFocusOnSelect": { "alias": "loseFocusOnSelect"; "required": false; }; }, { "emojiSelected": "emojiSelected"; "lostFocus": "lostFocus"; }, never, never, true, never>;
}

type HelperPosition = "top-left" | "top-right";

interface ITextAreaInsertable {
    activateAction(params?: unknown): void;
    deactivateAction(params?: unknown): void;
    initialize(etb: EtaEditorComponent): void;
    setDisabledState(isDisabled: boolean): void;
    saveInstanceIn(value: string): string;
    removeRequest$: ReplaySubject<void>;
    updateRequest$: ReplaySubject<void>;
}

interface IExtendedTextAreaPlugin {
    initialize(etaEditor: EtaEditorComponent): void;
    etaEditorInstance: EtaEditorComponent;
    deserializationPriority: number;
    applyOverContent(content: [string | ComponentRef<ITextAreaInsertable> | HTMLElement]): void;
}

type ExtendedTextAreaToolbarItem = {
    id: string;
    icon: string;
    tooltip: string;
    focused?: () => boolean;
    disabled: () => boolean;
    action: () => void;
    btnViewRef?: ViewContainerRef;
};

interface ExtendedTextAreaPluginsConfig {
    basicRichText?: {
        boldTooltip?: string;
        italicTooltip?: string;
        strikethroughTooltip?: string;
    };
    emoji?: {
        tooltip?: string;
    };
    formatter?: {
        tooltip?: string;
    };
}

declare class EtaEditorComponent implements AfterViewInit, OnInit, OnDestroy, OnChanges, ControlValueAccessor, MatFormFieldControl<string> {
    readonly etbRef: ViewContainerRef;
    btnsRef: QueryList<ViewContainerRef>;
    readonly bufferContainer: ViewContainerRef;
    get injector(): _angular_core.Injector;
    readonly cdr: ChangeDetectorRef;
    componentFactoryFn: typeof ViewContainerRef.prototype.createComponent;
    plugins: IExtendedTextAreaPlugin[];
    maxBufferHeightCssExpr: string;
    minBufferHeightCssExpr: string;
    singleLineMode: boolean;
    spellCheck: boolean;
    placeholder: string;
    required: boolean;
    autofilled: boolean;
    userAriaDescribedBy?: string | undefined;
    toolbarActionType: _angular_core.InputSignal<ToolbarActionType>;
    toolbarEnabled: _angular_core.InputSignal<boolean>;
    helperMessage: _angular_core.InputSignal<string | undefined>;
    helperPosition: _angular_core.InputSignal<HelperPosition>;
    errorContentTpl: _angular_core.InputSignal<TemplateRef<any> | null>;
    errorLargeMode: _angular_core.InputSignal<boolean>;
    toolbarActionTpl: _angular_core.InputSignal<TemplateRef<any> | null>;
    value: string;
    stateChanges: Subject<void>;
    id: string;
    ngControl: NgControl | null;
    focused: boolean;
    errorState: boolean;
    controlType: string;
    changes$: Subject<void>;
    readonly constructedCss: CSSStyleSheet;
    toolBarItems: ExtendedTextAreaToolbarItem[];
    customHTMLElSaver: Map<string, (element: HTMLElement, finalString: string) => string>;
    toolbarItemsNum: number;
    readonly afterViewInitRef$: ReplaySubject<void>;
    onDestroyRef$: DestroyRef;
    readonly WRAPPER_TAG_NAME = "ET-PARAM-WRAPPER";
    readonly insertedComponents: Map<string, [HTMLElement, ComponentRef<ITextAreaInsertable>]>;
    private _bufferMutationObserver;
    private _currentSelectionRange;
    textEditionMode: true | "plaintext-only";
    private _disabled;
    selectionChange$: EventEmitter<void>;
    get disabled(): boolean;
    set disabled(value: boolean);
    get empty(): boolean;
    get shouldLabelFloat(): boolean;
    private get _lineBreakNode();
    ngOnChanges(changes: SimpleChanges): void;
    setDescribedByIds(ids: string[]): void;
    onContainerClick(event?: MouseEvent): void;
    writeValue(obj: any): void;
    setDisabledState?(isDisabled: boolean): void;
    onChangeFn: (value: any) => void;
    registerOnChange(fn: any): void;
    onTouchedFn: () => void;
    registerOnTouched(fn: any): void;
    ngOnDestroy(): void;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    onGlobalSelectionChange: () => void;
    onKeyDown(event: KeyboardEvent): void;
    serializeNodesContent(elements: Node[]): string;
    deSerializeContent(content: string, excludedPlugins?: IExtendedTextAreaPlugin[]): [string | ComponentRef<ITextAreaInsertable> | HTMLElement];
    insertSerializedContent(text?: string): void;
    insertContentOnSelection(content: [string | ComponentRef<ITextAreaInsertable> | HTMLElement]): void;
    insertTextInSelection(text: string): void;
    insertComponentInSelection(component: ComponentRef<ITextAreaInsertable>): void;
    wrapComponentForInsertion(component: ComponentRef<ITextAreaInsertable>): HTMLElement;
    insertNodeInSelection(htmlNode: Node): void;
    setComponentActive(comp: ComponentRef<ITextAreaInsertable>, params?: unknown, exclusive?: boolean): void;
    clearBuffer(): void;
    private _setupBufferObserver;
    private _toggleBrHack;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<EtaEditorComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<EtaEditorComponent, "atom-eta-editor", never, { "plugins": { "alias": "plugins"; "required": false; }; "maxBufferHeightCssExpr": { "alias": "maxBufferHeightCssExpr"; "required": false; }; "minBufferHeightCssExpr": { "alias": "minBufferHeightCssExpr"; "required": false; }; "singleLineMode": { "alias": "singleLineMode"; "required": false; }; "spellCheck": { "alias": "spellCheck"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "required": { "alias": "required"; "required": false; }; "autofilled": { "alias": "autofilled"; "required": false; }; "userAriaDescribedBy": { "alias": "userAriaDescribedBy"; "required": false; }; "toolbarActionType": { "alias": "toolbarActionType"; "required": false; "isSignal": true; }; "toolbarEnabled": { "alias": "toolbarEnabled"; "required": false; "isSignal": true; }; "helperMessage": { "alias": "helperMessage"; "required": false; "isSignal": true; }; "helperPosition": { "alias": "helperPosition"; "required": false; "isSignal": true; }; "errorContentTpl": { "alias": "errorContentTpl"; "required": false; "isSignal": true; }; "errorLargeMode": { "alias": "errorLargeMode"; "required": false; "isSignal": true; }; "toolbarActionTpl": { "alias": "toolbarActionTpl"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; }; }, {}, never, never, true, never>;
}
type ToolbarActionType = 'button' | 'select';

declare class ExtendedTextAreaComponent implements ControlValueAccessor, OnInit {
    buffer: EtaEditorComponent;
    injector: Injector;
    ngControl: NgControl | null;
    ngOnInit(): void;
    writeValue(obj: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState?(isDisabled: boolean): void;
    singleLineMode: boolean;
    plugins: IExtendedTextAreaPlugin[];
    label: string;
    placeholder: string;
    required: boolean;
    disabled: boolean;
    maxHeightCssExpr: string;
    minHeightCssExpr: string;
    spellCheck: boolean;
    toolbarEnabled: _angular_core.InputSignal<boolean>;
    helperMessage: _angular_core.InputSignal<string | undefined>;
    helperPosition: _angular_core.InputSignal<HelperPosition>;
    toolbarActionType: _angular_core.InputSignal<ToolbarActionType>;
    errorLargeMode: _angular_core.InputSignal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ExtendedTextAreaComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ExtendedTextAreaComponent, "atom-extended-text-area", never, { "singleLineMode": { "alias": "singleLineMode"; "required": false; }; "plugins": { "alias": "plugins"; "required": false; }; "label": { "alias": "label"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "required": { "alias": "required"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "maxHeightCssExpr": { "alias": "maxHeightCssExpr"; "required": false; }; "minHeightCssExpr": { "alias": "minHeightCssExpr"; "required": false; }; "spellCheck": { "alias": "spellCheck"; "required": false; }; "toolbarEnabled": { "alias": "toolbarEnabled"; "required": false; "isSignal": true; }; "helperMessage": { "alias": "helperMessage"; "required": false; "isSignal": true; }; "helperPosition": { "alias": "helperPosition"; "required": false; "isSignal": true; }; "toolbarActionType": { "alias": "toolbarActionType"; "required": false; "isSignal": true; }; "errorLargeMode": { "alias": "errorLargeMode"; "required": false; "isSignal": true; }; }, {}, never, ["[atom-eta-errors]", "[atom-eta-toolbar-action]"], true, never>;
}

declare class AtomExtendedTextAreaPlugins {
    static Emoji(): IExtendedTextAreaPlugin;
    static BasicRichText(): IExtendedTextAreaPlugin;
    static TextLimiter(maxLength?: number, showLabel?: boolean): IExtendedTextAreaPlugin;
    static JsonContentFormatter(): IExtendedTextAreaPlugin;
    static XmlContentFormatter(): IExtendedTextAreaPlugin;
    static JsonAndXmlFormatter(): IExtendedTextAreaPlugin;
    private static createFormatterPlugin;
}

declare const ATOM_ETA_PLUGINS_CONFIG: InjectionToken<ExtendedTextAreaPluginsConfig>;

export { ATOM_ETA_PLUGINS_CONFIG, AtomExtendedTextAreaPlugins, CustomChipComponent, EmojiPickerComponent, EtaEditorComponent, ExtendedTextAreaComponent, SelectSearchV2Component, SpanEllipseComponent };
export type { ExtendedTextAreaPluginsConfig, ExtendedTextAreaToolbarItem, GroupConfig, GroupsConfigMap, IExtendedTextAreaPlugin, ITextAreaInsertable };
