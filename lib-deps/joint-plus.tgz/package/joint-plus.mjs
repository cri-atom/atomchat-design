import {
    dia as dia$1,
    util,
    g,
    V,
    mvc,
    elementTools as elementTools$1,
    linkTools,
    env,
    connectors,
    layout as layout$1,
    shapes as shapes$1
} from "@joint/core";

export {
    V,
    Vectorizer,
    anchors,
    config,
    connectionPoints,
    connectionStrategies,
    connectors,
    env,
    g,
    highlighters,
    linkAnchors,
    linkTools,
    mvc,
    routers,
    setTheme,
    util,
    version
} from "@joint/core";
var Element = dia$1.Element, ElementView = dia$1.ElementView, ElementViewPrototype = ElementView.prototype;
let Record = Element.define("standard.Record", {
    size: {width: 100},
    padding: 0,
    scrollTop: null,
    items: [],
    itemHeight: 20,
    itemOffset: 20,
    itemMinLabelWidth: 10,
    itemButtonSize: 10,
    itemIcon: {width: 16, height: 16, padding: 2},
    itemOverflow: !1,
    itemAboveViewSelector: "root",
    itemBelowViewSelector: "root",
    attrs: {
        root: {cursor: "move"},
        wrapper: {scrollable: !0},
        bodiesGroups: {fill: "transparent", stroke: "none"},
        labelsGroups: {fill: "#333333"},
        buttonsGroups: {fill: "transparent", stroke: "#333333", strokeWidth: 1},
        forksGroups: {stroke: "#333333"},
        groups: {groupPosition: !0},
        itemBodies: {groupWidth: !0, itemHighlight: {fill: "#eeeeee"}},
        itemLabels: {
            fontSize: 16,
            textVerticalAnchor: "middle",
            itemText: {textWrap: !0, ellipsis: !0},
            itemHighlight: {fill: "red"}
        }
    }
}, {
    markup: [],
    metrics: null,
    markupAttributes: ["items", "itemHeight", "itemOffset", "itemIcon", "itemMinLabelWidth", "itemButtonSize", "itemOverflow", "padding"],
    initialize: function () {
        dia$1.Element.prototype.initialize.apply(this, arguments), this.on("change", this.onChange, this), this.buildMarkup()
    },
    anyHasChanged: function (t) {
        return !!Array.isArray(t) && t.some(function (t) {
            return this.hasChanged(t)
        }, this)
    },
    onChange: function (t, e) {
        e.record !== this.id && this.hasChanged("markup") && error$1("Markup can not be modified."), this.anyHasChanged(this.markupAttributes) && this.buildMarkup(e)
    },
    getPadding: function () {
        return util.normalizeSides(this.attributes.padding)
    },
    buildMarkup: function (t) {
        var e = this.metrics = {}, i = e.items = {}, n = this.attributes, o = n.itemHeight, s = n.itemOffset,
            r = !!n.itemOverflow, a = n.items, l = (a = Array.isArray(a) ? a : []).length, h = 0,
            c = util.cloneDeep(this.markup),
            d = (Array.isArray(c) || error$1("Expects Prototype JSON Markup."), this.getPadding()), u = 0, p = [];
        c.push({tagName: "g", selector: "wrapper", children: p});
        for (var g = 0; g < l; g++) {
            for (var m = [], f = [], v = [], y = [], x = [], b = Array.from(a[g]), w = this.createQueue(b, 0, [], null), S = 0, P = 0; 0 < w.length;) {
                var C = w.pop(), A = C.path, k = C.level, E = C.item, C = C.parent,
                    B = (0 === k && A.splice(1, 0, g), E.id), L = -1 !== k, T = E.height || o, $ = E.icon, D = E.items,
                    z = !!E.highlighted, M = !!E.collapsed, R = Array.isArray(D) && 0 < D.length,
                    C = (B || error$1("Item id required."), i.hasOwnProperty(B) && error$1("Duplicated item id."), i[B] = {
                        path: A,
                        visible: L,
                        parent: C,
                        label: E.label,
                        height: T,
                        group: g,
                        hasSubItems: R,
                        highlighted: z,
                        collapsed: M
                    });
                R && (C.children = D.map(function (t) {
                    return t.id
                }), Array.prototype.push.apply(w, this.createQueue(D, M || !L ? -1 : k + 1, A, B))), L && (C.x = (z = s * k) + s, C.y = S, C.cx = z + s / 2, C.cy = S + T / 2, C.span = E.span || 1, B && (D = this.getItemBodyMarkup(E, z, S, g, r && 0 === g ? d.left : 0), m.push(D), A = this.getItemLabelMarkup(E, z, S, g), f.push(A), R && (v.push(this.getButtonMarkup(E, z, S, g)), M || x.push(B)), $) && (y.push(this.getIconMarkup(E, z, S, g)), C.x += n.itemIcon.width + n.itemIcon.padding), P = Math.max(P, C.x + n.itemMinLabelWidth), S += T)
            }
            u = Math.max(P, u), h = Math.max(h, S), b = [];
            p.push({
                tagName: "g",
                selector: this.getSelector("group", g),
                groupSelector: "groups",
                attributes: {"record-group": g},
                children: b
            }), b.push({
                tagName: "g",
                selector: this.getSelector("bodiesGroup", g),
                groupSelector: "bodiesGroups",
                children: m
            }, {
                tagName: "g",
                selector: this.getSelector("labelsGroup", g),
                groupSelector: "labelsGroups",
                children: f
            }), 0 < x.length && b.push({
                tagName: "g",
                selector: this.getSelector("forksGroup", g),
                groupSelector: "forksGroups",
                children: x.map(this.getForkMarkup, this)
            }), 0 < v.length && b.push({
                tagName: "g",
                selector: this.getSelector("buttonsGroup", g),
                groupSelector: "buttonsGroups",
                children: v
            }), 0 < y.length && b.push({
                tagName: "g",
                selector: this.getSelector("iconsGroup", g),
                groupSelector: "iconsGroups",
                children: y
            })
        }
        e.padding = d, e.groupsCount = l, e.overflow = r, e.minHeight = h + d.top + d.bottom, e.minWidth = u * l + d.left + d.right;
        e = util.assign({record: this.id, dry: !0}, t);
        this.set("markup", c, e), this.autoresize(e)
    },
    autoresize: function (t) {
        var e = this.getMinimalSize(), i = this.attributes.size, {height: i, width: n} = i,
            i = null === this.getScrollTop() ? e.height : i, n = Math.max(n, e.width);
        this.resize(n, i, t)
    },
    getMinimalSize: function () {
        var t = this.metrics;
        return {width: t.minWidth, height: t.minHeight}
    },
    removeInvalidLinks: function (e) {
        var t = this.graph;
        return t ? t.getConnectedLinks(this).filter(this.isLinkInvalid, this).map(function (t) {
            return t.remove(e)
        }) : []
    },
    isLinkInvalid: function (t) {
        var e = this.id, i = this.metrics.items, n = t.source(), o = n.port;
        return !((n.id !== e || !o || i[o] || this.hasPort(o)) && (o = (n = t.target()).port, n.id !== e || !o || i[o] || this.hasPort(o)))
    },
    createQueue: function (i, n, o, s) {
        var r = i.length;
        return Array.from({length: r}, function (t, e) {
            e = r - e - 1;
            return {path: o.concat(["items", e]), item: i[e], level: n, parent: s}
        })
    },
    getGroupSelector: function (t) {
        for (var e = Array.prototype.slice.call(arguments, 1), i = [t], n = 0, o = e.length; n < o; n++) {
            var s = e[n];
            if (null != s) for (var r = 0, a = (s = Array.isArray(s) ? s : [s]).length; r < a; r++) i.push(this.getSelector(t, s[r]))
        }
        return i
    },
    getItemLabelMarkup: function (t, e, i, n) {
        var o = this.attributes, s = o.itemOffset, r = t.height || o.itemHeight, a = t.id, e = e + s;
        return t.icon && (e += o.itemIcon.width + 2 * o.itemIcon.padding), {
            tagName: "text",
            className: "record-item-label",
            selector: this.getSelector("itemLabel", a),
            groupSelector: this.getGroupSelector("itemLabels", n, t.group),
            attributes: {x: e, y: i + r / 2, "item-id": a}
        }
    },
    getItemBodyMarkup: function (t, e, i, n, o) {
        var s = 0, o = (o && (s -= o), {x: s, y: i, height: t.height || this.attributes.itemHeight, "item-id": t.id}),
            s = t.span;
        return s && (o["item-span"] = s), {
            tagName: "rect",
            selector: this.getSelector("itemBody", t.id),
            groupSelector: this.getGroupSelector("itemBodies", n, t.group),
            className: "record-item-body",
            attributes: o
        }
    },
    getButtonMarkup: function (t, e, i) {
        var n = this.attributes, o = n.itemButtonSize, s = t.height || n.itemHeight;
        return {
            tagName: "path",
            className: "record-item-button",
            attributes: {
                d: this.getButtonPathData(e + n.itemOffset / 2, i + s / 2, o / 2, t.collapsed),
                "item-id": t.id,
                cursor: "pointer",
                "shape-rendering": "geometricprecision"
            }
        }
    },
    getIconMarkup: function (t, e, i, n) {
        var o = this.attributes, s = o.itemOffset, r = o.itemIcon, o = t.height || o.itemHeight;
        return {
            tagName: "image",
            className: "record-item-icon",
            selector: this.getSelector("itemIcon", t.id),
            groupSelector: this.getGroupSelector("itemIcons", n, t.group),
            attributes: {
                x: e + s + r.padding,
                y: i + (o - r.height) / 2,
                width: r.width,
                height: r.height,
                "xlink:href": t.icon,
                "item-id": t.id
            }
        }
    },
    getForkMarkup: function (t) {
        return {tagName: "path", attributes: {d: this.getForkPathData(t), fill: "none"}}
    },
    getButtonPathData: function (t, e, i, n) {
        var o = ["M", t - i, e - i, t + i, e - i, t + i, e + i, t - i, e + i, "Z", "M", t - i / 2, e, t + i / 2, e];
        return n && Array.prototype.push.apply(o, ["M", t, e - i / 2, t, e + i / 2]), o.join(" ")
    },
    getForkPathData: function (t) {
        var e = this.metrics.items;
        if (!e) return null;
        var i = e[t];
        if (!i) return null;
        var n = i.children;
        if (!n || 0 === n.length) return null;
        for (var o = this.attributes.itemButtonSize, s = [], r = 0, a = n.length; r < a; r++) {
            var l, h = (l = e[n[r]]).cx + (l.hasSubItems ? -1 : 1) * o / 2;
            s.push("M", i.cx, l.cy, h, l.cy)
        }
        return s.push("M", i.cx, i.cy + o / 2, i.cx, l.cy), s.join(" ")
    },
    item: function (t, e, i) {
        t = this.getItemPathArray(t);
        return t ? void 0 === e ? this.prop(t) : this.prop(t, e, i) : null
    },
    toggleItemCollapse: function (t, e) {
        var i, t = this.getItemPathArray(t);
        return t && (t.push("collapsed"), i = !!this.prop(t), this.prop(t, !i, e)), this
    },
    toggleItemHighlight: function (t, e) {
        var i, t = this.getItemPathArray(t);
        return t && (t.push("highlighted"), i = !!this.prop(t), this.prop(t, !i, e)), this
    },
    isItemVisible: function (t) {
        return this.getItemCacheAttribute(t, "visible")
    },
    isItemCollapsed: function (t) {
        return this.getItemCacheAttribute(t, "collapsed")
    },
    isItemHighlighted: function (t) {
        return this.getItemCacheAttribute(t, "highlighted")
    },
    getItemParentId: function (t) {
        return this.getItemCacheAttribute(t, "parent")
    },
    getItemGroupIndex: function (t) {
        return this.getItemCacheAttribute(t, "group")
    },
    getItemPathArray: function (t) {
        t = this.getItemCacheAttribute(t, "path");
        return t ? t.slice() : null
    },
    getItemSide: function (t) {
        var e = this.getItemGroupIndex(t);
        if (null === e) return null;
        var i = this.metrics, n = i.groupsCount;
        if (1 < n) {
            if (0 === e) return "left";
            if (e + i.items[t].span - 1 == n - 1) return "right"
        }
        return "middle"
    },
    getItemCacheAttribute: function (t, e) {
        return e && (t = this.getItemCache(t)) ? t[e] : null
    },
    getItemCache: function (t) {
        var e = this.metrics.items;
        return e && e[t] || null
    },
    getItemBBox: function (t) {
        var e, i, n, t = this.getItemCache(t);
        return t ? ({x: t, y: e, width: i, height: n} = t, new g.Rect(t, e, i, n)) : null
    },
    getSelector: function (t, e) {
        return t + "_" + e
    },
    removeItem: function (t, e) {
        var i, n, t = this.getItemPathArray(t);
        return t && (i = t.pop(), 1 < (n = this.prop(t).slice()).length ? (n.splice(i, 1), this.prop(t, n, util.assign({rewrite: !0}, e))) : 2 < t.length ? this.removeProp(t, e) : (i = t.pop(), (n = this.get("items").slice()).splice(i, 1, []), this.prop(t, n, util.assign({rewrite: !0}, e)))), this
    },
    addNextSibling: function (t, e, i) {
        var n = this.getItemPathArray(t);
        return n ? (t = this.getItemParentId(t) || this.getItemGroupIndex(t), n = n[n.length - 1] + 1, this.addItemAtIndex(t, n, e, i)) : this
    },
    addPrevSibling: function (t, e, i) {
        var n = this.getItemPathArray(t);
        return n ? (t = this.getItemParentId(t) || this.getItemGroupIndex(t), n = n[n.length - 1], this.addItemAtIndex(t, n, e, i)) : this
    },
    addItemAtIndex: function (t, e, i, n) {
        if (!i) return this;
        switch (typeof t) {
            case"number":
                var o = this.prop("items"), s = ["items", Math.min(Math.max(t, 0), o.length)];
                break;
            case"string":
                if (!(s = this.getItemPathArray(t))) return this;
                s.push("items");
                break;
            default:
                error$1("Requires an item id.")
        }
        var r = this.prop(s), r = Array.isArray(r) ? r.slice() : [], e = Math.min(Math.max(e, 0), r.length);
        return r.splice(e, 0, i), this.prop(s, r, util.assign({rewrite: !0}, n))
    },
    toJSON: function () {
        var t = dia$1.Element.prototype.toJSON.apply(this, arguments);
        return delete t.markup, t
    },
    getItemViewSign: function (t) {
        this.isItemVisible(t) || error$1(`Item "${t}" does not exist or is not visible.`);
        var e, {attributes: i, metrics: n} = this, {y: t, height: o} = n.items[t], s = this.getScrollTop();
        return null === s ? 0 : (i = i.size.height, {
            top: n,
            bottom: e
        } = n.padding, t - s < 0 ? -1 : i - n - e - (t + o - s) < 0 ? 1 : 0)
    },
    isItemInView: function (t) {
        return 0 === this.getItemViewSign(t)
    },
    isEveryItemInView: function () {
        var t, e;
        return null === this.getScrollTop() || (t = this.metrics.minHeight, e = this.size().height, t <= e)
    },
    clampScrollTop: function (t) {
        var e = this.size().height, i = this.metrics.minHeight;
        return Number.isFinite(t) ? Math.min(Math.max(t, 0), Math.max(i - e, 0)) : null
    },
    getScrollTop() {
        return this.clampScrollTop(this.get("scrollTop"))
    },
    setScrollTop(t, e) {
        var i = this.get("scrollTop"), t = this.clampScrollTop(t);
        i !== t && this.set("scrollTop", t, e)
    }
}, {
    attributes: {
        "item-text": {
            set: function (t, e, i, n) {
                if (!util.isPlainObject(t)) return null;
                var o, s, r, a = this.model, l = i.getAttribute("item-id"), l = a.metrics.items[l];
                l && (o = l.label, s = a.metrics.padding, a = a.metrics.groupsCount, s = (e.width - s.left - s.right) / a * l.span - (e = l.x), a = new g.Rect(e, l.y, s, l.height), e = t.textWrap ? (r = "text-wrap", util.assign({text: o}, t)) : (r = "text", o), this.getAttributeDefinition(r).set.call(this, e, a, i, n))
            }
        }, "item-highlight": {
            set: function (t, e, i, n) {
                if (!util.isPlainObject(t)) return null;
                var o = this.model, s = i.getAttribute("item-id");
                switch (o.getItemCacheAttribute(s, "highlighted")) {
                    case!0:
                        return t;
                    case null:
                    case!1:
                        return Object.keys(t).reduce(function (t, e) {
                            return !n.hasOwnProperty(e) && i.getAttribute(V.attributeNames[e]) && (t[e] = null), t
                        }, {})
                }
            }
        }, "group-width": {
            set: function (t, e, i) {
                var n = this.model.metrics, o = n.padding, s = n.groupsCount, e = (e.width - o.left - o.right) / s,
                    r = Number(i.getAttribute("item-span") || 1);
                return e *= r = isFinite(r) ? r : 1, n.overflow && (0 === (n = Number(this.findAttribute("record-group", i))) && (e += o.left), n + r === s) && (e += o.right), {width: e}
            }
        }, "group-position": {
            position: function (t, e, i) {
                var i = Number(i.getAttribute("record-group")), n = this.model.metrics, o = n.groupsCount,
                    n = n.padding, e = (e.width - n.left - n.right) / o;
                return new g.Point(n.left + i * e, n.top)
            }
        }, scrollable: {
            set: callWithScrollTop(function (t, e) {
                var {paper: {svg: i, defs: n}, model: o, cid: s} = this, s = "scroll-clip-" + s;
                let r, a = i.getElementById(s);
                a ? (a = V(a), [r] = a.children()) : (r = V("rect"), (a = V("clipPath", {id: s}, [r])).appendTo(n));
                var {padding: i, overflow: n} = o.metrics, {top: o, bottom: i, left: l, right: h} = i;
                let c = 0, d = e.width;
                return n || (c += l, d -= l + h), r.attr({
                    y: t + o,
                    x: c,
                    width: d,
                    height: Math.max(e.height - o - i, 0)
                }), {"clip-path": `url(#${s})`}
            }), position: callWithScrollTop(function (t) {
                return new g.Point(0, -t)
            })
        }
    }
}), BorderedRecord = Record.define("standard.BorderedRecord", {
    padding: 0,
    attrs: {body: {refWidth: "100%", refHeight: "100%", stroke: "#000000", fill: "#FFFFFF"}}
}, {markup: [{tagName: "rect", selector: "body"}]}), HeaderedRecord = Record.define("standard.HeaderedRecord", {
    padding: {top: 30, left: 0, right: 0, bottom: 0},
    itemAboveViewSelector: "header",
    itemBelowViewSelector: "header",
    attrs: {
        body: {refWidth: "100%", refHeight: "100%", stroke: "#000000", fill: "#FFFFFF"},
        header: {refWidth: "100%", height: 30, stroke: "#000000", fill: "transparent"},
        headerLabel: {
            refX: "50%",
            refY: 15,
            textAnchor: "middle",
            textVerticalAnchor: "middle",
            fontSize: 20,
            fill: "#333333"
        }
    }
}, {
    markup: [{tagName: "rect", selector: "body"}, {tagName: "rect", selector: "header"}, {
        tagName: "text",
        selector: "headerLabel"
    }]
});
var RecordViewPresentationAttributes = Record.prototype.markupAttributes.reduce(function (t, e) {
    return t[e] = ["UPDATE"], t
}, {scrollTop: ["UPDATE", "TOOLS"]});
let RecordView = dia$1.ElementView.extend({
    events: {
        "mousedown .record-item-button": "onItemButtonClick",
        "touchstart .record-item-button": "onItemButtonClick"
    },
    presentationAttributes: dia$1.ElementView.addPresentationAttributes(RecordViewPresentationAttributes),
    getLinkEnd: function (t, ...e) {
        var i = {id: this.model.id}, n = this.findAttribute("item-id", t) || this.findAttribute("port", t);
        return n && (i.port = n), this.customizeLinkEnd(i, t, ...e)
    },
    getMagnetFromLinkEnd: function (t) {
        for (var e = t.port, i = this.model; e && !i.isItemVisible(e);) e = i.getItemParentId(e);
        if (!e) return ElementViewPrototype.getMagnetFromLinkEnd.apply(this, arguments);
        let n;
        switch (i.getItemViewSign(e)) {
            case-1:
                n = String(i.get("itemAboveViewSelector"));
                break;
            case 1:
                n = String(i.get("itemBelowViewSelector"));
                break;
            default:
                n = i.getSelector("itemBody", e)
        }
        return this.findNode(n)
    },
    onItemButtonClick: function (t) {
        2 !== t.button && (t.stopPropagation(), t.preventDefault(), t = t.currentTarget.getAttribute("item-id"), this.model.toggleItemCollapse(t, {ui: !0}))
    }
}), BorderedRecordView = RecordView, HeaderedRecordView = RecordView;

function error$1(t) {
    throw new Error("shapes.standard.Record: " + t)
}

function callWithScrollTop(i) {
    return function (t, ...e) {
        if (t) return t = this.model, null !== (t = t.getScrollTop()) ? i.call(this, t, ...e) : void 0
    }
}

var standardRappid = {
    __proto__: null,
    BorderedRecord: BorderedRecord,
    BorderedRecordView: BorderedRecordView,
    HeaderedRecord: HeaderedRecord,
    HeaderedRecordView: HeaderedRecordView,
    Record: Record,
    RecordView: RecordView
};
let xmlns = 'xmlns="http://www.w3.org/2000/svg"';

function buildGatewayIcons({color: t = "#000", svg: e = !1} = {}) {
    let i = {
        exclusive_blank: null,
        exclusive: `<svg ${xmlns} viewBox="12 12 26 26"><path fill="${t}" stroke="${t}" d="M18.25 17.063L23.5 25.5l-5.25 8.438h4l3.25-5.25 3.25 5.25h3.906L27.438 25.5l5.218-8.438H28.75l-3.25 5.25-3.25-5.25h-4z"/></svg>`,
        inclusive: `<svg ${xmlns} viewBox="12 12 26 26"><circle cx="25" cy="25" r="9.429" fill="none" stroke="${t}" stroke-width="3"/></svg>`,
        parallel: `<svg ${xmlns} viewBox="12 12 26 26"><path fill="${t}" stroke="${t}" stroke-width="1.4" d="M16.388 21.821v5.625h5.86v6.328h5.624v-6.328H34.2v-5.625h-6.328v-5.86h-5.625v5.86z"/></svg>`,
        event: `<svg ${xmlns} viewBox="12 12 26 26"><circle stroke-width="1.4" cx="25" cy="25" r="12.121" fill="none" stroke="${t}"/><circle stroke-width="1.4" cx="25" cy="25" r="10.121" fill="none" stroke="${t}"/><path fill="none" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.4" d="M29.828 31.845h-9.069l-2.801-8.625 7.337-5.33 7.335 5.33-2.802 8.625z"/></svg>`,
        exclusive_event: `<svg ${xmlns} viewBox="12 12 26 26"><circle stroke-width="1.4" cx="25" cy="25" r="12.121" fill="none" stroke="${t}"/><path fill="none" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.4" d="M29.828 31.845h-9.069l-2.801-8.625 7.337-5.33 7.335 5.33-2.802 8.625z"/></svg>`,
        parallel_event: `<svg ${xmlns} viewBox="12 12 26 26"><circle stroke-width="1.4" cx="25" cy="25" r="12.121" fill="none" stroke="${t}"/><path fill="none" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.4" d="M16.388 21.821v5.625h5.86v6.328h5.624v-6.328H34.2v-5.625h-6.328v-5.86h-5.625v5.86z"/></svg>`,
        complex: `<svg ${xmlns} viewBox="13 13 25 25"><path fill="none" stroke="${t}" stroke-width="4" d="M16.25 25.5h19m-9.75-9.25v19m-6.644-2.96L32.29 18.857m-13.435.353L32.29 32.644"/></svg>`
    };
    if (e) return i;
    let n = {};
    return Object.keys(i).forEach(t => {
        n[t] = "data:image/svg+xml," + encodeURIComponent(i[t])
    }), n
}

function buildActivityMarkers({color: t = "#000", svg: e = !1} = {}) {
    let i = {
        none: null,
        parallel: `<svg ${xmlns} viewBox="-3 -3 16 16"><path fill="none" stroke="${t}" stroke-width="2" d="M0 0v10M3 0v10M6 0v10"/></svg>`,
        sequential: `<svg ${xmlns} viewBox="-3 -3 16 16"><path fill="none" stroke="${t}" stroke-width="2" d="M0 2h10M0  5h10M0 8h10"/></svg>`,
        "sub-process": `<svg ${xmlns} viewBox="-2 -2 14 14"><path fill="none" stroke="${t}" stroke-width="1" d="M0 0h10v10H0zm5 2v6M2 5h6"/></svg>`,
        compensation: `<svg ${xmlns} viewBox="8 8 24 24"><path fill="none" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 13.438v13.124L12.437 20 19 13.437m6.563 0v13.126L19 20l6.563-6.563z"/></svg>`,
        "ad-hoc": `<svg ${xmlns} viewBox="0 0 2000 2000"><path fill="${t}" d="M300 1039.87c58.332-138.228 134.894-282.23 266.546-360.085c97.784-58.392 218.701-22.42 308.428 34.819c138.188 85.207 246.292 211.842 382.606 299.507c82.335 48.265 184.733 8.718 244.748-58.056c72.401-84.446 155.215-164.023 197.672-269.981v330.038c-61.331 121.67-140.231 248.152-266.392 307.169c-103.228 44.44-223.148 17.789-312.524-46.586c-131.02-87.979-227.486-223.69-369.854-294.78c-69.172-36.004-157.377-27.545-215.331 26.623C431.412 1101.042 371.534 1231.858 300 1350v-310.13z"/></svg>`,
        loop: `<svg ${xmlns} viewBox="0 0 2000 2000"><path fill="${t}" d="M1057.07 410.836C805.11 407.3 563.447 583.065 491.134 824.983c-55.584 173.977-23.105 373.061 85.522 520.027l-269.086-52.09l-22.804 117.814l483.865 93.664l93.687-479.986l-117.779-22.988l-56.861 291.316c-138.733-165.6-136.73-427.773 4.367-591.379c137.417-171.716 399.203-221.007 590.733-114c183.232 94.568 284.888 318.597 234.896 518.746c-44.77 208.91-247.404 367.34-460.604 363.053c-55.485-3.935-83.374 76.196-37.436 107.561c40.104 24.986 90.846 7.364 134.808 4.475c248.181-37.748 457.52-249.452 489.52-498.91c36.994-238.025-91.384-488.935-304.803-600.241c-86.168-46.769-184.068-71.364-282.089-71.21z"/></svg>`
    };
    if (e) return i;
    let n = {};
    return Object.keys(i).forEach(t => {
        n[t] = "data:image/svg+xml," + encodeURIComponent(i[t])
    }), n
}

function buildActivityIcons({color: t = "#000", svg: e = !1} = {}) {
    let i = {
        none: null,
        "business-rule": `<svg ${xmlns} viewBox="5 5 25 20"><path fill="${t}" stroke="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.2" d="m 8,8 0,4 20,0 0,-4 z"/><path stroke="${t}" fill="none" d=" m 8,8 0,12 20,0 0,-12 zm 0,8 l 20,0 m -13,-4 l 0,8"/></svg>`,
        manual: `<svg ${xmlns} viewBox="0 0 2000 2000"><path d="M919.379 382.988c-22.3.007-42.953 8.258-60.567 19.616l-.029.017-.027.02c-94.694 61.32-418.867 286.29-490.127 335.2l-.002.003h-.002c-64.371 44.196-107.733 110.904-132.662 189.935l-.004.016-.004.014c-25.952 82.515-22.622 172.403-22.371 247.685l.002.02v.02c.255 56.685 1.606 106.154 16.309 166.148l.003.015c21.373 87.802 62.768 151.336 121.23 190.285 58.46 38.948 130.615 52.768 211.575 53.018 292.284 1.097 584.741 1.49 877.182 0h.05c32.21-.211 62.96-13.752 82.135-37.678 19.174-23.923 27.017-54.865 27.43-88.81.29-22.768-2.91-44.287-10.307-63.512h32.375c31.532 0 60.434-8.984 81.153-27.916 20.711-18.926 31.304-44.62 36.808-71.68v-.007c7.683-37.64 4.055-74.807-10.916-105.997 32.946-2.661 62.034-15.102 80.74-37.906 21.024-25.627 27.148-58.205 27.256-92.72.115-36.034-8.629-70.421-28.812-97.766s-53.772-45.956-91.567-46.01H1666.21c-13.76-.011-26.16.008-41.781 0 7.516-18.744 10.82-39.826 10.752-62.006v-.113c-.228-35.772-9.251-69.954-29.535-97.127-20.284-27.173-53.809-45.753-91.586-45.754-224.42-.885-446.252 2.157-634.903 1.203 9.83-9.885 19.378-19.525 29.871-29.96 32.482-32.304 63.7-62.743 79.827-83.612 38.555-49.623 44.307-116.852 11.85-166.305-17.114-26.143-42.208-43.832-69.151-47.513a89.543 89.543 0 00-10.012-.8v.003a90.145 90.145 0 00-2.162-.026zm.547 70.028a17.31 17.31 0 012.148.152c5.305.725 10.986 2.62 20.07 16.506l.018.025.016.026c12.691 19.326 12.131 58.305-8.623 84.992l-.035.045-.036.045c-7.546 9.77-41.454 44.616-73.818 76.802-32.364 32.187-63.134 61.896-78.357 80.442-14.557 17.734-9.216 32.647-5.268 41.982 3.948 9.335 8.465 20.237 28.598 25.02 6.028 1.432 6.36 1.02 8.289 1.152 1.929.133 3.923.224 6.267.309 4.689.169 10.688.297 18.094.406 226.465 1.38 450.423-1.24 676.709-.92h.063c17.211 0 26.557 5.657 35.492 17.627 8.929 11.962 15.468 31.813 15.629 55.652.066 24.73-5.857 39.82-13.057 48.133-7.2 8.313-16.845 13.52-37.475 13.588H1030v70h484.791c66.478.006 101.54-.042 151.363 0 17.308.03 26.53 5.662 35.324 17.578 8.8 11.922 15.21 31.827 15.133 55.975v.002c-.08 25.822-5.346 41.196-11.375 48.545-6.029 7.349-14.638 12.732-39.482 12.902-8.43.058-68.808.014-93.863.043-.397-.005-.786-.042-1.184-.043-180.227-.85-360.455-.002-540.682-.002H1030l-.025 70h.025c.043 0 382.517.239 541.33.047 19.7.279 31.511 8.21 40.934 23.601 9.563 15.621 14.323 40.11 8.68 67.756v.028c-3.737 18.38-9.413 28.473-15.436 33.976-6.023 5.504-14.335 9.592-33.934 9.592-180.523-.086-361.044-.452-541.568 0h-.092l.092 70h409.414c14.707.096 21.247 4.008 27.96 12.977 6.715 8.968 12.44 25.642 12.132 49.652v.025c-.284 23.412-5.952 38.272-12.057 45.889-6.105 7.617-12.405 11.357-27.973 11.459-292.123 1.488-584.356 1.097-876.51 0h-.025c-73.053-.223-130.456-12.932-173-41.275-42.55-28.344-73.607-72.869-92.039-148.598l-.008-.03-.005-.029c-12.87-52.492-14.06-94.01-14.311-149.81v-.041c-.256-76.57-1.724-160.05 19.146-226.408 21.392-67.802 55.988-119.253 105.512-153.256l.004-.002c72.125-49.505 398.23-275.66 488.5-334.12l.004-.001c8.476-5.465 15.5-7.79 20.719-8.303.87-.086 1.689-.122 2.457-.113z" fill="${t}" /></svg>`,
        receive: `<svg ${xmlns} viewBox="10 10 20 20"><path fill="none" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.2" d="M12.5 15.313v9.374h15v-9.375zm0 0l7.5 5.624 7.5-5.625"/></svg>`,
        script: `<svg ${xmlns} viewBox="0 0 2000 2000"><path d="M759.41 378l-8.262 4.904-2.699 1.604C631.658 453.72 551.284 517.185 498.23 579.16c-53.13 62.06-78.817 124.548-79.547 184.787-1.454 119.88 86.972 209.719 165.425 290.067 78.394 80.286 148.323 156.002 154.905 218.664 3.354 31.938-4.195 64.019-39.02 107.943-34.678 43.74-97.616 96.128-198.24 154.785L353.193 1622h916.854l10.85-6.313.011-.01c106.636-62.16 178.477-119.59 224.254-177.33 45.914-57.91 64.594-118.499 58.62-175.378-11.838-112.702-103.646-194.827-180.829-273.873-77.243-79.108-139.852-153.721-139-224.024.43-35.49 14.072-75.084 57.219-125.484 43.073-50.314 115.696-109.181 227.031-175.158v-.002L1674.045 378H759.41zm25.842 92.918h564.643c-49.73 37.078-89.049 72.898-119.307 108.242-53.13 62.06-78.817 124.548-79.547 184.787-1.453 119.882 86.977 209.72 165.43 290.067 78.393 80.286 148.316 156 154.898 218.664 3.355 31.938-4.193 64.019-39.017 107.943-33.397 42.123-93.456 92.386-187.79 148.461h-566.09c39.27-30.627 70.469-60.635 94.33-90.732 45.914-57.911 64.594-118.5 58.62-175.38-11.838-112.701-103.645-194.826-180.828-273.872-77.243-79.108-139.85-153.721-138.998-224.024.43-35.49 14.07-75.084 57.216-125.484 41.627-48.624 111.275-105.346 216.44-168.672zM653.13 629.393v42.92h441.398v-42.92H653.131zm-16.402 231.175v42.918h456.384v-42.918H636.73zm206.794 231.17v42.918h441.989v-42.918H843.523zm63.198 231.174v42.918h457.986v-42.918H906.721z" fill="${t}"/></svg>`,
        send: `<svg ${xmlns} viewBox="10 10 20 20"><path fill="${t}" d="M12.5 14.344l7.5 5.625 7.5-5.625zm0 .937v9.375h15v-9.375L20 20.906z"/></svg>`,
        service: `<svg ${xmlns} viewBox="0 0 2000 2000"><path d="M825.746 438.174c-.046 36.998.01 73.998.106 110.996-31.554 8.927-60.387 21.384-87.616 36.644l-79.582-78.625-148.806 149.668 79.576 78.612a393.526 393.526 0 00-35.752 87.242l-112.725.205v210.79l113.903-.411c10.416 41.298 33.084 78.425 55.662 111.623V963.094l-99.565.357V892.79l99.069-.18 5.56-28.172c8.11-41.084 24.17-80.249 47.244-115.292l15.785-23.973-69.603-68.762 50.094-50.385 69.73 68.893 23.73-15.836c36.264-23.926 75.929-39.963 115.481-48.316l27.96-5.805-.25-96.785h71.966l-.557 96.281h188.834c-17.713-21.144-91.12-48.658-118.508-56.324l.635-109.957c-78.4-.002-139.865.004-212.37-.002zm199.158 201.658l.287 110.992c-31.554 8.927-60.387 21.383-87.617 36.645l-79.584-78.625-148.806 149.668 79.578 78.611a393.515 393.515 0 00-35.754 87.244l-112.723.203v210.79l113.9-.409c8.966 31.257 21.395 59.8 36.626 86.746l-81.495 81.176 150.465 147.879 81.201-80.824c27.815 15.444 57.38 27.436 88.034 35.781l.052 114.713c72.392.634 149.467.307 211.336.3v-116.07c31.578-8.904 60.501-21.45 87.737-36.705l81.134 79.996 148.905-149.48-81.305-80.123a394.444 394.444 0 0035.799-87.399l110.379-.681v-210.586l-111.618.68c-8.972-31.287-21.22-59.637-36.654-86.762l77.121-77.319-150.38-148.13-77.022 77.285a398.637 398.637 0 00-87.68-35.639l.633-109.957h-212.549zm70.18 70h71.967l-.555 96.283 28.426 5.578c41.272 8.1 80.83 24.14 116.015 47.073l23.825 15.529 67.216-67.445 50.618 49.86-67.31 67.483 16.194 23.907c23.765 35.872 39.529 74.65 48.428 114.58l5.856 28.011 97.28-.591v70.59l-96.737.595-5.557 28.012a324.606 324.606 0 01-47.299 115.398l-15.803 24.006 71.258 70.223-50.086 50.28-71.265-70.266-23.69 15.738c-36.275 23.706-75.624 40.123-115.324 48.21l-28.144 5.622v102.215c-19.241.046-40.231.016-71.37-.028l-.045-101.449-28.271-5.521c-41.33-8.071-80.823-24.038-115.947-47.067l-23.754-15.574-71.541 71.21-50.625-49.757 71.64-71.361-16.347-24.004c-23.787-35.794-39.523-74.612-48.438-114.496l-5.85-27.926-99.564.355v-70.66l99.069-.181 5.56-28.168c8.11-41.085 24.17-80.252 47.244-115.295l15.785-23.975-69.605-68.762 50.094-50.384 69.732 68.892 23.73-15.834c36.31-23.77 74.841-39.541 115.481-48.314l27.96-5.805-.251-96.787zm37.166 257.203c-86.647 0-157.639 70.994-157.639 157.64 0 86.648 70.992 157.638 157.639 157.638s157.639-70.99 157.639-157.637-70.992-157.64-157.639-157.64zm0 70c48.816 0 87.639 38.825 87.639 87.64 0 48.817-38.823 87.638-87.639 87.638-48.816 0-87.637-38.821-87.637-87.637s38.82-87.64 87.637-87.64z" fill="${t}"/></svg>`,
        user: `<svg ${xmlns} viewBox="0 0 2000 2000"><path d="M991.75 365c-177.277 0-304.097 136.28-304.453 291.514v.088c.011 46.944 12.714 96.49 32.56 141.177 14.33 32.267 32.147 61.932 53.858 85.696-129.03 44.143-280.193 116.795-356.598 260.054L413 1151.25V1615h1157.5v-463.75l-4.117-7.72c-75.306-141.2-223.199-213.75-350.98-258.077 62.379-63.433 80.78-145.306 80.8-228.851v-.088C1295.847 501.28 1169.027 365 991.75 365zM870.709 530.299c8.194.02 17.191.294 27.11.879 79.022 4.657 105.618 18.882 126.062 32.373 20.443 13.49 34.855 26.333 88.883 27.908h.034c42.101-1.575 62.349-9.081 76.869-17.584 5.884-3.445 10.824-7.027 15.887-10.447 13.38 28.682 20.567 60.389 20.648 93.203-.028 93.44-16.092 158.876-101.768 212.424l8.381 63.17c17.833 5.415 36.266 11.357 54.975 17.873 2.613 10.9 5.632 25.196 7.662 40.394 2.127 15.923 2.964 32.489 1.652 44.928-1.311 12.439-5.173 19.154-5.851 19.832-43.547 43.547-120.847 68.943-199.252 68.943-78.406 0-155.705-25.396-199.252-68.943-.678-.678-4.54-7.393-5.852-19.832-1.311-12.439-.475-29.005 1.653-44.928 2.041-15.282 5.084-29.662 7.707-40.584 18.522-6.44 36.77-12.32 54.43-17.683l4.995-67.688c-4.068-5.217-8.213-8.673-13.16-12.385-19.121-14.345-42.31-45.903-58.69-82.785-16.373-36.868-26.517-79.01-26.532-112.744.101-40.444 10.985-79.211 30.976-112.697 3.577-1.332 7.349-2.739 11.588-4.133 14.908-4.903 35.337-9.583 70.846-9.494zM719.361 979.855c-.063.46-.133.907-.195 1.368-2.587 19.363-4.107 40.44-1.883 61.537 2.224 21.096 7.79 43.81 25.969 61.988 62.048 62.048 155.95 89.447 248.748 89.447 92.797 0 186.7-27.4 248.748-89.447 18.178-18.178 23.745-40.892 25.969-61.988 2.224-21.097.704-42.174-1.883-61.537-.051-.382-.11-.753-.162-1.133 94.334 41.369 185.515 100.615 235.828 189.074V1545H1333v-265h-70v265H719v-265h-70v265H483v-375.836c50.408-88.626 141.838-147.93 236.361-189.309z" fill="${t}" fill-rule="evenodd"/></svg>`
    };
    if (e) return i;
    let n = {};
    return Object.keys(i).forEach(t => {
        n[t] = "data:image/svg+xml," + encodeURIComponent(i[t])
    }), n
}

function buildNewIcons({color: t = "#000", svg: e = !1} = {}) {
    let i = {
        none: null,
        message1: `<svg ${xmlns} viewBox="10 10 20 20"><path fill="none" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.2" d="M12.5 15.313v9.374h15v-9.375zm0 0l7.5 5.624 7.5-5.625"/></svg>`,
        message2: `<svg ${xmlns} viewBox="10 10 20 20"><path fill="${t}" d="M12.5 14.344l7.5 5.625 7.5-5.625zm0 .937v9.375h15v-9.375L20 20.906z"/></svg>`,
        timer1: `<svg ${xmlns} viewBox="8 8 24 24"><g fill="none" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"><circle cx="20" cy="20" r="10"/><path d="M20 10v3m5-2l-1.5 3m5.5 1l-3 1.5m4 3.5h-3m2 5l-3-1.5M25 29l-1.5-3M20 30v-3m-5 2l1.5-3M11 25l3-1.5M10 20h3m-2-5l3 1.5m1-5.5l1.5 3m5.5-1l-2 7h4"/></g></svg>`,
        conditional1: `<svg ${xmlns} viewBox="6 6 28 28"><path fill="none" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M11.563 11.563h16.874v16.874H11.563V11.563m2.813 2.813h11.25m-11.25 3.75h11.25m-11.25 3.75h11.25m-11.25 3.75h11.25z"/></svg>`,
        link1: `<svg ${xmlns} viewBox="8 8 24 24"><path fill="none" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M14.406 18.125h8.438v-2.813L27.53 20l-4.687 4.688v-2.813h-9.375v-3.75"/></svg>`,
        link2: `<svg ${xmlns} viewBox="8 8 24 24"><path fill="${t}" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M14.406 18.125h8.438v-2.813L27.53 20l-4.687 4.688v-2.813h-9.375v-3.75"/></svg>`,
        signal1: `<svg ${xmlns}  viewBox="8 8 24 24"><path fill="none" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M13.17 24.851h13.706l-6.853-11.879-6.854 11.88z"/></svg>`,
        signal2: `<svg ${xmlns}  viewBox="8 8 24 24"><path fill="${t}" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M13.17 24.851h13.706l-6.853-11.879-6.854 11.88z"/></svg>`,
        error1: `<svg ${xmlns} viewBox="8 8 24 24"><path fill="none" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M26.4 15.455l-3.238 12.58L17.7 18.37 13.76 23.8l3.478-12.412 5.576 8.72 3.586-4.652z"/></svg>`,
        error2: `<svg ${xmlns} viewBox="8 8 24 24"><path fill="${t}" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M26.4 15.455l-3.238 12.58L17.7 18.37 13.76 23.8l3.478-12.412 5.576 8.72 3.586-4.652z"/></svg>`,
        escalation1: `<svg ${xmlns} viewBox="8 8 24 24"><path fill="none" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 13.219l5.625 14.062L20 20.953l-5.625 6.328z"/></svg>`,
        escalation2: `<svg ${xmlns} viewBox="8 8 24 24"><path fill="${t}" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 13.219l5.625 14.062L20 20.953l-5.625 6.328z"/></svg>`,
        termination1: `<svg ${xmlns} viewBox="8 8 24 24"><circle cx="20" cy="20" r="10.5" fill="none" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/></svg>`,
        termination2: `<svg ${xmlns} viewBox="8 8 24 24"><circle cx="20" cy="20" r="10.5" fill="${t}" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/></svg>`,
        compensation1: `<svg ${xmlns} viewBox="8 8 24 24"><path fill="none" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 13.438v13.124L12.437 20 19 13.437m6.563 0v13.126L19 20l6.563-6.563z"/></svg>`,
        compensation2: `<svg ${xmlns} viewBox="8 8 24 24"><path fill="${t}" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 13.438v13.124L12.437 20 19 13.437m6.563 0v13.126L19 20l6.563-6.563z"/></svg>`,
        cancel1: `<svg ${xmlns} viewBox="8 8 24 24"><path fill="none" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M11.284 14.274l2.867-2.868 5.735 5.735 5.735-5.735 2.868 2.868-5.735 5.735 5.735 5.735-2.868 2.867-5.735-5.735-5.735 5.735-2.867-2.867 5.735-5.735-5.735-5.735z"/></svg>`,
        cancel2: `<svg ${xmlns} viewBox="8 8 24 24"><path fill="${t}" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M11.284 14.274l2.867-2.868 5.735 5.735 5.735-5.735 2.868 2.868-5.735 5.735 5.735 5.735-2.868 2.867-5.735-5.735-5.735 5.735-2.867-2.867 5.735-5.735-5.735-5.735z"/></svg>`,
        multiple1: `<svg ${xmlns} viewBox="8 8 24 24"><path fill="none" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M24.52 26.39h-9.443l-2.918-8.982 7.64-5.55 7.64 5.551-2.919 8.98z"/></svg>`,
        multiple2: `<svg ${xmlns} viewBox="8 8 24 24"><path fill="${t}" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M24.52 26.39h-9.443l-2.918-8.982 7.64-5.55 7.64 5.551-2.919 8.98z"/></svg>`,
        parallel1: `<svg ${xmlns} viewBox="8 8 24 24"><path fill="none" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M11.344 17.203v5.625h5.86v6.328h5.624v-6.328h6.328v-5.625h-6.328v-5.86h-5.625v5.86z"/></svg>`,
        parallel2: `<svg ${xmlns} viewBox="8 8 24 24"><path fill="${t}" stroke="${t}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M11.344 17.203v5.625h5.86v6.328h5.624v-6.328h6.328v-5.625h-6.328v-5.86h-5.625v5.86z"/></svg>`
    };
    if (e) return i;
    let n = {};
    return Object.keys(i).forEach(t => {
        n[t] = "data:image/svg+xml," + encodeURIComponent(i[t])
    }), n
}

let eventIcons = buildNewIcons({color: "${color}", svg: !0}),
    gatewayIcons = buildGatewayIcons({color: "${color}", svg: !0}),
    activityMarkers = buildActivityMarkers({color: "${color}", svg: !0}),
    activityIcons = buildActivityIcons({color: "${color}", svg: !0});

function borderSetAttributeWrapper(r) {
    return function (t, e, i, n) {
        switch (t) {
            case"double":
                var o = e.clone().inflate(-3), {fill: s = "none"} = n;
                return {d: r(e, n, 0) + " " + r(o, n, 3), fill: s};
            case"thick":
                var o = e.clone().inflate(-3), {stroke: s = "black"} = n;
                return {d: r(e, n, 0) + " " + r(o, n, 3), fill: s};
            default:
                return {d: r(e, n, 0), fill: "none"}
        }
    }
}

function borderStyleSetAttribute(t, e, i, n) {
    let o;
    switch (t) {
        case"dashed":
            var {width: s, height: r} = e, s = Math.floor(Math.min(s, r) / 20);
            o = 4 * s + "," + s;
            break;
        case"dotted":
            r = n["stroke-width"];
            o = r + "," + 2 * r;
            break;
        default:
            o = "none"
    }
    return {"stroke-dasharray": o}
}

function getIconAttributes(t, e, i = {}) {
    let n;
    var i = i[t];
    return {
        "xlink:href": n = "string" == typeof i ? (e = e["icon-color"] ?? "black", (i = i.replace(/\${color}/g, e)).startsWith("<svg") ? "data:image/svg+xml," + encodeURIComponent(i) : i) : null,
        "data-icon-type": t
    }
}

function iconSetAttributeWrapper(o) {
    return function (t, e, i, n) {
        return getIconAttributes(t, n, this.model.constructor[o])
    }
}

let IconsFlows = {row: "row", column: "column"}, IconsOrigins = {
    topLeft: "left-top",
    bottomLeft: "left-bottom",
    topRight: "right-top",
    bottomRight: "right-bottom",
    topMiddle: "top",
    bottomMiddle: "bottom",
    rightMiddle: "right",
    leftMiddle: "left",
    center: "center"
}, IconsOriginsFunctions = Object.keys(IconsOrigins).reduce((t, e) => (t[IconsOrigins[e]] = e, t), {});

function iconsSetAttributeWrapper(h) {
    return function (t, e, i, r) {
        var n = "joint-icons", o = mvc.$.data.get(i, n), s = r["icon-color"] ?? "#333333";
        let a = r["icon-size"] ?? 30;
        var l = r["icons-flow"] ?? IconsFlows.row, s = `${t.toString()} ${s} ${a} ` + l;
        if (o !== s) {
            o = V(i);
            o.empty();
            let s = l === IconsFlows.column;
            if (!Array.isArray(t)) return;
            l = t.map((t, e) => {
                var i = V("image");
                i.attr(getIconAttributes(t, r, this.model.constructor[h]));
                let n, o;
                return o = s ? (n = 0, e * a) : (n = e * a, 0), i.attr({x: n, y: o, width: a, height: a}), i
            });
            o.append(l)
        }
        mvc.$.data.set(i, n, s)
    }
}

function iconsPositionAttribute(t, e, i, n) {
    var o = n["icon-size"] ?? 30, s = n["icons-flow"] ?? IconsFlows.row, n = n["icons-origin"] ?? IconsOrigins.topLeft;
    let r, a;
    t = Array.isArray(t) ? t.length : 0, a = s === IconsFlows.column ? t * (r = o) : (r = t * o, o), s = new g.Rect(0, 0, -r, -a);
    return n in IconsOriginsFunctions ? s[IconsOriginsFunctions[n]]() : s.center()
}

function labelTextWrap(t, e, i, n, o, s, r) {
    var a = util.clone(n), {left: l, right: h, top: c, bottom: d} = util.normalizeSides(n["label-margin"]),
        n = LabelAlignmentAnchors[n["label-alignment"]], o = new g.Rect(l, c, o - l - h, s - c - d);
    n && (a["text-anchor"] = n["text-anchor"], a["text-vertical-anchor"] = n["text-vertical-anchor"]);
    let u, p;
    return p = e.textWrap ? (u = "text-wrap", {
        text: r,
        ellipsis: e.ellipsis
    }) : (u = "text", r), t.getAttributeDefinition(u).set.call(t, p, o, i, a), n
}

let LabelAlignments = util.clone(IconsOrigins), LabelAlignmentAnchors = {
    "left-top": {"text-anchor": "start", "text-vertical-anchor": "top"},
    "left-bottom": {"text-anchor": "start", "text-vertical-anchor": "bottom"},
    "right-top": {"text-anchor": "end", "text-vertical-anchor": "top"},
    "right-bottom": {"text-anchor": "end", "text-vertical-anchor": "bottom"},
    top: {"text-anchor": "middle", "text-vertical-anchor": "top"},
    bottom: {"text-anchor": "middle", "text-vertical-anchor": "bottom"},
    right: {"text-anchor": "end", "text-vertical-anchor": "middle"},
    left: {"text-anchor": "start", "text-vertical-anchor": "middle"},
    center: {"text-anchor": "middle", "text-vertical-anchor": "middle"}
}, automaticHeaderAttributes = {
    set: function (t, e, i, n, o) {
        var o = o.model, s = o.getHeaderSide(), o = o.getHeaderSize();
        return "left" === s || "right" === s ? {width: o, height: e.height} : {width: e.width, height: o}
    }, unset: ["width", "height"], position: function (t, e, i, n, o) {
        var o = o.model, s = o.getHeaderSide(), r = o.getHeaderSize();
        switch (s) {
            case"left":
            case"top":
                return {x: 0, y: 0};
            case"right":
                return {x: e.width - r, y: 0};
            case"bottom":
                return {x: 0, y: e.height - r}
        }
    }
}, automaticHeaderTextAttributes = {
    set: function (t, e, i, n, o) {
        o = o.model, o = o.getHeaderSide();
        if ("left" === o || "right" === o) return {transform: "rotate(-90)"}
    }, unset: "transform", position: function (t, e, i, n, o) {
        var o = o.model, s = o.getHeaderSide(), r = o.getHeaderSize();
        switch (s) {
            case"left":
                return {x: r / 2, y: e.height / 2};
            case"top":
                return {x: e.width / 2, y: r / 2};
            case"right":
                return {x: e.width - r / 2, y: e.height / 2};
            case"bottom":
                return {x: e.width / 2, y: e.height - r / 2}
        }
    }
}, automaticHeaderTextWrap = {
    set: function (t, e, i, n, o) {
        var s = o.model, r = s.getHeaderSide(), a = s.getHeaderSize(), s = s.getHeaderTextMargin(),
            a = {preserveSpaces: !0, ellipsis: !0, height: Math.max(0, a - 2 * s)};
        a.width = "left" === r || "right" === r ? Math.max(0, e.height - 2 * s) : Math.max(0, e.width - 2 * s), dia$1.attributes["text-wrap"].set.call(this, a, e, i, n, o)
    }, unset: "text-wrap"
};

function getUnion(...t) {
    return g.Rect.fromRectUnion(...t.filter(t => t))
}

function setElementBBox(t, e, i, n, o, s) {
    t.set({position: {x: e, y: i}, size: {width: n, height: o}}, s)
}

function generateId() {
    return "_" + util.uuid()
}

let Event = dia$1.Element.define("bpmn2.Event", {
    size: {width: 40, height: 40},
    attrs: {
        root: {cursor: "move", magnetSelector: "background", highlighterSelector: "background"},
        background: {refCx: "50%", refCy: "50%", refRx: "50%", refRy: "50%", fill: "#FFFFFF"},
        border: {stroke: "#333333", fillRule: "evenodd", borderType: "single", borderStyle: "solid", strokeWidth: 2},
        icon: {iconColor: "#333333", iconType: "none", refX: "15%", refY: "15%", refWidth: "70%", refHeight: "70%"},
        label: {
            refDy: 10,
            refX: "50%",
            textVerticalAnchor: "top",
            textAnchor: "middle",
            fontSize: 12,
            fontFamily: "sans-serif",
            fontWeight: "bold"
        }
    }
}, {
    generateId: generateId,
    markup: [{tagName: "ellipse", selector: "background"}, {tagName: "image", selector: "icon"}, {
        tagName: "path",
        selector: "border"
    }, {tagName: "text", selector: "label"}]
}, {
    attributes: {
        "border-type": {set: borderSetAttributeWrapper(t => toEllipsePathData(t))},
        "border-style": {set: borderStyleSetAttribute},
        "icon-type": {set: iconSetAttributeWrapper("EVENT_ICONS")}
    }, EVENT_ICONS: eventIcons
});

function toEllipsePathData(t) {
    var e = t.center(), e = V("ellipse", {cx: e.x, cy: e.y, rx: t.width / 2, ry: t.height / 2});
    return V.convertEllipseToPathData(e)
}

let Gateway = dia$1.Element.define("bpmn2.Gateway", {
    size: {width: 58, height: 58},
    attrs: {
        root: {cursor: "move", magnetSelector: "body", highlighterSelector: "body"},
        body: {refPoints: "1,0,2,1,1,2,0,1", fill: "#FFFFFF", stroke: "#333333", strokeWidth: 2},
        icon: {iconColor: "#333333", refX: "19%", refY: "19%", refWidth: "62%", refHeight: "62%"},
        label: {
            refDy: 10,
            refX: "50%",
            textVerticalAnchor: "top",
            textAnchor: "middle",
            fontSize: 12,
            fontFamily: "sans-serif",
            fontWeight: "bold"
        }
    }
}, {
    generateId: generateId,
    markup: [{tagName: "polygon", selector: "body"}, {tagName: "image", selector: "icon"}, {
        tagName: "text",
        selector: "label"
    }]
}, {attributes: {"icon-type": {set: iconSetAttributeWrapper("GATEWAY_ICONS")}}, GATEWAY_ICONS: gatewayIcons});
var CYLINDER_TILT = 10;
let DataStore = dia$1.Element.define("bpmn2.DataStore", {
        size: {width: 63, height: 63},
        attrs: {
            root: {cursor: "move", magnetSelector: "body", highlighterSelector: "body"},
            body: {lateralArea: CYLINDER_TILT, fill: "#FFFFFF", stroke: "#333333", strokeWidth: 2},
            top: {
                refCx: "50%",
                cy: CYLINDER_TILT,
                refRx: "50%",
                ry: CYLINDER_TILT,
                fill: "#FFFFFF",
                stroke: "#333333",
                strokeWidth: 2
            },
            label: {
                textVerticalAnchor: "top",
                textAnchor: "middle",
                refX: "50%",
                refY: "100%",
                refY2: CYLINDER_TILT,
                fontSize: 12,
                fontFamily: "sans-serif",
                fontWeight: "bold",
                fill: "#333333",
                textWrap: {width: "200%"}
            }
        }
    }, {
        generateId: generateId,
        markup: [{tagName: "path", selector: "body"}, {tagName: "ellipse", selector: "top"}, {
            tagName: "text",
            selector: "label"
        }],
        topRy: function (t, e) {
            var i;
            return void 0 === t ? this.attr("body/lateralArea") : (i = util.isPercentage(t), this.attr({
                body: {lateralArea: t},
                top: i ? {refCy: t, refRy: t, cy: null, ry: null} : {refCy: null, refRy: null, cy: t, ry: t},
                label: {refY2: t}
            }, e))
        }
    }, {
        attributes: {
            "lateral-area": {
                set: function (t, e) {
                    var i = util.isPercentage(t), n = (i && (t = parseFloat(t) / 100), e.x), o = e.y, s = e.width,
                        e = e.height, r = i ? e * t : t, a = V.KAPPA, l = a * (s / 2), a = a * (i ? e * t : t), i = n,
                        t = n + s / 2, s = n + s, h = o + r, c = h - r, d = o + e - r, o = o + e,
                        e = ["M", i, h, "L", i, d, "C", n, d + a, t - l, o, t, o, "C", t + l, o, s, d + a, s, d, "L", s, h, "C", s, h - a, t + l, c, t, c, "C", t - l, c, i, h - a, i, h, "Z"],
                        n = h + 7, o = h + r + 7;
                    return e.push("M", s, n, "C", s, n + a, t + l, o, t, o, "C", t - l, o, i, n + a, i, n), e.push("L", i, n += 7, "C", i, n + a, t - l, o += 7, t, o, "C", t + l, o, s, n + a, s, n, "Z"), {d: e.join(" ")}
                }
            }
        }
    }), DataObject = dia$1.Element.define("bpmn2.DataObject", {
        size: {width: 48, height: 65},
        attrs: {
            root: {cursor: "move", magnetSelector: "body", highlighterSelector: "body"},
            body: {objectD: 10, fill: "#FFFFFF", stroke: "#333333", strokeWidth: 2},
            label: {
                refY: "100%",
                refY2: 10,
                refX: "50%",
                textVerticalAnchor: "top",
                textAnchor: "middle",
                fontSize: 12,
                fontFamily: "sans-serif",
                fontWeight: "bold",
                textWrap: {width: "200%"}
            },
            dataTypeIcon: {iconColor: "#333333", iconType: "none", x: 0, y: 0, width: 25, height: 25},
            collectionIcon: {
                iconColor: "#333333",
                collection: !1,
                refX: "50%",
                refY: "100%",
                y: -18,
                x: -6,
                width: 16,
                height: 16
            }
        }
    }, {
        generateId: generateId,
        markup: [{tagName: "path", selector: "body"}, {tagName: "text", selector: "label"}, {
            tagName: "image",
            selector: "dataTypeIcon"
        }, {tagName: "image", selector: "collectionIcon"}]
    }, {
        attributes: {
            "object-d": {
                set: function (t, e) {
                    var i = e.topLeft(), n = e.bottomLeft(), o = e.bottomRight(), e = e.topRight(),
                        s = e.clone().offset(-t, t), r = e.clone().offset(0, t), e = e.clone().offset(-t, 0);
                    return {d: `M ${i.serialize()} ${n.serialize()} ${o.serialize()} ${r.serialize()} ${e.serialize()} Z` + " " + (`M ${e.serialize()} ${s.serialize()} ` + r.serialize())}
                }
            },
            "icon-type": {set: iconSetAttributeWrapper("DATA_OBJECT_TYPE_ICONS")},
            collection: {set: iconSetAttributeWrapper("DATA_OBJECT_COLLECTION_ICONS")}
        },
        DATA_OBJECT_TYPE_ICONS: {none: null, input: eventIcons.link1, output: eventIcons.link2},
        DATA_OBJECT_COLLECTION_ICONS: {
            false: null,
            true: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="-3 -3 16 16"><path fill="none" stroke="${color}" stroke-width="2" d="M0 0v10M3 0v10M6 0v10"/></svg>'
        }
    }), defaultLabel = {
        markup: [{tagName: "rect", selector: "body"}, {tagName: "text", selector: "label"}],
        attrs: {
            label: {
                fill: "#333333",
                fontSize: 12,
                textAnchor: "middle",
                textVerticalAnchor: "middle",
                fontFamily: "sans-serif"
            }, body: {ref: "label", fill: "#ffffff", stroke: "none", refX: 0, refY: 0, refWidth: "100%", refHeight: "100%"}
        },
        position: {distance: .5}
    }, DataAssociation = dia$1.Link.define("bpmn2.DataAssociation", {
        attrs: {
            line: {
                connection: !0,
                stroke: "#333333",
                strokeWidth: 2,
                strokeLinejoin: "round",
                strokeDasharray: "2,5",
                targetMarker: {type: "path", d: "M 10 -7 0 0 10 7", "stroke-width": 2, fill: "none"}
            }, wrapper: {connection: !0, strokeWidth: 10, strokeLinejoin: "round"}
        }
    }, {
        generateId: generateId,
        defaultLabel: defaultLabel,
        markup: [{
            tagName: "path",
            selector: "wrapper",
            attributes: {fill: "none", cursor: "pointer", stroke: "transparent", "stroke-linecap": "round"}
        }, {tagName: "path", selector: "line", attributes: {fill: "none", "pointer-events": "none"}}]
    }), Activity = dia$1.Element.define("bpmn2.Activity", {
        size: {width: 120, height: 100},
        attrs: {
            root: {cursor: "move", magnetSelector: "background", highlighterSelector: "background"},
            background: {refWidth: "100%", refHeight: "100%", fill: "#FFFFFF", rx: 10, ry: 10},
            border: {
                stroke: "#333333",
                fillRule: "evenodd",
                borderType: "single",
                borderStyle: "solid",
                borderRadius: 10,
                strokeWidth: 2
            },
            icon: {iconColor: "#333333", iconType: "none", x: 5, y: 0, width: 30, height: 30},
            label: {
                refY: "50%",
                refX: "50%",
                textVerticalAnchor: "middle",
                textAnchor: "middle",
                fontSize: 12,
                fontFamily: "sans-serif",
                fontWeight: "bold",
                textWrap: {width: -10, height: -50, ellipsis: !0}
            },
            markers: {
                event: "element:marker:pointerdown",
                iconSize: 16,
                iconColor: "#333333",
                iconTypes: [""],
                iconsOrigin: IconsOrigins.bottomMiddle,
                iconsFlow: IconsFlows.row,
                refX: "50%",
                refY: "100%",
                refY2: -5
            }
        }
    }, {
        generateId: generateId,
        markup: [{tagName: "rect", selector: "background"}, {tagName: "image", selector: "icon"}, {
            tagName: "path",
            selector: "border"
        }, {tagName: "text", selector: "label"}, {tagName: "g", selector: "markers"}]
    }, {
        attributes: {
            "border-type": {
                set: borderSetAttributeWrapper((t, e, i) => {
                    e = e["border-radius"] ?? 0, e = Math.max(Math.min(e, 2), e - i), i = t.toJSON();
                    return i.rx = i.ry = e, V.rectToPath(i)
                })
            },
            "border-style": {set: borderStyleSetAttribute},
            "icon-type": {set: iconSetAttributeWrapper("ACTIVITY_TYPE_ICONS")},
            "icon-types": {set: iconsSetAttributeWrapper("ACTIVITY_MARKER_ICONS"), position: iconsPositionAttribute},
            "icon-size": {},
            "icons-origin": {},
            "icons-flow": {},
            "icon-color": {},
            "border-radius": {}
        }, ACTIVITY_TYPE_ICONS: activityIcons, ACTIVITY_MARKER_ICONS: util.omit(activityMarkers, "none")
    }), Conversation = dia$1.Element.define("bpmn2.Conversation", {
        size: {width: 58, height: 47},
        attrs: {
            root: {cursor: "move", magnetSelector: "body", highlighterSelector: "body"},
            body: {
                fill: "#FFFFFF",
                stroke: "#333333",
                refPoints: "1,0 3,0, 4,1 3,2 1,2 0,1, 1,0",
                strokeLinejoin: "round",
                strokeWidth: 2
            },
            markers: {
                event: "element:marker:pointerdown",
                iconSize: 16,
                iconColor: "#333333",
                iconTypes: [],
                iconsOrigin: IconsOrigins.bottomMiddle,
                iconsFlow: IconsFlows.row,
                refX: "50%",
                refY: "100%"
            },
            label: {
                refDy: 10,
                refX: "50%",
                textVerticalAnchor: "top",
                textAnchor: "middle",
                fontSize: 12,
                fontFamily: "sans-serif",
                fontWeight: "bold"
            }
        }
    }, {
        generateId: generateId,
        markup: [{tagName: "polygon", selector: "body"}, {tagName: "text", selector: "label"}, {
            tagName: "g",
            selector: "markers"
        }]
    }, {
        attributes: {
            "icon-types": {
                set: iconsSetAttributeWrapper("CONVERSATION_MARKER_ICONS"),
                position: iconsPositionAttribute
            }, "icon-size": {}, "icons-origin": {}, "icons-flow": {}, "icon-color": {}
        }, CONVERSATION_MARKER_ICONS: util.omit(activityMarkers, "none")
    }), ConversationLink = dia$1.Link.define("bpmn2.ConversationLink", {
        attrs: {
            line: {
                connection: !0,
                stroke: "#FFFFFF",
                strokeWidth: 2,
                strokeLinejoin: "round"
            },
            outline: {connection: !0, stroke: "#333333", strokeWidth: 6, strokeLinejoin: "round"},
            wrapper: {connection: !0, strokeWidth: 10, strokeLinejoin: "round"}
        }
    }, {
        generateId: generateId,
        defaultLabel: defaultLabel,
        markup: [{
            tagName: "path",
            selector: "wrapper",
            attributes: {fill: "none", cursor: "pointer", stroke: "transparent", "stroke-linecap": "round"}
        }, {tagName: "path", selector: "outline", attributes: {fill: "none", "pointer-events": "none"}}, {
            tagName: "path",
            selector: "line",
            attributes: {fill: "none", "pointer-events": "none"}
        }]
    }), setSourceMarker = dia$1.attributes["source-marker"].set, setTargetMarker = dia$1.attributes["target-marker"].set,
    FlowTypes = {sequence: "sequence", default: "default", conditional: "conditional", message: "message"},
    Flow = dia$1.Link.define("bpmn2.Flow", {
        attrs: {
            line: {
                connection: !0,
                stroke: "#333333",
                strokeWidth: 2,
                strokeLinejoin: "round",
                flowType: "sequence"
            }, wrapper: {connection: !0, strokeWidth: 10, strokeLinejoin: "round"}
        }
    }, {
        generateId: generateId,
        defaultLabel: defaultLabel,
        markup: [{
            tagName: "path",
            selector: "wrapper",
            attributes: {fill: "none", cursor: "pointer", stroke: "transparent", "stroke-linecap": "round"}
        }, {tagName: "path", selector: "line", attributes: {fill: "none", "pointer-events": "none"}}]
    }, {
        attributes: {
            "flow-type": {
                set: function (t, e, i, n) {
                    var o = n["marker-fill"] ?? "#FFFFFF", s = n["stroke-width"] ?? 2,
                        r = {"stroke-dasharray": "none", "marker-start": null, "marker-end": null};
                    let a, l;
                    switch (t) {
                        case FlowTypes.default:
                            a = {d: "M 5 -5 15 5", "stroke-width": s}, l = {type: "path", d: "M 12 -5 0 0 12 5 z"};
                            break;
                        case FlowTypes.conditional:
                            a = {d: "M 0 0 9 -5 18 0 9 5 Z", "stroke-width": s, fill: o}, l = {
                                type: "path",
                                d: "M 12 -5 0 0 12 5 z"
                            };
                            break;
                        case FlowTypes.message:
                            r["stroke-dasharray"] = "5,2", a = {
                                type: "circle",
                                cx: 5,
                                r: 5,
                                "stroke-width": s,
                                fill: o
                            }, l = {type: "path", d: "M 12 -5 0 0 12 5 z", "stroke-width": s, fill: o};
                            break;
                        default:
                            FlowTypes.sequence;
                            l = {type: "path", d: "M 12 -5 0 0 12 5 z"}
                    }
                    return a && util.assign(r, setSourceMarker.call(this, a, e, i, n)), l && util.assign(r, setTargetMarker.call(this, l, e, i, n)), r
                }
            }, "marker-fill": {}
        }, FLOW_TYPES: FlowTypes
    }), Group = dia$1.Element.define("bpmn2.Group", {
        size: {width: 120, height: 100},
        attrs: {
            root: {cursor: "move", magnetSelector: "body", highlighterSelector: "body"},
            body: {
                refWidth: "100%",
                refHeight: "100%",
                fill: "transparent",
                rx: 10,
                ry: 10,
                stroke: "#333333",
                borderStyle: "dashed",
                strokeWidth: 2,
                strokeLinecap: "square",
                pointerEvents: "none"
            },
            wrapper: {
                refX: 5,
                refY: 5,
                refWidth: -10,
                refHeight: -10,
                pointerEvents: "stroke",
                strokeWidth: 10,
                stroke: "transparent",
                fill: "none"
            },
            label: {
                refY: 6,
                refX: "50%",
                textAnchor: "middle",
                fontSize: 12,
                fontFamily: "sans-serif",
                fontWeight: "bold",
                textWrap: {width: -12, height: -12, ellipsis: !0}
            }
        }
    }, {
        generateId: generateId,
        markup: [{tagName: "rect", selector: "body"}, {tagName: "rect", selector: "wrapper"}, {
            tagName: "text",
            selector: "label"
        }]
    }, {
        attributes: {
            "border-style": {
                set: function (t, e, i, n) {
                    n = n["stroke-width"] || 1;
                    return {"stroke-dasharray": 2 * n + "," + 2 * n + "," + n / 2}
                }
            }
        }
    }), Annotation = dia$1.Element.define("bpmn2.Annotation", {
        size: {width: 80, height: 40},
        attrs: {
            root: {cursor: "move", magnetSelector: "body", highlighterSelector: "body"},
            body: {refWidth: "100%", refHeight: "100%", fill: "transparent"},
            border: {annotationD: {size: 10}, fill: "none", stroke: "#333333", strokeWidth: 2},
            label: {
                refY: 6,
                refX: 4,
                fontSize: 12,
                fontFamily: "sans-serif",
                textWrap: {width: -12, height: -12, ellipsis: !0}
            }
        }
    }, {
        generateId: generateId,
        markup: [{tagName: "rect", selector: "body"}, {tagName: "path", selector: "border"}, {
            tagName: "text",
            selector: "label"
        }]
    }, {
        attributes: {
            "annotation-d": {
                set: function (t, e) {
                    var i = t.size || 0, t = t.side, n = e.topLeft(), o = e.bottomLeft(), s = e.topRight(),
                        r = e.bottomRight();
                    switch (t) {
                        case"top":
                            var a = n.clone().offset(0, i), l = s.clone().offset(0, i);
                            return {d: `M ${a.serialize()} ${n.serialize()} ${s.serialize()} ` + l.serialize()};
                        case"right":
                            a = s.clone().offset(-i, 0), l = r.clone().offset(-i, 0);
                            return {d: `M ${a.serialize()} ${s.serialize()} ${r.serialize()} ` + l.serialize()};
                        case"bottom":
                            a = o.clone().offset(0, -i), l = r.clone().offset(0, -i);
                            return {d: `M ${a.serialize()} ${o.serialize()} ${r.serialize()} ` + l.serialize()};
                        default:
                            a = n.clone().offset(i, 0), l = o.clone().offset(i, 0);
                            return {d: `M ${a.serialize()} ${n.serialize()} ${o.serialize()} ` + l.serialize()}
                    }
                }
            }
        }
    }), AnnotationLink = dia$1.Link.define("bpmn2.AnnotationLink", {
        attrs: {
            line: {
                connection: !0,
                stroke: "#333333",
                strokeWidth: 2,
                strokeLinejoin: "round",
                strokeDasharray: "2,5"
            }, wrapper: {connection: !0, strokeWidth: 10, strokeLinejoin: "round"}
        }
    }, {
        generateId: generateId,
        defaultLabel: defaultLabel,
        markup: [{
            tagName: "path",
            selector: "wrapper",
            attributes: {fill: "none", cursor: "pointer", stroke: "transparent", "stroke-linecap": "round"}
        }, {tagName: "path", selector: "line", attributes: {fill: "none", "pointer-events": "none"}}]
    }), Pool = dia$1.Element.define("bpmn2.Pool", {
        size: {width: 600, height: 300},
        lanes: null,
        milestones: null,
        milestonesSize: 20,
        padding: 0,
        headerSize: 20,
        attrs: {
            body: {cursor: "move", refWidth: "100%", refHeight: "100%", fill: "transparent"},
            laneGroups: {laneContainerPosition: !0},
            laneHeaders: {
                fill: "#ffffff",
                stroke: "#333333",
                strokeWidth: 2,
                headerSize: !0,
                shapeRendering: "optimizespeed"
            },
            laneLabels: {
                fontSize: 14,
                fill: "#333333",
                transform: "rotate(-90)",
                textAnchor: "middle",
                textVerticalAnchor: "middle",
                labelAlignment: LabelAlignments.center,
                labelMargin: {vertical: 1, horizontal: 10},
                fontFamily: "sans-serif",
                labelPosition: !0,
                laneLabel: {textWrap: !0, ellipsis: !0}
            },
            lanes: {stroke: "#333333", strokeWidth: 2, fill: "#ffffff", laneSize: !0, shapeRendering: "optimizespeed"},
            milestoneGroups: {milestoneContainerPosition: !0},
            milestoneHeaders: {
                fill: "#ffffff",
                stroke: "#333333",
                strokeWidth: 2,
                milestoneHeaderSize: !0,
                shapeRendering: "optimizespeed"
            },
            milestoneLabels: {
                fontSize: 14,
                fill: "#333333",
                textAnchor: "end",
                textVerticalAnchor: "middle",
                labelAlignment: LabelAlignments.rightMiddle,
                labelMargin: {vertical: 1, horizontal: 10},
                fontFamily: "sans-serif",
                milestoneLabelPosition: !0,
                milestoneLabel: {textWrap: !0, ellipsis: !0}
            },
            milestoneLines: {stroke: "#333333", strokeWidth: 2, milestoneLinePosition: !0, shapeRendering: "optimizespeed"}
        }
    }, {
        metrics: null,
        generateId: generateId,
        markup: [{tagName: "rect", selector: "body"}],
        markupAttributes: ["lanes", "padding", "milestones", "headerSize", "milestonesSize"],
        initialize: function () {
            dia$1.Element.prototype.initialize.apply(this, arguments), this.on("change", this.onChange, this), this.buildMarkup()
        },
        anyHasChanged: function (t) {
            return !!Array.isArray(t) && t.some(function (t) {
                return this.hasChanged(t)
            }, this)
        },
        onChange: function (t, e) {
            e.pool !== this.id && this.hasChanged("markup") && error("Markup cannot be modified."), this.anyHasChanged(this.markupAttributes) && this.buildMarkup(e)
        },
        buildMarkup: function (t) {
            var e = util.cloneDeep(this.markup),
                i = (Array.isArray(e) || error("Expects Prototype JSON Markup."), this.attributes.lanes || [{}]),
                n = (Array.isArray(i) || error("Expects lanes to be an array."), this.attributes.milestones || []),
                o = (Array.isArray(n) || error("Expects milestones to be an array."), this.metrics = {}),
                o = (o.lanes = {}, o.lanesNameCache = {}, o.milestonesNameCache = {}, o.milestones = {}, o.totalTakenHeightSpace = 0, o.topLaneGroupsCount = i.length, o.padding = util.normalizeSides(this.attributes.padding), this.buildLanesMarkupRecursively(i, e, null, 1, 0), this.buildMilestones(n, e), util.assign({
                    pool: this.id,
                    dry: !0
                }, t));
            this.set("markup", e, o), !1 !== o.autoResize && this.autoresize(o)
        },
        buildLanesMarkupRecursively: function (t, u, p, g, m) {
            Array.isArray(t) || error("Expects lanes to be an array.");
            let f = 0;
            return t.forEach((t, e) => {
                let i = 0;
                var n, o = void 0 !== t.id && "" !== t.id ? t.id : null, s = null !== p ? p + "_" + e : "" + e,
                    r = this.getLaneGroupMarkup(s, o),
                    a = (u.push(r), Number.isFinite(t.size) ? Math.max(t.size, 0) : void 0), l = this.getLaneMarkup(s, o),
                    l = (r.children.push(l), t.label), h = "string" == typeof t.label,
                    c = h ? Number.isFinite(t.headerSize) ? Math.max(t.headerSize, 0) : this.attributes.headerSize : 0,
                    d = (h && (d = this.getHeaderMarkup(s, o), n = this.getLabelMarkup(s, o), r.children.push(d), r.children.push(n)), t.sublanes && !Array.isArray(t.sublanes) && error("Expects sublanes to be an array."), t.sublanes || []),
                    t = (d.length && (n = r.children, i = this.buildLanesMarkupRecursively(d, n, s, g + 1, d.length)), i = a && a > i ? a : i, f += i, {
                        nestLevel: g,
                        laneIndexWithinGroup: e,
                        parentId: p ? "lanes_" + p : null,
                        parentSublanesCount: m,
                        headerSize: c,
                        label: l,
                        hasLabel: h,
                        size: a,
                        takenUpSpaceByLaneAndSublanes: i,
                        sublanesCount: d.length,
                        customId: o
                    });
                this.addLaneGroupMetrics(s, t)
            }), f
        },
        buildMilestones: function (t, l) {
            let {metrics: h, attributes: e} = this;
            var i = h.padding;
            h.milestonesCount = t.length, i.top += t.length ? e.milestonesSize : 0, t.forEach((t, e) => {
                var i = t.id, n = "milestone_" + e, o = void 0 !== h.milestonesNameCache[n],
                    s = (i && (s = i !== n && void 0 !== h.milestones[i], void 0 === h.milestonesNameCache[i] && !s || error("Duplicated milestone group id: " + i), h.milestonesNameCache[i] = n), o && error("Duplicated milestone group id: " + n), this.getMilestoneGroupMarkup(e, i)),
                    o = (l.push(s), this.getMilestoneHeaderMarkup(e, i)), r = this.getMilestoneLabelMarkup(e, i),
                    a = this.getMilestoneLineMarkup(e, i);
                h.milestones[n] = {
                    label: "string" == typeof t.label ? t.label : "",
                    indexWithin: e,
                    size: Number.isFinite(t.size) ? Math.max(t.size, 0) : void 0,
                    customId: i
                }, s.children.push(a), s.children.push(o), s.children.push(r)
            })
        },
        addLaneGroupMetrics: function (t, e) {
            var i, t = "lanes_" + t, {laneSize: n, customId: o} = e, s = this.metrics;
            void 0 !== s.lanesNameCache[t] && error("Duplicated lane group id: " + t), null !== o && (i = o !== t && void 0 !== s.lanes[o], void 0 === s.lanesNameCache[o] && !i || error("Duplicated lane group id: " + o), s.lanesNameCache[o] = t), s.lanes[t] = e, Number.isFinite(n) && (s.totalTakenHeightSpace += n)
        },
        autoresize: function (t) {
            var e = this.getMinimalSize(), i = this.attributes.size;
            this.resize(Math.max(e.width, i.width), Math.max(e.height, i.height), t)
        },
        getMinimalSize: function () {
            let s = this.metrics;
            var t, e = s.padding;
            let r = 0, a = 0, i = 0;
            var n = this.attributes.milestonesSize;
            let l = s.lanes, o = s.milestones;
            return Object.keys(l).forEach(t => {
                var e = l[t];
                let i = t, n = 0;
                for (; i;) {
                    var o = s.lanes[i];
                    n += o.headerSize || 0, i = o.parentId
                }
                r = n > r ? n : r, 1 === e.nestLevel && (a += e.takenUpSpaceByLaneAndSublanes || 0)
            }), Object.keys(o).forEach(t => {
                i += o[t].size || 0
            }), t = r > i ? r : i, {
                height: (s.milestonesCount && n > a ? 0 : a) + e.top + e.bottom,
                width: t + e.left + e.right
            }
        },
        getLaneGroupMarkup: function (t, e) {
            var i = ["laneGroups"];
            return e && i.push("lanes_" + e), {
                tagName: "g",
                selector: "lanes_" + t,
                groupSelector: i,
                attributes: {laneGroupId: "lanes_" + t},
                children: []
            }
        },
        getMilestoneGroupMarkup: function (t, e) {
            var i = ["milestoneGroups"];
            return e && i.push("milestone_" + e), {
                tagName: "g",
                selector: "milestone_" + t,
                groupSelector: i,
                attributes: {milestoneGroupId: "milestone_" + t},
                children: []
            }
        },
        getLaneMarkup: function (t, e) {
            var i = ["lanes"];
            return e && i.push("lane_" + e), {
                tagName: "rect",
                selector: "lane_" + t,
                groupSelector: i,
                children: [],
                attributes: {laneGroupId: "lanes_" + t}
            }
        },
        getHeaderMarkup: function (t, e) {
            var i = ["laneHeaders"];
            return e && i.push("header_" + e), {
                tagName: "rect",
                selector: "header_" + t,
                groupSelector: i,
                attributes: {laneGroupId: "lanes_" + t}
            }
        },
        getLabelMarkup: function (t, e) {
            var i = ["laneLabels"];
            return e && i.push("label_" + e), {
                tagName: "text",
                selector: "label_" + t,
                groupSelector: i,
                attributes: {laneGroupId: "lanes_" + t}
            }
        },
        getMilestoneHeaderMarkup: function (t, e) {
            var i = ["milestoneHeaders"];
            return e && i.push("milestoneHeader_" + e), {
                tagName: "rect",
                selector: "milestoneHeader_" + t,
                groupSelector: i,
                attributes: {milestoneGroupId: "milestone_" + t}
            }
        },
        getMilestoneLabelMarkup: function (t, e) {
            var i = ["milestoneLabels"];
            return e && i.push("milestoneLabel_" + e), {
                tagName: "text",
                selector: "milestoneLabel_" + t,
                groupSelector: i,
                attributes: {milestoneGroupId: "milestone_" + t}
            }
        },
        getMilestoneLineMarkup: function (t, e) {
            var i = ["milestoneLines"];
            return e && i.push("milestoneLine_" + e), {
                tagName: "line",
                selector: "milestoneLine_" + t,
                groupSelector: i,
                attributes: {milestoneGroupId: "milestone_" + t}
            }
        },
        getParentIndexesArray: function (t) {
            var e = [];
            let i = t;
            for (; i;) {
                e.push(i);
                var n = this.metrics.lanes[i];
                i = n.parentId
            }
            return e.reverse()
        },
        getFlexAndFixedLaneSizesWithinGroup: function (t) {
            var e = this.metrics, t = e.lanes[t];
            let i = t.parentId, n = 0, o = 0, s = t.parentSublanesCount - 1;
            for (i || (i = "lanes", s = e.topLaneGroupsCount - 1); 0 <= s;) {
                var r = i + "_" + s, r = e.lanes[r];
                Number.isFinite(r.size) ? n += Math.max(r.size, r.takenUpSpaceByLaneAndSublanes) : o++, s--
            }
            return {totalFixedSize: n, flexLanesWithinGroupCount: o}
        },
        getLaneWidth: function (t) {
            let e = this.metrics;
            var i = e.padding, t = this.getParentIndexesArray(t), i = this.attributes.size.width - i.left - i.right;
            let n = 0;
            return t.forEach(t => {
                t = e.lanes[t];
                n += t.headerSize
            }), Math.max(i - n, 0)
        },
        getLaneHeight: function (c) {
            let d = this.metrics;
            var t = d.lanes[c], e = d.padding;
            let i = this.getParentIndexesArray(c);
            var n = this.attributes.size.height - e.top - e.bottom, o = t.parentId;
            let u = n;
            if (o) {
                var s, n = d.lanes[o].sublanesCount;
                if (t.laneIndexWithinGroup === n - 1) return n = this.getLaneContainerPosition(c).y, s = this.getLaneHeight(o), Math.max(s - n, 0)
            }
            return Number.isFinite(t.size) ? o || t.laneIndexWithinGroup !== d.topLaneGroupsCount - 1 ? (s = t.takenUpSpaceByLaneAndSublanes, Math.max(s, t.size, 0)) : (n = this.getLaneContainerPosition(c).y, Math.max(this.attributes.size.height - n - e.bottom, 0)) : ((o = i.map(t => t).reverse().find(t => d.lanes[t].size)) && (n = (s = i.map(t => t)).indexOf(o), i = s.slice(n + 1), u = d.lanes[o].size), i.forEach(t => {
                var e = this.getFlexAndFixedLaneSizesWithinGroup(t), i = d.lanes[t].parentId,
                    t = d.lanes[t].parentSublanesCount, n = d.topLaneGroupsCount;
                let o = 0, s = 0;
                var r = (u - e.totalFixedSize) / (e.flexLanesWithinGroupCount || 1);
                let a = i ? t - 1 : n - 1;
                for (; 0 <= a;) {
                    var l, h = `${i || "lanes"}_` + a;
                    h === c ? a-- : (l = (h = d.lanes[h]).takenUpSpaceByLaneAndSublanes, !h.size && r < l && (o += l, s++), a--)
                }
                u = (u -= e.totalFixedSize + o) / Math.max(e.flexLanesWithinGroupCount - s, 1)
            }), s = (e = t.takenUpSpaceByLaneAndSublanes) > u ? e : u, Math.max(s, 0))
        },
        getMilestoneWidth: function (t) {
            var e = this.metrics, i = e.padding, i = this.attributes.size.width - i.left - i.right, t = e.milestones[t],
                n = e.milestonesCount;
            if (Number.isFinite(t.size)) return t.size;
            let o = n - 1, s = 0, r = 0;
            for (; 0 <= o;) {
                var a = "milestone_" + o, a = e.milestones[a];
                Number.isFinite(a.size) && (s += a.size, r++), o--
            }
            t = (i - s) / (n - r || 1);
            return Math.max(t, 0)
        },
        getLaneContainerPosition: function (t) {
            var e = this.metrics, i = e.padding, {laneIndexWithinGroup: t, nestLevel: n, parentId: o} = e.lanes[t];
            let s = o ? e.lanes[o].headerSize : 0, r = 0, a = (1 === n && (s += i.left, r += i.top), 0), l = t - 1;
            for (; 0 <= l;) {
                var h = o ? o + "_" + l : "lanes_" + l;
                a += this.getLaneHeight(h), l--
            }
            return new g.Point(s, r + a)
        },
        getMilestoneContainerPosition: function (t) {
            var e = this.metrics, t = e.milestones[t].indexWithin, e = e.padding;
            let i = t - 1, n = 0;
            for (; 0 <= i;) {
                var o = "milestone_" + i, o = this.getMilestoneWidth(o);
                n += o, i--
            }
            var t = this.attributes.milestonesSize, s = n + e.left;
            return new g.Point(s, e.top - t)
        },
        getLaneBBox: function (t) {
            "string" != typeof t && error("Expects id to be a string");
            var e, i, n, o, s = this.metrics, r = this.position();
            let a = s.lanes[t];
            return a || (t = s.lanesNameCache[t], a = s.lanes[t]), a ? (s = a.parentId, e = a.headerSize, i = {
                x: 0,
                y: 0
            }, {
                x: s,
                y: n
            } = (s && (s = this.getLaneBBox(s), i.x += s.x - r.x, i.y += s.y - r.y), this.getLaneContainerPosition(t)), o = this.getLaneWidth(t), t = this.getLaneHeight(t), new g.Rect({
                x: s + i.x + r.x,
                y: n + i.y + r.y,
                width: o + e,
                height: t
            })) : null
        },
        getParentLaneId(t) {
            var {lanes: e, lanesNameCache: i} = this.metrics, i = i.hasOwnProperty(t) ? i[t] : t,
                t = (i in e || error(`Lane with ID ${t} wasn't found`), e[i]);
            return null === t.parentId ? null : null !== (i = e[t.parentId]).customId ? i.customId : t.parentId
        },
        getLanesIds: function () {
            let i = this.metrics.lanes;
            return Object.keys(i).map(t => {
                var e = i[t].customId;
                return null !== e ? e : t
            })
        },
        getLaneMetrics(t) {
            var {lanes: e, lanesNameCache: i} = this.metrics;
            return e[t in i ? i[t] : t] || null
        },
        getMilestoneBBox: function (t) {
            "string" != typeof t && error("Expects id to be a string");
            var e, {metrics: i, attributes: n} = this, o = i.padding, s = i.milestones;
            let r = s[t];
            return r || (t = i.milestonesNameCache[t], r = s[t]), r ? (i = this.position(), s = this.getMilestoneWidth(t), e = n.milestonesSize, n = n.size.height - o.bottom - o.top + e, {
                x: o,
                y: e
            } = this.getMilestoneContainerPosition(t), new g.Rect(o + i.x, e + i.y, s, n)) : null
        },
        getLanesFromPoint: function (t) {
            t || error("A point is required");
            var e = this.getBBox(), i = e.center(), n = this.angle();
            let o = new g.Point(t).rotate(i, n);
            if (!e.containsPoint(o)) return [];
            let s = this.metrics, r = s.lanes, a = [], l = t => {
                let e = t ? r[t].sublanesCount - 1 : s.topLaneGroupsCount - 1;
                for (; 0 <= e;) {
                    var i = t ? t + "_" + e : "lanes_" + e;
                    if (this.getLaneBBox(i).containsPoint(o)) {
                        var n = r[i].customId;
                        a.push(n || i), l(i);
                        break
                    }
                    e--
                }
            };
            return l(), a.reverse()
        },
        getMilestoneFromPoint: function (t) {
            t || error("A point is required");
            var e = this.metrics, i = this.getBBox(), n = this.angle(), o = new g.Point(t).rotate(i.center(), n);
            if (i.containsPoint(o)) {
                let t = e.milestonesCount - 1;
                for (; 0 <= t;) {
                    var s, r = "milestone_" + t;
                    if (this.getMilestoneBBox(r).containsPoint(o)) return void 0 === (s = e.milestones[r].customId) ? r : s;
                    t--
                }
            }
            return null
        },
        getLanePath: function (t) {
            t = this.getLaneMetrics(t);
            if (null === t) return [];
            var e = this.metrics.lanes, i = [t.laneIndexWithinGroup];
            let n = t;
            for (; n.parentId;) {
                var o = e[n.parentId].laneIndexWithinGroup;
                i.unshift(o, "sublanes"), n = e[n.parentId]
            }
            return i.unshift("lanes"), i
        },
        toJSON: function () {
            var t = dia$1.Element.prototype.toJSON.apply(this, arguments);
            return delete t.markup, t
        }
    }, {
        attributes: {
            "lane-container-position": {
                position: function (t, e, i) {
                    i = i.getAttribute("lane-group-id");
                    return this.model.getLaneContainerPosition(i)
                }
            }, "lane-size": {
                set: function (t, e, i) {
                    var n = this.model, i = i.getAttribute("lane-group-id"), o = n.getLaneWidth(i), s = n.getLaneHeight(i);
                    return {width: o + n.metrics.lanes[i].headerSize, height: s}
                }
            }, "header-size": {
                set: function (t, e, i) {
                    i = i.getAttribute("lane-group-id");
                    return {width: this.model.metrics.lanes[i].headerSize, height: Math.max(this.model.getLaneHeight(i), 0)}
                }
            }, "label-position": {
                position: function (t, e, i, n) {
                    var o = this.model, i = i.getAttribute("lane-group-id"), s = o.metrics.lanes[i].headerSize,
                        r = o.getLaneHeight(i), {
                            left: a,
                            top: l,
                            right: h,
                            bottom: c
                        } = util.normalizeSides(n["label-margin"]), d = r / 2, u = s / 2;
                    switch (n["label-alignment"]) {
                        case LabelAlignments.topMiddle:
                            return {x: l, y: d + a - h};
                        case LabelAlignments.topLeft:
                            return {x: l, y: r - h};
                        case LabelAlignments.topRight:
                            return {x: l, y: a};
                        case LabelAlignments.leftMiddle:
                            return {x: u + l - c, y: r - h};
                        case LabelAlignments.rightMiddle:
                            return {x: u + l - c, y: a};
                        case LabelAlignments.bottomLeft:
                            return {x: s - c, y: r - h};
                        case LabelAlignments.bottomMiddle:
                            return {x: s - c, y: d + a - h};
                        case LabelAlignments.bottomRight:
                            return {x: s - c, y: a};
                        default:
                            LabelAlignments.center;
                            return {x: u + l - c, y: d + a - h}
                    }
                }
            }, "lane-label": {
                set: function (t, e, i, n) {
                    var o, s, r, a;
                    return util.isPlainObject(t) ? (o = this.model, s = i.getAttribute("lane-group-id"), a = (r = o.metrics.lanes[s]).headerSize, labelTextWrap(this, t, i, n, o.getLaneHeight(s), a, r.label)) : null
                }
            }, "milestone-container-position": {
                position: function (t, e, i) {
                    i = i.getAttribute("milestone-group-id");
                    return this.model.getMilestoneContainerPosition(i)
                }
            }, "milestone-header-size": {
                set: function (t, e, i) {
                    var n = this.model, i = i.getAttribute("milestone-group-id");
                    return {width: n.getMilestoneWidth(i), height: n.attributes.milestonesSize}
                }
            }, "milestone-label-position": {
                position: function (t, e, i, n) {
                    var o = this.model, i = i.getAttribute("milestone-group-id"), s = o.getMilestoneWidth(i),
                        r = o.attributes.milestonesSize, {
                            left: a,
                            top: l,
                            right: h,
                            bottom: c
                        } = util.normalizeSides(n["label-margin"]), d = r / 2, u = s / 2;
                    switch (n["label-alignment"]) {
                        case LabelAlignments.topMiddle:
                            return {x: u + a - h, y: l};
                        case LabelAlignments.topLeft:
                            return {x: a, y: l};
                        case LabelAlignments.topRight:
                            return {x: s - h, y: l};
                        case LabelAlignments.leftMiddle:
                            return {x: a, y: d + l - c};
                        case LabelAlignments.bottomLeft:
                            return {x: a, y: r - c};
                        case LabelAlignments.bottomMiddle:
                            return {x: u + a - h, y: r - c};
                        case LabelAlignments.bottomRight:
                            return {x: s - h, y: r - c};
                        case LabelAlignments.rightMiddle:
                            return {x: s - h, y: d + l - c};
                        default:
                            LabelAlignments.center;
                            return {x: u + a - h, y: d + l - c}
                    }
                }
            }, "milestone-label": {
                set: function (t, e, i, n) {
                    var o, s, r;
                    return util.isPlainObject(t) ? (o = this.model, s = i.getAttribute("milestone-group-id"), r = o.metrics.milestones[s], labelTextWrap(this, t, i, n, o.getMilestoneWidth(s), o.attributes.milestonesSize, r.label)) : null
                }
            }, "milestone-line-position": {
                set: function (t, e, i) {
                    var n = this.model, o = n.position(), s = n.metrics.padding, r = n.attributes.milestonesSize,
                        i = i.getAttribute("milestone-group-id"), {x: n, width: i, height: a} = n.getMilestoneBBox(i);
                    let l = "block";
                    e = e.width - s.right, s = Math.ceil(n) - o.x + Math.ceil(i);
                    return {x1: i, x2: i, y1: r, y2: a, display: l = e <= s ? "none" : l}
                }
            }, "text-vertical": {
                set: function () {
                    return {transform: "rotate(-90)"}
                }
            }, "text-wrap": {
                set: function (t, e, i, n) {
                    var o;
                    n["text-vertical"] && (o = e.width, e.width = e.height, e.height = o), dia$1.attributes["text-wrap"].set.call(this, t, e, i, n)
                }
            }, "label-margin": {}, "label-alignment": {}
        }
    }), HeaderedPool = Pool.define("bpmn2.HeaderedPool", {
        padding: {top: 0, left: 30, right: 0, bottom: 0},
        attrs: {
            header: {
                width: 30,
                refHeight: "100%",
                stroke: "#333333",
                strokeWidth: 2,
                fill: "#ffffff",
                shapeRendering: "optimizespeed"
            },
            headerLabel: {
                textVertical: !0,
                textWrap: {width: -10, ellipsis: !0, maxLineCount: 1},
                refX: 15,
                refY: "50%",
                fontSize: 20,
                fill: "#333333",
                fontFamily: "sans-serif",
                textAnchor: "middle",
                textVerticalAnchor: "middle"
            }
        }
    }, {
        markup: [{tagName: "rect", selector: "body"}, {tagName: "rect", selector: "header"}, {
            tagName: "text",
            selector: "headerLabel"
        }]
    }), PoolViewPresentationAttributes = Pool.prototype.markupAttributes.reduce(function (t, e) {
        return t[e] = ["UPDATE", "TOOLS"], t
    }, {}),
    PoolView = dia$1.ElementView.extend({presentationAttributes: dia$1.ElementView.addPresentationAttributes(PoolViewPresentationAttributes)}),
    HeaderedPoolView = PoolView;

function error(t) {
    throw new Error("shapes.bpmn2.Pool: " + t)
}

let Choreography = dia$1.Element.define("bpmn2.Choregraphy", {
    type: "bpmn2.Choreography",
    size: {width: 100, height: 120},
    attrs: {
        root: {cursor: "move"},
        body: {width: "calc(w)", height: "calc(h)", strokeWidth: 2, stroke: "#333333", fill: "#ffffff"},
        fo: {width: "calc(w)", height: "calc(h)"},
        participants: {participantY: !0},
        participantsBodies: {width: "calc(w)", height: 20, strokeWidth: 2, stroke: "#333333", fill: "#aaaaaa"},
        participantsLabels: {
            x: "calc(w / 2)",
            y: 10,
            textAnchor: "middle",
            dominantBaseline: "central",
            fontSize: 12,
            fontFamily: "sans-serif"
        },
        initiatingParticipantBody: {fill: "transparent"},
        content: {
            contentAlignment: !0,
            style: {textAlign: "center", verticalAlign: "middle", display: "table-cell", fontFamily: "sans-serif"},
            html: ""
        },
        subProcess: {
            d: "M -8 -20 H 8 V -4 H -8 Z M -6 -12 H 6 M 0 -18 V -6",
            fill: "transparent",
            transform: "translate(calc(w / 2), 0)",
            subProcessY: !0,
            stroke: "#000000",
            strokeWidth: 2
        }
    },
    subProcess: !1,
    participants: [],
    participantHeight: 20,
    initiatingParticipant: 0
}, {
    generateId: generateId,
    markup: [{tagName: "rect", selector: "body"}, {
        tagName: "foreignObject",
        selector: "fo",
        children: [{tagName: "div", selector: "content", namespaceURI: "http://www.w3.org/1999/xhtml"}]
    }, {tagName: "text", selector: "label"}],
    markupAttributes: ["participants", "initiatingParticipant", "subProcess"],
    initialize: function () {
        dia$1.Element.prototype.initialize.apply(this, arguments), this.on("change", (t, e) => this.onChange(e)), this.buildMarkup()
    },
    anyHasChanged: function (t) {
        return !!Array.isArray(t) && t.some(function (t) {
            return this.hasChanged(t)
        }, this)
    },
    onChange: function (t) {
        if (t.choreography !== this.id && this.hasChanged("markup")) throw new Error("bpmn2.Choreography: Markup can not be modified.");
        this.anyHasChanged(this.markupAttributes) && this.buildMarkup(t)
    },
    buildParticipantMarkup: function (t, e, i) {
        var t = {tagName: "g", groupSelector: "participants", attributes: {"participant-id": t}},
            n = {tagName: "rect", groupSelector: "participantsBodies"},
            e = {tagName: "text", groupSelector: "participantsLabels", textContent: e};
        return i && (t.selector = "initiatingParticipant", n.selector = "initiatingParticipantBody", e.selector = "initiatingParticipantLabel"), t.children = [n, e], t
    },
    buildSubProcessMarkup: function () {
        return {tagName: "path", selector: "subProcess"}
    },
    buildMarkup: function (t) {
        let {initiatingParticipantIndex: n, participants: o} = this;
        var e = o.map((t, e) => {
                var i = e > n ? -(o.length - e) : e;
                return this.buildParticipantMarkup(i, t, e === n)
            }), e = this.markup.concat(...e),
            t = (this.get("subProcess") && e.push(this.buildSubProcessMarkup()), util.assign({
                choreography: this.id,
                dry: !0
            }, t));
        this.set("markup", e, t)
    }
}, {
    attributes: {
        "participant-y": {
            position(t, e, i) {
                var n = this.model.participantHeight, i = parseInt(i.getAttribute("participant-id"), 10);
                return {x: 0, y: i < 0 ? e.height + i * n : i * n}
            }
        }, "sub-process-y": {
            position(t, e, i) {
                var {participantHeight: n, participants: o, initiatingParticipantIndex: s} = this.model,
                    n = n * (o.length - s - 1);
                return {x: 0, y: e.height - n}
            }
        }, "content-alignment": {
            set(t, e, i) {
                var {participantHeight: n, participants: o, initiatingParticipantIndex: s} = this.model;
                i.style.paddingTop = n * (s + 1) + "px", i.style.height = e.height - o.length * n + "px", i.style.width = e.width + "px"
            }
        }
    }
}), Swimlane = (Object.defineProperty(Choreography.prototype, "participants", {
    get() {
        var t = this.get("participants");
        return Array.isArray(t) ? t : []
    }
}), Object.defineProperty(Choreography.prototype, "initiatingParticipantIndex", {
    get() {
        var t = this.get("initiatingParticipant");
        return Number.isFinite(t) ? t : this.participants.indexOf(t)
    }
}), Object.defineProperty(Choreography.prototype, "participantHeight", {
    get() {
        var t = this.get("participantHeight");
        return Number.isFinite(t) ? t : 20
    }
}), dia$1.Element.define("bpmn2.Swimlane", {
    headerSize: 30,
    headerTextMargin: 5,
    contentMargin: 20,
    size: {width: 80, height: 60},
    attrs: {
        root: {cursor: "move"},
        body: {width: "calc(w)", height: "calc(h)"},
        header: {automaticHeaderAttributes: !0},
        headerText: {
            automaticHeaderTextAttributes: !0,
            cursor: "text",
            automaticHeaderTextWrap: !0,
            textAnchor: "middle",
            textVerticalAnchor: "middle"
        }
    }
}, {
    generateId: generateId,
    markup: [{tagName: "rect", selector: "body"}, {tagName: "rect", selector: "header"}, {
        tagName: "text",
        selector: "headerText"
    }],
    isHorizontal() {
        throw new Error("Abstract method `swimlane.isHorizontal()`. Needs to be implemented by a child class.")
    },
    getHeaderSide() {
        return this.get("headerSide")
    },
    getPadding() {
        var t = {top: 0, left: 0, right: 0, bottom: 0}, e = this.getHeaderSide(), i = this.getHeaderSize();
        return t[e] = i, t
    },
    getHeaderSize() {
        return this.get("headerSize")
    },
    getHeaderTextMargin() {
        return this.get("headerTextMargin")
    },
    getContentMargin() {
        return this.get("contentMargin")
    },
    getElements() {
        return this.getEmbeddedCells().filter(t => !t.isLink())
    },
    getElementsBBox() {
        var t = this.graph;
        return t && t.getCellsBBox(this.getElements()) || null
    },
    isCompatibleWithPool(t) {
        return !!t && t.isHorizontal() === this.isHorizontal()
    },
    resizeToFitContent() {
        var t = this.getContentMargin(), e = this.getPadding(), {width: i, height: n} = this.size(), {
            width: t,
            height: e
        } = (this.fitEmbeds({
            expandOnly: !0,
            padding: {left: t + e.left, right: t + e.right, top: t + e.top, bottom: t + e.bottom}
        }), this.size());
        return i !== t || n !== e
    }
}, {
    attributes: {
        "automatic-header-attributes": automaticHeaderAttributes,
        "automatic-header-text-attributes": automaticHeaderTextAttributes,
        "automatic-header-text-wrap": automaticHeaderTextWrap
    }, isSwimlane: function (t) {
        return t instanceof Swimlane
    }
})), SwimlaneView = dia$1.ElementView.extend({
    presentationAttributes: dia$1.ElementView.addPresentationAttributes({
        headerSize: ["UPDATE", "TOOLS"],
        headerTextMargin: ["UPDATE", "TOOLS"],
        contentMargin: ["UPDATE", "TOOLS"]
    })
}), Phase = dia$1.Element.define("bpmn2.Phase", {
    headerSize: 30,
    headerTextMargin: 5,
    size: {width: 80, height: 60},
    attrs: {
        root: {cursor: "move"},
        body: {width: "calc(w)", height: "calc(h)", fill: "transparent", pointerEvents: "none"},
        header: {automaticHeaderAttributes: !0},
        headerText: {
            automaticHeaderTextAttributes: !0,
            cursor: "text",
            automaticHeaderTextWrap: !0,
            textAnchor: "middle",
            textVerticalAnchor: "middle"
        }
    }
}, {
    generateId: generateId,
    markup: [{tagName: "rect", selector: "body"}, {tagName: "rect", selector: "header"}, {
        tagName: "text",
        selector: "headerText"
    }],
    isHorizontal() {
        throw new Error("Abstract method `phase.isHorizontal()`. Needs to be implemented by a child class.")
    },
    getHeaderSide() {
        return this.get("headerSide")
    },
    getPadding() {
        var t = {top: 0, left: 0, right: 0, bottom: 0}, e = this.getHeaderSide(), i = this.getHeaderSize();
        return t[e] = i, t
    },
    getHeaderSize() {
        return this.get("headerSize")
    },
    getHeaderTextMargin() {
        return this.get("headerTextMargin")
    },
    getElements() {
        var t, e, i = this.getParentCell();
        return i ? (t = this.isHorizontal(), e = this.getBBox(), i.getElementsInOrthogonalRange(e[i = t ? "y" : "x"], e[i] + e[t ? "height" : "width"], {partial: !1})) : []
    },
    getElementsBBox() {
        var t = this.graph;
        return t && t.getCellsBBox(this.getElements()) || null
    },
    isCompatibleWithPool(t) {
        return !!t && t.isHorizontal() !== this.isHorizontal()
    }
}, {
    attributes: {
        "automatic-header-attributes": automaticHeaderAttributes,
        "automatic-header-text-attributes": automaticHeaderTextAttributes,
        "automatic-header-text-wrap": automaticHeaderTextWrap
    }, isPhase: function (t) {
        return t instanceof Phase
    }
}), PhaseView = dia$1.ElementView.extend({
    presentationAttributes: dia$1.ElementView.addPresentationAttributes({
        headerSize: ["UPDATE", "TOOLS"],
        headerTextMargin: ["UPDATE", "TOOLS"]
    })
}), CompositePool = dia$1.Element.define("bpmn2.CompositePool", {
    contentMargin: 20,
    minimumLaneSize: 60,
    size: {width: 80, height: 60},
    attrs: {root: {cursor: "move"}, body: {width: "calc(w)", height: "calc(h)"}}
}, {
    generateId: generateId, markup: [{tagName: "rect", selector: "body"}], isHorizontal() {
        throw new Error("Abstract method `compositePool.isHorizontal()`. Needs to be implemented by a child class.")
    }, getMinimalXRange() {
        throw new Error("Abstract method `compositePool.getMinimalXRange()`. Needs to be implemented by a child class.")
    }, getMinimalYRange() {
        throw new Error("Abstract method `compositePool.getMinimalYRange()`. Needs to be implemented by a child class.")
    }, addSwimlane() {
        throw new Error("Abstract method `compositePool.addSwimlane()`. Needs to be implemented by a child class.")
    }, removeSwimlane() {
        throw new Error("Abstract method `compositePool.removeSwimlane()`. Needs to be implemented by a child class.")
    }, addPhase() {
        throw new Error("Abstract method `compositePool.addPhase()`. Needs to be implemented by a child class.")
    }, removePhase() {
        throw new Error("Abstract method `compositePool.removePhase()`. Needs to be implemented by a child class.")
    }, adjustToContainElements() {
        throw new Error("Abstract method `compositePool.adjustToContainElements()`. Needs to be implemented by a child class.")
    }, getSwimlanes() {
        return sortByCoordinate(this._getUnsortedSwimlanes(), this.getSwimlaneOrthogonalCoordinate())
    }, getPhases() {
        return sortByCoordinate(this._getUnsortedPhases(), this.getPhaseOrthogonalCoordinate())
    }, getContentMargin() {
        return this.get("contentMargin")
    }, getMinimumLaneSize() {
        return this.get("minimumLaneSize")
    }, getPadding() {
        return util.normalizeSides(this.get("padding"))
    }, getSwimlanePadding() {
        var [t] = this.getSwimlanes();
        return t ? t.getPadding() : {top: 0, right: 0, bottom: 0, left: 0}
    }, getSwimlaneCoordinate() {
        return getCoordinate(this.isHorizontal())
    }, getSwimlaneOrthogonalCoordinate() {
        return getCoordinate(!this.isHorizontal())
    }, getSwimlaneDimension() {
        return getDimension(this.isHorizontal())
    }, getSwimlaneOrthogonalDimension() {
        return getDimension(!this.isHorizontal())
    }, getSwimlaneStartSide() {
        return getStartSide(this.isHorizontal())
    }, getSwimlaneOrthogonalStartSide() {
        return getStartSide(!this.isHorizontal())
    }, getSwimlaneEndSide() {
        return getEndSide(this.isHorizontal())
    }, getSwimlaneOrthogonalEndSide() {
        return getEndSide(!this.isHorizontal())
    }, getPhasePadding() {
        var [t] = this.getPhases();
        return t ? t.getPadding() : {top: 0, right: 0, bottom: 0, left: 0}
    }, getPhaseCoordinate() {
        return getCoordinate(!this.isHorizontal())
    }, getPhaseOrthogonalCoordinate() {
        return getCoordinate(this.isHorizontal())
    }, getPhaseDimension() {
        return getDimension(!this.isHorizontal())
    }, getPhaseOrthogonalDimension() {
        return getDimension(this.isHorizontal())
    }, getPhaseStartSide() {
        return getStartSide(!this.isHorizontal())
    }, getPhaseOrthogonalStartSide() {
        return getStartSide(this.isHorizontal())
    }, getPhaseEndSide() {
        return getEndSide(!this.isHorizontal())
    }, getPhaseOrthogonalEndSide() {
        return getEndSide(this.isHorizontal())
    }, getSwimlaneInsertIndexFromPoint(t) {
        let e = this.getSwimlaneOrthogonalCoordinate(), i = this.getSwimlaneOrthogonalDimension();
        var n = this.getSwimlanes().map(t => {
            t = t.getBBox();
            return t[e] + t[i] / 2
        });
        return util.sortedIndex(n, t[e])
    }, getElementsInOrthogonalRange(i, n, t = {}) {
        let {partial: o = !1} = t, s = this.getPhaseOrthogonalCoordinate(), r = this.getPhaseOrthogonalDimension();
        t = this.getSwimlanes();
        let a = [];
        return t.forEach(t => {
            t.getElements().forEach(t => {
                var e = t.getBBox();
                o ? e[s] + e[r] >= i && e[s] <= n && a.push(t) : e[s] > i && e[s] + e[r] < n && a.push(t)
            })
        }), a
    }, getMinimalWidth() {
        var t = this.getMinimumLaneSize(), e = this.getPadding(), i = this.getSwimlanePadding(),
            n = this.getPhasePadding();
        return e.left + e.right + (i.left + i.right) + (n.left + n.right) + t
    }, getMinimalHeight() {
        var t = this.getMinimumLaneSize(), e = this.getPadding(), i = this.getSwimlanePadding(),
            n = this.getPhasePadding();
        return e.top + e.bottom + (i.top + i.bottom) + (n.top + n.bottom) + t
    }, findPhaseFromOrthogonalCoord(e) {
        let i = this.getPhaseOrthogonalCoordinate(), n = this.getPhaseOrthogonalDimension();
        return this.getPhases().find(t => {
            t = t.getBBox();
            return t[i] <= e && t[i] + t[n] >= e
        }) || null
    }, changeSize(t, e, i) {
        var {width: n, height: o} = this.size();
        switch (t) {
            case"bottom":
                null != e && this.resize(n, e, {direction: "bottom", ...i}), this.afterResizeBottom();
                break;
            case"top":
                null != e && this.resize(n, e, {direction: "top", ...i}), this.afterResizeTop();
                break;
            case"right":
                null != e && this.resize(e, o, {direction: "right", ...i}), this.afterResizeRight();
                break;
            case"left":
                null != e && this.resize(e, o, {direction: "left", ...i}), this.afterResizeLeft()
        }
    }, changeSwimlaneSize(t, e, i, n) {
        var {width: o, height: s} = t.size();
        switch (e) {
            case"bottom":
                null != i && t.resize(o, i, {direction: "bottom", ...n}), this.afterSwimlaneResizeBottom(t);
                break;
            case"top":
                null != i && t.resize(o, i, {direction: "top", ...n}), this.afterSwimlaneResizeTop(t);
                break;
            case"right":
                null != i && t.resize(i, s, {direction: "right", ...n}), this.afterSwimlaneResizeRight(t);
                break;
            case"left":
                null != i && t.resize(i, s, {direction: "left", ...n}), this.afterSwimlaneResizeLeft(t)
        }
    }, changePhaseSize(t, e, i, n) {
        var {width: o, height: s} = t.size();
        switch (e) {
            case"bottom":
                null != i && t.resize(o, i, {direction: "bottom", ...n}), this.afterPhaseResizeBottom(t);
                break;
            case"top":
                null != i && t.resize(o, i, {direction: "top", ...n}), this.afterPhaseResizeTop(t);
                break;
            case"right":
                null != i && t.resize(i, s, {direction: "right", ...n}), this.afterPhaseResizeRight(t);
                break;
            case"left":
                null != i && t.resize(i, s, {direction: "left", ...n}), this.afterPhaseResizeLeft(t)
        }
    }, resizeToFitSwimlanes(t) {
        var e, i = this.graph, n = this.getPadding(), o = this.getSwimlanes();
        return 0 !== o.length && (e = this.getPhasePadding(), setElementBBox(this, (i = i.getCellsBBox(o)).x - n.left - e.left, i.y - n.top - e.top, i.width + n.left + n.right + e.left, i.height + n.top + n.bottom + e.top, t), !0)
    }, resizeToFitPhases(t) {
        var e = this.graph, i = this.getPadding(), n = this.getPhases();
        return 0 !== n.length && (setElementBBox(this, (e = e.getCellsBBox(n)).x - i.left, e.y - i.top, e.width + i.left + i.right, e.height + i.top + i.bottom, t), !0)
    }, fixSwimlanesDimensionToFitPhases(i) {
        var t = this.graph, e = this.getPhases();
        let n = t.getCellsBBox(e);
        t = this.getSwimlanes();
        let o = this.getSwimlaneCoordinate(), s = this.getSwimlaneDimension();
        t.forEach(t => {
            var e = t.getBBox();
            e[o] = n[o], e[s] = n[s], setElementBBox(t, e.x, e.y, e.width, e.height, i)
        })
    }, fixPhasesDimensionToFitPool(i) {
        let n = this.getBBox(), o = this.getPadding();
        var t = this.getPhases();
        let s = this.getPhaseCoordinate(), r = this.getPhaseDimension(), a = this.getPhaseStartSide(),
            l = this.getPhaseEndSide();
        t.forEach(t => {
            var e = t.getBBox();
            e[s] = n[s] + o[a], e[r] = n[r] - o[a] - o[l], setElementBBox(t, e.x, e.y, e.width, e.height, i)
        })
    }, setStackingOrder() {
        var t = this.graph;
        if (t) {
            let i = this.z();
            var s = this.getSwimlanes(), r = this.getPhases();
            let e = [];
            var a = t.getElements().filter(t => CompositePool.isPool(t)).at(-1);
            this.startBatch("set-stacking-order"), s.forEach(t => {
                e.push(...t.getElements())
            });
            let n = 1, o = (s.forEach(t => {
                t.set("z", i + n)
            }), n++, r.forEach(t => {
                t.set("z", i + n)
            }), n++, e.forEach(t => {
                t.set("z", i + n)
            }), n++, a.z());
            t.getConnectedLinks(this, {deep: !0, includeEnclosed: !0}).forEach(t => {
                var e = t.isEmbedded() ? i + n : o + n;
                t.set("z", e)
            }), this.stopBatch("set-stacking-order")
        }
    }, setAsParent(t) {
        t.isEmbedded() && ((e = t.getParentCell()).unembed(t), e.layout());
        var e = this.graph;
        e && (t.graph ? e.getConnectedLinks(t, {deep: !0}).forEach(t => t.remove()) : e.addCell(t)), this.embed(t)
    }, _getUnsortedSwimlanes() {
        return this.getEmbeddedCells().filter(t => Swimlane.isSwimlane(t))
    }, _getUnsortedPhases() {
        return this.getEmbeddedCells().filter(t => Phase.isPhase(t))
    }
}, {
    isPool: function (t) {
        return t instanceof CompositePool
    }
}), CompositePoolView = dia$1.ElementView.extend({
    presentationAttributes: dia$1.ElementView.addPresentationAttributes({
        padding: ["UPDATE", "TOOLS"],
        contentMargin: ["UPDATE", "TOOLS"],
        minimumLaneSize: ["UPDATE", "TOOLS"]
    })
});

function sortByCoordinate(t, e) {
    return util.sortBy(t, t => t.position()[e])
}

function getCoordinate(t) {
    return t ? "x" : "y"
}

function getDimension(t) {
    return t ? "width" : "height"
}

function getStartSide(t) {
    return t ? "left" : "top"
}

function getEndSide(t) {
    return t ? "right" : "bottom"
}

let HorizontalPool = CompositePool.define("bpmn2.HorizontalPool", {
        attrs: {
            body: {
                strokeWidth: 2,
                stroke: "#000000",
                fill: "#ffffff"
            }
        }
    }, {
        isHorizontal() {
            return !0
        }, getMinimalXRange() {
            var t, e = this.getMinimumLaneSize(),
                i = getUnion(...this.getSwimlanes().map(t => t.getElementsBBox()?.inflate(t.getContentMargin()))),
                n = this.getPhases();
            let o = null;
            return 2 < n.length ? (t = n.slice(1, -1), (o = getUnion(...t.map(t => t.getBBox()))).x -= e, o.width += 2 * e) : ([t, n] = n, t && n && (n = t.getBBox(), o = new g.Rect(n.x + n.width - e, 0, 2 * e, 0))), i || o ? i ? o ? [(t = i.union(o)).x, t.x + t.width] : [i.x, i.x + i.width] : [o.x, o.x + o.width] : null
        }, getMinimalYRange() {
            var t, e, i, n = this.getMinimumLaneSize(), o = this.getSwimlanes(),
                s = getUnion(...o.map(t => t.getElementsBBox()?.inflate(t.getContentMargin())));
            let r = null,
                a = (2 < o.length ? (i = o.slice(1, -1), (r = getUnion(...i.map(t => t.getBBox()))).y -= n, r.height += 2 * n) : ([i, o] = o, i && o && ((r = o.getBBox()).y -= n, r.height = 2 * n)), null);
            0 < this.getPhases().length && (i = this.getBBox(), o = this.getPadding(), t = this.getPhasePadding(), e = i.y + i.height - o.bottom - n, i = i.y + o.top + t.top + n, a = new g.Rect(0, e, 0, i - e));
            o = getUnion(s, r, a);
            return o ? [o.y, o.y + o.height] : null
        }, addSwimlane(t, e = 1 / 0) {
            var i = this.getSwimlanes(), n = i.indexOf(t);
            if (-1 === n) this.setAsParent(t); else {
                if (n === e) return;
                i.splice(n, 1), n < e ? e-- : e = Math.min(e, i.length)
            }
            i.splice(e, 0, t);
            var o, n = this.getMinimumLaneSize(), e = this.getBBox(), s = this.getPadding(), r = this.getSwimlanePadding(),
                a = this.getPhasePadding(), l = this.getSwimlaneCoordinate(), h = this.getSwimlaneDimension(),
                c = this.getSwimlaneStartSide(), d = this.getSwimlaneEndSide(), u = this.getSwimlaneOrthogonalCoordinate(),
                p = this.getSwimlaneOrthogonalDimension(), g = this.getSwimlaneOrthogonalStartSide(),
                m = this.getSwimlaneOrthogonalEndSide(), d = Math.max(e[h] - s[c] - s[d] - a[c], t.size()[h], r[c] + n);
            1 === i.length ? ((o = {})[l] = e[l] + s[c] + a[c], o[u] = e[u] + s[g] + a[g], t.position(o.x, o.y, {deep: !0}), l = {}, c = Math.max(e[p] - s[g] - s[m] - a[g], t.size()[p], r[g] + n), l[h] = d, l[p] = c, t.resize(l.width, l.height)) : this.layoutSwimlanes(i, e.x + s.left + a.left, e.y + s.top + a.top, d), this.resizeToFitSwimlanes(), this.afterResizeRight(), this.fixPhasesDimensionToFitPool(), this.setStackingOrder()
        }, removeSwimlane(t) {
            this.startBatch("remove-swimlane"), t.remove(), this.layout(), this.stopBatch("remove-swimlane")
        }, addPhase(o, s) {
            var r = this.graph, a = this.getContentMargin(), l = this.getMinimumLaneSize(), h = this.getBBox(),
                c = this.getPadding(), d = this.getSwimlanePadding(), u = this.getPhasePadding(),
                p = this.getPhaseDimension(), g = this.getPhaseStartSide(), m = this.getPhaseEndSide();
            let f = this.getPhaseOrthogonalCoordinate();
            var v = this.getPhaseOrthogonalDimension(), y = this.getPhaseOrthogonalStartSide(),
                x = this.getPhaseOrthogonalEndSide();
            let b;
            var w = this.getPhases();
            if (0 === w.length) b = 0, o.prop(["size", p], Math.max(h[p] - c[g] - c[m], u[g] + l)), o.prop(["size", v], Math.max(h[v] - c[y] - c[x], u[y] + l)); else {
                s = s ?? h[f] + h[v] - c[x];
                var p = this.findPhaseFromOrthogonalCoord(s), m = o, g = (b = w.indexOf(p) + 1, p.getBBox()), u = g[f],
                    h = u + g[v], c = this.getElementsInOrthogonalRange(u, s, {partial: !0}), x = r.getCellsBBox(c),
                    c = this.getElementsInOrthogonalRange(s, h, {partial: !1}), S = r.getCellsBBox(c),
                    P = this.getElementsInOrthogonalRange(h, 1 / 0, {partial: !1}), r = r.getCellsBBox(P);
                let t = s;
                x && (C = x[f], x = x[v], t = Math.max(C + x + a, s));
                var C = t - u;
                let e = l;
                0 === w.indexOf(p) && (e += d[y]);
                x = Math.max(C, e), s = x - C, u = s + t;
                let i = h - t, n = l;
                S && (y = h - (d = S[f] - a), n = Math.max(n, y), C = i - y, l = Math.max(0, u - d), h = Math.min(s - l, C), i -= h);
                y = Math.max(i, n), d = m.position();
                if (d[f] = u, m.position(d.x, d.y), S) {
                    s = S[f];
                    let i = Math.max(0, u - (s - a));
                    0 < i && c.forEach(t => {
                        var e = {x: 0, y: 0};
                        e[f] = i, t.translate(e.x, e.y)
                    })
                }
                if (r) {
                    let i = x + y - g[v];
                    0 < i && P.forEach(t => {
                        var e = {x: 0, y: 0};
                        e[f] = i, t.translate(e.x, e.y)
                    })
                }
                p.prop(["size", v], x), m.prop(["size", v], y)
            }
            this.setAsParent(o), w.splice(b, 0, o), this.layout({phases: w}), this.fixSwimlanesDimensionToFitPhases(), this.resizeToFitSwimlanes() || this.resizeToFitPhases(), this.fixPhasesDimensionToFitPool()
        }, removePhase(t) {
            var e = this.getPhases(), i = e.indexOf(t);
            if (-1 === i) throw new Error("Phase not found");
            this.startBatch("remove-phase");
            var n = this.getPhaseOrthogonalCoordinate(), o = this.getPhaseOrthogonalDimension(), s = e[i + 1], i = e[i - 1],
                r = t.size();
            i ? i.prop(["size", o], i.size()[o] + r[o]) : s && ((i = s.getBBox())[n] -= r[o], i[o] += r[o], setElementBBox(s, i.x, i.y, i.width, i.height)), t.remove(), 1 === e.length && this.resizeToFitSwimlanes(), this.stopBatch("remove-phase")
        }, adjustToContainElements(t) {
            var e = this.getSwimlaneOrthogonalStartSide(), i = this.getSwimlaneOrthogonalEndSide(), n = this.getSwimlanes();
            let m = this.getPhases(), f = m.length;
            if (0 === f) t.resizeToFitContent() && (o = this.getSwimlaneStartSide(), s = this.getSwimlaneEndSide(), this.changeSwimlaneSize(t, o), this.changeSwimlaneSize(t, s), this.changeSwimlaneSize(t, e), this.changeSwimlaneSize(t, i), this.layout({
                swimlanes: n,
                phases: m
            })); else {
                let c = this.graph, d = this.getContentMargin();
                var o = this.getSwimlanePadding();
                let u = this.getPhaseOrthogonalCoordinate(), p = this.getPhaseOrthogonalDimension();
                var s = this.getPhaseOrthogonalStartSide(), [r] = m, r = r.getBBox();
                let g = [];
                g.push(r[u] + o[s]), m.forEach(t => {
                    t = t.getBBox();
                    g.push(t[u] + t[p])
                }), g.forEach((t, n) => {
                    var e = n - 1;
                    let i, o, s;
                    -1 == e ? (i = -1 / 0, o = t + d - 1, s = "start") : e == f - 1 ? (i = t - d + 1, o = 1 / 0, s = "end") : (i = t - d + 1, o = t + d - 1);
                    var r = this.getElementsInOrthogonalRange(i, o, {partial: !0});
                    if (0 !== r.length) {
                        var r = c.getCellsBBox(r), a = g[n - 1] ?? -1 / 0, l = g[n + 1] ?? 1 / 0, h = r[u] + r[p] / 2;
                        if (!(h <= a || l < h)) if ("start" === (s = s || (t < h ? "start" : "end"))) {
                            a = r[u] - t - d;
                            this.resizePhaseOrthogonalStart(m, 1 + e, a)
                        } else if ("end" === s) {
                            let i = r[u] + r[p] - t + d;
                            this.resizePhaseOrthogonalEnd(m, e, i), g.forEach((t, e) => {
                                n < e && (g[e] += i)
                            })
                        }
                    }
                }), t.resizeToFitContent() && (this.changeSwimlaneSize(t, e), this.changeSwimlaneSize(t, i), this.layout({
                    swimlanes: n,
                    phases: m
                }))
            }
        }, afterResizeBottom() {
            var t = this.getSwimlanes(), e = this.getPhases();
            let i = this.getBBox(), n = this.getPadding();
            0 < t.length && (t = t.at(-1)).prop(["size", "height"], i.y + i.height - n.bottom - t.position().y), e.forEach(t => {
                t.prop(["size", "height"], i.height - n.top - n.bottom)
            })
        }, afterResizeTop() {
            var t = this.getSwimlanes(), e = this.getPhases();
            let i = this.getBBox(), n = this.getPadding();
            var o, s, r = this.getPhasePadding();
            0 < t.length && ([t, s] = t, o = t.getBBox(), r = i.y + n.top + r.top, s = s ? s.position().y : i.y + i.height - n.bottom, setElementBBox(t, o.x, r, o.width, s - r)), e.forEach(t => {
                var e = t.getBBox();
                setElementBBox(t, e.x, i.y + n.top, e.width, i.height - n.top - n.bottom)
            })
        }, afterResizeRight() {
            var t = this.getSwimlanes(), e = this.getPhases();
            let i = this.getBBox(), n = this.getPadding(), o = this.getPhasePadding();
            t.forEach(t => {
                t.prop(["size", "width"], i.width - n.left - o.left - n.right)
            }), 0 < e.length && (t = e.at(-1)).prop(["size", "width"], i.x + i.width - n.right - t.position().x)
        }, afterResizeLeft() {
            var t = this.getSwimlanes(), e = this.getPhases();
            let i = this.getBBox(), n = this.getPadding();
            t.forEach(t => {
                var e = t.getBBox();
                setElementBBox(t, i.x + n.left, e.y, i.width - n.left - n.right, e.height)
            }), 0 < e.length && ([t] = e, e = t.getBBox(), setElementBBox(t, i.x + n.left, e.y, e.x + e.width - i.x - n.left, e.height))
        }, afterSwimlaneResizeBottom(t, e = {}) {
            let i;
            var e = e.swimlanes ?? this.getSwimlanes(), n = e.indexOf(t), t = t.getBBox(), o = this.getBBox(),
                s = this.getPadding(), e = e.slice(n + 1);
            if (0 < e.length) {
                var [n] = e;
                if (0 === (i = t.y + t.height - n.position().y)) return;
                e.forEach(t => t.translate(0, i))
            } else if (0 === (i = t.y + t.height - (o.y + o.height - s.bottom))) return;
            this.prop(["size", "height"], o.height + i), this.fixPhasesDimensionToFitPool()
        }, afterSwimlaneResizeTop(t, e = {}) {
            let i;
            var e = e.swimlanes ?? this.getSwimlanes(), n = e.indexOf(t), t = t.getBBox(), o = this.getBBox(),
                e = e.slice(0, n);
            if (0 < e.length) {
                n = e.at(-1).getBBox();
                if (0 === (i = t.y - n.y - n.height)) return;
                e.forEach(t => t.translate(0, i))
            } else {
                n = this.getPadding(), e = this.getPhasePadding();
                if (0 === (i = t.y - o.y - n.top - e.top)) return
            }
            setElementBBox(this, o.x, o.y + i, o.width, o.height - i), this.fixPhasesDimensionToFitPool()
        }, afterSwimlaneResizeRight(e, t = {}) {
            let i;
            var n = this.getSwimlanes();
            let o = e.getBBox();
            var s = this.getBBox(), n = (n.forEach(t => {
                e !== t && t.prop(["size", "width"], o.width)
            }), t.phases ?? this.getPhases()), t = n[n.length - 1];
            if (t) {
                n = t.getBBox();
                if (0 === (i = o.x + o.width - n.x - n.width)) return;
                t.prop(["size", "width"], n.width + i)
            } else {
                t = this.getPadding();
                if (0 === (i = o.x + o.width - (s.x + s.width - t.right))) return
            }
            this.prop(["size", "width"], s.width + i)
        }, afterSwimlaneResizeLeft(i, t = {}) {
            let e;
            var n = this.getSwimlanes();
            let o = i.getBBox();
            var s = this.getBBox(), n = (n.forEach(t => {
                var e;
                i !== t && (e = t.getBBox(), setElementBBox(t, o.x, e.y, o.width, e.height))
            }), t.phases ?? this.getPhases()), [t] = n;
            if (t) {
                n = t.getBBox();
                if (0 === (e = o.x - n.x)) return;
                setElementBBox(t, n.x + e, n.y, n.width - e, n.height)
            } else {
                t = this.getPadding();
                if (0 === (e = o.x - s.x - t.left)) return
            }
            setElementBBox(this, s.x + e, s.y, s.width - e, s.height)
        }, afterPhaseResizeBottom(t, e = {}) {
            var t = t.getBBox(), i = this.getPadding(), n = this.getBBox(),
                t = t.y + t.height - (n.y + n.height - i.bottom);
            0 != t && ((i = (e.swimlanes ?? this.getSwimlanes()).at(-1)) && (e = i.getBBox(), i.prop(["size", "height"], e.height + t)), setElementBBox(this, n.x, n.y, n.width, n.height + t), this.fixPhasesDimensionToFitPool())
        }, afterPhaseResizeTop(t, e = {}) {
            var t = t.getBBox(), i = this.getPadding(), n = this.getBBox(), i = n.y + i.top - t.y;
            0 != i && ((t = (e.swimlanes ?? this.getSwimlanes())[0]) && (e = t.getBBox(), setElementBBox(t, e.x, e.y - i, e.width, e.height + i)), setElementBBox(this, n.x, n.y - i, n.width, n.height + i), this.fixPhasesDimensionToFitPool())
        }, afterPhaseResizeRight(t, e = {}) {
            let i;
            var e = e.phases ?? this.getPhases(), n = e.indexOf(t), t = t.getBBox(), o = this.getBBox(),
                s = this.getPadding(), e = e.slice(n + 1);
            if (0 < e.length) {
                var [n] = e, n = n.position().x;
                if (0 === (i = t.x + t.width - n)) return;
                e.forEach(t => t.translate(i, 0)), this.getElementsInOrthogonalRange(n, 1 / 0, {partial: !1}).forEach(t => t.translate(i, 0))
            } else if (0 === (i = t.x + t.width - (o.x + o.width - s.right))) return;
            this.prop(["size", "width"], o.width + i), this.fixSwimlanesDimensionToFitPhases()
        }, afterPhaseResizeLeft(t, e = {}) {
            let i;
            var e = e.phases ?? this.getPhases(), n = e.indexOf(t), t = t.getBBox(), o = this.getBBox(),
                s = this.getPadding(), e = e.slice(0, n);
            if (0 < e.length) {
                n = e.at(-1).getBBox(), n = n.x + n.width;
                if (0 === (i = t.x - n)) return;
                e.forEach(t => t.translate(i, 0)), this.getElementsInOrthogonalRange(-1 / 0, n, {partial: !1}).forEach(t => t.translate(i, 0))
            } else if (0 === (i = t.x - (o.x + s.left))) return;
            setElementBBox(this, o.x + i, o.y, o.width - i, o.height), this.fixSwimlanesDimensionToFitPhases()
        }, layout(t = {}) {
            var e = this.getBBox(), i = this.getPadding(), n = t.swimlanes ?? this.getSwimlanes();
            let o = this.getSwimlaneDimension();
            var s = this.getPhasePadding(), r = n.reduce((t, e) => {
                    e = e.getBBox();
                    return Math.max(t, e[o])
                }, 0),
                n = (this.layoutSwimlanes(n, e.x + i.left + s.left, e.y + i.top + s.top, r), this.resizeToFitSwimlanes(), this.getBBox()),
                s = t.phases ?? this.getPhases(), r = this.getPhaseDimension(), t = this.getPhaseStartSide(),
                a = this.getPhaseEndSide(), n = n[r] - i[t] - i[a];
            this.layoutPhases(s, e.x + i.left, e.y + i.top, n), this.setStackingOrder()
        }, layoutSwimlanes(t, o, s, r) {
            var a = this.graph;
            if (a) {
                let e = this.getSwimlaneDimension(), i = (t.forEach(t => {
                    t.prop(["size", e], r)
                }), a.startBatch("layout-swimlanes"), o), n = s;
                t.forEach(t => {
                    var e = t.get("size").height;
                    t.position(i, n, {deep: !0}), n += e
                }), a.stopBatch("layout-swimlanes")
            }
        }, layoutPhases(t, o, s, r) {
            var a = this.graph;
            if (a) {
                let e = this.getPhaseDimension(), i = (t.forEach(t => {
                    t.prop(["size", e], r)
                }), a.startBatch("layout-phases"), o), n = s;
                t.forEach(t => {
                    var e = t.get("size").width;
                    t.position(i, n), i += e
                }), a.stopBatch("layout-phases")
            }
        }, resizePhaseOrthogonalStart(t, e, i) {
            var n = this.getPhaseOrthogonalCoordinate(), o = this.getPhaseOrthogonalDimension(), e = t[e], s = e.getBBox();
            s[n] += i, s[o] -= i, setElementBBox(e, s.x, s.y, s.width, s.height), this.afterPhaseResizeLeft(e, {phases: t})
        }, resizePhaseOrthogonalEnd(t, e, i) {
            var n = this.getPhaseOrthogonalDimension(), e = t[e];
            e.prop(["size", n], e.size()[n] + i), this.afterPhaseResizeRight(e, {phases: t})
        }
    }), HeaderedHorizontalPool = HorizontalPool.define("bpmn2.HeaderedHorizontalPool", {
        headerSide: "left",
        padding: {left: 40},
        headerTextMargin: 5,
        attrs: {
            header: {automaticHeaderAttributes: !0, strokeWidth: 2, stroke: "#000000", fill: "#ffffff"},
            headerText: {
                automaticHeaderTextAttributes: !0,
                cursor: "text",
                fontSize: 16,
                fill: "#000000",
                text: "Pool",
                automaticHeaderTextWrap: !0,
                textAnchor: "middle",
                textVerticalAnchor: "middle"
            }
        }
    }, {
        markup: [{tagName: "rect", selector: "body"}, {tagName: "rect", selector: "header"}, {
            tagName: "text",
            selector: "headerText"
        }], getHeaderSide() {
            var t = this.get("headerSide");
            if (-1 === ["left", "top", "right", "bottom"].indexOf(t)) throw new Error("Invalid value provided to `headerSide` model attribute.");
            return t
        }, getHeaderSize() {
            var t = this.getHeaderSide();
            return this.getPadding()[t]
        }, getHeaderTextMargin() {
            return this.get("headerTextMargin")
        }
    }, {
        attributes: {
            "automatic-header-attributes": automaticHeaderAttributes,
            "automatic-header-text-attributes": automaticHeaderTextAttributes,
            "automatic-header-text-wrap": automaticHeaderTextWrap
        }
    }), HorizontalPoolView = CompositePoolView,
    HeaderedHorizontalPoolView = HorizontalPoolView.extend({presentationAttributes: HorizontalPoolView.addPresentationAttributes({headerTextMargin: ["UPDATE", "TOOLS"]})}),
    VerticalPool = CompositePool.define("bpmn2.VerticalPool", {
        attrs: {
            body: {
                strokeWidth: 2,
                stroke: "#000000",
                fill: "#ffffff"
            }
        }
    }, {
        isHorizontal() {
            return !1
        }, getMinimalXRange() {
            var t, e, i, n = this.getMinimumLaneSize(), o = this.getSwimlanes(),
                s = getUnion(...o.map(t => t.getElementsBBox()?.inflate(t.getContentMargin())));
            let r = null,
                a = (2 < o.length ? (i = o.slice(1, -1), (r = getUnion(...i.map(t => t.getBBox()))).x -= n, r.width += 2 * n) : ([i, o] = o, i && o && ((r = o.getBBox()).x -= n, r.width = 2 * n)), null);
            0 < this.getPhases().length && (i = this.getBBox(), o = this.getPadding(), t = this.getPhasePadding(), e = i.x + i.width - o.right - n, i = i.x + o.left + t.left + n, a = new g.Rect(e, 0, i - e, 0));
            o = getUnion(s, r, a);
            return o ? [o.x, o.x + o.width] : null
        }, getMinimalYRange() {
            var t, e = this.getMinimumLaneSize(),
                i = getUnion(...this.getSwimlanes().map(t => t.getElementsBBox()?.inflate(t.getContentMargin()))),
                n = this.getPhases();
            let o = null;
            return 2 < n.length ? (t = n.slice(1, -1), (o = getUnion(...t.map(t => t.getBBox()))).y -= e, o.height += 2 * e) : ([t, n] = n, t && n && (n = t.getBBox(), o = new g.Rect(0, n.y + n.height - e, 0, 2 * e))), i || o ? i ? o ? [(t = i.union(o)).y, t.y + t.height] : [i.y, i.y + i.height] : [o.y, o.y + o.height] : null
        }, addSwimlane(t, e = 1 / 0) {
            var i = this.getSwimlanes(), n = i.indexOf(t);
            if (-1 === n) this.setAsParent(t); else {
                if (n === e) return;
                i.splice(n, 1), n < e ? e-- : e = Math.min(e, i.length)
            }
            i.splice(e, 0, t);
            var o, n = this.getMinimumLaneSize(), e = this.getBBox(), s = this.getPadding(),
                r = this.getSwimlanePadding(), a = this.getPhasePadding(), l = this.getSwimlaneCoordinate(),
                h = this.getSwimlaneDimension(), c = this.getSwimlaneStartSide(), d = this.getSwimlaneEndSide(),
                u = this.getSwimlaneOrthogonalCoordinate(), p = this.getSwimlaneOrthogonalDimension(),
                g = this.getSwimlaneOrthogonalStartSide(), m = this.getSwimlaneOrthogonalEndSide(),
                d = Math.max(e[h] - s[c] - s[d] - a[c], t.size()[h], r[c] + n);
            1 === i.length ? ((o = {})[l] = e[l] + s[c] + a[c], o[u] = e[u] + s[g] + a[g], t.position(o.x, o.y, {deep: !0}), l = {}, c = Math.max(e[p] - s[g] - s[m] - a[g], t.size()[p], r[g] + n), l[h] = d, l[p] = c, t.resize(l.width, l.height)) : this.layoutSwimlanes(i, e.x + s.left + a.left, e.y + s.top + a.top, d), this.resizeToFitSwimlanes(), this.afterResizeRight(), this.fixPhasesDimensionToFitPool(), this.setStackingOrder()
        }, removeSwimlane(t) {
            this.startBatch("remove-swimlane"), t.remove(), this.layout(), this.stopBatch("remove-swimlane")
        }, addPhase(o, s) {
            var r = this.graph, a = this.getContentMargin(), l = this.getMinimumLaneSize(), h = this.getBBox(),
                c = this.getPadding(), d = this.getSwimlanePadding(), u = this.getPhasePadding(),
                p = this.getPhaseDimension(), g = this.getPhaseStartSide(), m = this.getPhaseEndSide();
            let f = this.getPhaseOrthogonalCoordinate();
            var v = this.getPhaseOrthogonalDimension(), y = this.getPhaseOrthogonalStartSide(),
                x = this.getPhaseOrthogonalEndSide();
            let b;
            var w = this.getPhases();
            if (0 === w.length) b = 0, o.prop(["size", p], Math.max(h[p] - c[g] - c[m], u[g] + l)), o.prop(["size", v], Math.max(h[v] - c[y] - c[x], u[y] + l)); else {
                s = s ?? h[f] + h[v] - c[x];
                var p = this.findPhaseFromOrthogonalCoord(s), m = o, g = (b = w.indexOf(p) + 1, p.getBBox()), u = g[f],
                    h = u + g[v], c = this.getElementsInOrthogonalRange(u, s, {partial: !0}), x = r.getCellsBBox(c),
                    c = this.getElementsInOrthogonalRange(s, h, {partial: !1}), S = r.getCellsBBox(c),
                    P = this.getElementsInOrthogonalRange(h, 1 / 0, {partial: !1}), r = r.getCellsBBox(P);
                let t = s;
                x && (C = x[f], x = x[v], t = Math.max(C + x + a, s));
                var C = t - u;
                let e = l;
                0 === w.indexOf(p) && (e += d[y]);
                x = Math.max(C, e), s = x - C, u = s + t;
                let i = h - t, n = l;
                S && (y = h - (d = S[f] - a), n = Math.max(n, y), C = i - y, l = Math.max(0, u - d), h = Math.min(s - l, C), i -= h);
                y = Math.max(i, n), d = m.position();
                if (d[f] = u, m.position(d.x, d.y), S) {
                    s = S[f];
                    let i = Math.max(0, u - (s - a));
                    0 < i && c.forEach(t => {
                        var e = {x: 0, y: 0};
                        e[f] = i, t.translate(e.x, e.y)
                    })
                }
                if (r) {
                    let i = x + y - g[v];
                    0 < i && P.forEach(t => {
                        var e = {x: 0, y: 0};
                        e[f] = i, t.translate(e.x, e.y)
                    })
                }
                p.prop(["size", v], x), m.prop(["size", v], y)
            }
            this.setAsParent(o), w.splice(b, 0, o), this.layout({phases: w}), this.fixSwimlanesDimensionToFitPhases(), this.resizeToFitSwimlanes() || this.resizeToFitPhases(), this.fixPhasesDimensionToFitPool()
        }, removePhase(t) {
            var e = this.getPhases(), i = e.indexOf(t);
            if (-1 === i) throw new Error("Phase not found");
            this.startBatch("remove-phase");
            var n = this.getPhaseOrthogonalCoordinate(), o = this.getPhaseOrthogonalDimension(), s = e[i + 1],
                i = e[i - 1], r = t.size();
            i ? i.prop(["size", o], i.size()[o] + r[o]) : s && ((i = s.getBBox())[n] -= r[o], i[o] += r[o], setElementBBox(s, i.x, i.y, i.width, i.height)), t.remove(), 1 === e.length && this.resizeToFitSwimlanes(), this.stopBatch("remove-phase")
        }, adjustToContainElements(t) {
            var e = this.getSwimlaneOrthogonalStartSide(), i = this.getSwimlaneOrthogonalEndSide(),
                n = this.getSwimlanes();
            let m = this.getPhases(), f = m.length;
            if (0 === f) t.resizeToFitContent() && (o = this.getSwimlaneStartSide(), s = this.getSwimlaneEndSide(), this.changeSwimlaneSize(t, o), this.changeSwimlaneSize(t, s), this.changeSwimlaneSize(t, e), this.changeSwimlaneSize(t, i), this.layout({
                swimlanes: n,
                phases: m
            })); else {
                let c = this.graph, d = this.getContentMargin();
                var o = this.getSwimlanePadding();
                let u = this.getPhaseOrthogonalCoordinate(), p = this.getPhaseOrthogonalDimension();
                var s = this.getPhaseOrthogonalStartSide(), [r] = m, r = r.getBBox();
                let g = [];
                g.push(r[u] + o[s]), m.forEach(t => {
                    t = t.getBBox();
                    g.push(t[u] + t[p])
                }), g.forEach((t, n) => {
                    var e = n - 1;
                    let i, o, s;
                    -1 == e ? (i = -1 / 0, o = t + d - 1, s = "start") : e == f - 1 ? (i = t - d + 1, o = 1 / 0, s = "end") : (i = t - d + 1, o = t + d - 1);
                    var r = this.getElementsInOrthogonalRange(i, o, {partial: !0});
                    if (0 !== r.length) {
                        var r = c.getCellsBBox(r), a = g[n - 1] ?? -1 / 0, l = g[n + 1] ?? 1 / 0, h = r[u] + r[p] / 2;
                        if (!(h <= a || l < h)) if ("start" === (s = s || (t < h ? "start" : "end"))) {
                            a = r[u] - t - d;
                            this.resizePhaseOrthogonalStart(m, 1 + e, a)
                        } else if ("end" === s) {
                            let i = r[u] + r[p] - t + d;
                            this.resizePhaseOrthogonalEnd(m, e, i), g.forEach((t, e) => {
                                n < e && (g[e] += i)
                            })
                        }
                    }
                }), t.resizeToFitContent() && (this.changeSwimlaneSize(t, e), this.changeSwimlaneSize(t, i), this.layout({
                    swimlanes: n,
                    phases: m
                }))
            }
        }, afterResizeBottom() {
            var t = this.getSwimlanes(), e = this.getPhases();
            let i = this.getBBox(), n = this.getPadding(), o = this.getPhasePadding();
            t.forEach(t => {
                t.prop(["size", "height"], i.height - n.top - o.top - n.bottom)
            }), 0 < e.length && (t = e.at(-1)).prop(["size", "height"], i.y + i.height - n.bottom - t.position().y)
        }, afterResizeTop() {
            var t = this.getSwimlanes(), e = this.getPhases();
            let i = this.getBBox(), n = this.getPadding();
            t.forEach(t => {
                var e = t.getBBox();
                setElementBBox(t, e.x, i.y + n.top, e.width, i.height - n.top - n.bottom)
            }), 0 < e.length && ([t] = e, e = t.getBBox(), setElementBBox(t, e.x, i.y + n.top, e.width, e.y + e.height - i.y - n.top))
        }, afterResizeRight() {
            var t = this.getSwimlanes(), e = this.getPhases();
            let i = this.getBBox(), n = this.getPadding();
            0 < t.length && (t = t.at(-1)).prop(["size", "width"], i.x + i.width - n.right - t.position().x), e.forEach(t => {
                t.prop(["size", "width"], i.width - n.left - n.right)
            })
        }, afterResizeLeft() {
            var t = this.getSwimlanes(), e = this.getPhases();
            let i = this.getBBox(), n = this.getPadding();
            var o, s, r = this.getPhasePadding();
            0 < t.length && ([t, s] = t, o = t.getBBox(), r = i.x + n.left + r.left, s = s ? s.position().x : i.x + i.width - n.right, setElementBBox(t, r, o.y, s - r, o.height)), e.forEach(t => {
                var e = t.getBBox();
                setElementBBox(t, i.x + n.left, e.y, i.width - n.left - n.right, e.height)
            })
        }, afterSwimlaneResizeBottom(e, t = {}) {
            let i;
            var n = this.getSwimlanes();
            let o = e.getBBox();
            var s = this.getBBox(), n = (n.forEach(t => {
                e !== t && t.prop(["size", "height"], o.height)
            }), t.phases ?? this.getPhases()), t = n[n.length - 1];
            if (t) {
                n = t.getBBox();
                if (0 === (i = o.y + o.height - n.y - n.height)) return;
                t.prop(["size", "height"], n.height + i)
            } else {
                t = this.getPadding();
                if (0 === (i = o.y + o.height - (s.y + s.height - t.bottom))) return
            }
            this.prop(["size", "height"], s.height + i)
        }, afterSwimlaneResizeTop(i, t = {}) {
            let e;
            var n = this.getSwimlanes();
            let o = i.getBBox();
            var s = this.getBBox(), n = (n.forEach(t => {
                var e;
                i !== t && (e = t.getBBox(), setElementBBox(t, e.x, o.y, e.width, o.height))
            }), t.phases ?? this.getPhases()), [t] = n;
            if (t) {
                n = t.getBBox();
                if (0 === (e = o.y - n.y)) return;
                setElementBBox(t, n.x, n.y + e, n.width, n.height - e)
            } else {
                t = this.getPadding();
                if (0 === (e = o.y - s.y - t.top)) return
            }
            setElementBBox(this, s.x, s.y + e, s.width, s.height - e)
        }, afterSwimlaneResizeRight(t, e = {}) {
            let i;
            var e = e.swimlanes ?? this.getSwimlanes(), n = e.indexOf(t), t = t.getBBox(), o = this.getBBox(),
                s = this.getPadding(), e = e.slice(n + 1);
            if (0 < e.length) {
                var [n] = e;
                if (0 === (i = t.x + t.width - n.position().x)) return;
                e.forEach(t => t.translate(i, 0))
            } else if (0 === (i = t.x + t.width - (o.x + o.width - s.right))) return;
            this.prop(["size", "width"], o.width + i), this.fixPhasesDimensionToFitPool()
        }, afterSwimlaneResizeLeft(t, e = {}) {
            let i;
            var e = e.swimlanes ?? this.getSwimlanes(), n = e.indexOf(t), t = t.getBBox(), o = this.getBBox(),
                e = e.slice(0, n);
            if (0 < e.length) {
                n = e.at(-1).getBBox();
                if (0 === (i = t.x - n.x - n.width)) return;
                e.forEach(t => t.translate(i, 0))
            } else {
                n = this.getPadding(), e = this.getPhasePadding();
                if (0 === (i = t.x - o.x - n.left - e.left)) return
            }
            setElementBBox(this, o.x + i, o.y, o.width - i, o.height), this.fixPhasesDimensionToFitPool()
        }, afterPhaseResizeBottom(t, e = {}) {
            let i;
            var e = e.phases ?? this.getPhases(), n = e.indexOf(t), t = t.getBBox(), o = this.getBBox(),
                s = this.getPadding(), e = e.slice(n + 1);
            if (0 < e.length) {
                var [n] = e, n = n.position().y;
                if (0 === (i = t.y + t.height - n)) return;
                e.forEach(t => t.translate(0, i)), this.getElementsInOrthogonalRange(n, 1 / 0, {partial: !1}).forEach(t => t.translate(0, i))
            } else if (0 === (i = t.y + t.height - (o.y + o.height - s.bottom))) return;
            this.prop(["size", "height"], o.height + i), this.fixSwimlanesDimensionToFitPhases()
        }, afterPhaseResizeTop(t, e = {}) {
            let i;
            var e = e.phases ?? this.getPhases(), n = e.indexOf(t), t = t.getBBox(), o = this.getBBox(),
                s = this.getPadding(), e = e.slice(0, n);
            if (0 < e.length) {
                n = e.at(-1).getBBox(), n = n.y + n.height;
                if (0 === (i = t.y - n)) return;
                e.forEach(t => t.translate(0, i)), this.getElementsInOrthogonalRange(-1 / 0, n, {partial: !1}).forEach(t => t.translate(0, i))
            } else if (0 === (i = t.y - (o.y + s.top))) return;
            setElementBBox(this, o.x, o.y + i, o.width, o.height - i), this.fixSwimlanesDimensionToFitPhases()
        }, afterPhaseResizeRight(t, e = {}) {
            var t = t.getBBox(), i = this.getPadding(), n = this.getBBox(),
                t = t.x + t.width - (n.x + n.width - i.right);
            0 != t && ((i = (e.swimlanes ?? this.getSwimlanes()).at(-1)) && (e = i.getBBox(), i.prop(["size", "width"], e.width + t)), setElementBBox(this, n.x, n.y, n.width + t, n.height), this.fixPhasesDimensionToFitPool())
        }, afterPhaseResizeLeft(t, e = {}) {
            var t = t.getBBox(), i = this.getPadding(), n = this.getBBox(), i = n.x + i.left - t.x;
            0 != i && ((t = (e.swimlanes ?? this.getSwimlanes())[0]) && (e = t.getBBox(), setElementBBox(t, e.x - i, e.y, e.width + i, e.height)), setElementBBox(this, n.x - i, n.y, n.width + i, n.height), this.fixPhasesDimensionToFitPool())
        }, layout(t = {}) {
            var e = this.getBBox(), i = this.getPadding(), n = t.swimlanes ?? this.getSwimlanes();
            let o = this.getSwimlaneDimension();
            var s = this.getPhasePadding(), r = n.reduce((t, e) => {
                    e = e.getBBox();
                    return Math.max(t, e[o])
                }, 0),
                n = (this.layoutSwimlanes(n, e.x + i.left + s.left, e.y + i.top + s.top, r), this.resizeToFitSwimlanes(), this.getBBox()),
                s = t.phases ?? this.getPhases(), r = this.getPhaseDimension(), t = this.getPhaseStartSide(),
                a = this.getPhaseEndSide(), n = n[r] - i[t] - i[a];
            this.layoutPhases(s, e.x + i.left, e.y + i.top, n), this.setStackingOrder()
        }, layoutSwimlanes(t, o, s, r) {
            var a = this.graph;
            if (a) {
                let e = this.getSwimlaneDimension(), i = (t.forEach(t => {
                    t.prop(["size", e], r)
                }), a.startBatch("layout-swimlanes"), o), n = s;
                t.forEach(t => {
                    var e = t.get("size").width;
                    t.position(i, n, {deep: !0}), i += e
                }), a.stopBatch("layout-swimlanes")
            }
        }, layoutPhases(t, o, s, r) {
            var a = this.graph;
            if (a) {
                let e = this.getPhaseDimension(), i = (t.forEach(t => {
                    t.prop(["size", e], r)
                }), a.startBatch("layout-phases"), o), n = s;
                t.forEach(t => {
                    var e = t.get("size").height;
                    t.position(i, n), n += e
                }), a.stopBatch("layout-phases")
            }
        }, resizePhaseOrthogonalStart(t, e, i) {
            var n = this.getPhaseOrthogonalCoordinate(), o = this.getPhaseOrthogonalDimension(), e = t[e],
                s = e.getBBox();
            s[n] += i, s[o] -= i, setElementBBox(e, s.x, s.y, s.width, s.height), this.afterPhaseResizeTop(e, {phases: t})
        }, resizePhaseOrthogonalEnd(t, e, i) {
            var n = this.getPhaseOrthogonalDimension(), e = t[e];
            e.prop(["size", n], e.size()[n] + i), this.afterPhaseResizeBottom(e, {phases: t})
        }
    }), HeaderedVerticalPool = VerticalPool.define("bpmn2.HeaderedVerticalPool", {
        headerSide: "top",
        padding: {top: 40},
        headerTextMargin: 5,
        attrs: {
            header: {automaticHeaderAttributes: !0, strokeWidth: 2, stroke: "#000000", fill: "#ffffff"},
            headerText: {
                automaticHeaderTextAttributes: !0,
                cursor: "text",
                fontSize: 16,
                fill: "#000000",
                text: "Pool",
                automaticHeaderTextWrap: !0,
                textAnchor: "middle",
                textVerticalAnchor: "middle"
            }
        }
    }, {
        markup: [{tagName: "rect", selector: "body"}, {tagName: "rect", selector: "header"}, {
            tagName: "text",
            selector: "headerText"
        }], getHeaderSide() {
            var t = this.get("headerSide");
            if (-1 === ["left", "top", "right", "bottom"].indexOf(t)) throw new Error("Invalid value provided to `headerSide` model attribute.");
            return t
        }, getHeaderSize() {
            var t = this.getHeaderSide();
            return this.getPadding()[t]
        }, getHeaderTextMargin() {
            return this.get("headerTextMargin")
        }
    }, {
        attributes: {
            "automatic-header-attributes": automaticHeaderAttributes,
            "automatic-header-text-attributes": automaticHeaderTextAttributes,
            "automatic-header-text-wrap": automaticHeaderTextWrap
        }
    }), VerticalPoolView = CompositePoolView,
    HeaderedVerticalPoolView = VerticalPoolView.extend({presentationAttributes: VerticalPoolView.addPresentationAttributes({headerTextMargin: ["UPDATE", "TOOLS"]})}),
    HorizontalSwimlane = Swimlane.define("bpmn2.HorizontalSwimlane", {
        headerSide: "left",
        attrs: {
            body: {strokeWidth: 2, stroke: "#000000", fill: "#ffffff"},
            header: {strokeWidth: 2, stroke: "none", fill: "transparent"},
            headerText: {fontSize: 16, fill: "#000000", text: "Lane"}
        }
    }, {
        isHorizontal() {
            return !0
        }
    }), HorizontalSwimlaneView = SwimlaneView, VerticalSwimlane = Swimlane.define("bpmn2.VerticalSwimlane", {
        headerSide: "top",
        attrs: {
            body: {strokeWidth: 2, stroke: "#000000", fill: "#ffffff"},
            header: {strokeWidth: 2, stroke: "none", fill: "transparent"},
            headerText: {fontSize: 16, fill: "#000000", text: "Lane"}
        }
    }, {
        isHorizontal() {
            return !1
        }
    }), VerticalSwimlaneView = SwimlaneView, HorizontalPhase = Phase.define("bpmn2.HorizontalPhase", {
        headerSide: "left",
        attrs: {
            body: {strokeWidth: 2, stroke: "#000000"},
            header: {strokeWidth: 2, stroke: "#000000", fill: "#ffffff"},
            headerText: {fontSize: 16, fill: "#000000", text: "Phase"}
        }
    }, {
        isHorizontal() {
            return !0
        }
    }), HorizontalPhaseView = PhaseView, VerticalPhase = Phase.define("bpmn2.VerticalPhase", {
        headerSide: "top",
        attrs: {
            body: {strokeWidth: 2, stroke: "#000000"},
            header: {strokeWidth: 2, stroke: "#000000", fill: "#ffffff"},
            headerText: {fontSize: 16, fill: "#000000", text: "Phase"}
        }
    }, {
        isHorizontal() {
            return !1
        }
    }), VerticalPhaseView = PhaseView;
var bpmn2 = {
    __proto__: null,
    Activity: Activity,
    Annotation: Annotation,
    AnnotationLink: AnnotationLink,
    Choreography: Choreography,
    CompositePool: CompositePool,
    CompositePoolView: CompositePoolView,
    Conversation: Conversation,
    ConversationLink: ConversationLink,
    DataAssociation: DataAssociation,
    DataObject: DataObject,
    DataStore: DataStore,
    Event: Event,
    Flow: Flow,
    Gateway: Gateway,
    Group: Group,
    HeaderedHorizontalPool: HeaderedHorizontalPool,
    HeaderedHorizontalPoolView: HeaderedHorizontalPoolView,
    HeaderedPool: HeaderedPool,
    HeaderedPoolView: HeaderedPoolView,
    HeaderedVerticalPool: HeaderedVerticalPool,
    HeaderedVerticalPoolView: HeaderedVerticalPoolView,
    HorizontalPhase: HorizontalPhase,
    HorizontalPhaseView: HorizontalPhaseView,
    HorizontalPool: HorizontalPool,
    HorizontalPoolView: HorizontalPoolView,
    HorizontalSwimlane: HorizontalSwimlane,
    HorizontalSwimlaneView: HorizontalSwimlaneView,
    Phase: Phase,
    PhaseView: PhaseView,
    Pool: Pool,
    PoolView: PoolView,
    Swimlane: Swimlane,
    SwimlaneView: SwimlaneView,
    VerticalPhase: VerticalPhase,
    VerticalPhaseView: VerticalPhaseView,
    VerticalPool: VerticalPool,
    VerticalPoolView: VerticalPoolView,
    VerticalSwimlane: VerticalSwimlane,
    VerticalSwimlaneView: VerticalSwimlaneView
};
let $$m = mvc.$, Plot = dia$1.Element.extend({
    useCSSSelectors: !0,
    markup: ['<clipPath class="clip"><rect/></clipPath>', '<g class="rotatable">', '<g class="scalable"></g>', '<g class="background"><rect/><text/></g>', '<g class="axis">', '<g class="y-axis"><path/><g class="ticks"></g></g>', '<g class="x-axis"><path/><g class="ticks"></g></g>', '<g class="markings"></g>', "</g>", '<g class="data"><g class="series"></g></g>', '<g class="foreground">', '<rect/><text class="caption"/><text class="subcaption"/>', '<g class="legend"><g class="legend-items"></g></g>', '<line class="guideline x-guideline" /><line class="guideline y-guideline" />', "</g>", "</g>"].join(""),
    tickMarkup: '<g class="tick"><line/><text/></g>',
    pointMarkup: '<g class="point"><circle/><text/></g>',
    barMarkup: '<path class="bar"/>',
    markingMarkup: '<g class="marking"><rect/><text/></g>',
    serieMarkup: '<g><clipPath class="serie-clip"><rect/></clipPath><path/><g class="bars"></g><g class="points"></g></g>',
    legendItemMarkup: '<g class="legend-item"><circle/><text/></g>',
    defaults: util.defaultsDeep({
        type: "chart.Plot", attrs: {
            root: {cursor: "move"},
            ".data path": {fill: "none", stroke: "black"},
            ".data .bars rect": {fill: "none", stroke: "black"},
            ".background rect": {fill: "white", stroke: "#e5e5e5", opacity: 1},
            ".background text": {
                fill: "black",
                text: "No data available.",
                ref: ".",
                "ref-x": .5,
                "ref-y": .5,
                "text-anchor": "middle",
                "y-alignment": "middle",
                display: "none"
            },
            ".foreground > rect": {fill: "white", stroke: "#e5e5e5", opacity: 0, "pointer-events": "none"},
            ".foreground .caption": {
                fill: "black",
                text: "",
                ref: ".foreground > rect",
                "ref-x": .5,
                "ref-y": 10,
                "text-anchor": "middle",
                "y-alignment": "middle",
                "font-size": 14
            },
            ".foreground .subcaption": {
                fill: "black",
                text: "",
                ref: ".foreground > rect",
                "ref-x": .5,
                "ref-y": 23,
                "text-anchor": "middle",
                "y-alignment": "middle",
                "font-size": 10
            },
            ".point": {display: "inline-block"},
            ".point circle": {r: 2, stroke: "black", fill: "black", opacity: .3},
            ".point text": {fill: "black", "font-size": 8, "text-anchor": "middle", display: "none"},
            ".axis path": {fill: "none", stroke: "black"},
            ".axis .tick": {fill: "none", stroke: "black"},
            ".y-axis .tick line": {fill: "none", stroke: "black", x2: 2, y2: 0, opacity: 1},
            ".x-axis .tick line": {fill: "none", stroke: "black", x2: 0, y2: -3, opacity: 1},
            ".y-axis .tick text": {fill: "black", stroke: "none", "font-size": 10, "text-anchor": "end"},
            ".x-axis .tick text": {fill: "black", stroke: "none", "font-size": 10, "text-anchor": "middle"},
            ".y-axis .tick text > tspan": {dy: "-.5em", x: -5},
            ".x-axis .tick text > tspan": {dy: ".5em", x: 0},
            ".axis .markings": {fill: "black", stroke: "none", "fill-opacity": 1},
            ".axis .markings text": {fill: "black", "text-anchor": "end", "font-size": 10, dy: -5, dx: -5},
            ".guideline": {"pointer-events": "none", display: "none"},
            ".x-guideline": {stroke: "black", visibility: "hidden"},
            ".y-guideline": {stroke: "black", visibility: "hidden"},
            ".legend": {"ref-x": 10, "ref-y": 10},
            ".legend-item text": {fill: "black", transform: "translate(14, 0)", "font-size": 11},
            ".legend-item circle": {r: 5, transform: "translate(5,5)"},
            ".legend-item": {cursor: "pointer"},
            ".legend-item.disabled circle": {fill: "gray"},
            ".legend-item.disabled text": {opacity: .5}
        }
    }, dia$1.Element.prototype.defaults),
    legendPosition: function (t, e) {
        e = e || {}, this.trigger("batch:start"), [".legend/ref-x", ".legend/ref-y", ".legend/ref-dx", ".legend/ref-dy", ".legend/x-alignment", ".legend/y-alignment"].forEach(function (t) {
            this.removeAttr(t, {silent: !0})
        }, this);
        e = e.padding || 10, e = {
            n: {".legend": {"ref-x": .5, "x-alignment": -.5, "ref-y": e}},
            ne: {".legend": {"ref-dx": -e, "x-alignment": -.999, "ref-y": e}},
            e: {".legend": {"ref-dx": -e, "x-alignment": -.999, "ref-y": .5, "y-alignment": -.5}},
            se: {".legend": {"ref-dx": -e, "ref-dy": -e, "x-alignment": -.999, "y-alignment": -.999}},
            s: {".legend": {"ref-x": .5, "ref-dy": -e, "x-alignment": -.5, "y-alignment": -.999}},
            sw: {".legend": {"ref-x": e, "ref-dy": -e, "y-alignment": -.999}},
            w: {".legend": {"ref-x": e, "ref-y": .5, "y-alignment": -.5}},
            nw: {".legend": {"ref-x": e, "ref-y": e}},
            nnw: {".legend": {"ref-x": e, "ref-y": -e, "y-alignment": -.999}},
            nn: {".legend": {"ref-x": .5, "ref-y": -e, "x-alignment": -.5, "y-alignment": -.999}},
            nne: {".legend": {"ref-dx": -e, "ref-y": -e, "x-alignment": -.999, "y-alignment": -.999}},
            nnee: {".legend": {"ref-dx": e, "ref-y": -e, "y-alignment": -.999}},
            nee: {".legend": {"ref-y": e, "ref-dx": e}},
            ee: {".legend": {"ref-dx": e, "ref-y": .5, "y-alignment": -.5}},
            see: {".legend": {"ref-dx": e, "ref-dy": -e, "y-alignment": -.999}},
            ssee: {".legend": {"ref-dx": e, "ref-dy": e}},
            sse: {".legend": {"ref-dx": -e, "ref-dy": e, "x-alignment": -.999}},
            ss: {".legend": {"ref-x": .5, "ref-dy": e, "x-alignment": -.5}},
            ssw: {".legend": {"ref-x": e, "ref-dy": e}},
            ssww: {".legend": {"ref-x": -e, "ref-dy": e, "x-alignment": -.999}},
            sww: {".legend": {"ref-x": -e, "ref-dy": -e, "x-alignment": -.999, "y-alignment": -.999}},
            ww: {".legend": {"ref-x": -e, "ref-y": .5, "x-alignment": -.999, "y-alignment": -.5}},
            nww: {".legend": {"ref-x": -e, "ref-y": e, "x-alignment": -.999}},
            nnww: {".legend": {"ref-x": -e, "ref-y": -e, "x-alignment": -.999, "y-alignment": -.999}}
        };
        e[t] && this.attr(e[t]), this.trigger("batch:stop")
    },
    addPoint: function (t, e, i) {
        i = i || {};
        var n = this.get("series"), o = util.toArray(n).findIndex(function (t) {
            return t.name === e
        });
        if (-1 === o) throw new Error("Serie " + e + " was not found.");
        var s = util.cloneDeep(n[o]);
        s.data.push(t), Number.isFinite(i.maxLen) && s.data.length > i.maxLen && s.data.shift(), (n = n.slice())[o] = s, this.set("series", n, i)
    },
    lastPoint: function (e) {
        var t = util.toArray(this.get("series")).find(function (t) {
            return t && t.name === e
        }).data;
        return t[t.length - 1]
    },
    firstPoint: function (e) {
        return util.toArray(this.get("series")).find(function (t) {
            return t && t.name === e
        }).data[0]
    }
}), PlotView = dia$1.ElementView.extend({
    events: {mousemove: "onMouseMove", mouseout: "onMouseOut"},
    presentationAttributes: dia$1.ElementView.addPresentationAttributes({
        series: ["UPDATE"],
        interpolate: ["UPDATE"],
        padding: ["UPDATE"],
        canvas: ["UPDATE"],
        markings: ["UPDATE"],
        axis: ["UPDATE"]
    }),
    initialize: function () {
        dia$1.ElementView.prototype.initialize.apply(this, arguments), this.on("cell:pointerdown", this.onPointerDown, this), this._disabledSeries = []
    },
    renderMarkup: function () {
        dia$1.ElementView.prototype.renderMarkup.apply(this, arguments), this.elDataClipPath = this.$(".clip")[0], this.elDataClipPathRect = this.elDataClipPath.firstChild, this.elBackgroundRect = this.$(".background rect")[0], this.elBackgroundText = this.$(".background text")[0], this.elForeground = this.$(".foreground")[0], this.elForegroundRect = this.$(".foreground rect")[0], this.elDataSeries = this.$(".data .series")[0], this.elYAxisPath = this.$(".y-axis path")[0], this.elYAxisTicks = this.$(".y-axis .ticks")[0], this.elXAxisPath = this.$(".x-axis path")[0], this.elXAxisTicks = this.$(".x-axis .ticks")[0], this.elMarkings = this.$(".axis .markings")[0], this.elXGuideline = this.$(".x-guideline")[0], this.elYGuideline = this.$(".y-guideline")[0], this.elLegend = this.$(".legend")[0], this.elLegendItems = this.$(".legend-items")[0], this.elTick = V(this.model.tickMarkup), this.elMarking = V(this.model.markingMarkup), this.elLegendItem = V(this.model.legendItemMarkup), this.elPoint = V(this.model.pointMarkup), this.elBar = V(this.model.barMarkup), this.elSerie = V(this.model.serieMarkup), this.elDataClipPath.id = "clip_" + this.cid, V(this.$(".data")[0]).attr("clip-path", "url(#" + this.elDataClipPath.id + ")"), V(this.elMarkings).attr("clip-path", "url(#" + this.elDataClipPath.id + ")")
    },
    update: function () {
        var t = this.filterSeries(), e = (this.calculateStats(t), this.model.get("size")), i = e.width, e = e.height,
            n = (this.canvas = util.assign({x: 0, y: 0, width: i, height: e}, this.model.get("canvas")), {
                top: 0,
                right: 0,
                bottom: 0,
                left: 0
            }), o = this.model.get("padding"), o = util.isObject(o) ? util.assign({}, n, o) : void 0 !== o ? {
                top: o,
                right: 2 * o,
                bottom: 2 * o,
                left: o
            } : n, n = (this.canvas = g.rect(this.canvas).moveAndExpand(g.rect(o.left, o.top, -o.right, -o.bottom)), {
                x: 0,
                y: 0,
                width: i,
                height: e
            });
        V(this.elDataClipPathRect).attr(n), V(this.elBackgroundRect).attr(n), V(this.elForegroundRect).attr(n), this.updateAxis(), this.updateMarkings(), this.isEmpty() ? this.elBackgroundText.style.display = "block" : this.elBackgroundText.style.display = "none", this.updateSeries(t), this.updateLegend(), dia$1.ElementView.prototype.update.apply(this, arguments)
    },
    calculateStats: function (t) {
        t = t || this.model.get("series");
        var o = [], s = [], r = {}, a = {}, l = {}, t = (util.toArray(t).forEach(function (e, t) {
            var i, n = l[e.name || t] || (l[e.name || t] = {});
            n.decreasingX = !0, n.decreasingY = !0, n.nonDecreasingX = !0, n.nonDecreasingY = !0, util.forIn(e.data, function (t) {
                n.minX = void 0 === n.minX ? t.x : Math.min(n.minX, t.x), n.maxX = void 0 === n.maxX ? t.x : Math.max(n.maxX, t.x), n.minY = void 0 === n.minY ? t.y : Math.min(n.minY, t.y), n.maxY = void 0 === n.maxY ? t.y : Math.max(n.maxY, t.y), i && (n.decreasingX = n.decreasingX && t.x < i.x, n.decreasingY = n.decreasingY && t.y < i.y, n.nonDecreasingX = n.nonDecreasingX && t.x >= i.x, n.nonDecreasingY = n.nonDecreasingY && t.y >= i.y), o.includes(t.x) || o.push(t.x), s.includes(t.y) || s.push(t.y), (r[t.x] || (r[t.x] = [])).push({
                    serie: e,
                    x: t.x,
                    y: t.y
                }), (a[t.y] || (a[t.y] = [])).push({serie: e, x: t.x, y: t.y}), i = t
            })
        }), this.model.get("axis") || {}), e = t["x-axis"] || {}, t = t["y-axis"] || {};
        this.stats = {
            minX: void 0 === e.min ? o.reduce(function (t, e) {
                return e < t ? e : t
            }, 1 / 0) : e.min, maxX: void 0 === e.max ? o.reduce(function (t, e) {
                return t < e ? e : t
            }, -1 / 0) : e.max, minY: void 0 === t.min ? s.reduce(function (t, e) {
                return e < t ? e : t
            }, 1 / 0) : t.min, maxY: void 0 === t.max ? s.reduce(function (t, e) {
                return t < e ? e : t
            }, -1 / 0) : t.max, bySerie: l, xValues: o, yValues: s, xMap: r, yMap: a
        }
    },
    isEmpty: function () {
        return !this.stats.xValues.length
    },
    updateSeries: function (t) {
        var l, h, c, d, u;
        t = t || this.model.get("series"), this.elDataSeries.textContent = "", this.isEmpty() || (l = [this.stats.minX, this.stats.maxX], h = [this.stats.minY, this.stats.maxY], c = [this.canvas.x, this.canvas.x + this.canvas.width], d = [this.canvas.y + this.canvas.height, this.canvas.y], u = this.model.get("attrs"), util.toArray(t).forEach(function (n, t) {
            var e = n.data, o = [], i = this.elSerie.clone().attr("class", n.name || "serie-" + t),
                e = (V(this.elDataSeries).append(i), util.forIn(e, function (t) {
                    var e = g.scale.linear(l, c, t.x), i = g.scale.linear(h, d, t.y);
                    o.push({
                        x: e,
                        y: i
                    }), u[".point"] && "none" !== u[".point"].display && this.renderPoint(t, n), n.bars && this.renderBar(t, n)
                }.bind(this)), i.findOne(".serie-clip")), s = this.model.get("size"),
                r = this.stats.bySerie[n.name || t], a = g.scale.linear(l, c, r.minX), r = g.scale.linear(l, c, r.maxX);
            e.findOne("rect").attr(g.rect(a, 0, r - a, s.height)), n.bars || i.findOne("path").attr({
                d: this.seriePathData(o, n, t),
                "clip-path": "url(#" + e.node.id + ")"
            })
        }, this))
    },
    seriePathClipData: function (t, e) {
        var i = this.model.get("size"), t = t[0];
        return ["M", t.x, t.y, "V", i.height + 10].join(" ")
    },
    renderBar: function (t, e) {
        var i = [this.stats.minX, this.stats.maxX], n = [this.stats.minY, this.stats.maxY],
            o = [this.canvas.x, this.canvas.x + this.canvas.width],
            s = [this.canvas.y + this.canvas.height, this.canvas.y], i = g.scale.linear(i, o, t.x),
            o = g.scale.linear(n, s, t.y), r = e.bars.barWidth || .8,
            r = 1 < r ? r : this.canvas.width / (this.stats.maxX - this.stats.minX) * r,
            s = g.scale.linear(n, s, 0) - o,
            n = (n[0] === n[1] && (o = this.canvas.y + this.canvas.height, s = 0), t["top-rx"] || e.bars["top-rx"]),
            a = t["top-ry"] || e.bars["top-ry"], l = t["bottom-rx"] || e.bars["bottom-rx"],
            h = t["bottom-ry"] || e.bars["bottom-ry"],
            i = {left: i, middle: i - r / 2, right: i - r}[e.bars.align || "middle"], c = this.elBar.clone(),
            t = (c.attr({
                "data-serie": e.name,
                "data-x": t.x,
                "data-y": t.y,
                d: V.rectToPath({
                    x: i,
                    y: o,
                    width: r,
                    height: s,
                    "top-rx": n,
                    "top-ry": a,
                    "bottom-rx": l,
                    "bottom-ry": h
                })
            }), e.name || "serie-" + this.model.get("series").indexOf(e));
        return V(this.elDataSeries).findOne("." + t + " .bars").append(c), c.node
    },
    renderPoint: function (t, e) {
        var i = [this.stats.minX, this.stats.maxX], n = [this.stats.minY, this.stats.maxY],
            o = [this.canvas.x, this.canvas.x + this.canvas.width],
            s = [this.canvas.y + this.canvas.height, this.canvas.y], i = g.scale.linear(i, o, t.x),
            o = g.scale.linear(n, s, t.y),
            s = (n[0] === n[1] && (o = this.canvas.y + this.canvas.height), this.elPoint.clone()),
            n = (s.attr({"data-serie": e.name, "data-x": t.x, "data-y": t.y}), s.findOne("circle").attr({
                cx: i,
                cy: o
            }), s.findOne("text").attr({
                x: i,
                dy: o
            }).text(this.pointLabel(t, e)), e.name || "serie-" + this.model.get("series").indexOf(e));
        return V(this.elDataSeries).findOne("." + n + " .points").append(s), s.node
    },
    seriePathData: function (t, e, i) {
        var n, o, s = t.length, r = [this.stats.minY, this.stats.maxY];
        if (r[0] === r[1]) for (n = 0; n < s; n++) t[n].y = this.canvas.y + this.canvas.height;
        switch (void 0 === e.interpolate ? this.model.get("interpolate") : e.interpolate) {
            case"bezier":
                o = new g.Path(g.Curve.throughPoints(t));
                break;
            case"step":
                for ((o = new g.Path).appendSegment(g.Path.createSegment("M", t[0].x, t[0].y)), n = 1; n < s; n++) o.appendSegment(g.Path.createSegment("L", (t[n - 1].x + t[n].x) / 2, t[n - 1].y)), o.appendSegment(g.Path.createSegment("L", (t[n - 1].x + t[n].x) / 2, t[n].y));
                o.appendSegment(g.Path.createSegment("L", t[s - 1].x, t[s - 1].y));
                break;
            case"stepBefore":
                for ((o = new g.Path).appendSegment(g.Path.createSegment("M", t[0].x, t[0].y)), n = 1; n < s; n++) o.appendSegment(g.Path.createSegment("L", t[n - 1].x, t[n].y)), o.appendSegment(g.Path.createSegment("L", t[n].x, t[n].y));
                break;
            case"stepAfter":
                for ((o = new g.Path).appendSegment(g.Path.createSegment("M", t[0].x, t[0].y)), n = 1; n < s; n++) o.appendSegment(g.Path.createSegment("L", t[n].x, t[n - 1].y)), o.appendSegment(g.Path.createSegment("L", t[n].x, t[n].y));
                break;
            default:
                for ((o = new g.Path).appendSegment(g.Path.createSegment("M", t[0].x, t[0].y)), n = 1; n < s; n++) o.appendSegment(g.Path.createSegment("L", t[n].x, t[n].y))
        }
        return this.fixPathForFill(o, t, e, i).serialize()
    },
    fixPathForFill: function (t, e, i, n) {
        var o, s, r, a;
        return 0 === e.length || i.hideFillBoundaries || this.stats.bySerie[i.name || n].nonDecreasingX && (n = t.getSegment(0), t.replaceSegment(0, g.Path.createSegment("L", n.end.x, n.end.y)), n = i.fillPadding && i.fillPadding.left || 0, o = i.fillPadding && i.fillPadding.right || 0, s = i.fillPadding && i.fillPadding.bottom || 10, r = this.model.get("size"), a = e[0], t.insertSegment(0, g.Path.createSegment("M", (e = e[e.length - 1]).x + o, r.height + s)), t.insertSegment(1, g.Path.createSegment("L", a.x - n, r.height + s)), t.insertSegment(2, g.Path.createSegment("L", a.x - n, a.y)), i.showRightFillBoundary) && (t.appendSegment(g.Path.createSegment("L", e.x + o, e.y)), t.appendSegment(g.Path.createSegment("Z"))), t
    },
    updateAxis: function () {
        var t, e, i, n = this.model.get("axis"), o = this.model.get("size"), s = o.height, r = o.width;

        function l(t, e, i, n, o, s, r, a) {
            for (var l = i[1] - i[0], h = t.ticks || 11, c = l / (h = 0 == l ? 1 : h) / a, d = i[0], u = 0; u < h; u++) p.call(this, t, e, i, n, o, s, r, d), d += c
        }

        function p(t, e, i, n, o, s, r, a) {
            var l = this.elTick.clone(), o = o.call(this, i, n, a);
            o > e.width || (s.call(this, l, o, e), s = r.call(this, a, i, n), l.findOne("text").text(this.tickLabel(s, t)))
        }

        V(this.elXAxisPath).attr("d", ["M", 0, s, "L", r, s].join(" ")), V(this.elYAxisPath).attr("d", ["M", 0, 0, "L", 0, s].join(" ")), this.elXAxisTicks.textContent = "", this.elYAxisTicks.textContent = "", this.isEmpty() || (r = [this.stats.minX, this.stats.maxX], s = [this.stats.minY, this.stats.maxY], t = [this.canvas.x, this.canvas.x + this.canvas.width], e = [0, this.canvas.height], i = n && n["y-axis"] || {}, n = n && n["x-axis"] || {}, function (t, e, i, n) {
            function o(t, e, i) {
                t.translate(e, i.height), V(this.elXAxisTicks).append(t)
            }

            function s(t, e, i) {
                return g.scale.linear(t, e, i)
            }

            function r(t) {
                return t
            }

            var a;
            t.ticks ? (a = this.canvas.width / (e.width - 2 * this.canvas.x), l.call(this, t, e, i, n, s, o, r, a)) : (a = this.stats.xValues, function (i, n, o, s, r, a, l, t) {
                t.forEach(function (t, e) {
                    e % (i.tickStep || 1) == 0 && p.call(this, i, n, o, s, r, a, l, t)
                }, this)
            }.call(this, t, e, i, n, s, o, r, a))
        }.call(this, n, o, r, t), function (t, e, i, n) {
            var o = this.canvas.height / e.height;
            l.call(this, t, e, i, n, function (t, e, i) {
                return t[0] === t[1] ? this.canvas.y + this.canvas.height : g.scale.linear(t, e, i)
            }, function (t, e) {
                t.translate(0, e), V(this.elYAxisTicks).append(t)
            }, function (t, e, i) {
                t = e[1] - (t - e[0]);
                return t += g.scale.linear(i, e, this.canvas.y) - e[0]
            }, o)
        }.call(this, i, o, s, e))
    },
    tickLabel: function (t, e) {
        var i;
        return util.isFunction(e.tickFormat) ? e.tickFormat(t) : (i = e.tickFormat || ".1f", util.format.number(i, t) + (util.isFunction(e.tickSuffix) ? e.tickSuffix(t) : e.tickSuffix || ""))
    },
    pointLabel: function (t, e) {
        var i;
        return util.isFunction(e.pointFormat) ? e.pointFormat(t) : (i = e.pointFormat || ".1f", util.format.number(i, t.y) + (e.pointSuffix || ""))
    },
    updateMarkings: function () {
        this.elMarkings.textContent = "";
        var t, c, d, u, p, m, f, e = this.model.get("markings");

        function v(t, e) {
            return void 0 === t ? e : t
        }

        e && 0 !== e.length && (t = this.model.get("size"), c = t.width, d = t.height, u = [this.stats.minX, this.stats.maxX], p = [this.stats.minY, this.stats.maxY], m = [this.canvas.x, this.canvas.x + this.canvas.width], f = [this.canvas.y, this.canvas.y + this.canvas.height], util.toArray(e).forEach(function (t, e) {
            var i = t.start || t.end, n = t.end || t.start,
                o = Math.min(v(i.x, this.stats.minX), v(n.x, this.stats.minX)),
                s = Math.max(v(i.x, this.stats.maxX), v(n.x, this.stats.maxX)),
                r = Math.min(v(i.y, this.stats.minY), v(n.y, this.stats.minY)),
                a = Math.max(v(i.y, this.stats.maxY), v(n.y, this.stats.maxY)), l = void 0 === i.x || void 0 === n.x,
                i = void 0 === i.y || void 0 === n.y,
                n = (l && (m = [0, c]), i && (f = [0, d]), g.scale.linear(u, m, o)), l = g.scale.linear(u, m, s),
                i = g.scale.linear(p, f, r), o = g.scale.linear(p, f, a), s = n, h = f[1] - o + f[0], l = l - n,
                n = o - i;
            if (p[0] === p[1] && r === a) {
                if (p[0] !== r) return;
                h = this.canvas.y + this.canvas.height, n = 1
            }
            l = Math.max(l, 1), n = Math.max(n, 1), o = this.elMarking.clone(), o.findOne("rect").attr({
                x: s,
                y: h,
                width: l,
                height: n
            }), o.findOne("text").text(t.label || "").attr({
                x: s + l,
                y: h
            }), i = o.attr("class") + " " + (t.name || "marking-" + e);
            o.attr(util.assign({class: i}, t.attrs)), V(this.elMarkings).append(o)
        }, this))
    },
    updateLegend: function () {
        var t = this.model.get("series");
        this.elLegendItems.textContent = "", util.toArray(t).forEach(function (t, e) {
            var i;
            util.isFunction(t.showLegend) && !t.showLegend(t, this.stats.bySerie[t.name || e]) || !1 !== t.showLegend && (i = this.elLegendItem.clone(), this._disabledSeries.includes(t.name) && i.addClass("disabled"), i.attr("data-serie", t.name), i.findOne("circle").attr({fill: this.getSerieColor(t.name)}), i.findOne("text").text(t.label || t.name), i.translate(0, e * (t.legendLabelLineHeight || 16)), V(this.elLegendItems).append(i))
        }, this)
    },
    getSerieColor: function (e) {
        var t = this.model.get("attrs"), i = Object.keys(t).find(function (t) {
            return t.includes(e)
        });
        return i ? t[i].stroke || t[i].fill : "black"
    },
    hideSerie: function (t) {
        this._disabledSeries.includes(t) || this._disabledSeries.push(t);
        t = this.filterSeries();
        this.update(t)
    },
    showSerie: function (t) {
        this._disabledSeries = util.without(this._disabledSeries, t);
        t = this.filterSeries();
        this.update(t)
    },
    filterSeries: function (t) {
        return t = t || this.model.get("series"), t = util.toArray(t).filter(function (t) {
            return !this._disabledSeries.includes(t.name)
        }, this)
    },
    onPointerDown: function (t, e, i) {
        t = t.target.closest(".legend-item");
        t && (V(t).toggleClass("disabled"), V(t).hasClass("disabled") ? this.hideSerie(V(t).attr("data-serie")) : this.showSerie(V(t).attr("data-serie")))
    },
    onMouseMove: function (t) {
        this.showGuidelines(t.clientX, t.clientY, t)
    },
    onMouseOut: function (t) {
        this.hideGuidelines(), this.trigger("mouseout", t)
    },
    showGuidelines: function (t, e, i) {
        var n, o, s = this.model.get("angle"), r = this.model.getBBox(),
            s = new g.Point(V(this.paper.layers).toLocalPoint(t, e)).rotate(r.center(), s);
        g.rect(r).containsPoint(s) && (o = this.model.get("size"), n = s.x - r.x, s = s.y - r.y, V(this.elXGuideline).attr({
            x1: n,
            y1: 0,
            x2: n,
            y2: o.height,
            visibility: "visible"
        }), V(this.elYGuideline).attr({
            x1: 0,
            y1: s,
            x2: o.width,
            y2: s,
            visibility: "visible"
        }), r = g.scale.linear([this.canvas.x, this.canvas.x + this.canvas.width], [this.stats.minX, this.stats.maxX], n), o = g.scale.linear([this.canvas.y, this.canvas.y + this.canvas.height], [this.stats.minY, this.stats.maxY], s), n = {
            x: r,
            y: this.stats.minY + this.stats.maxY - o
        }, s = {x: t, y: e}, o = this.closestPoints(r), this.trigger("mouseover", n, s, o, i))
    },
    closestPoints: function (t) {
        var e = util.sortedIndex(this.stats.xValues, t), i = this.stats.xValues[e], e = this.stats.xValues[e - 1],
            t = void 0 === e || Math.abs(t - i) < Math.abs(t - e) ? i : e;
        return this.stats.xMap[t]
    },
    hideGuidelines: function () {
        V(this.elXGuideline).attr("visibility", "hidden"), V(this.elYGuideline).attr("visibility", "hidden")
    }
}), Pie = dia$1.Element.extend({
    useCSSSelectors: !0,
    markup: ['<g class="rotatable">', '<g class="scalable"></g>', '<g class="background"><rect/><text/></g>', '<g class="data"></g>', '<g class="foreground">', '<rect/><text class="caption"/><text class="subcaption"/>', '<g class="legend"><g class="legend-items"></g></g>', "</g>", "</g>"].join(""),
    sliceMarkup: '<g class="slice"/>',
    sliceFillMarkup: '<path class="slice-fill"/>',
    sliceBorderMarkup: '<path class="slice-border"/>',
    sliceInnerLabelMarkup: '<text class="slice-inner-label"/>',
    legendSerieMarkup: '<g class="legend-serie"><text/></g>',
    legendSliceMarkup: '<g class="legend-slice"><circle/><text/></g>',
    defaults: util.defaultsDeep({
        type: "chart.Pie",
        size: {width: 200, height: 200},
        pieHole: 0,
        serieDefaults: {startAngle: 0, degree: 360, label: null, showLegend: !0, labelLineHeight: 6},
        sliceDefaults: {
            innerLabel: "{percentage:.0f}%",
            innerLabelMargin: 6,
            legendLabel: "{label}: {value}",
            legendLabelLineHeight: 6,
            legendLabelMargin: 14,
            offset: 0,
            onClickEffect: {type: "offset", offset: 20},
            onHoverEffect: null
        },
        series: [],
        attrs: {
            root: {cursor: "move"},
            ".background > rect": {opacity: 0},
            ".background > text": {
                fill: "black",
                text: "No data available.",
                ref: ".background > rect",
                "ref-x": .5,
                "ref-y": .5,
                "text-anchor": "middle",
                "y-alignment": "middle",
                display: "none"
            },
            ".foreground > rect": {fill: "white", stroke: "#e5e5e5", opacity: 0, "pointer-events": "none"},
            ".foreground .caption": {
                fill: "black",
                text: "",
                ref: ".foreground > rect",
                "ref-x": 2,
                "ref-y": 6,
                "text-anchor": "start",
                "y-alignment": "middle",
                "font-size": 14
            },
            ".foreground .subcaption": {
                fill: "black",
                text: "",
                ref: ".foreground > rect",
                "ref-x": 2,
                "ref-y": 18,
                "text-anchor": "start",
                "y-alignment": "middle",
                "font-size": 10
            },
            ".data": {ref: ".background", "ref-x": .5, "ref-y": .5},
            ".slice": {cursor: "pointer"},
            ".slice > .slice-fill": {stroke: "#ffffff", "stroke-width": 1, "fill-opacity": 1},
            ".slice.hover > .slice-fill": {"fill-opacity": .8},
            ".slice > .slice-border": {
                "stroke-width": 6,
                "stroke-opacity": .4,
                "fill-opacity": 1,
                fill: "none",
                display: "none"
            },
            ".slice.hover > .slice-border": {display: "block"},
            ".slice > .slice-inner-label": {
                "text-anchor": "middle",
                "font-size": "12",
                stroke: "none",
                "stroke-width": "0",
                fill: "#ffffff"
            },
            ".slice > .slice-inner-label > tspan": {dy: "-.5em"},
            ".legend": {"ref-dx": 20, "ref-y": 5},
            ".legend-serie text": {fill: "grey", transform: "translate(2, 0)", "font-size": 13},
            ".legend-slice": {cursor: "pointer"},
            ".legend-slice text": {"font-weight": "normal", fill: "black", "font-size": 11},
            ".legend-slice.hover text": {"font-weight": "bold"},
            ".legend-slice circle": {r: 5, transform: "translate(5,5)"}
        }
    }, dia$1.Element.prototype.defaults),
    addSlice: function (t, e, i) {
        i = i || {}, e = e || 0;
        var n = this.get("series"), o = (void 0 === n[e] && (n[e] = {data: []}), util.cloneDeep(n[e]));
        o.data.push(t), i = 1 < ((n = n.slice())[e] = o).data.length ? util.assign(i, {changedSerieIndex: e}) : i, this.set("series", n, i)
    },
    editSlice: function (t, e, i, n) {
        n = n || {}, i = i || 0;
        var o = this.get("series");
        if (void 0 === o[i] || void 0 === o[i].data[e]) throw new Error("Slice " + e + " on serie " + i + " was not found.");
        var s = util.cloneDeep(o[i]);
        s.data[e] = util.assign(s.data[e], t), (o = o.slice())[i] = s, this.set("series", o, util.assign(n, {changedSerieIndex: i}))
    }
}), PieView = dia$1.ElementView.extend({
    events: {
        "mouseover .slice": "onMouseOverSlice",
        "mouseout .slice": "onMouseOverSlice",
        "mousemove .slice": "onMouseMoveSlice",
        "mouseover .legend-slice": "onEventLegendItem",
        "mouseout .legend-slice": "onEventLegendItem"
    },
    presentationAttributes: dia$1.ElementView.addPresentationAttributes({
        series: ["UPDATE"],
        serieDefaults: ["UPDATE"],
        sliceDefaults: ["UPDATE"],
        pieHole: ["UPDATE"]
    }),
    initialize: function () {
        dia$1.ElementView.prototype.initialize.apply(this, arguments), this.on("cell:pointerclick", this.onClickSlice, this), this.on("cell:pointerclick", this.onEventLegendItem, this)
    },
    renderMarkup: function () {
        dia$1.ElementView.prototype.renderMarkup.apply(this, arguments), this.elBackgroundRect = this.$(".background rect")[0], this.elBackgroundText = this.$(".background text")[0], this.elForegroundRect = this.$(".foreground rect")[0], this.elLegendItems = this.$(".legend-items")[0], this.elPie = this.$(".data")[0], this.elSlice = V(this.model.sliceMarkup), this.elSliceFill = V(this.model.sliceFillMarkup), this.elSliceBorder = V(this.model.sliceBorderMarkup), this.elSliceInnerLabel = V(this.model.sliceInnerLabelMarkup), this.elLegendSerie = V(this.model.legendSerieMarkup), this.elLegendSlice = V(this.model.legendSliceMarkup)
    },
    update: function (t, e, i) {
        var n = (i = i || {}).changedSerieIndex, i = this.calculateSeries(n),
            o = (n in i ? $$m(this.elPie).find(".serie-" + n).remove() : $$m(this.elPie).empty(), this.model.get("size"));
        V(this.elBackgroundRect).attr(o), V(this.elForegroundRect).attr(o), i.length ? this.elBackgroundText.style.display = "none" : this.elBackgroundText.style.display = "block", util.toArray(i).forEach(function (t, e) {
            void 0 !== n && n !== e || util.forIn(t.data, this.updateSlice.bind(this))
        }, this), this.updateLegend(), dia$1.ElementView.prototype.update.apply(this, arguments)
    },
    calculateSeries: function (r) {
        var t = util.cloneDeep(this.model.get("series")), a = this.model.get("serieDefaults"),
            l = this.model.get("sliceDefaults"), e = this.model.get("size"), e = Math.min(e.width, e.height) / 2,
            i = this.model.get("pieHole"), h = e, c = (e - (1 < i ? i : e * i)) / t.length;
        return this._series = t.map(function (t, i) {
            var n, e, o, s;
            return void 0 !== r && r !== i || (n = (t = util.defaults(t, a)).startAngle, e = t.data.reduce(function (t, e) {
                return t + e.value
            }, 0), o = t.degree / e || 0, s = 100 / e, t.data = t.data.map(function (t, e) {
                (t = util.defaults(t, util.omit(l, "offset", "onClickEffect", "onHoverEffect"))).outerRadius = h, t.innerRadius = h - c, i || ((t = util.defaults(t, util.pick(l, "offset", "onClickEffect", "onHoverEffect"))).isOuter = !0, t.offset = 1 < t.offset ? t.offset : t.offset * t.outerRadius, t.onClickEffect.offset = 1 < t.onClickEffect.offset ? t.onClickEffect.offset : t.onClickEffect.offset * t.outerRadius), t.serieIndex = i, t.sliceIndex = e, t.innerLabelMargin = t.innerLabelMargin < -1 || 1 < t.innerLabelMargin ? t.innerLabelMargin : t.innerLabelMargin * t.outerRadius, t.percentage = t.value * s;
                e = t.value * o;
                return t.degree = {angle: e, start: n, end: e + n}, t.rad = {
                    angle: g.toRad(t.degree.angle, !0),
                    start: g.toRad(t.degree.start, !0),
                    end: g.toRad(t.degree.end, !0)
                }, t.middleangle = (t.rad.start + t.rad.end) / 2, n = t.degree.end, t
            }), h -= c), t
        }), this._series
    },
    updateLegend: function () {
        var t = this._series, s = (this.elLegendItems.textContent = "", 0),
            i = parseInt(this.model.attr(".legend-serie text/font-size"), 10),
            r = parseInt(this.model.attr(".legend-slice text/font-size"), 10);
        util.toArray(t).forEach(function (t, o) {
            var e;
            t.showLegend && (t.label && (e = this.elLegendSerie.clone(), t.name && e.addClass(t.name), e.attr({"data-serie": o}), e.findOne("text").text(t.label), e.translate(0, s), V(this.elLegendItems).append(e), s += i + t.labelLineHeight), util.forIn(t.data, function (t, e) {
                var i = this.elLegendSlice.clone(), n = this.getSliceFillColor(e, o);
                t.name && i.addClass(t.name), i.attr({
                    "data-serie": o,
                    "data-slice": e
                }), i.findOne("text").text(util.format.string(t.legendLabel, t)), i.findOne("text").translate(t.legendLabelMargin), i.translate(0, s), s += r + t.legendLabelLineHeight, util.isObject(n) ? this.applyGradient(i.node.querySelector("circle"), "fill", n) : i.findOne("circle").attr({fill: n}), V(this.elLegendItems).append(i)
            }.bind(this)))
        }, this)
    },
    applyGradient: function (t, e, i) {
        var t = util.isString(t) ? this.findNodes(t) : $$m(t).toArray(), n = this.paper.defineGradient(i);
        t.forEach(function (t) {
            V(t).attr(e, "url(#" + n + ")")
        })
    },
    updateSlice: function (t) {
        var e = this.elSlice.clone(), i = (V(this.elPie).append(e), this.elSliceFill.clone()),
            n = this.getSliceFillColor(t.sliceIndex, t.serieIndex), i = (i.attr({
                fill: n,
                d: V.createSlicePathData(t.innerRadius, t.outerRadius, t.rad.start, t.rad.end)
            }), e.append(i), util.isObject(n) && this.applyGradient("#" + i.attr("id"), "fill", n), this.elSliceBorder.clone()),
            o = parseInt(this.model.attr(".slice > .slice-border/stroke-width"), 10),
            s = g.point.fromPolar(t.outerRadius + o / 2, -t.rad.start, g.point(0, 0)),
            r = g.point.fromPolar(t.outerRadius + o / 2, -t.rad.end, g.point(0, 0)), s = (i.attr({
                stroke: n,
                d: this.drawArc(s, r, t.outerRadius + o / 2, t.rad.start, t.rad.end)
            }), e.append(i), util.isObject(n) && this.applyGradient("#" + i.attr("id"), "stroke", n), this.elSliceInnerLabel.clone()),
            r = (s.text(util.format.string(t.innerLabel, t)), e.append(s), s.bbox()),
            o = t.outerRadius - r.width / 2 - t.innerLabelMargin,
            i = (s.translate(o * Math.cos(-t.middleangle), -o * Math.sin(-t.middleangle)), e.attr({
                "data-serie": t.serieIndex,
                "data-slice": t.sliceIndex,
                "data-value": t.value
            }), this._series[t.serieIndex].name);
        return i && e.addClass(i), t.name && e.addClass(t.name), e.addClass("serie-" + t.serieIndex + " slice-" + t.sliceIndex), t.isOuter && (e.addClass("outer"), t.offset) && (e.addClass("clicked"), this.effectOnSlice(e, t, {
            type: "offset",
            offset: t.offset
        })), e
    },
    getSliceFillColor: function (e, i) {
        i = i || 0;
        var t = this.model.get("attrs"), n = Object.keys(t).find(function (t) {
            return -1 < t.indexOf(".serie-" + i + ".slice-" + e + " > .slice-fill")
        });
        return (n ? t[n] : this._series[i].data[e]).fill
    },
    onMouseMoveSlice: function (t) {
        var e = V(t.currentTarget), i = e.attr("data-serie"), e = e.attr("data-slice"), i = this._series[i].data[e];
        this.trigger(t.type, i, t)
    },
    mouseOverSlice: function (t, e) {
        var i = V(this.$('.slice[data-serie="' + (e = e || 0) + '"][data-slice="' + t + '"]')[0]),
            n = this._series[e].data[t],
            n = (i.toggleClass("hover"), n.isOuter && !util.isEmpty(n.onHoverEffect) && this.effectOnSlice(i, n, n.onHoverEffect, !i.hasClass("hover")), V(this.$('.legend-slice[data-serie="' + e + '"][data-slice="' + t + '"]')[0])),
            i = (n && n.toggleClass("hover"), Object.keys(this.model.get("attrs")).filter(function (t) {
                return -1 < t.indexOf(".slice") || -1 < t.indexOf(".legend-slice")
            }));
        dia$1.ElementView.prototype.update.call(this, this.model, util.pick(this.model.get("attrs"), i))
    },
    onMouseOverSlice: function (t) {
        var e = V(t.currentTarget), i = e.attr("data-serie"), e = e.attr("data-slice"),
            i = (this.mouseOverSlice(e, i), this._series[i].data[e]);
        this.trigger(t.type, i, t)
    },
    clickSlice: function (t, e) {
        var i = V(this.$('.slice[data-serie="' + (e = e || 0) + '"][data-slice="' + t + '"]')[0]),
            n = this._series[e].data[t];
        n.isOuter && (i.hasClass("clicked") ? (i.removeClass("clicked"), this.model.get("series")[e].data[t].offset = 0, this.effectOnSlice(i, n, n.onClickEffect, !0)) : (i.addClass("clicked"), this.model.get("series")[e].data[t].offset = n.onClickEffect.offset, this.effectOnSlice(i, n, n.onClickEffect)))
    },
    onClickSlice: function (t) {
        var e, i = V(t.target.closest(".slice.outer"));
        i && (e = i.attr("data-serie"), i = i.attr("data-slice"), this.clickSlice(i, e), e = this._series[e].data[i], this.trigger(t.type, e, t))
    },
    onEventLegendItem: function (t) {
        var e = V(t.target.closest(".legend-slice"));
        if (e) {
            var i = e.attr("data-serie"), n = e.attr("data-slice");
            switch (t.type) {
                case"click":
                    this.clickSlice(n, i);
                    break;
                case"mouseover":
                case"mouseout":
                    this.mouseOverSlice(n, i)
            }
        }
    },
    effectOnSlice: function (t, e, i, n) {
        switch (n = n || !1, i.type) {
            case"enlarge":
                n ? t.scale(1) : t.scale(i.scale || 1.05);
                break;
            case"offset":
                n ? t.translate(0, 0, {absolute: !0}) : t.translate(i.offset * Math.cos(-e.middleangle), -i.offset * Math.sin(-e.middleangle))
        }
    },
    svgArcMax: 2 * Math.PI - 1e-6,
    drawArc: function (t, e, i, n, o) {
        var s = 0, r = 1, o = o - n;
        return o > Math.PI && (s = 1, o >= this.svgArcMax) && (r = s = 0), "M" + t.x + "," + t.y + " A" + i + "," + i + " 0 " + s + "," + r + " " + e.x + "," + e.y
    }
}), Knob = Pie.extend({
    defaults: util.defaultsDeep({
        type: "chart.Knob",
        sliceDefaults: {legendLabel: "{value:.0f}", outer: {offsetOnClick: 0}},
        pieHole: .7,
        value: 0,
        attrs: {
            ".legend": {"ref-x": .5, "ref-y": .5, "ref-dx": null, "x-alignment": -.5, "y-alignment": -.5},
            ".legend-slice text": {"font-size": 30},
            ".legend-slice circle": {display: "none"},
            ".slice-inner-label": {display: "none"},
            ".slice-fill": {stroke: "none"}
        }
    }, Pie.prototype.defaults), initialize: function () {
        this.set("series", this.getKnobSeries(), {silent: !0}), Pie.prototype.initialize.apply(this, arguments), this.on("change:value change:min change:max change:fill", this.updateKnob, this)
    }, getKnobSeries: function () {
        var t = Array.isArray(this.get("value")) ? this.get("value") : [this.get("value")],
            s = Array.isArray(this.get("fill")) ? this.get("fill") : [this.get("fill")],
            r = Array.isArray(this.get("min")) ? this.get("min") : [this.get("min")],
            a = Array.isArray(this.get("max")) ? this.get("max") : [this.get("max")];
        return t.map(function (t, e) {
            var i = void 0 === r[e] ? r[0] : r[e], n = void 0 === a[e] ? a[0] : a[e], o = void 0 === s[e] ? s[0] : s[e];
            return {degree: g.scale.linear([i, n], [0, 360], t), data: [{value: t, fill: o}], showLegend: !(0 < e)}
        })
    }, updateKnob: function () {
        this.set("series", this.getKnobSeries())
    }
}), KnobView = PieView, Matrix = dia$1.Element.extend({
    useCSSSelectors: !0,
    markup: ['<g class="rotatable">', '<g class="scalable">', '<g class="background"><rect/></g>', '<g class="cells"/>', '<g class="foreground"/>', "</g>", '<g class="labels">', '<g class="rows"/>', '<g class="columns"/>', "</g>", "</g>"].join(""),
    cellMarkup: '<rect class="cell"/>',
    labelMarkup: '<text class="label"/>',
    gridLineMarkup: '<path class="grid-line"/>',
    defaults: util.defaultsDeep({
        type: "chart.Matrix",
        attrs: {
            root: {cursor: "move"},
            ".background rect": {fill: "#eeeeee"},
            ".grid-line": {stroke: "white", "stroke-width": 2},
            ".label": {fill: "black", "alignment-baseline": "middle"},
            ".labels .rows .label": {"text-anchor": "end"},
            ".labels .columns .label": {"text-anchor": "start"}
        }
    }, dia$1.Element.prototype.defaults)
}), MatrixView = dia$1.ElementView.extend({
    presentationAttributes: dia$1.ElementView.addPresentationAttributes({
        size: ["LABELS"],
        cells: [dia$1.ElementView.Flags.RENDER]
    }), confirmUpdate: function (t, e) {
        return this.hasFlag(t, "LABELS") && !this.hasFlag(t, dia$1.ElementView.Flags.RENDER) && (this.renderLabels(), t = this.removeFlag(t, "LABELS")), dia$1.ElementView.prototype.confirmUpdate.call(this, t, e)
    }, renderMarkup: function () {
        dia$1.ElementView.prototype.renderMarkup.apply(this, arguments), this.elCells = this.$(".cells")[0], this.elRowLabels = this.$(".labels .rows")[0], this.elColumnLabels = this.$(".labels .columns")[0], this.elForeground = this.$(".foreground")[0], this.elCell = V(this.model.cellMarkup), this.elGridLine = V(this.model.gridLineMarkup);
        var t = this.model.get("cells") || [], e = this.model.get("size");
        if (this.elBackgroundRect = this.$(".background rect")[0], V(this.elBackgroundRect).attr(e), Array.isArray(t) && 0 !== t.length && Array.isArray(t[0]) && 0 !== t[0].length) {
            for (var i, n, o, s, r, a = e.height / t.length, l = e.width / t[0].length, h = document.createDocumentFragment(), c = (this.elCells.textContent = "", this.elForeground.textContent = "", document.createDocumentFragment()), d = 0; d < t.length; d++) for ((o = this.elGridLine.clone()).addClass("horizontal"), o.attr("d", "M 0 " + d * a + " " + e.width + " " + d * a), c.appendChild(o.node), i = t[d], n = 0; n < i.length; n++) 0 === d && ((o = this.elGridLine.clone()).addClass("vertical"), o.attr("d", "M " + n * l + " 0 " + n * l + " " + e.height), c.appendChild(o.node)), (s = i[n]) && ((r = this.elCell.clone()).attr(util.assign({
                x: n * l,
                y: d * a,
                width: l,
                height: a
            }, s)), h.appendChild(r.node));
            this.elForeground.appendChild(c), this.elCells.appendChild(h), this.renderLabels()
        }
    }, renderLabels: function () {
        this.elLabel = V(this.model.labelMarkup);
        var t = this.model.get("cells") || [];
        if (Array.isArray(t) && 0 !== t.length && Array.isArray(t[0]) && 0 !== t[0].length) {
            for (var e, i, n, o, s = this.model.get("labels") || {}, r = s.rows || [], a = s.columns || [], l = this.model.get("size"), h = l.height / t.length, c = l.width / t[0].length, d = (this.elRowLabels.textContent = "", this.elColumnLabels.textContent = "", document.createDocumentFragment()), u = 0; u < r.length; u++) e = s.rows[u], (i = this.elLabel.clone()).text(e.text), i.attr(util.assign({
                x: -(s.padding || 5),
                y: u * h + h / 2,
                "text-anchor": "end",
                "dominant-baseline": "central",
                "font-size": h,
                "data-row": u
            }, util.omit(e, "text"))), d.appendChild(i.node);
            this.elRowLabels.appendChild(d);
            for (var p = document.createDocumentFragment(), g = 0; g < a.length; g++) e = s.columns[g], i = this.elLabel.clone(), o = -(s.padding || 5), i.attr("x", n = g * c + c / 2), i.text(e.text), i.attr(util.assign({
                y: o,
                "text-anchor": "start",
                "dominant-baseline": "central",
                "font-size": c,
                "data-column": g
            }, util.omit(e, "text"))), i.rotate(-90, n, o), p.appendChild(i.node);
            this.elColumnLabels.appendChild(p)
        }
    }
});
var chart = {
    __proto__: null,
    Knob: Knob,
    KnobView: KnobView,
    Matrix: Matrix,
    MatrixView: MatrixView,
    Pie: Pie,
    PieView: PieView,
    Plot: Plot,
    PlotView: PlotView
};
let {Link: BaseLink, attributes} = dia$1, zeroVector = new g.Point(1, 0),
    Distance = BaseLink.define("measurement.Distance", {
        attrs: {
            line: {
                connection: !0,
                stroke: "#333333",
                strokeWidth: 2,
                strokeLinejoin: "round",
                targetMarker: {type: "path", "stroke-width": 2, d: "M 0 10 0 -10 M 10 10 0 0 10 -10", fill: "none"},
                sourceMarker: {type: "path", "stroke-width": 2, d: "M 0 10 0 -10 M 10 10 0 0 10 -10", fill: "none"}
            },
            wrapper: {connection: !0, strokeWidth: 10, strokeLinejoin: "round"},
            anchorLines: {stroke: "#333333", strokeWidth: 1, strokeDasharray: "1,2"},
            sourceAnchorLine: {dAnchor: "source"},
            targetAnchorLine: {dAnchor: "target"},
            distanceLabel: {
                distanceText: {unit: "px", fixed: 0},
                fontFamily: "sans-serif",
                fontWeight: "lighter",
                fontSize: 14,
                labelPosition: {ratio: .5, offset: 12},
                textAnchor: "middle",
                textVerticalAnchor: "middle"
            }
        }
    }, {
        markup: [{tagName: "path", selector: "sourceAnchorLine", groupSelector: "anchorLines"}, {
            tagName: "path",
            selector: "targetAnchorLine",
            groupSelector: "anchorLines"
        }, {
            tagName: "path",
            selector: "wrapper",
            attributes: {fill: "none", cursor: "pointer", stroke: "transparent", "stroke-linecap": "round"}
        }, {tagName: "path", selector: "line", attributes: {fill: "none", "pointer-events": "none"}}, {
            tagName: "text",
            selector: "distanceLabel"
        }], getDistanceText: function (t, e = {}) {
            var {fixed: e = 0, unit: i = ""} = e, t = t.getConnectionLength().toFixed(e);
            return i ? t + " " + i : "" + t
        }
    }, {
        attributes: {
            "distance-text": {
                set: function (t, ...e) {
                    attributes.text.set.call(this, this.model.getDistanceText(this, t), ...e)
                }
            }, "d-anchor": {
                set: function (t) {
                    return {d: "M " + new g.Line(this.getEndAnchor(t), this.getEndConnectionPoint(t)).serialize()}
                }
            }, "label-position": {
                set: function (t) {
                    var {ratio: t = .5, offset: e = 0} = t;
                    let i, n;
                    t = this.getTangentAtRatio(t);
                    t ? (n = t.vector().vectorAngle(zeroVector), i = t.start) : (i = this.path.start, n = 0);
                    let o, s = e;
                    return {
                        transform: o = 0 === n ? `translate(${i.x},${i.y})` : (t = g.normalizeAngle((n + 90) % 180 - 90), n !== t && (s = -e), `translate(${i.x},${i.y}) rotate(${t})`),
                        y: s
                    }
                }
            }
        }
    }), AngleStarts = {self: "self", source: "source", target: "target"},
    AngleDirections = {clockwise: "clockwise", anticlockwise: "anticlockwise", small: "small", large: "large"},
    Angle = BaseLink.define("measurement.Angle", {
        attrs: {
            line: {
                connection: !0,
                stroke: "#333333",
                strokeWidth: 2,
                strokeLinejoin: "round"
            },
            wrapper: {connection: !0, strokeWidth: 10, strokeLinejoin: "round"},
            angles: {stroke: "#333333", fill: "none", strokeWidth: 1, angleRadius: 40},
            sourceAngle: {angleD: "source"},
            targetAngle: {angleD: "target"},
            angleLabels: {
                textAnchor: "middle",
                textVerticalAnchor: "middle",
                fill: "#333333",
                fontSize: 11,
                fontFamily: "sans-serif",
                angleTextDecimalPoints: 0,
                angleTextDistance: 23
            },
            sourceAngleLabel: {angleText: "source", angleTextPosition: "source"},
            targetAngleLabel: {angleText: "target", angleTextPosition: "target"}
        }
    }, {
        markup: [{
            tagName: "path",
            selector: "wrapper",
            attributes: {fill: "none", cursor: "pointer", stroke: "transparent", "stroke-linecap": "round"}
        }, {tagName: "path", selector: "line", attributes: {fill: "none", "pointer-events": "none"}}, {
            tagName: "path",
            selector: "sourceAngle",
            groupSelector: "angles",
            attributes: {cursor: "pointer"}
        }, {
            tagName: "path",
            selector: "targetAngle",
            groupSelector: "angles",
            attributes: {cursor: "pointer"}
        }, {tagName: "text", selector: "sourceAngleLabel", groupSelector: "angleLabels"}, {
            tagName: "text",
            selector: "targetAngleLabel",
            groupSelector: "angleLabels"
        }], getAngleText: function (t = {}) {
            var {angle: t = 0, decimalPoints: e = 2} = t;
            return t.toFixed(e) + "\xb0"
        }
    }, {
        AngleStarts: AngleStarts, AngleDirections: AngleDirections, attributes: {
            "angle-d": {
                set: function (t, e, i, n) {
                    var o, s, {
                        "angle-radius": n = 40,
                        "angle-start": r = AngleStarts.self,
                        "angle-pie": a = !1,
                        "angle-direction": l = AngleDirections.small,
                        angle: h
                    } = n, t = getAngleData(this, t, {angle: h, angleRadius: n, angleStart: r, angleDirection: l});
                    return t ? ({
                        connectionPoint: h,
                        linkArcPoint: r,
                        otherArcPoint: l,
                        arcAngle: t,
                        largeArcFlag: o,
                        sweepFlag: s
                    } = t, r = ["M " + r.serialize(), `A ${n} ${n} ${t} ${o} ${s} ` + l.serialize()], a && r.push(`L ${h.serialize()} Z`), {d: r.join(" ")}) : {d: "M 0 0 0 0"}
                }
            },
            "angle-text": {
                set: function (t, e, i, n) {
                    let o = "";
                    t = getAngleData(this, t, {angleRadius: 40});
                    t && (o = this.model.getAngleText({
                        angle: t.angleBetween,
                        decimalPoints: n["angle-text-decimal-points"]
                    })), attributes.text.set.call(this, o, e, i, n)
                }
            },
            "angle-text-position": {
                set: function (t, e, i, n) {
                    var {"angle-text-distance": n = 60} = n, t = getAngleData(this, t, {angleRadius: n});
                    if (!t) return {};
                    var {connectionPoint: t, otherArcPoint: o, linkArcPoint: s, angleBetween: r, largeArcFlag: a} = t;
                    let l;
                    Math.abs(r - 180) < 1e-6 ? (r = s.clone().rotate(t, a ? 90 : -90), l = new g.Line(t, r).setLength(n)) : (r = new g.Line(s, o).midpoint(), l = new g.Line(t, r).setLength(n), a && l.scale(-1, -1, l.start));
                    s = l.end, o = g.normalizeAngle((l.angle() + 90) % 180 - 90);
                    return {transform: `translate(${s.serialize()}) rotate(${o})`}
                }
            },
            angle: {},
            "angle-radius": {},
            "angle-text-distance": {},
            "angle-text-decimal-points": {},
            "angle-pie": {},
            "angle-start": {},
            "angle-direction": {}
        }
    });

function getAngleData(t, e, i) {
    let n;
    var o = "angleData", s = t.nodeCache(t.el);
    if (o in s) {
        if (e in s[o]) return s[o][e]
    } else s[o] = {};
    var r, a, o = "number" == typeof i.angle, l = t.getEndView(e);
    return (l || o) && (a = t.getTangentAtRatio((r = "target" === e) ? 1 : 0)) ? (r && a.scale(-1, -1, a.start), n = o ? getManualAngleData(a, i) : l.model.isLink() ? getLinkAngleData(a, l, i) : getElementAngleData(a, l, t.getEndMagnet(e), i), s.angleData[e] = n) : null
}

function getManualAngleData(t, {angle: e, angleRadius: i}) {
    var n = t.clone().rotate(t.start, -e);
    return getTangentsAngleData(t, n, {
        angleRadius: i,
        angleStart: AngleStarts.target,
        angleDirection: e < 0 ? AngleDirections.clockwise : AngleDirections.anticlockwise
    })
}

function getLinkAngleData(t, e, i) {
    var n = e.getClosestPointLength(t.start);
    return getTangentsAngleData(t, e.getTangentAtLength(n), i)
}

function getTangentsAngleData(t, e, {angleRadius: i, angleStart: n, angleDirection: o}) {
    var {start: s, end: r} = t.setLength(i), t = t.angle();
    let a = e.setLength(i).end, l = s.angleBetween(r, a), h = 1, c = 0, d = !1, u = !1, p = !0;
    var m = Math.floor(l / 90);
    switch (n) {
        case AngleStarts.target:
            o === AngleDirections.small ? o = l < 180 ? AngleDirections.clockwise : AngleDirections.anticlockwise : o === AngleDirections.large && (o = 180 < l ? AngleDirections.clockwise : AngleDirections.anticlockwise), o === AngleDirections.anticlockwise ? (0 < l && l < 180 && (c ^= 1), u = !0) : (AngleDirections.clockwise, 180 <= l && (c ^= 1), h ^= 1), p = !1;
            break;
        case AngleStarts.source:
            o === AngleDirections.small ? o = 180 < l ? AngleDirections.clockwise : AngleDirections.anticlockwise : o === AngleDirections.large && (o = l < 180 ? AngleDirections.clockwise : AngleDirections.anticlockwise), o === AngleDirections.anticlockwise ? (180 < l && (c ^= 1), h = 1, u = !0) : (AngleDirections.clockwise, l < 180 && (c ^= 1), h = 0), p = !1, d = !0, l = g.normalizeAngle(l + 180);
            break;
        default:
            AngleStarts.self;
            switch (o) {
                case AngleDirections.anticlockwise:
                    d = 0 === m || 1 === m, h = 1, u = !0;
                    break;
                case AngleDirections.clockwise:
                    d = 2 === m || 3 === m, h = 0, u = !1;
                    break;
                case AngleDirections.small:
                    d = 1 === m || 2 === m, h = 0 === m || 2 === m ? 0 : 1, u = 1 === m || 3 === m;
                    break;
                case AngleDirections.large:
                    d = 0 === m || 3 === m, h = 1 === m || 3 === m ? 0 : 1, u = 0 === m || 2 === m
            }
    }
    return d && (a = a.reflection(s)), p && 180 <= l && (l = g.normalizeAngle(l - 180)), {
        angleBetween: l = u ? g.normalizeAngle((p ? 180 : 360) - l) : l,
        connectionPoint: s,
        linkArcPoint: r,
        otherArcPoint: a,
        largeArcFlag: c,
        sweepFlag: h,
        arcAngle: t
    }
}

function getElementAngleData(t, e, i, {angleRadius: n, angleDirection: o}) {
    var s = e.model, r = s.angle(), s = s.getCenter(), e = e.getNodeUnrotatedBBox(i), i = t.clone().setLength(1).end,
        i = i.rotate(s, r);
    if (e.containsPoint(i)) return null;
    let a = 0, l = 0, h = t.angle() - r;
    i.y > e.y + e.height || i.y < e.y ? (h += 90, a = n) : l = n, h = g.normalizeAngle(h);
    let c;
    var d = Math.floor(h / 90);
    switch (d) {
        case 0:
            c = 1;
            break;
        case 1:
            c = 0;
            break;
        case 2:
            a *= -1, l *= -1, c = 1;
            break;
        case 3:
            a *= -1, l *= -1, c = 0
    }
    let u = !1;
    switch (o) {
        case AngleDirections.large:
            u = !0;
            break;
        case AngleDirections.anticlockwise:
            u = 0 === d || 2 === d;
            break;
        case AngleDirections.clockwise:
            u = 1 === d || 3 === d
    }
    u && (a *= -1, l *= -1, c ^= 1);
    var {start: s, end: i} = t.setLength(n), e = s.clone().offset(a, l).rotate(s, -r);
    let p = s.angleBetween(i, e);
    return 180 < p && (p = 360 - p), {
        arcAngle: h,
        angleBetween: p,
        sweepFlag: c,
        largeArcFlag: 0,
        otherArcPoint: e,
        linkArcPoint: i,
        connectionPoint: s
    }
}

var measurement = {__proto__: null, Angle: Angle, Distance: Distance};

class Quadtree {
    constructor(t) {
        this.center = null, this.weight = 0, this.radius = 0, this.object = null, this.bounds = t, this.nodes = [], this.center = null
    }

    initialize(t) {
        this.clear();
        var e = t.map(t => t.p.x), i = t.map(t => t.p.y), n = Math.min(...e), e = Math.max(...e), o = Math.min(...i);
        let s = e - n || 1, r = Math.max(...i) - o || 1;
        (r = s > r ? s : r) > s && (s = r), this.bounds = {x: n, y: o, width: s, height: r}, t.forEach(t => {
            this.insert(t)
        })
    }

    split() {
        var t = this.bounds.width / 2, e = this.bounds.height / 2, i = this.bounds.x, n = this.bounds.y;
        this.nodes[0] = new Quadtree({x: i + t, y: n, width: t, height: e}), this.nodes[1] = new Quadtree({
            x: i,
            y: n,
            width: t,
            height: e
        }), this.nodes[2] = new Quadtree({x: i, y: n + e, width: t, height: e}), this.nodes[3] = new Quadtree({
            x: i + t,
            y: n + e,
            width: t,
            height: e
        })
    }

    getIndex(t) {
        var t = Array.isArray(t) ? t[0] : t, e = this.bounds.x + this.bounds.width / 2,
            i = this.bounds.y + this.bounds.height / 2, i = t.p.y < i, t = t.p.x < e;
        return i && !t ? 0 : i && t ? 1 : !i && t ? 2 : i || t ? 0 : 3
    }

    insert(t) {
        let e, i, n, o;
        o = Array.isArray(t) ? (i = t[0].p, n = t.reduce((t, e) => t + e.weight, 0), Math.max(...t.map(t => t.radius))) : (i = t.p, n = t.weight, t.radius), this.nodes.length ? (e = this.getIndex(t), this.center.x = (this.center.x + i.x) / 2, this.center.y = (this.center.y + i.y) / 2, this.weight += n, this.radius = Math.max(this.radius, o), this.nodes[e].insert(t)) : this.object ? this.center.x === i.x && this.center.y === i.y ? (this.object = [].concat(this.object, t), this.weight += n, this.radius = Math.max(this.radius, o)) : (this.split(), e = this.getIndex(this.object), this.nodes[e].insert(this.object), this.object = null, this.center.x = (this.center.x + i.x) / 2, this.center.y = (this.center.y + i.y) / 2, this.weight += n, this.radius = Math.max(this.radius, o), e = this.getIndex(t), this.nodes[e].insert(t)) : (this.object = t, this.center = {
            x: i.x,
            y: i.y
        }, this.weight = n, this.radius = o)
    }

    clear() {
        this.object = null, this.weight = 0, this.radius = 0, this.center = null;
        for (let t = 0; t < this.nodes.length; t++) this.nodes[t].clear();
        this.nodes = []
    }
}

class ForceDirected extends mvc.Model {
    constructor(t) {
        super(t)
    }

    defaults() {
        return {
            weightDistribution: "linkCount",
            layoutArea: null,
            linkDistance: 50,
            linkStrength: 200,
            charge: 10,
            randomize: !1,
            randomizeArea: null,
            gravity: 10,
            gravityCenter: null,
            linkBias: !0,
            theta: .7,
            deltaT: .99,
            velocityDecay: .6,
            tMin: .001,
            tTarget: 0,
            timeQuantum: .03,
            elementPoint: "center",
            radialForceStrength: 0,
            gravityType: "graph",
            x: null,
            y: null,
            width: null,
            height: null
        }
    }

    initialize() {
        var t = this.get("graph");
        let i, n;
        if (Array.isArray(t)) {
            var o = t;
            i = [], n = [];
            for (let t = 0, e = o.length; t < e; t++) {
                var s = o[t];
                (s.isLink() ? i : n).push(s)
            }
        } else n = t.getElements(), i = t.getLinks();
        var t = this.get("x"), e = this.get("y"), r = this.get("width"), a = this.get("height"),
            t = (t && e && r && a && (this.layoutArea = {
                x: t,
                y: e,
                width: r,
                height: a
            }), this.gravityCenter = this.get("gravityCenter"), this.randomize = this.get("randomize"), this.randomizeArea = this.get("randomizeArea") || this.get("layoutArea"), this.gravity = this.get("gravity"), this.linkStrength = this.get("linkStrength"), this.linkDistance = this.get("linkDistance"), this.layoutArea = this.get("layoutArea"), this.weightDistribution = this.get("weightDistribution"), this.velocityDecay = this.get("velocityDecay"), this.linkBias = this.get("linkBias"), this.charge = this.get("charge"), this.elementPoint = this.get("elementPoint"), this.gravityType = this.get("gravityType"), this.theta = this.get("theta"), this.t = 1, this.tMin = this.get("tMin"), this.tTarget = this.get("tTarget"), this.timeQuantum = this.get("timeQuantum"), this.deltaT = this.get("deltaT"), this.elementData = new Map, this.linkData = new Map, this.get("radialForceStrength"));
        this.radialForceFunction = "function" == typeof t ? t : 0 !== t ? this.createDefaultRadialForceFunction(t) : null, this.useRadialForce = !!this.radialForceFunction, 0 !== this.charge && (this.useRepulsiveForce = !0), n.forEach(t => this.addElement(t)), i.forEach(t => this.addLink(t, !1)), this.calculateBias(), this.quadtree = new Quadtree, (1 < this.velocityDecay || this.velocityDecay < 0) && console.warn("Velocity decay must be a number between 0 and 1.")
    }

    createDefaultRadialForceFunction(i) {
        return t => {
            var {radiusSum: t, distance: e} = t;
            return (t - e) / e * i
        }
    }

    start() {
        if (this.randomize && this.randomizeArea) {
            let {width: e, height: i, x: n, y: o} = this.randomizeArea;
            this.elementData.forEach(t => {
                t.fixed || (t.p = {x: g.random(n, n + e), y: g.random(o, o + i)}, this.setPosition(t.element, t.p))
            })
        }
    }

    addElement(t) {
        let e;
        switch (this.elementPoint) {
            case"center":
                e = t.getCenter();
                break;
            case"origin":
                e = t.position()
        }
        var i, n = this.getCellLayoutAttribute(t) || {},
            o = (n.weight || ((o = t.get("weight")) ? (n.weight = o, t.prop(ForceDirected.attributesName + "/weight", o)) : (o = t.get("charge")) && (n.weight = o)), {
                weight: n.weight || 1,
                weightCoeff: n.weight || 1,
                p: {x: e.x, y: e.y},
                v: {x: 0, y: 0},
                force: {x: 0, y: 0},
                absoluteForce: {x: 0, y: 0},
                element: t,
                fixed: n.fixed || !1,
                restrictX: n.restrictX || !1,
                restrictY: n.restrictY || !1,
                alignX: n.alignX || null,
                alignY: n.alignY || null
            });
        this.useRadialForce && (i = t.getBBox(), i = Math.sqrt(i.width * i.width + i.height * i.height) / 2, o.radius = n.radius || i), this.elementData.set(t.id, o)
    }

    addLink(t, e = !0) {
        var i, n = this.elementData.get(t.getSourceElement().id), o = this.elementData.get(t.getTargetElement().id),
            s = this.getCellLayoutAttribute(t) || {};
        s.strength || (i = t.get("strength")) && (s.strength = i), s.distance || (i = t.get("distance")) && (s.distance = i), this.linkData.set(t.id, {
            source: n,
            target: o,
            strength: s.strength || this.linkStrength,
            distance: s.distance || this.linkDistance,
            link: t,
            bias: .5
        }), e && this.calculateBias()
    }

    removeElement(t) {
        this.elementData.delete(t)
    }

    removeLink(t) {
        this.linkData.delete(t)
    }

    getElementData(t) {
        return this.elementData.get(t)
    }

    getLinkData(t) {
        return this.linkData.get(t)
    }

    getCellLayoutAttribute(t) {
        return t.get(ForceDirected.attributesName)
    }

    calculateWeightCoeff(t) {
        var e;
        if (null == (null == (e = this.getCellLayoutAttribute(t.element)) ? void 0 : e.weight)) switch (this.weightDistribution) {
            case"uniform":
                t.weightCoeff = 1;
                break;
            case"linkCount":
                var i = t.weight;
                i <= 4 && (t.weightCoeff = 1), 4 < i && (t.weightCoeff = .401841 + .41751 * i - .00215849 * i * i + 405786e-11 * i * i * i)
        }
    }

    calculateBias() {
        let n = new Map;
        this.linkData.forEach(t => {
            var e = t.source.element.id, t = t.target.element.id;
            n.set(e, (n.get(e) || 0) + 1), n.set(t, (n.get(t) || 0) + 1)
        }), this.linkData.forEach(t => {
            var e = t.source.element.id, i = t.target.element.id,
                e = ("linkCount" === this.weightDistribution && (this.elementData.get(e).weight = n.get(e), this.elementData.get(i).weight = n.get(i)), this.calculateWeightCoeff(this.elementData.get(e)), this.calculateWeightCoeff(this.elementData.get(i)), n.get(e)),
                i = n.get(i);
            this.linkBias && (t.bias = e / (e + i))
        })
    }

    hasConverged() {
        return this.t < this.tMin
    }

    canIterate() {
        return this.t > this.tTarget
    }

    step(t = this.timeQuantum) {
        this.hasConverged() ? this.notifyEnd() : (this.initializeQuadtree(), this.calculateForces(), this.applyForces(t), this.applyModelChanges(), this.canIterate() && (this.t *= this.deltaT))
    }

    calculateForces() {
        this.useRepulsiveForce && this.calculateRepulsiveForce(), this.calculateAttractiveForce(), this.useRadialForce && this.calculateRadialForce(), this.calculateGravityForce()
    }

    calculateRepulsiveForce() {
        this.elementData.forEach(t => {
            var e = this.calculateRepulsiveForceOnNode(t, this.quadtree);
            e.x /= t.weight, e.y /= t.weight, t.force.x += e.x, t.force.y += e.y
        })
    }

    calculateRepulsiveForceOnNode(o, s) {
        let r = {x: 0, y: 0};
        var a = this.theta, l = s.object;
        if (s.nodes.length || l) {
            var h = s.nodes, c = s.bounds.width, d = s.center, s = s.weight;
            let e = d.x - o.p.x, i = d.y - o.p.y,
                t = (0 === e && (e = this.jiggle()), 0 === i && (i = this.jiggle()), e * e + i * i);
            t < 5 && (t = 5);
            d = Math.sqrt(t);
            let n = this.linkDistance * this.linkDistance / t;
            if (h.length) a < c / d ? h.forEach(t => {
                t = this.calculateRepulsiveForceOnNode(o, t);
                r.x += t.x, r.y += t.y
            }) : (r.x -= e * n * s * this.charge, r.y -= i * n * s * this.charge); else if (l) if (Array.isArray(l)) l.forEach(t => {
                t.id !== o.element.id && (r.x -= e * n * t.weight * this.charge, r.y -= i * n * t.weight * this.charge)
            }); else {
                if (l.id === o.element.id) return r;
                r.x -= e * n * l.weight * this.charge, r.y -= i * n * l.weight * this.charge
            }
        }
        return r
    }

    calculateAttractiveForce() {
        this.linkData.forEach(e => {
            var i = e.target.p.x - e.source.p.x || this.jiggle(), n = e.target.p.y - e.source.p.y || this.jiggle(),
                o = Math.sqrt(i * i + n * n);
            if (this.linkBias) {
                var s = e.bias;
                let t;
                t = .5 < s ? (o - (e.distance + .3 * e.source.weightCoeff * e.distance)) / o * e.strength : (o - (e.distance + .3 * e.target.weightCoeff * e.distance)) / o * e.strength, e.source.force.x += i * t * (1 - s), e.source.force.y += n * t * (1 - s), e.target.force.x += -i * t * s, e.target.force.y += -n * t * s
            } else {
                s = (o - e.distance) / o * e.strength;
                e.source.force.x += i * s, e.source.force.y += n * s, e.target.force.x += -i * s, e.target.force.y += -n * s
            }
        })
    }

    calculateRadialForce() {
        this.elementData.forEach(t => {
            var e = this.calculateRadialForceOnNode(t, this.quadtree);
            t.force.x += e.x, t.force.y += e.y
        })
    }

    calculateRadialForceOnNode(n, o) {
        let s = {x: 0, y: 0};
        var r = o.object, a = o.nodes;
        if (a.length || r) {
            var l = o.center, o = o.radius;
            let t = l.x - n.p.x, e = l.y - n.p.y,
                i = (0 === t && (t = this.jiggle()), 0 === e && (e = this.jiggle()), t * t + e * e);
            i < 1 && (i = 1);
            var h, c, d, u = Math.sqrt(i), p = n.radius + o;
            if (a.length) a.forEach(t => {
                t = this.calculateRadialForceOnNode(n, t);
                s.x += t.x, s.y += t.y
            }); else {
                if (!r || p < u) return s;
                for (h of Array.isArray(r) ? r : [r]) h.id !== n.element.id && ((c = this.elementData.get(h.id)) && 0 !== (d = this.radialForceFunction({
                    radiusSum: p,
                    distance: u,
                    u: n,
                    v: c
                }))) && (s.x -= t * d, s.y -= e * d)
            }
        }
        return s
    }

    calculateGravityForce() {
        if (this.gravityCenter) switch (this.gravityType) {
            case"element":
                this.elementData.forEach(t => {
                    var e = -(t.p.x - this.gravityCenter.x) * this.gravity,
                        i = -(t.p.y - this.gravityCenter.y) * this.gravity;
                    t.force.x += e, t.force.y += i
                });
                break;
            case"elementUniform":
                this.elementData.forEach(t => {
                    var e = t.p.x - this.gravityCenter.x, i = t.p.y - this.gravityCenter.y,
                        n = Math.sqrt(e * e + i * i), e = -e / n * this.gravity, i = -i / n * this.gravity;
                    t.force.x += e, t.force.y += i
                });
                break;
            default: {
                let e = 0, i = 0;
                var t = this.elementData.size;
                this.elementData.forEach(t => {
                    e += t.p.x, i += t.p.y
                });
                let n = -(e / t - this.gravityCenter.x) * this.gravity,
                    o = -(i / t - this.gravityCenter.y) * this.gravity;
                this.elementData.forEach(t => {
                    t.absoluteForce.x += n, t.absoluteForce.y += o
                });
                break
            }
        }
    }

    applyForces(a) {
        this.elementData.forEach(t => {
            if (t.fixed) t.force = {x: 0, y: 0}, t.absoluteForce = {x: 0, y: 0}; else {
                t.restrictX && (t.force.x = 0, t.absoluteForce.x = 0), t.restrictY && (t.force.y = 0, t.absoluteForce.y = 0);
                const s = t.force.x * this.t + t.absoluteForce.x, r = t.force.y * this.t + t.absoluteForce.y;
                var e, i, n, o;
                t.p.x += t.v.x * a + .5 * s * a * a, t.p.y += t.v.y * a + .5 * r * a * a, t.v.x += s * a, t.v.y += r * a, t.v.x *= 1 - this.velocityDecay, t.v.y *= 1 - this.velocityDecay, t.force = {
                    x: 0,
                    y: 0
                }, t.absoluteForce = {
                    x: 0,
                    y: 0
                }, t.alignX && (t.p.x = this.elementData.get(t.alignX).p.x), t.alignY && (t.p.y = this.elementData.get(t.alignY).p.y), this.layoutArea && ({
                    x: e,
                    y: i,
                    width: n,
                    height: o
                } = this.layoutArea, t.p.x < e && (t.p.x = e), t.p.y < i && (t.p.y = i), t.p.x > e + n && (t.p.x = e + n), t.p.y > i + o) && (t.p.y = i + o)
            }
        })
    }

    initializeQuadtree() {
        this.quadtree.initialize(Array.from(this.elementData, ([t, e]) => ({
            id: t,
            p: e.p,
            weight: e.weightCoeff,
            radius: e.radius
        })))
    }

    restart(t) {
        this.t = t || 1
    }

    finalize() {
        for (; !this.hasConverged() && this.canIterate();) this.initializeQuadtree(), this.calculateForces(), this.applyForces(this.timeQuantum), this.t *= this.deltaT;
        this.applyModelChanges()
    }

    changeElementData(t, e) {
        var i = this.elementData.get(t);
        i ? Object.assign(i, e) : console.warn(`Element with id ${t} not found.`)
    }

    changeLinkData(t, e) {
        var i = this.linkData.get(t);
        i ? Object.assign(i, e) : console.warn(`Link with id ${t} not found.`)
    }

    applyModelChanges() {
        this.elementData.forEach(t => {
            this.setPosition(t.element, t.p)
        })
    }

    setPosition(t, e) {
        switch (this.elementPoint) {
            case"center":
                var i = t.size();
                t.position(e.x - i.width / 2, e.y - i.height / 2, {forceDirected: this.cid});
                break;
            case"origin":
                t.position(e.x, e.y, {forceDirected: this.cid})
        }
    }

    notifyEnd() {
        this.trigger("end")
    }

    jiggle() {
        return .001 * (Math.random() - .5)
    }
}

function setPositionAndSize(t, e, i) {
    var n, {size: e, position: o} = e;
    e && ({width: e, height: n} = e, t.resize(e, n, i)), o && ({x: e, y: n} = o, t.position(e, n, i))
}

ForceDirected.attributesName = "forceDirectedAttributes";
let GridLayout = {
        layout: function (t, p) {
            t instanceof dia$1.Graph ? m = t : (m = new dia$1.Graph(null, {ignoreLayers: !0})).resetCells(t, {
                dry: !0,
                sort: !1
            }), t = null, p = p || {};
            var m, e = m.getElements(), f = p.columns || 1, i = Math.ceil(e.length / f), v = p.verticalAlign || "middle",
                y = p.horizontalAlign || "middle", x = !!p.resizeToFit, t = p.marginX || 0, n = p.marginY || 0,
                b = p.columnGap || 0, w = p.rowGap || 0, S = p.setAttributes,
                P = ("function" != typeof S && (S = setPositionAndSize), []), o = p.columnWidth;
            if ("compact" === o) for (var s = 0; s < f; s++) {
                var r = this._elementsAtColumn(e, s, f);
                P.push(this._maxDim(r, "width"))
            } else {
                o && !util.isString(o) || (o = this._maxDim(e, "width"));
                for (var a = 0; a < f; a++) P.push(o)
            }
            var C = this._accumulate(P, t).map((t, e) => t + (e - .5) * b), A = [], l = p.rowHeight;
            if ("compact" === l) for (var h = 0; h < i; h++) {
                var c = this._elementsAtRow(e, h, f);
                A.push(this._maxDim(c, "height"))
            } else {
                l && !util.isString(l) || (l = this._maxDim(e, "height"));
                for (var d = 0; d < i; d++) A.push(l)
            }
            var k = this._accumulate(A, n).map((t, e) => t + (e - .5) * w),
                t = (m.startBatch("layout"), e.forEach(function (t, e) {
                    var i, n, o, s, r = e % f, e = Math.floor(e / f), a = P[r], l = A[e], h = 0, c = 0, d = t.get("size"),
                        u = {};
                    switch (x && (i = a, o = d.height * (d.width ? a / d.width : 1), s = d.width * (d.height ? l / d.height : 1), (n = l) < o ? i = s : n = o, u.size = d = {
                        width: i,
                        height: n
                    }), v) {
                        case"top":
                            break;
                        case"bottom":
                            c = l - d.height;
                            break;
                        case"middle":
                            c = (l - d.height) / 2
                    }
                    switch (y) {
                        case"left":
                            break;
                        case"right":
                            h = a - d.width;
                            break;
                        case"middle":
                            h = (a - d.width) / 2
                    }
                    u.position = {x: C[r] + h + b / 2, y: k[e] + c + w / 2}, S.call(m, t, u, p)
                }), m.stopBatch("layout"), 0 < f && (C[0] += b / 2, C[f] -= b / 2), 0 < i ? (k[0] += w / 2, k[i] -= w / 2) : 0 === k.length && (k = [n, n]), new g.Rect(t, n, C[f] - C[0], k[i] - k[0]));
            return {rowHeights: A, columnWidths: P, gridY: k, gridX: C, bbox: t}
        }, _maxDim: function (t, i) {
            return t.reduce(function (t, e) {
                return Math.max(e.get("size")[i], t)
            }, 0)
        }, _elementsAtRow: function (t, e, i) {
            for (var n = [], o = i * e, s = Math.min(o + i, t.length); o < s; o++) n.push(t[o]);
            return n
        }, _elementsAtColumn: function (t, e, i) {
            for (var n = [], o = e, s = t.length; o < s; o += i) n.push(t[o]);
            return n
        }, _accumulate: function (t, e) {
            return 0 === t.length ? [] : t.reduce(function (t, e, i) {
                return t.push(t[i] + e), t
            }, [e || 0])
        }
    }, Directions = {TopBottom: "TB", BottomTop: "BT", LeftRight: "LR", RightLeft: "RL"},
    Alignments = {Start: "start", Middle: "middle", End: "end"}, setAttributesDefault = (t, e, i) => {
        var n, {size: e, position: o} = e;
        e && ({width: e, height: n} = e, t.resize(e, n, i)), o && ({x: e, y: n} = o, t.position(e, n, i))
    }, StackLayout = {
        Directions: Directions, Alignments: Alignments, layout: function (t, o = {}) {
            let {
                    direction: s = Directions.TopBottom,
                    topLeft: e,
                    bottomLeft: i,
                    topRight: n,
                    bottomRight: r,
                    stackGap: a = 10,
                    stackElementGap: l = 10,
                    stackSize: h = 100,
                    stackCount: c,
                    setAttributes: d = setAttributesDefault,
                    alignment: u = Alignments.Middle,
                    stackIndexAttributeName: p = "stackIndex",
                    stackElementIndexAttributeName: m = "stackElementIndex"
                } = o, f, v, y,
                x = (t instanceof dia$1.Graph ? (v = t.getElements(), y = t) : (v = t)[0] && (y = v[0].graph), f = c ? Array(c).fill(null).map(() => Array()) : [], v.forEach(t => {
                    var e = t.get(p) || 0;
                    f[e] || (f[e] = []), f[e].push(t)
                }), s === Directions.TopBottom || s === Directions.BottomTop);
            var b = s === Directions.LeftRight || s === Directions.RightLeft, t = f.length;
            let w, S;
            x && (w = f.reduce((t, e) => Math.max(t, e.reduce((t, e) => t + e.size().height, 0) + (e.length - 1) * l), 0), S = t * h + (t - 1) * a), b && (S = f.reduce((t, e) => Math.max(t, e.reduce((t, e) => t + e.size().width, 0) + (e.length - 1) * l), 0), w = t * h + (t - 1) * a);
            var t = e ? new g.Rect(e.x, e.y, S, w) : n ? new g.Rect(n.x - S, n.y, S, w) : i ? new g.Rect(i.x, i.y - w, S, w) : r ? new g.Rect(r.x - S, r.y - w, S, w) : new g.Rect(0, 0, S, w),
                P = t.topLeft(), C = [];
            for (let t = 0; t < f.length; t++) f[t] = util.sortBy(f[t], t => t.get(m) || 0), x && (C.push({
                bbox: new g.Rect(P.x, P.y, h, w),
                elements: f[t],
                index: t
            }), P.x += h + a), b && (C.push({bbox: new g.Rect(P.x, P.y, S, h), elements: f[t], index: t}), P.y += h + a);
            y && y.startBatch("layout");
            for (let t = 0; t < C.length; t++) {
                var A = C[t];
                if (A.elements.length) {
                    let n = A.bbox.topLeft();
                    s === Directions.BottomTop && (n.y += A.bbox.height), s === Directions.RightLeft && (n.x += A.bbox.width), A.elements.forEach(t => {
                        var e = t.size(),
                            i = (s === Directions.BottomTop && (n.y -= e.height), s === Directions.RightLeft && (n.x -= e.width), n.toJSON());
                        switch (u) {
                            case Alignments.Middle:
                                x ? i.x += (h - e.width) / 2 : i.y += (h - e.height) / 2;
                                break;
                            case Alignments.End:
                                x ? i.x += h - e.width : i.y += h - e.height
                        }
                        d(t, {position: i}, o), s === Directions.BottomTop && (n.y -= l), s === Directions.TopBottom && (n.y += e.height + l), s === Directions.RightLeft && (n.x -= l), s === Directions.LeftRight && (n.x += e.width + l)
                    })
                }
            }
            return y && y.stopBatch("layout"), {bbox: t, stacks: C}
        }
    };

function LayoutSiblings(t, e, i) {
    i = util.defaults(i || {}, {siblingGap: 0}), this.width = 0, this.height = 0, this.layoutAreas = this.sortLayoutAreas(t), this.parentArea = e, this.siblingGap = i.siblingGap, this.exists() && this.computeSize(i)
}

util.assign(LayoutSiblings.prototype, {
    sortLayoutAreas: function (t) {
        t = util.sortBy(t, "siblingRank");
        return t.forEach(function (t, e) {
            t.siblingRank = e
        }), t
    }, move: function (t, e) {
        for (var i = 0, n = this.layoutAreas.length; i < n; i++) this.layoutAreas[i].dx += t, this.layoutAreas[i].dy += e
    }, exists: function () {
        return 0 < this.layoutAreas.length
    }, sumGaps: function (t) {
        return Math.max(this.layoutAreas.length - 1, 0) * t
    }, getSiblingRankByPoint: function (t) {
        return this.exists() ? (t = this.findAreaByPoint(t)) ? t.siblingRank - 1 : this.layoutAreas.length - 1 : -1
    }, getFirstChildConnectionPoints: function () {
        return []
    }, getConnectionPoints: function (t, e) {
        var i;
        return this.exists() ? (i = {
            dx: t.x - this.parentArea.rootCX,
            dy: t.y - this.parentArea.rootCY
        }, this.layoutAreas[0].getRootVertices(i, e)) : this.getFirstChildConnectionPoints(t)
    }, getParentConnectionPoint: function () {
        var t = this.parentArea, e = this.proxyLayoutArea("getConnectionPoint", t.rootSize);
        return g.point(t.rootCX, t.rootCY).offset(e.x, e.y)
    }, getChildConnectionPoint: function (t, e) {
        e = this.proxyLayoutArea("getConnectionPoint", e);
        return g.point(t).difference(e)
    }, proxyLayoutArea: function (t) {
        var e = Array.prototype.slice.call(arguments, 1);
        return LayoutArea.fromDirection(this.direction).prototype[t].apply(this.parentArea, e)
    }
}), LayoutSiblings.extend = mvc.Model.extend;
var VerticalLayoutSiblings = LayoutSiblings.extend({
        getTopDY: function () {
            return -this.height / 2
        }, findAreaByPoint: function (e) {
            return this.layoutAreas.find(function (t) {
                return t.rootCY > e.y
            })
        }, computeSize: function (n) {
            this.height = this.sumGaps(n.siblingGap);
            var t = this.layoutAreas;
            if (n.symmetrical) {
                let i = t.reduce(function (t, e) {
                    return Math.max(t, e.height + e.prevSiblingGap + e.nextSiblingGap)
                }, 0);
                this.height += i * t.length, t.reduce((t, e) => (this.width = Math.max(this.width, e.getExtendedWidth()), e.dy += t + i / 2, t + i + n.siblingGap), this.getTopDY())
            } else this.height += t.reduce(function (t, e) {
                return t + e.height + e.prevSiblingGap + e.nextSiblingGap
            }, 0), t.reduce((t, e) => (this.width = Math.max(this.width, e.getExtendedWidth()), e.dy += t + e.getCY(), t + e.prevSiblingGap + e.height + e.nextSiblingGap + n.siblingGap), this.getTopDY())
        }, getYTowardsParent: function () {
            return this.parentArea.rootCY
        }, getXTowardsParent: function () {
            var t = this.parentArea;
            return t.rootCX + this.LRSign * (t.rootSize.width / 2 + t.gap)
        }, getNeighborPointFromRank: function (t) {
            var e, i = this.siblingGap;
            return e = this.exists() ? (e = this.layoutAreas[t], t = this.layoutAreas[t + 1], e ? t ? (e.y + e.height + t.y) / 2 : e.y + e.height + i / 2 : t.y - i / 2) : this.getYTowardsParent(), {
                x: this.getXTowardsParent(),
                y: e
            }
        }
    }), LeftLayoutSiblings = VerticalLayoutSiblings.extend({direction: "L", LRSign: -1}),
    RightLayoutSiblings = VerticalLayoutSiblings.extend({direction: "R", LRSign: 1}), treeLayoutSiblings = {
        getXTowardsParent: function () {
            var t = this.parentArea;
            return t.rootCX + this.LRSign * t.gap
        }, getYTowardsParent: function () {
            var t = this.parentArea, e = t.getLRHeight(t.siblings) / 2;
            return e += Math.min(t.firstChildGap, this.siblingGap / 2), t.rootCY + this.TBSign * e
        }, getFirstChildConnectionPoints: function (t) {
            return [g.point(this.parentArea.rootCX, t.y)]
        }, getChildConnectionPoint: function (t, e) {
            return g.point(t).offset(-this.LRSign * e.width / 2, 0)
        }, getParentConnectionPoint: function () {
            var t = this.parentArea;
            return g.point(t.rootCX, t.rootCY).offset(0, this.TBSign * (t.rootSize.height - t.rootMargin) / 2)
        }
    }, bottomTreeLayoutSiblings = {
        getTopDY: function () {
            return 0
        }
    }, topTreeLayoutSiblings = {
        getTopDY: function () {
            return -this.height
        }
    }, BottomRightLayoutSiblings = VerticalLayoutSiblings.extend({direction: "BR", LRSign: 1, TBSign: 1}),
    BottomLeftLayoutSiblings = (util.assign(BottomRightLayoutSiblings.prototype, treeLayoutSiblings, bottomTreeLayoutSiblings), VerticalLayoutSiblings.extend({
        direction: "BL",
        LRSign: -1,
        TBSign: 1
    })),
    TopRightLayoutSiblings = (util.assign(BottomLeftLayoutSiblings.prototype, treeLayoutSiblings, bottomTreeLayoutSiblings), VerticalLayoutSiblings.extend({
        direction: "TR",
        LRSign: 1,
        TBSign: -1
    })),
    TopLeftLayoutSiblings = (util.assign(TopRightLayoutSiblings.prototype, treeLayoutSiblings, topTreeLayoutSiblings), VerticalLayoutSiblings.extend({
        direction: "TL",
        LRSign: -1,
        TBSign: -1
    })),
    HorizontalLayoutSiblings = (util.assign(TopLeftLayoutSiblings.prototype, treeLayoutSiblings, topTreeLayoutSiblings), LayoutSiblings.extend({
        getLeftDX: function () {
            return -this.width / 2
        }, findAreaByPoint: function (e) {
            return this.layoutAreas.find(function (t) {
                return t.rootCX > e.x
            })
        }, computeSize: function (n) {
            this.width = this.sumGaps(n.siblingGap);
            var t = this.layoutAreas;
            if (n.symmetrical) {
                let i = t.reduce(function (t, e) {
                    return Math.max(t, e.width + e.prevSiblingGap + e.nextSiblingGap)
                }, 0);
                this.width += i * t.length, t.reduce((t, e) => (this.height = Math.max(this.height, e.getExtendedHeight()), e.dx += t + i / 2, t + i + n.siblingGap), this.getLeftDX())
            } else this.width += t.reduce(function (t, e) {
                return t + e.width + e.prevSiblingGap + e.nextSiblingGap
            }, 0), t.reduce((t, e) => (this.height = Math.max(this.height, e.getExtendedHeight()), e.dx += t + e.getCX(), t + e.prevSiblingGap + e.width + e.nextSiblingGap + n.siblingGap), this.getLeftDX())
        }, getNeighborPointFromRank: function (t) {
            var e;
            return {
                x: this.exists() ? (e = this.layoutAreas[t], t = this.layoutAreas[t + 1], e ? t ? (e.x + e.width + t.x) / 2 : e.x + e.width + this.siblingGap / 2 : t.x - this.siblingGap / 2) : this.parentArea.rootCX,
                y: this.getYTowardsParent()
            }
        }
    })), TopLayoutSiblings = HorizontalLayoutSiblings.extend({
        direction: "T", getYTowardsParent: function () {
            var t = this.parentArea;
            return t.rootCY - t.getLRHeight() / 2 - t.gap
        }
    }), BottomLayoutSiblings = HorizontalLayoutSiblings.extend({
        direction: "B", getYTowardsParent: function () {
            var t = this.parentArea;
            return t.rootCY + t.getLRHeight() / 2 + t.gap
        }
    });

function LayoutArea(t, e) {
    this.root = t;
    t = util.assign({}, e, this.getRootAttributes(t, e.attributeNames)), e = e.gap || 0;
    util.defaults(t, {
        parentGap: e,
        siblingGap: e,
        firstChildGap: e
    }), this.siblingRank = t.siblingRank, this.rootOffset = t.rootOffset, this.rootMargin = t.rootMargin, this.siblingGap = t.siblingGap, this.gap = this.parentGap = t.parentGap, this.nextSiblingGap = t.nextSiblingGap, this.prevSiblingGap = t.prevSiblingGap, this.firstChildGap = t.firstChildGap, this.dx = 0, this.dy = 0, this.width = 0, this.height = 0, this.symmetrical = t.symmetrical
}

util.assign(LayoutArea, {
    create: function (t, e, i) {
        return new (LayoutArea.fromDirection(t, i))(e, i)
    }, fromDirection: function (t, e) {
        var i;
        switch (t) {
            case"L":
                i = LeftLayoutArea;
                break;
            case"T":
                i = TopLayoutArea;
                break;
            case"R":
                i = RightLayoutArea;
                break;
            case"B":
                i = BottomLayoutArea;
                break;
            case"BR":
                i = BottomRightLayoutArea;
                break;
            case"BL":
                i = BottomLeftLayoutArea;
                break;
            case"TR":
                i = TopRightLayoutArea;
                break;
            case"TL":
                i = TopLeftLayoutArea;
                break;
            default:
                i = LayoutArea
        }
        return i
    }
}), util.assign(LayoutArea.prototype, {
    direction: null, compute: function (t) {
        this.childAreas = t, this.computeRelativePosition(this.root, t)
    }, getHeight: function (t, e) {
        return this.getTHeight(t) + this.getBHeight(t) + this.getLRHeight()
    }, getWidth: function (t, e) {
        var i = Math.max(t.T.width, t.B.width) / 2;
        return Math.max(this.getLWidth(t, e) + e.width / 2, i) + Math.max(this.getRWidth(t, e) + e.width / 2, i)
    }, getLRHeight: function () {
        return Math.max(this.rootSize.height, this.siblings.L.height, this.siblings.R.height)
    }, getTHeight: function (t) {
        return t.T.height + this.getTXHeight(t)
    }, getBHeight: function (t) {
        return t.B.height + this.getBXHeight(t)
    }, getXLRWidth: function (t, e) {
        return this.getLWidth(t, e) + e.width + this.getRWidth(t, e)
    }, getXRWidth: function (t, e) {
        t = Math.max(t.BR.width, t.TR.width);
        return 0 < t && (t -= e.width / 2), t
    }, getTXHeight: function (t) {
        t = Math.max(t.TR.height, t.TL.height);
        return 0 < t && (t += this.firstChildGap), t
    }, getBXHeight: function (t) {
        t = Math.max(t.BR.height, t.BL.height);
        return 0 < t && (t += this.firstChildGap), t
    }, getXLWidth: function (t, e) {
        t = Math.max(t.BL.width, t.TL.width);
        return 0 < t && (t -= e.width / 2), t
    }, getRWidth: function (t, e) {
        return Math.max(t.R.width, this.getXRWidth(t, e))
    }, getLWidth: function (t, e) {
        return Math.max(t.L.width, this.getXLWidth(t, e))
    }, getTBOverlap: function (t, e) {
        t = Math.max(t.T.width, t.B.width);
        return t = 0 < t ? (t - e.width) / 2 : t
    }, getRootDX: function (t, e) {
        var i = this.getTBOverlap(t, e), n = Math.max(this.getLWidth(t, e), i);
        return (n -= Math.max(this.getRWidth(t, e), i)) / 2
    }, getMinimalGap: function (t) {
        return Math.min(t.siblingGap, this.firstChildGap, this.parentGap)
    }, getBBox: function (t) {
        var e = g.rect(this), t = t && t.expandBy;
        return t && e.moveAndExpand({x: -t, y: -t, width: 2 * t, height: 2 * t}), e
    }, containsPoint: function (t, e) {
        return this.getBBox(e).containsPoint(t)
    }, getLayoutSiblings: function (t) {
        return this.siblings[t]
    }, getExtendedWidth: function () {
        return this.width + this.gap + this.rootOffset
    }, getExtendedHeight: function () {
        return this.height + this.gap + this.rootOffset
    }, findMinimalAreaByPoint: function (e, i) {
        var n;
        return this.containsPoint(e, i) ? (this.childAreas.some(function (t) {
            return !!(n = t.findMinimalAreaByPoint(e, i))
        }), n || this) : null
    }, getType: function () {
        return Object.keys(this.siblings).reduce((t, e) => this.siblings[e].exists() ? t.concat(e) : t, []).sort().join("-")
    }, getRootAttributes: function (t, e) {
        var i = {
                rootOffset: t.get(e.offset || "offset") || 0,
                rootMargin: t.get(e.margin || "margin") || 0,
                prevSiblingGap: t.get(e.prevSiblingGap || "prevSiblingGap") || 0,
                nextSiblingGap: t.get(e.nextSiblingGap || "nextSiblingGap") || 0
            }, n = t.get(e.siblingRank || "siblingRank"),
            n = (util.isNumber(n) && (i.siblingRank = n), t.get(e.firstChildGap || "firstChildGap"));
        return util.isNumber(n) && (i.firstChildGap = n), i
    }, getRootSize: function (t, e) {
        t = t.size();
        return t[this.marginDimension] += e, t
    }, createSiblings: function (t, e) {
        t = util.groupBy(t, "direction");
        return {
            L: new LeftLayoutSiblings(t.L, this, e),
            T: new TopLayoutSiblings(t.T, this, e),
            R: new RightLayoutSiblings(t.R, this, e),
            B: new BottomLayoutSiblings(t.B, this, e),
            BR: new BottomRightLayoutSiblings(t.BR, this, e),
            BL: new BottomLeftLayoutSiblings(t.BL, this, e),
            TR: new TopRightLayoutSiblings(t.TR, this, e),
            TL: new TopLeftLayoutSiblings(t.TL, this, e)
        }
    }, computeSize: function (t, e) {
        return {width: this.getWidth(t, e), height: this.getHeight(t, e)}
    }, computeOrigin: function () {
        var t = this.siblings, e = this.rootSize,
            e = Math.max(this.getLWidth(t, e) + e.width / 2, this.getXLWidth(t, e) + e.width / 2, t.T.width / 2, t.B.width / 2);
        return {x: this.rootCX - e, y: this.rootCY - this.getTHeight(t) - this.getLRHeight() / 2}
    }, moveSiblings: function (t, e) {
        this.hasHorizontalSiblings(t) && (e = e.width / 2, t.L.move(-e, 0), t.R.move(e, 0)), this.hasVerticalSiblings(t) && (e = this.getLRHeight() / 2, t.T.move(0, -e), t.B.move(0, e), t.BR.move(0, e), t.BL.move(0, e), t.B.move(0, this.getBXHeight(t)), t.TR.move(0, -e), t.TL.move(0, -e), t.T.move(0, -this.getTXHeight(t)))
    }, moveRootToConnectionPoint: function (t) {
        t = this.getConnectionPoint(t);
        this.dx += t.x, this.dy += t.y
    }, computeRelativePosition: function (t, e) {
        e = this.siblings = this.createSiblings(e, {
            siblingGap: this.siblingGap,
            symmetrical: this.symmetrical
        }), t = this.rootSize = this.getRootSize(t, this.rootMargin);
        util.assign(this, this.computeSize(e, t)), this.moveSiblings(e, t), this.moveRootToConnectionPoint(t), this.moveRootBehindSiblings(e, t), this.moveRootFromParent()
    }, computeAbsolutePosition: function () {
        var t;
        this.parentArea ? (this.rootCX = this.parentArea.rootCX + this.dx, this.rootCY = this.parentArea.rootCY + this.dy, this.level = this.parentArea.level + 1) : (t = this.root.getCenter(), this.rootCX = t.x, this.rootCY = t.y, this.level = 0), util.assign(this, this.computeOrigin())
    }, hasVerticalSiblings: function (t) {
        return t.T.exists() || t.B.exists() || t.BR.exists() || t.BL.exists() || t.TR.exists() || t.TL.exists()
    }, hasHorizontalSiblings: function (t) {
        return t.L.exists() || t.R.exists()
    }, isSourceArea: function () {
        return !this.parentArea
    }, isSinkArea: function () {
        return 0 === this.childAreas.length
    }, getRootPosition: function () {
        var t = this.root.get("size");
        return {x: this.rootCX - t.width / 2, y: this.rootCY - t.height / 2}
    }, getRootVertices: function (t, e) {
        var i;
        return e = e || {}, 0 !== (t = t || this)[this.deltaCoordinate] && this.parentArea ? (i = this.parentArea.getInnerSize(), e = !e.ignoreSiblings && this.hasSiblingsBetweenParent() ? (e = this.siblings[this.oppositeDirection], this.getRelativeVerticesAvoidingSiblings(i, t, e)) : this.getRelativeVertices(i, t), util.invoke(e, "offset", this.parentArea.rootCX, this.parentArea.rootCY)) : []
    }, getInnerSize: function () {
        return {width: this.rootSize.width, height: this.getLRHeight()}
    }, getConnectionPoint: function () {
        return null
    }, getRelativeVertices: function () {
        return null
    }, moveRootFromParent: function () {
    }, moveRootBehindSiblings: function () {
    }, hasSiblingsBetweenParent: function () {
        return !this.isSourceArea() && this.siblings[this.oppositeDirection].exists()
    }, getCY: function () {
        return this.height / 2 + this.prevSiblingGap
    }, getCX: function () {
        return this.width / 2 + this.prevSiblingGap
    }
}), LayoutArea.extend = mvc.Model.extend;
var RightLayoutArea = LayoutArea.extend({
    direction: "R",
    oppositeDirection: "L",
    deltaCoordinate: "dx",
    marginDimension: "height",
    getConnectionPoint: function (t) {
        return g.point(t.width / 2, 0)
    },
    moveRootBehindSiblings: function (t, e) {
        this.dx += Math.max(this.getLWidth(t, e), this.getTBOverlap(t, e)), this.dy += (this.getTHeight(t) - this.getBHeight(t)) / 2
    },
    moveRootFromParent: function () {
        this.dx += this.parentGap + this.rootOffset
    },
    getRelativeVertices: function (t, e) {
        var t = this.getConnectionPoint(t), i = this.parentGap / 2;
        return [t.clone().offset(i, 0), t.clone().offset(i, e.dy)]
    },
    getRelativeVerticesAvoidingSiblings: function (t, e, i) {
        var t = this.getConnectionPoint(t), n = i.siblingGap / 2, o = 0 < this.dx ? -1 : 1,
            i = e.dy + o * (i.height + n) / 2, n = e.dy + o * this.rootSize.height / 4, e = this.gap / 2,
            o = 1.5 * e + Math.max(this.getLWidth(this.siblings, this.rootSize), this.getTBOverlap(this.siblings, this.rootSize));
        return [t.clone().offset(e, 0), t.clone().offset(e, i), t.clone().offset(o, i), t.clone().offset(o, n)]
    }
}), LeftLayoutArea = LayoutArea.extend({
    direction: "L",
    oppositeDirection: "R",
    deltaCoordinate: "dx",
    marginDimension: "height",
    getConnectionPoint: function (t) {
        return g.point(-t.width / 2, 0)
    },
    moveRootBehindSiblings: function (t, e) {
        this.dx -= Math.max(this.getRWidth(t, e), this.getTBOverlap(t, e)), this.dy += (this.getTHeight(t) - this.getBHeight(t)) / 2
    },
    moveRootFromParent: function () {
        this.dx -= this.parentGap + this.rootOffset
    },
    getRelativeVertices: function (t, e) {
        var t = this.getConnectionPoint(t), i = -this.parentGap / 2;
        return [t.clone().offset(i, 0), t.clone().offset(i, e.dy)]
    },
    getRelativeVerticesAvoidingSiblings: function (t, e, i) {
        var t = this.getConnectionPoint(t), n = 0 < this.dx ? -1 : 1, i = e.dy + n * (i.height + i.siblingGap / 2) / 2,
            e = e.dy + n * this.rootSize.height / 4, n = this.gap / 2,
            o = 1.5 * n + Math.max(this.getRWidth(this.siblings, this.rootSize), this.getTBOverlap(this.siblings, this.rootSize));
        return [t.clone().offset(-n, 0), t.clone().offset(-n, i), t.clone().offset(-o, i), t.clone().offset(-o, e)]
    }
}), TopLayoutArea = LayoutArea.extend({
    direction: "T",
    oppositeDirection: "B",
    deltaCoordinate: "dy",
    marginDimension: "width",
    getConnectionPoint: function (t) {
        return g.point(0, -t.height / 2)
    },
    moveRootBehindSiblings: function (t, e) {
        this.dx += this.getRootDX(t, e), this.hasHorizontalSiblings(t) && (this.dy -= (this.getLRHeight() - e.height) / 2), this.dy -= this.getBHeight(t)
    },
    moveRootFromParent: function () {
        this.dy -= this.parentGap + this.rootOffset
    },
    getRelativeVertices: function (t, e) {
        var t = this.getConnectionPoint(t), i = -this.getTXHeight(this.parentArea.siblings) - this.parentGap / 2;
        return [t.clone().offset(0, i), t.clone().offset(e.dx, i)]
    },
    getRelativeVerticesAvoidingSiblings: function (t, e) {
        var t = this.getConnectionPoint(t), i = this.siblings, n = i.B,
            o = this.getTXHeight(this.parentArea.siblings) + this.parentGap / 2, s = o + n.height,
            r = (s += this.getBXHeight(this.siblings) + this.parentGap / 4, this.dy < 0 ? -1 : 1),
            i = i[0 < r ? "BR" : "BL"].width, a = e.dx,
            i = (a += r * (Math.max(i, n.width / 2) + n.siblingGap / 4), e.dx + r * this.rootSize.width / 4);
        return [t.clone().offset(0, -o), t.clone().offset(a, -o), t.clone().offset(a, -s), t.clone().offset(i, -s)]
    }
}), BottomLayoutArea = LayoutArea.extend({
    direction: "B",
    oppositeDirection: "T",
    deltaCoordinate: "dy",
    marginDimension: "width",
    getConnectionPoint: function (t) {
        return g.point(0, t.height / 2)
    },
    moveRootBehindSiblings: function (t, e) {
        this.dx += this.getRootDX(t, e), this.dy += this.getTHeight(t), this.hasHorizontalSiblings(t) && (this.dy += (this.getLRHeight() - e.height) / 2)
    },
    moveRootFromParent: function () {
        this.dy += this.parentGap + this.rootOffset
    },
    getRelativeVertices: function (t, e) {
        var t = this.getConnectionPoint(t), i = this.getBXHeight(this.parentArea.siblings) + this.parentGap / 2;
        return [t.clone().offset(0, i), t.clone().offset(e.dx, i)]
    },
    getRelativeVerticesAvoidingSiblings: function (t, e) {
        var t = this.getConnectionPoint(t), i = this.siblings, n = i.T,
            o = this.getBXHeight(this.parentArea.siblings) + this.parentGap / 2, s = o + n.height,
            r = (s += this.getTXHeight(i) + this.parentGap / 4, this.dy < 0 ? -1 : 1), i = i[0 < r ? "TR" : "TL"].width,
            a = e.dx, i = (a += r * (Math.max(i, n.width / 2) + n.siblingGap / 4), e.dx + r * this.rootSize.width / 4);
        return [t.clone().offset(0, o), t.clone().offset(a, o), t.clone().offset(a, s), t.clone().offset(i, s)]
    }
}), BottomRightLayoutArea = LayoutArea.extend({
    direction: "BR",
    oppositeDirection: "L",
    deltaCoordinate: "dy",
    marginDimension: "height",
    getConnectionPoint: function (t) {
        return g.point(0, t.height / 2)
    },
    getCY: function () {
        return this.prevSiblingGap
    },
    moveRootBehindSiblings: function (t, e) {
        var i = Math.max(t.T.width, t.B.width);
        this.dx += Math.max(this.getLWidth(t, e), (i - e.width) / 2), this.dy += this.getTHeight(t), this.hasHorizontalSiblings(t) && (this.dy += (this.getLRHeight() - e.height) / 2)
    },
    moveRootFromParent: function () {
        var t = this.parentArea;
        t && (this.dy += t.firstChildGap), this.dx += this.rootSize.width / 2 + this.rootOffset + this.parentGap
    },
    getRelativeVertices: function (t, e) {
        var i = this.getConnectionPoint(t), {dx: e, dy: n} = e, {width: t, height: o} = t;
        let s;
        return s = n - o / 2 < 0 ? (t / 2 + (e - this.rootSize.width / 2)) / 2 : 0, [i.clone().offset(s, n - o / 2)]
    },
    getRelativeVerticesAvoidingSiblings: function (t, e, i) {
        var n = e.dx - this.rootSize.width / 4, e = e.dy,
            e = (e += Math.max(i.height, this.rootSize.height) / 2) + this.getMinimalGap(i) / 2;
        return [g.point(0, e), g.point(n, e)]
    }
}), BottomLeftLayoutArea = LayoutArea.extend({
    direction: "BL",
    oppositeDirection: "R",
    deltaCoordinate: "dy",
    marginDimension: "height",
    getConnectionPoint: function (t) {
        return g.point(0, t.height / 2)
    },
    getCY: function () {
        return this.prevSiblingGap
    },
    moveRootBehindSiblings: function (t, e) {
        var i = Math.max(t.T.width, t.B.width);
        this.dx -= Math.max(this.getRWidth(t, e), (i - e.width) / 2), this.dy += this.getTHeight(t), this.hasHorizontalSiblings(t) && (this.dy += (this.getLRHeight() - e.height) / 2)
    },
    moveRootFromParent: function () {
        var t = this.parentArea;
        t && (this.dy += t.firstChildGap), this.dx -= this.rootSize.width / 2 + this.rootOffset + this.parentGap
    },
    getRelativeVertices: function (t, e) {
        var i = this.getConnectionPoint(t), {dx: e, dy: n} = e, {width: t, height: o} = t;
        let s;
        return s = n - o / 2 < 0 ? (-t / 2 + (e + this.rootSize.width / 2)) / 2 : 0, [i.clone().offset(s, n - o / 2)]
    },
    getRelativeVerticesAvoidingSiblings: function (t, e, i) {
        var n = e.dx + this.rootSize.width / 4, e = e.dy,
            e = (e += Math.max(i.height, this.rootSize.height) / 2) + this.getMinimalGap(i) / 2;
        return [g.point(0, e), g.point(n, e)]
    }
}), TopRightLayoutArea = LayoutArea.extend({
    direction: "TR",
    oppositeDirection: "L",
    deltaCoordinate: "dy",
    marginDimension: "height",
    getConnectionPoint: function (t) {
        return g.point(0, t.height / 2)
    },
    getCY: function () {
        return this.height - this.rootSize.height + this.prevSiblingGap
    },
    moveRootBehindSiblings: function (t, e) {
        this.dx += Math.max(this.getLWidth(t, e), this.getTBOverlap(t, e)), this.dy -= this.getBHeight(t), this.hasHorizontalSiblings(t) && (this.dy -= (this.getLRHeight() - e.height) / 2)
    },
    moveRootFromParent: function () {
        var t = this.parentArea;
        t && (this.dy -= t.firstChildGap), this.dx += this.rootSize.width / 2 + this.rootOffset + this.parentGap
    },
    getRelativeVertices: function (t, e) {
        var i = this.getConnectionPoint(t), {dx: e, dy: n} = e, {width: t, height: o} = t;
        let s;
        return s = 0 < n + o / 2 ? (t / 2 + (e - this.rootSize.width / 2)) / 2 : 0, [i.clone().offset(s, n - o / 2)]
    },
    getRelativeVerticesAvoidingSiblings: function (t, e, i) {
        var n = e.dx - this.rootSize.width / 4, e = e.dy,
            e = (e -= Math.max(i.height, this.rootSize.height) / 2) - this.getMinimalGap(i) / 2;
        return [g.point(0, e), g.point(n, e)]
    }
}), TopLeftLayoutArea = LayoutArea.extend({
    direction: "TL",
    oppositeDirection: "R",
    deltaCoordinate: "dy",
    marginDimension: "height",
    getConnectionPoint: function (t) {
        return g.point(0, t.height / 2)
    },
    getCY: function () {
        return this.height - this.rootSize.height + this.prevSiblingGap
    },
    moveRootBehindSiblings: function (t, e) {
        this.dx -= Math.max(this.getRWidth(t, e), this.getTBOverlap(t, e)), this.dy -= this.getBHeight(t), this.hasHorizontalSiblings(t) && (this.dy -= (this.getLRHeight() - e.height) / 2)
    },
    moveRootFromParent: function () {
        var t = this.parentArea;
        t && (this.dy -= t.firstChildGap), this.dx -= this.rootSize.width / 2 + this.rootOffset + this.parentGap
    },
    getRelativeVertices: function (t, e) {
        var i = this.getConnectionPoint(t), {dx: e, dy: n} = e, {width: t, height: o} = t;
        let s;
        return s = 0 < n + o / 2 ? (-t / 2 + (e + this.rootSize.width / 2)) / 2 : 0, [i.clone().offset(s, n - o / 2)]
    },
    getRelativeVerticesAvoidingSiblings: function (t, e, i) {
        var n = e.dx + this.rootSize.width / 4, e = e.dy,
            e = (e -= Math.max(i.height, this.rootSize.height) / 2) - this.getMinimalGap(i) / 2;
        return [g.point(0, e), g.point(n, e)]
    }
}), directionRules = {
    rotate: function (t) {
        var i = "LRBT", n = i.indexOf(t[0]) - i.indexOf(t[1]);
        return function (t) {
            var e = i.indexOf(t);
            return 0 <= e ? i[(4 + e - n) % 4] : t
        }
    }, flip: function (t) {
        var e = t[0], i = t[1];
        return function (t) {
            return t === e ? i : t === i ? e : t
        }
    }, straighten: function (t) {
        return function () {
            return t[1]
        }
    }
};
let TreeLayout = mvc.Model.extend({
        defaults: {
            graph: void 0,
            gap: 20,
            parentGap: 20,
            siblingGap: 20,
            firstChildGap: 20,
            direction: "R",
            directionRule: directionRules.straighten,
            updatePosition: function (t, e, i) {
                t.set("position", e, i)
            },
            updateVertices: function (t, e, i) {
                t.set("vertices", e, i)
            },
            updateSiblingRank: function (t, e, i, n) {
                n.changeSiblingRank(t, e, i)
            },
            updateAttributes: null,
            filter: null,
            attributeNames: {}
        }, initialize: function () {
            this._cacheOptions(this.attributes), this.layoutAreas = {}
        }, layout: function (t) {
            this.layoutAreas = {};
            for (var e = this.getGraphSources(t), i = 0, n = e.length; i < n; i++) this.layoutTree(e[i], t);
            return this.trigger("layout:done", t), this
        }, layoutTree: function (t, e) {
            (e = e || {}).treeLayout = !0;
            t = this._computeLayoutAreas(t, null, e);
            return this._computeAbsolutePositions(t), this._updateCells(t, e), this
        }, positionTree: function (t, e, i, n) {
            t.position(e, i, n);
            e = this.getLayoutArea(t);
            this._computeAbsolutePositions(e), this._updateCells(e, n)
        }, getLayoutBBox: function () {
            return this.getRootLayoutAreas().reduce(function (t, e) {
                e = e.getBBox();
                return t ? t.union(e) : e
            }, null)
        }, getLayoutArea: function (t) {
            return this.layoutAreas[t.id || t] || null
        }, getRootLayoutAreas: function () {
            return this.getGraphSources().map(this.getLayoutArea, this)
        }, getGraphSources: function (t) {
            var e = this.graph.getSources();
            return e = this.filter && 0 < e.length ? this.filter(e, null, t, this) || e : e
        }, getMinimalRootAreaByPoint: function (e) {
            var t = this.getRootLayoutAreas().filter(function (t) {
                return t.containsPoint(e)
            });
            return util.isEmpty(t) ? null : t.reduce(function (t, e) {
                return e.width * e.height < t.min && (t.min = e.width * e.height, t.item = e), t
            }, {min: 1 / 0, item: void 0}).item
        }, findClosestRootAreaByPoint: function (n, e) {
            var t = this.getRootLayoutAreas().filter(function (t) {
                return t.containsPoint(n, e)
            });
            return util.isEmpty(t) ? null : t.reduce(function (t, e) {
                var i = e.getBBox().pointNearestToPoint(n).squaredDistance(n);
                return i < t.distance ? {distance: i, item: e} : t
            }, {distance: 1 / 0, item: void 0}).item
        }, _computeLayoutAreas: function (t, e, i) {
            for (var n = e ? e.direction : this.get("direction"), n = t.get(this.getAttributeName("direction")) || n, o = LayoutArea.create(n, t, this.attributes), s = (o.parentArea = e, o.link = this.graph.getConnectedLinks(t, {inbound: !0})[0], this._getChildren(t, i)), r = (this.layoutAreas[t.id] = o, []), a = 0, l = s.length; a < l; a++) r.push(this._computeLayoutAreas(s[a], o, i));
            return o.compute(r), o
        }, _cacheOptions: function (e) {
            ["updateAttributes", "updateVertices", "updatePosition", "updateSiblingRank", "filter"].forEach(function (t) {
                this[t] = util.isFunction(e[t]) ? e[t] : null
            }, this), this.graph = e.graph
        }, _getChildren: function (t, e) {
            var i;
            return this.layoutAreas[t.id] ? [] : (i = this.graph.getNeighbors(t, {outbound: !0}), this.filter && 0 < i.length && this.filter(i, t, e, this) || i)
        }, _computeAbsolutePositions: function (t) {
            t.computeAbsolutePosition(t);
            for (var e = 0, i = t.childAreas.length; e < i; e++) this._computeAbsolutePositions(t.childAreas[e])
        }, _updateCells: function (t, e) {
            var i = t.root, n = t.link || null;
            n && (this.updatePosition && this.updatePosition(i, t.getRootPosition(), e, this), this.updateVertices) && this.updateVertices(n, t.getRootVertices(), e, this), this.updateSiblingRank && this.updateSiblingRank(i, t.siblingRank, e, this), this.updateAttributes && this.updateAttributes(t, i, n, e, this);
            for (var o = 0, s = t.childAreas.length; o < s; o++) this._updateCells(t.childAreas[o], e)
        }, updateDirections: function (t, e, i) {
            i = i || {};
            var n = this.getAttributeName("direction"), o = this.get("directionRule")(e);
            this.graph.search(t, (t, e) => {
                0 !== e && (e = o(t.get(n)), this.changeDirection(t, e, i))
            }, {outbound: !0})
        }, reconnectElement: function (t, e, i) {
            i = i || {};
            var n = this.getLayoutArea(t), o = n.link;
            return !!o && (o.set("source", {id: e.id || e}, i), o = n.direction, e = i.direction || o, n = i.siblingRank || void 0, this.changeSiblingRank(t, n, i), this.changeDirection(t, e, i), o !== e && this.updateDirections(t, [o, i.direction], i), !0)
        }, changeSiblingRank: function (t, e, i) {
            t.set(this.getAttributeName("siblingRank"), e, i)
        }, changeDirection: function (t, e, i) {
            t.set(this.getAttributeName("direction"), e, i)
        }, getAttributeName: function (t) {
            return this.get("attributeNames")[t] || t
        }, getAttribute: function (t, e) {
            return t.get(this.getAttributeName(e))
        }, prepare: function () {
            return this
        }, removeElement: function (t, o = {}) {
            let [s] = this.graph.getNeighbors(t, {inbound: !0});
            if (s) {
                let i = t.get("siblingRank"), n = this.graph.getConnectedLinks(t, {outbound: !0});
                n.forEach(t => {
                    t.source(s);
                    var t = t.getTargetCell(), e = g.scale.linear([0, n.length], [0, 1], t.get("siblingRank"));
                    t.set("siblingRank", i + e, o)
                })
            }
            t.remove(o), !1 !== o.layout && this.layout(o)
        }
    }, {directionRules: directionRules}), RecordScrollbar = dia$1.ToolView.extend({
        name: "scroll-bar",
        tagName: "rect",
        options: {margin: 2, width: 8, rightAlign: !1},
        attributes: {fill: "#333", rx: 4, ry: 4, "fill-opacity": .4, cursor: "grab"},
        events: {mousedown: "onPointerDown", touchstart: "onPointerDown"},
        documentEvents: {
            mousemove: "onPointerMove",
            touchmove: "onPointerMove",
            mouseup: "onPointerUp",
            touchend: "onPointerUp",
            touchcancel: "onPointerUp"
        },
        onRender: function () {
            this.update()
        },
        update: function () {
            var t = this.getBBox();
            return t ? (this.enable(), this.vel.attr(t.toJSON())) : this.disable(), this
        },
        getTrackHeight() {
            var {relatedView: t, options: e} = this, t = t.model, i = t.metrics, i = i.padding, e = e.margin,
                i = i.top + i.bottom + 2 * Math.abs(e), e = t.attributes.size.height;
            return e - i
        },
        getScale() {
            var t = this.relatedView, {metrics: t, attributes: e} = t.model, t = t.minHeight, e = e.size.height,
                i = this.getTrackHeight();
            return i / (t - (e - i))
        },
        getBBox: function () {
            var {relatedView: t, options: e} = this, t = t.model;
            if (t.isEveryItemInView()) return null;
            var {metrics: i, attributes: n} = t, o = n.size.width, {padding: i, overflow: s} = i, r = this.getTrackHeight();
            if (r <= 0) return null;
            var {margin: a, width: l} = e, h = this.getScale(), r = r * h, {x: n, y: c} = n.position,
                c = c + Math.abs(a) + i.top;
            let d = n;
            return e.rightAlign ? (d += o - a, 0 <= a && (d -= l), s || (d -= i.right)) : (d += a, a < 0 && (d -= l), s || (d += i.left)), new g.Rect({
                x: d,
                y: c + h * t.getScrollTop(),
                width: l,
                height: r
            })
        },
        disable: function () {
            this.vel.attr("display", "none")
        },
        enable: function () {
            this.vel.attr("display", "")
        },
        onPointerDown: function (t) {
            var e, i;
            this.guard(t) || (t.stopPropagation(), t.preventDefault(), e = this.relatedView, (i = e.model).startBatch("scroll-record", {
                ui: !0,
                tool: this.cid
            }), this.focus(), this.delegateDocumentEvents(null, {
                y: t.clientY,
                scrollTop: i.getScrollTop()
            }), e.paper.undelegateEvents())
        },
        onPointerMove: function (t) {
            var t = util.normalizeEvent(t), {y: e, scrollTop: i, lastScrollTop: n} = t.data, o = this.relatedView,
                o = o.model, s = this.getScale(), i = i + (t.clientY - e) / s;
            n !== i && (t.data.lastScrollTop = i, o.setScrollTop(i))
        },
        onPointerUp: function () {
            this.undelegateDocumentEvents(), this.paper.delegateEvents(), this.blur(), this.el.style.pointerEvents = "", this.relatedView.model.stopBatch("scroll-record", {
                ui: !0,
                tool: this.cid
            })
        }
    }), SwimlaneBoundary = elementTools$1.Boundary.extend({
        name: "swimlane-boundary",
        tagName: "rect",
        options: {padding: 10, laneId: ""},
        update: function () {
            var {vel: t, relatedView: e, options: i} = this, e = e.model, n = e.angle(), o = e.getCenter(),
                e = this.getBoundaryBBox(e, i.laneId, i.padding);
            return null === e ? t.attr({
                width: 0,
                height: 0
            }) : (t.attr(e.toJSON()), t.rotate(n, o.x, o.y, {absolute: !0})), this
        },
        getBoundaryBBox: function (t, e, i) {
            var {left: i, top: n, right: o, bottom: s} = util.normalizeSides(i), t = t.getLaneBBox(e);
            return null === t ? null : (t.moveAndExpand({
                x: -i,
                y: -n,
                width: i + o,
                height: n + s
            }), t.width < 0 && (t.width = 0), t.height < 0 && (t.height = 0), t)
        }
    }), RotatedRect = function (t, e, i) {
        this.top = t.topLine().rotate(e, -i), this.left = t.leftLine().rotate(e, -i), this.right = t.rightLine().rotate(e, -i), this.bottom = t.bottomLine().rotate(e, -i)
    }, TransformHandle = (RotatedRect.inflatedOnSide = function (t, e, i, n, o) {
        var s = new RotatedRect(t, e, i), r = s.getLine(o);
        switch (o) {
            case"top":
            case"right":
                s[o] = r.parallel(-n);
                break;
            case"bottom":
            case"left":
                s[o] = r.parallel(n)
        }
        return s
    }, RotatedRect.prototype = {
        getLine: function (t) {
            switch (t) {
                case"top":
                    return this.top;
                case"right":
                    return this.right;
                case"bottom":
                    return this.bottom;
                case"left":
                    return this.left
            }
        }, isPointOnLine: function (t, e) {
            return 0 === Math.round(this.getLine(e).closestPoint(t).distance(t))
        }, isPointToTheLeftOfLine: function (t, e) {
            var i = Math.round(this.getLine(e).pointOffset(t));
            switch (e) {
                case"top":
                case"right":
                    return 0 < i;
                case"bottom":
                case"left":
                    return i < 0
            }
        }, isPointToTheRightOfLine: function (t, e) {
            var i = Math.round(this.getLine(e).pointOffset(t));
            switch (e) {
                case"top":
                case"right":
                    return i < 0;
                case"bottom":
                case"left":
                    return 0 < i
            }
        }, isPointInside: function (t) {
            var e = this.isPointToTheLeftOfLine(t, "top"), i = this.isPointToTheLeftOfLine(t, "right"),
                n = this.isPointToTheLeftOfLine(t, "bottom");
            return this.isPointToTheLeftOfLine(t, "left") && e && i && n
        }, isPointInsideOrOnLine: function (t) {
            var e = this.isPointInside(t), i = this.isPointOnLine(t, "top"), n = this.isPointOnLine(t, "right"),
                o = this.isPointOnLine(t, "bottom"), t = this.isPointOnLine(t, "left");
            return e || i || n || o || t
        }, findClosestPointToLine: function (t, i) {
            let n = new g.Point, o = 1 / 0;
            return t.forEach(t => {
                var e = this.getDistanceFromLineToPoint(t, i);
                e < o && (n.update(t.x, t.y), o = e)
            }), n
        }, findFurthestPointFromLine: function (t, i) {
            let n = new g.Point, o = -1 / 0;
            return t.forEach(t => {
                var e = this.getDistanceFromLineToPoint(t, i);
                e > o && (n.update(t.x, t.y), o = e)
            }), n
        }, getDistanceFromLineToPoint: function (t, e) {
            var i = this.getLine(e), e = this.isPointToTheRightOfLine(t, e) ? 1 : -1, i = Math.abs(i.pointOffset(t)) * e;
            return Math.round(i)
        }
    }, linkTools.Segments.SegmentHandle.extend({
        className: "swimlane-transform-handle",
        children: [{
            tagName: "rect",
            selector: "handle",
            attributes: {
                width: 20,
                height: 8,
                x: -10,
                y: -4,
                rx: 4,
                ry: 4,
                fill: "#3498db",
                stroke: "#FFFFFF",
                "stroke-width": 2
            }
        }],
        position: function (t, e, i) {
            var n = this.childNodes.handle, t = V.createSVGMatrix().translate(t, e).rotate(i);
            n.setAttribute("transform", V.matrixToTransformString(t)), n.setAttribute("cursor", i % 180 == 0 ? "row-resize" : "col-resize")
        }
    })), HandleSides = {Top: "top", Right: "right", Bottom: "bottom", Left: "left"}, HandleAxes = {X: "x", Y: "y"},
    SwimlaneTransform = dia$1.ToolView.extend({
        name: "swimlane-transform",
        options: {
            laneId: void 0,
            minSize: 30,
            padding: 10,
            stopPropagation: !0,
            constraintsPadding: 10,
            handleClass: TransformHandle,
            minSizeConstraints: void 0,
            maxSizeConstraints: void 0
        },
        handles: null,
        minConstraintPoints: null,
        maxConstraintPoints: null,
        initialize: function () {
            var t = this.options;
            void 0 === t.minSizeConstraints && (t.minSizeConstraints = (t, e, i) => this.getMinConstraintsToEmbeds(t, e, i)), void 0 === t.maxSizeConstraints && (t.maxSizeConstraints = (t, e, i) => this.getMaxConstraintsToEmbeds(t, e, i))
        },
        update: function () {
            return this.render(), this
        },
        onRender: function () {
            return this.removeHandles(), this.doesLaneExist() && this.renderHandles(), this
        },
        onRemove: function () {
            this.removeHandles()
        },
        doesLaneExist: function () {
            return null !== this.relatedView.model.getLaneBBox(this.options.laneId)
        },
        removeHandles: function () {
            var e = this.handles;
            if (this.handles = [], this.stopListening(), Array.isArray(e)) for (let t = 0; t < e.length; t++) e[t].remove()
        },
        renderHandles: function () {
            this.getHandlesPositionInfo().forEach(t => {
                t = this.renderHandle(t);
                this.simulateRelatedView(t.el), this.handles.push(t)
            })
        },
        getHandlesPositionInfo: function () {
            var {options: t, relatedView: e} = this, i = t.laneId, e = e.model, n = e.angle(), o = e.getCenter(),
                e = this.getHandlesBoundaryBBox(e, i, t.padding);
            return [{
                position: e.topMiddle().rotate(o, -n),
                axis: HandleAxes.Y,
                side: HandleSides.Top
            }, {
                position: e.leftMiddle().rotate(o, -n),
                axis: HandleAxes.X,
                side: HandleSides.Left
            }, {
                position: e.rightMiddle().rotate(o, -n),
                axis: HandleAxes.X,
                side: HandleSides.Right
            }, {position: e.bottomMiddle().rotate(o, -n), axis: HandleAxes.Y, side: HandleSides.Bottom}]
        },
        getHandlesBoundaryBBox: function (t, e, i) {
            var {left: i, top: n, right: o, bottom: s} = util.normalizeSides(i),
                t = t.getLaneBBox(e).moveAndExpand({x: -i, y: -n, width: i + o, height: n + s});
            return t.width < 0 && (t.width = 0), t.height < 0 && (t.height = 0), t
        },
        renderHandle: function (t) {
            var e = new this.options.handleClass({
                paper: this.paper,
                axis: t.axis,
                side: t.side,
                guard: t => this.guard(t)
            });
            return e.render(), e.vel.appendTo(this.el), this.updateHandlePosition(e, t.position), this.startHandleListening(e), e
        },
        updateHandlePosition: function (t, e) {
            let i = this.relatedView.model.angle();
            t.options.axis === HandleAxes.X && (i += 90), t.position(e.x, e.y, i)
        },
        startHandleListening: function (t) {
            this.listenTo(t, "change:start", this.onHandleChangeStart), this.listenTo(t, "changing", this.onHandleChanging), this.listenTo(t, "change:end", this.onHandleChangeEnd)
        },
        onHandleChangeStart: function (t, e) {
            var i = t.options.side, {options: n, handles: o, relatedView: s} = this, {model: r, paper: a} = s;
            Array.isArray(o) && (this.hideNonSelectedHandles(o, t), this.updateConstraintPoints(i), this.focus(), r.startBatch("lane-resize", {
                ui: !0,
                tool: this.cid
            }), n.stopPropagation || s.notifyPointerdown(...a.getPointerArgs(e)))
        },
        hideNonSelectedHandles: function (t, e) {
            t.forEach(t => t === e ? t.show() : t.hide())
        },
        updateConstraintPoints: function (t) {
            var {relatedView: e, options: i} = this, n = i.laneId, e = e.model, o = i.minSizeConstraints,
                i = i.maxSizeConstraints;
            let s, r;
            util.isFunction(o) && (s = o(e, n, t)), util.isFunction(i) && (r = i(e, n, t)), this.minConstraintPoints = Array.isArray(s) ? s.map(t => new g.Point(t)) : [], this.maxConstraintPoints = Array.isArray(r) ? r.map(t => new g.Point(t)) : []
        },
        onHandleChanging: function (t, e) {
            var {options: i, relatedView: n} = this, {model: o, paper: s} = n, {laneId: i, stopPropagation: r} = i,
                a = o.getBBox(), l = o.angle(), h = a.center(), c = t.options, d = c.axis;
            let u = c.side;
            var c = this.getHandlesPositionInfo().find(t => t.side === u).position, e = util.normalizeEvent(e),
                s = s.snapToGrid(e.clientX, e.clientY), p = s.clone().rotate(h, l).round(),
                h = c.clone().rotate(h, l).round(), p = p.difference(h), h = 0 !== p.y, g = 0 !== p.x;
            d === HandleAxes.Y && h ? (h = u === HandleSides.Top ? -p.y : p.y, this.updateLaneHeight(i, h, u, a, l)) : d === HandleAxes.X && g && (h = u === HandleSides.Left ? -p.x : p.x, this.updateLaneWidth(i, h, o, u, a, l)), this.updateHandlePosition(t, c), r || n.notifyPointermove(e, s.x, s.y)
        },
        onHandleChangeEnd: function (t, e) {
            var {options: i, relatedView: n} = this, {paper: o, model: s} = n, e = util.normalizeEvent(e), {
                x: o,
                y: r
            } = o.snapToGrid(e.clientX, e.clientY);
            this.render(), this.blur(), s.stopBatch("lane-resize", {
                ui: !0,
                tool: this.cid
            }), i.stopPropagation || n.notifyPointerup(e, o, r), n.checkMouseleave(e)
        },
        updateLaneHeight: function (t, e, i, n, o) {
            let s = this.relatedView.model, r = util.cloneDeep(s.prop("lanes"));
            var a = this.getNeighbourLanesIds(s, t, i), l = this.getSublanesAndMostEmbeddedLaneId(s, t, i),
                h = void 0 === a.foundNeighbourLaneId, c = [a.foundNeighbourLaneId, ...a.sublaneIds],
                d = [t, ...l.sublaneIds, ...a.laneIdsPathToNeighbour];
            e = this.getDiffWithinConstraints(t, e, i, n.center(), o), e = this.getDiffWithinLaneSizeLimits(s, e, l.mostEmbeddedLaneId, a.mostEmbeddedLaneId), d.forEach(t => this.addSizeToLane(s, r, t, e)), h ? this.resizeShape(s, n.width, n.height + e, i) : c.forEach(t => this.addSizeToLane(s, r, t, -e)), s.prop("lanes", r, {
                ui: !0,
                tool: this.cid,
                autoResize: !1
            })
        },
        getSublanesAndMostEmbeddedLaneId: function (t, e, i) {
            t = this.getIdsOfClosestSublanesToTheSide(t, e, i);
            return {sublaneIds: t, mostEmbeddedLaneId: t[0] || e}
        },
        getOppositeHandleSide: function (t) {
            switch (t) {
                case HandleSides.Top:
                    return HandleSides.Bottom;
                case HandleSides.Right:
                    return HandleSides.Left;
                case HandleSides.Bottom:
                    return HandleSides.Top;
                case HandleSides.Left:
                    return HandleSides.Right
            }
        },
        getNeighbourLanesIds: function (t, e, i) {
            var n = this.getOppositeHandleSide(i), {
                foundNeighbourLaneId: e,
                laneIdsPathToNeighbour: i
            } = this.findNeighbourLane(t, e, i), t = this.getIdsOfClosestSublanesToTheSide(t, e, n);
            return {foundNeighbourLaneId: e, laneIdsPathToNeighbour: i, sublaneIds: t, mostEmbeddedLaneId: t[0] || e}
        },
        addSizeToLane: function (t, e, i, n) {
            n = this.getLaneBBoxHeight(t, i) + n, t = t.getLanePath(i);
            t.push("size"), util.setByPath({lanes: e}, t, n)
        },
        updateLaneWidth: function (t, e, i, n, o, s) {
            e = this.getDiffWithinConstraints(t, e, n, o.center(), s);
            t = i.getMinimalSize().width, s = Math.max(o.width + e, t);
            this.resizeShape(i, s, o.height, n)
        },
        resizeShape: function (t, e, i, n) {
            t.resize(e, i, {ui: !0, tool: this.cid, direction: n})
        },
        getLaneBBoxHeight: function (t, e) {
            return t.getLaneBBox(e).height
        },
        getDiffWithinLaneSizeLimits: function (t, e, i, n) {
            var o = Math.sign(e), s = void 0 !== n, i = this.getLaneBBoxHeight(t, i),
                s = s ? this.getLaneBBoxHeight(t, n) : 1 / 0, t = i + e, n = s - e, r = this.getMinSize();
            return t < r ? e = (i - r) * o : n < r && (e = (s - r) * o), Math.round(e)
        },
        getMinSize: function () {
            let t = this.options.minSize;
            var e = 2 * this.options.constraintsPadding;
            return t = e > t ? e : t
        },
        getDiffWithinConstraints: function (t, e, i, n, o) {
            var t = this.relatedView.model.getLaneBBox(t), s = this.getConstraintPaddingRelativeToHandleSide(e),
                r = RotatedRect.inflatedOnSide(t, n, o, s, i), t = RotatedRect.inflatedOnSide(t, n, o, e + s, i),
                n = this.getMaxConstraintPointsInsideLane(t), o = this.getMinConstraintPointsOutsideLane(t, i);
            return 0 < n.length ? (s = r.findClosestPointToLine(n, i), e = r.getDistanceFromLineToPoint(s, i)) : 0 < o.length && (t = r.findFurthestPointFromLine(o, i), e = r.getDistanceFromLineToPoint(t, i)), e
        },
        getConstraintPaddingRelativeToHandleSide: function (t) {
            return this.options.constraintsPadding * (t < 0 ? -1 : 1)
        },
        getMaxConstraintPointsInsideLane: function (e) {
            return this.maxConstraintPoints.filter(t => e.isPointInside(t))
        },
        getMinConstraintPointsOutsideLane: function (i, n) {
            return this.minConstraintPoints.filter(t => {
                var e = i.isPointToTheRightOfLine(t, n), t = i.isPointOnLine(t, n);
                return e || t
            })
        },
        findNeighbourLane: function (t, e, i) {
            var n = t.metrics, o = [], s = i === HandleSides.Top;
            let r = void 0, a = e;
            for (; a;) {
                var l = t.getLaneMetrics(a), h = l.parentId, c = l.laneIndexWithinGroup;
                if (!(s ? 0 === c : c === l.parentSublanesCount - 1)) {
                    r = this.getSublaneIdOfParent(n.lanes, h, s ? c - 1 : c + 1);
                    break
                }
                h && o.unshift(h), a = h
            }
            return {foundNeighbourLaneId: r, laneIdsPathToNeighbour: o}
        },
        getSublaneIdOfParent: function (e, i, n) {
            return Object.keys(e).find(t => {
                t = e[t];
                return t.parentId === i && t.laneIndexWithinGroup === n
            })
        },
        getIdsOfClosestSublanesToTheSide: function (t, e, i) {
            var n = [];
            let o = e;
            for (; o;) {
                var s = t.getLaneMetrics(o).sublanesCount, s = i === HandleSides.Top ? 0 : s - 1, s = o + "_" + s,
                    r = null !== t.getLaneMetrics(s);
                o = r ? (n.unshift(s), s) : void 0
            }
            return n
        },
        getMinConstraintsToEmbeds: function (t, e, i) {
            let n = [];
            var o = t.getCenter(), s = t.angle(), e = t.getLaneBBox(e), e = new RotatedRect(e, o, s),
                o = t.getEmbeddedCells({deep: !0}), s = i === HandleSides.Left || i === HandleSides.Right;
            return this.getEmbedPointsInsideLane(e, o, i).forEach(t => n.push(t)), s && 0 < o.length && ({
                leftMostPoint: i,
                rightMostPoint: s
            } = this.findLeftMostAndRightMostEmbedPoints(t, e, o), n.push(i), n.push(s)), n
        },
        getMaxConstraintsToEmbeds: function (t, e, i) {
            let n = [];
            var o = t.angle(), s = t.getCenter(), r = t.getEmbeddedCells({deep: !0}),
                a = this.findNeighbourLane(t, e, HandleSides.Top).foundNeighbourLaneId,
                e = this.findNeighbourLane(t, e, HandleSides.Bottom).foundNeighbourLaneId;
            return void 0 !== a && (a = t.getLaneBBox(a), a = new RotatedRect(a, s, o), this.getEmbedPointsInsideLane(a, r, i, {addOverflowingEmbedsOnlyOnHandleSide: !0}).forEach(t => n.push(t))), void 0 !== e && (a = t.getLaneBBox(e), t = new RotatedRect(a, s, o), this.getEmbedPointsInsideLane(t, r, i, {addOverflowingEmbedsOnlyOnHandleSide: !0}).forEach(t => n.push(t))), n
        },
        getEmbedPointsInsideLane: function (o, t, s, r) {
            let a = [];
            return t.forEach(t => {
                var e = t.angle(), i = t.getBBox(), n = i.center();
                t.isLink() || (t = this.getBBoxCornerPoints(i, n, e), this.isElementInsideLane(o, t, n, s, r) && t.forEach(t => a.push(t)))
            }), a
        },
        isElementInsideLane: function (n, t, e, o, s = {}) {
            s = s.addOverflowingEmbedsOnlyOnHandleSide, e = n.isPointInsideOrOnLine(e);
            if (s) {
                let i = this.getOppositeHandleSide(o);
                s = t.every(t => n.isPointInsideOrOnLine(t)), o = t.some(t => {
                    var e = n.isPointToTheLeftOfLine(t, i), t = n.isPointOnLine(t, i);
                    return e || t
                }), t = t.some(t => n.isPointToTheRightOfLine(t, i));
                return e && (s || o && t)
            }
            return e
        },
        getBBoxCornerPoints: function (t, e, i) {
            return [t.topLeft().rotate(e, -i).round(), t.topRight().rotate(e, -i).round(), t.bottomLeft().rotate(e, -i).round(), t.bottomRight().rotate(e, -i).round()]
        },
        findLeftMostAndRightMostEmbedPoints: function (t, e, i) {
            var n = t.angle(), o = t.getBBox(), s = o.center(), o = new RotatedRect(o, s, n);
            let r = [];
            i.forEach(t => {
                var e, i;
                t.isLink() || (i = (e = t.getBBox()).center(), t = t.angle(), this.getBBoxCornerPoints(e, i, t).forEach(t => r.push(t)))
            });
            s = o.findFurthestPointFromLine(r, HandleSides.Left);
            return {
                leftMostPoint: this.getLeftMostPointCorrectedToPoolHeaders(t, s, o.left, e.left),
                rightMostPoint: o.findFurthestPointFromLine(r, HandleSides.Right)
            }
        },
        getLeftMostPointCorrectedToPoolHeaders: function (t, e, i, n) {
            var o = this.getTotalLaneHeadersWidth(t), t = t.metrics.padding.left, n = n.pointOffset(i.start) - t - o,
                t = i.closestPoint(e), o = new g.Line(t, e), i = o.length() + n;
            return o.setLength(i), o.end
        },
        getTotalLaneHeadersWidth: function (o) {
            var t = o.metrics.lanes;
            let s = 0;
            return Object.keys(t).forEach(t => {
                let e = t, i = 0;
                for (; e;) {
                    var n = o.metrics.lanes[e];
                    i += n.headerSize || 0, e = n.parentId
                }
                s = i > s ? i : s
            }), s
        }
    }, {TransformHandle: TransformHandle});

function pick(n, ...t) {
    let o = {};
    return t.forEach(t => {
        if (Array.isArray(t)) t.forEach(t => {
            n && n.hasOwnProperty(t) && (o[t] = n[t])
        }, o); else if (util.isFunction(t)) for (var e in n) {
            var i;
            n.hasOwnProperty(e) && t(i = n[e], e) && (o[e] = i)
        }
    }), o
}

function toBatchCommand(t) {
    return Array.isArray(t) ? t : [t]
}

function throwError(t) {
    throw new Error("CommandManager: " + t)
}

let CommandManager = mvc.Model.extend({
        defaults: {
            cmdBeforeAdd: null,
            cmdNameRegex: /^(?:add|remove|change:.*)$/,
            applyOptionsList: ["propertyPath"],
            revertOptionsList: ["propertyPath"],
            storeReducedOptions: !0,
            stackLimit: 1 / 0
        }, PREFIX_LENGTH: 7, initialize: function (t) {
            util.bindAll(this, "initBatchCommand", "storeBatchCommand"), this.model = this.graph = t.model || t.graph, this.reset(), this.listen()
        }, listen: function () {
            this.listenTo(this.model, "all", this.addCommand, this), this.listenTo(this.model, "batch:start", this.initBatchCommand, this), this.listenTo(this.model, "batch:stop", this.storeBatchCommand, this), this.listenTo(this.model, "reset", this.reset, this)
        }, push: function (t, e) {
            this.redoStack = [], t.batch ? (this.lastCmdIndex = Math.max(this.lastCmdIndex, 0), this.trigger("batch", t)) : (this._push(this.undoStack, t), this.notifyStackChange("push", t, e), this.trigger("add", t))
        }, _push: function (t, e) {
            var {stackLimit: i = 1 / 0} = this.attributes;
            t.push(e), t.length > i && t.splice(0, t.length - i)
        }, squashUndo: function (t) {
            this.constructor.squashCommands(this.undoStack, t)
        }, squashRedo: function (t) {
            this.constructor.squashCommands(this.redoStack, t)
        }, addCommand: function (i, n, t, o) {
            if (!(o = o || {}).dry && this.get("cmdNameRegex").test(i) && ("function" != typeof this.get("cmdBeforeAdd") || this.get("cmdBeforeAdd").apply(this, arguments))) {
                let t = void 0, e = n === this.model;
                var s,
                    r = (this.batchCommand ? (t = this.batchCommand[Math.max(this.lastCmdIndex, 0)], s = e && !t.graphChange || t.data.id !== n.id, r = t.action !== i, 0 <= this.lastCmdIndex && (s || r) && ((s = this.batchCommand.findIndex(t => (e && t.graphChange || t.data.id === n.id) && t.action === i)) < 0 || "add" === i || "remove" === i ? t = this.constructor.createCommand({batch: !0}) : (t = this.batchCommand[s], this.batchCommand.splice(s, 1)), this.lastCmdIndex = this.batchCommand.push(t) - 1)) : t = this.constructor.createCommand({batch: !1}), this.attributes).storeReducedOptions;
                "add" === i || "remove" === i ? (t.action = i, t.data.id = n.id, t.data.type = n.attributes.type, t.data.attributes = util.merge({}, n.toJSON()), t.options = r ? this.reduceOptions(o) : o, o.replace && (t.replace = !0)) : (s = i.substr(this.PREFIX_LENGTH), t.batch && t.action || (t.action = i, s in n.previousAttributes() && (t.data.previous[s] = util.clone(n.previous(s))), t.options = r ? this.reduceOptions(o) : o, e ? t.graphChange = !0 : (t.data.id = n.id, t.data.type = n.attributes.type)), s in n.attributes && (t.data.next[s] = util.clone(n.get(s)))), this.push(t, o)
            }
        }, reduceOptions: function (t) {
            var {applyOptionsList: e, revertOptionsList: i} = this.attributes;
            return pick(t, e, i)
        }, initBatchCommand: function () {
            this.batchCommand ? this.batchLevel++ : (this.batchCommand = [this.constructor.createCommand({batch: !0})], this.lastCmdIndex = -1, this.batchLevel = 0)
        }, storeBatchCommand: function (t) {
            var e;
            this.batchCommand && this.batchLevel <= 0 ? (0 < (e = this.constructor.filterBatchCommand(this.batchCommand)).length && (this.redoStack = [], this._push(this.undoStack, e), this.notifyStackChange("push", e, t), this.trigger("add", e)), this.batchCommand = null, this.lastCmdIndex = null, this.batchLevel = null) : this.batchCommand && 0 < this.batchLevel && this.batchLevel--
        }, revertCommand: function (t, e) {
            this.processCommand(t, e, {reverse: !0})
        }, applyCommand: function (t, e) {
            this.processCommand(t, e)
        }, processCommand: function (t, e, {reverse: i = !1} = {}) {
            this.stopListening();
            let n;
            n = Array.isArray(t) ? this.constructor.sortBatchCommand(t) : [t];
            var o = this.model, s = o instanceof dia$1.Graph, r = n.length;
            for (let t = 0; t < r; t++) {
                var a = i ? r - 1 - t : t, l = n[a],
                    h = util.assign({commandManager: this.id || this.cid}, e, pick(l.options, this.get(i ? "revertOptionsList" : "applyOptionsList")));
                switch (i ? (t => {
                    switch (t) {
                        case"add":
                            return "remove";
                        case"remove":
                            return "add";
                        default:
                            return t
                    }
                })(l.action) : l.action) {
                    case"add":
                        s || throwError("Cannot perform an 'add' action - the root model is not a dia.Graph."), o.addCell(l.data.attributes, h);
                        break;
                    case"remove":
                        s || throwError("Cannot perform a 'remove' action - the root model is not a dia.Graph.");
                        var c = o.getCell(l.data.id);
                        if (!c) {
                            if (i) break;
                            throwError("Trying to perform a 'remove' action on a cell that is not present in the graph.")
                        }
                        c.remove(h);
                        break;
                    case"replace":
                        if (s || throwError("Cannot perform a 'replace' action - the root model is not a dia.Graph."), o.syncCells([i ? l.data.previous : l.data.next], h), i) {
                            var d, u = o.getCell(l.data.id),
                                c = (u || throwError("Trying to perform a 'replace' action on a cell that is not present in the graph."), util.difference(Object.keys(l.data.next), Object.keys(l.data.previous)));
                            for (d of c) u.unset(d, h)
                        }
                        break;
                    default:
                        var p = l.graphChange ? o : s && o.getCell(l.data.id),
                            g = (p || throwError("Trying to perform a 'change' action on a cell that is not present in the graph."), l.action.substr(this.PREFIX_LENGTH)),
                            m = i ? l.data.previous : l.data.next;
                        g in m ? p.set(g, m[g], h) : p.unset(g, h)
                }
            }
            this.listen()
        }, undo: function (t) {
            var e = this.undoStack.pop();
            e && (this.revertCommand(e, t), this.redoStack.push(e), this.notifyStackChange("undo", e, t))
        }, redo: function (t) {
            var e = this.redoStack.pop();
            e && (this.applyCommand(e, t), this.undoStack.push(e), this.notifyStackChange("redo", e, t))
        }, cancel: function (t) {
            var e = this.undoStack.pop();
            e && (this.revertCommand(e, t), this.redoStack = [], this.notifyStackChange("cancel", e, t))
        }, reset: function (t) {
            this.undoStack = [], this.redoStack = [], this.notifyStackChange("reset", null, t)
        }, hasUndo: function () {
            return 0 < this.undoStack.length
        }, hasRedo: function () {
            return 0 < this.redoStack.length
        }, notifyStackChange: function (t, e, i = {}) {
            let n;
            n = e ? [toBatchCommand(e), i] : [i], this.trigger("stack:" + t, ...n), this.trigger("stack", i)
        }, toJSON() {
            var {undoStack: t, redoStack: e} = this;
            return {undo: this.exportBatchCommands(t), redo: this.exportBatchCommands(e)}
        }, fromJSON(t, e) {
            t && Array.isArray(t.undo) && Array.isArray(t.redo) || throwError("JSON must contain undo and redo arrays."), this.undoStack = util.cloneDeep(t.undo), this.redoStack = util.cloneDeep(t.redo), this.notifyStackChange("reset", null, e)
        }, exportBatchCommands: function (t) {
            let e = this.attributes.storeReducedOptions;
            return t.map(t => toBatchCommand(t).map(t => {
                t = util.clone(t);
                return e || (t.options = this.reduceOptions(t.options)), util.cloneDeep(t)
            }))
        }
    }, {
        createCommand(t = {}) {
            var e = {
                action: t.action,
                data: {id: t.id, type: t.type, previous: t.previous || {}, next: t.next || {}},
                batch: !!t.batch
            };
            return t.options && (e.options = t.options), e
        }, squashCommands: function (e, i = 1 / 0) {
            var t = e.length;
            if (!(t < 2)) {
                i = Math.min(t, i);
                for (var n = []; 0 < i;) {
                    let t = e.pop();
                    Array.isArray(t) || (t.batch = !0, t = [t]), n.unshift(...t), i--
                }
                t = this.filterBatchCommand(n);
                return e.push(t), t
            }
        }, sortBatchCommand: function (t) {
            for (var e = [], i = 0; i < t.length; i++) {
                var n = t[i], o = null;
                if ("add" === n.action) for (var s = n.data.id, r = 0; r < i; r++) if (t[r].data.id === s) {
                    o = r;
                    break
                }
                null !== o ? e.splice(o, 0, n) : e.push(n)
            }
            return e
        }, filterBatchCommand: function (t) {
            let e = t.slice();
            for (var i = []; 0 < e.length;) {
                var o = e.shift();
                let n = o.data.id;
                if (null != o.action && (null != n || o.graphChange)) {
                    if ("add" === o.action) {
                        let i = e.findIndex(function (t) {
                            return "remove" === t.action && t.data && t.data.id === n && !t.replace
                        });
                        if (0 <= i) {
                            e = e.filter(function (t, e) {
                                return e > i || t.data.id !== n
                            });
                            continue
                        }
                    } else if ("remove" === o.action) {
                        if (o.replace) {
                            var s = e.shift(),
                                r = (s && s.replace && "add" === s.action && s.data && s.data.id === n || throwError("Expected `add` command following `remove` command for `replace` operation."), util.merge({}, o.options, s.options)),
                                s = this.createCommand({
                                    action: "replace",
                                    id: n,
                                    previous: o.data.attributes,
                                    next: s.data.attributes,
                                    options: r,
                                    batch: !0
                                });
                            i.push(s);
                            continue
                        }
                        r = e.findIndex(function (t) {
                            return "add" === t.action && t.data && t.data.id == n
                        });
                        if (0 <= r) {
                            e.splice(r, 1);
                            continue
                        }
                    } else if (0 === o.action.indexOf("change") && util.isEqual(o.data.previous, o.data.next)) continue;
                    i.push(o)
                }
            }
            return i
        }
    }),
    Validator = (CommandManager.prototype.createCommand = CommandManager.createCommand, CommandManager.sortBatchCommands = CommandManager.sortBatchCommand, CommandManager.prototype.filterBatchCommand = function (t) {
        return this.constructor.filterBatchCommand(t)
    }, mvc.Model.extend({
        initialize: function (t) {
            this._map = {}, this._commandManager = t.commandManager, this.listenTo(this._commandManager, "add", this._onCommand)
        }, defaults: {cancelInvalid: !0}, _onCommand: function (t) {
            Array.isArray(t) ? t.find(t => !this._validateCommand(t)) : this._validateCommand(t)
        }, _validateCommand: function (s) {
            if (s.options && !1 === s.options.validation) return !0;
            let r;
            return util.toArray(this._map[s.action]).forEach(n => {
                let o = 0;
                !function e(t) {
                    var i = n[o++];
                    try {
                        i ? i(t, s, e) : r = t
                    } catch (t) {
                        e(t)
                    }
                }(r)
            }), !r || (this.get("cancelInvalid") && this._commandManager.cancel(), this.trigger("invalid", r), !1)
        }, validate: function (t) {
            var e = Array.prototype.slice.call(arguments, 1);
            return this.addRule(t, ...e), this
        }, addRule: function (e, ...i) {
            i.forEach(t => {
                util.isFunction(t) || this.throwError(e + " requires callback functions.")
            });
            let n = this._map;
            this.parseActions(e).forEach(t => {
                let e = n[t];
                (e = e || (n[t] = [])).push(i)
            })
        }, removeRule: function (t, ...e) {
            0 === arguments.length && this.throwError("requires at least one argument (actions).");
            let s = this._map;
            0 === e.length ? this.parseActions(t).forEach(t => {
                delete s[t]
            }) : this.parseActions(t).forEach(n => {
                let o = s[n];
                o && e.forEach(e => {
                    for (let t = 0; t < o.length; t++) {
                        var i = o[t];
                        -1 !== i.indexOf(e) && (0 < (i = i.filter(t => t !== e)).length ? o[t] = i : (o.splice(t, 1), t--), 0 === o.length) && delete s[n]
                    }
                })
            })
        }, clearRules: function () {
            this._map = {}
        }, parseActions: function (t) {
            return "string" != typeof t && this.throwError("actions must be a string."), t.split(/\s+/).filter(t => 0 < t.length)
        }, throwError: function (t) {
            throw new Error("dia.Validator: " + t)
        }
    }));

class QuadNode extends Array {
    constructor(t = null, e = 0, i = null) {
        super(), this.boundary = t, this.level = e, this.tree = i, this.clear()
    }

    insert(i) {
        if (!this.overlapsRect(i)) return !1;
        if (!this.hasSubdivisions()) {
            if (this.objects.length < this.tree.nodeCapacity || this.boundary.width <= this.tree.minNodeSize || this.boundary.height <= this.tree.minNodeSize || this.level >= this.tree.maxLevel) return this.objects.push(i), !0;
            this.subdivide();
            for (let t = 0, e = this.objects.length; t < e; t++) {
                var n = this.objects[t], o = this.getInsertSubdivisions(n);
                for (let t = 0, e = o.length; t < e; t++) o[t].insert(n)
            }
            this.objects = []
        }
        for (let t = 0, e = this.length; t < e; t++) this[t].insert(i);
        return !0
    }

    subdivide() {
        var {x: t, y: e, width: i, height: n} = this.boundary, i = i / 2, n = n / 2, o = this.level + 1;
        this[QuadNode.NW] = new QuadNode({
            x: t,
            y: e,
            width: i,
            height: n
        }, o, this.tree), this[QuadNode.NE] = new QuadNode({
            x: t + i,
            y: e,
            width: i,
            height: n
        }, o, this.tree), this[QuadNode.SW] = new QuadNode({
            x: t,
            y: e + n,
            width: i,
            height: n
        }, o, this.tree), this[QuadNode.SE] = new QuadNode({x: t + i, y: e + n, width: i, height: n}, o, this.tree)
    }

    remove(e) {
        if (!this.overlapsRect(e)) return !1;
        var t;
        if (!this.hasSubdivisions()) return -1 !== (t = this.objects.indexOf(e)) && (this.objects.splice(t, 1), !0);
        let i = !1;
        for (let t = 0; t < this.length; t++) this[t].remove(e) && (i = !0);
        return i
    }

    hasSubdivisions() {
        return 0 < this.length
    }

    getInsertSubdivisions(e) {
        return this.filter(t => t.overlapsRect(e))
    }

    queryRect(t, e, i) {
        for (var n = new Set, o = [this]; 0 < o.length;) {
            var s = o.pop();
            if (s.overlapsRect(t)) if (s.hasSubdivisions()) o.push(...s); else for (var r of s.objects) i && !i(r) || (e ? QuadNode.isRectInsideRect(r, t) : QuadNode.isRectOverlappingRect(r, t)) && n.add(r)
        }
        return Array.from(n)
    }

    queryPoint(t, e, i) {
        for (var n = [], o = [this]; 0 < o.length;) {
            var s = o.pop();
            if (s.containsPoint(t)) if (s.hasSubdivisions()) o.push(...s); else for (var r of s.objects) i && !i(r) || QuadNode.isPointInsideRect(t, r, e) && n.push(r)
        }
        return n
    }

    hasRect(i, t, e) {
        for (var n = [this]; 0 < n.length;) {
            var o = n.pop();
            if (o.overlapsRect(i)) if (o.hasSubdivisions()) for (let t = 0, e = o.length; t < e; t++) {
                var s = o[t];
                s.overlapsRect(i) && n.push(s)
            } else for (var r of o.objects) if (!e || e(r)) if (t ? QuadNode.isRectInsideRect(r, i) : QuadNode.isRectOverlappingRect(r, i)) return !0
        }
        return !1
    }

    hasPoint(i, t, e) {
        for (var n = [this]; 0 < n.length;) {
            var o = n.pop();
            if (o.containsPoint(i)) if (o.hasSubdivisions()) for (let t = 0, e = o.length; t < e; t++) {
                var s = o[t];
                s.containsPoint(i) && n.push(s)
            } else for (var r of o.objects) if ((!e || e(r)) && QuadNode.isPointInsideRect(i, r, t)) return !0
        }
        return !1
    }

    clear() {
        this.objects = [], this.hasSubdivisions() && this.splice(0, this.length)
    }

    overlapsRect(t) {
        return QuadNode.isRectOverlappingRect(this.boundary, t)
    }

    containsRect(t) {
        return QuadNode.isRectInsideRect(t, this.boundary)
    }

    containsPoint(t) {
        return QuadNode.isPointInsideRect(t, this.boundary)
    }

    static isRectOverlappingRect(t, e) {
        return t.x < e.x + e.width && t.x + t.width > e.x && t.y < e.y + e.height && t.y + t.height > e.y
    }

    static isRectInsideRect(t, e) {
        return t.x >= e.x && t.x + t.width <= e.x + e.width && t.y >= e.y && t.y + t.height <= e.y + e.height
    }

    static isPointInsideRect(t, e, i) {
        return i ? t.x > e.x && t.x < e.x + e.width && t.y > e.y && t.y < e.y + e.height : t.x >= e.x && t.x <= e.x + e.width && t.y >= e.y && t.y <= e.y + e.height
    }
}

QuadNode.EAST = 1, QuadNode.SOUTH = 2, QuadNode.NW = 0, QuadNode.NE = 1, QuadNode.SW = 2, QuadNode.SE = 3;

class QuadTree {
    constructor(t = {x: 0, y: 0, width: 1024, height: 1024}, e = 6, i = 16, n = 1, o = !0) {
        this.initialBoundary = t, this.maxDepth = e, this.nodeCapacity = i, this.minNodeSize = n, this.autoGrow = o, this.root = new QuadNode(t, 0, this), this.maxLevel = e
    }

    insert(t) {
        return this.autoGrow && this.grow(t), this.root.insert(t)
    }

    remove(t) {
        return this.root.remove(t)
    }

    clear() {
        this.root.clear(), this.root.boundary = this.initialBoundary, this.root.level = 0, this.maxLevel = this.maxDepth
    }

    queryRect(t, e = !1, i) {
        return this.root.queryRect(t, e, i)
    }

    queryPoint(t, e = !1, i) {
        return this.root.queryPoint(t, e, i)
    }

    hasRect(t, e = !1, i) {
        return this.root.hasRect(t, e, i)
    }

    hasPoint(t, e = !1, i) {
        return this.root.hasPoint(t, e, i)
    }

    grow(t) {
        for (; !this.root.containsRect(t);) this.growTowardsRect(t)
    }

    growTowardsRect(t) {
        var e = this.root, {x: i, y: n, width: o, height: s} = e.boundary,
            r = {x: i, y: n, width: 2 * o, height: 2 * s};
        let a = QuadNode.NW;
        i >= t.x && (r.x = i - o, a |= QuadNode.EAST), t.y <= n && (r.y = n - s, a |= QuadNode.SOUTH);
        i = new QuadNode(r, e.level - 1, this);
        i.subdivide(), i[a] = e, this.root = i, this.maxLevel = this.maxDepth - i.level
    }
}

class SearchGraph extends dia$1.Graph {
    constructor(t = null, e = {}) {
        super(t, e), this.EPSILON = .001, this.qtNodeInitialSize = 1024, this.qtNodeMinSize = 64, this.qtMaxDepth = 8, this.qtNodeCapacity = 16, this.qtDirty = !1, this.qtLazyMode = !1, this.qtIndexFilter = null, this.qtUpdateAttributes = ["position", "size", "angle", "vertices", "source", "target", "ports"], this.qt = new QuadTree(void 0, this.qtMaxDepth, this.qtNodeCapacity, this.qtNodeMinSize, !0), this.qtSearchObjectMap = new Map, this.on("add", this.onCellAdded, this).on("remove", this.onCellRemoved, this).on("change", this.onCellChanged, this).on("reset", this.onCollectionReset, this)
    }

    onCellAdded(t) {
        this.qtDirty || (this.qtLazyMode ? this.invalidateQuadTree() : this.qtIndexFilter && !this.qtIndexFilter(t) || this.indexCell(t))
    }

    onCellRemoved(t) {
        this.qtDirty || (this.qtLazyMode ? this.invalidateQuadTree() : this.qtIndexFilter && !this.qtIndexFilter(t) || this.unindexCell(t))
    }

    onCellChanged(e) {
        this.qtDirty || this.qtUpdateAttributes.every(t => !e.hasChanged(t)) || (this.qtLazyMode ? this.invalidateQuadTree() : this.qtIndexFilter && !this.qtIndexFilter(e) || (this.reindexCell(e), e.isElement() && this.getConnectedLinks(e).forEach(t => this.reindexCell(t))))
    }

    onCollectionReset() {
        this.qtLazyMode ? this.invalidateQuadTree() : this.indexCells()
    }

    indexCell(t) {
        this.qt.insert(this.registerSearchObject(t))
    }

    unindexCell(t) {
        t = this.unregisterSearchObject(t);
        t && this.qt.remove(t)
    }

    reindexCell(t) {
        this.unindexCell(t), this.indexCell(t)
    }

    registerSearchObject(t) {
        var e = this.qtSearchObjectMap.get(t.id);
        return e || (e = this.createSearchObject(t), this.qtSearchObjectMap.set(t.id, e)), e
    }

    unregisterSearchObject(t) {
        var e = this.qtSearchObjectMap.get(t.id);
        return e ? (this.qtSearchObjectMap.delete(t.id), e) : null
    }

    createSearchObject(t) {
        var e = t.isElement(), i = e ? t.getBBox({rotate: !0}) : t.getBBox();
        return 0 === i.width && (i.width = this.EPSILON), 0 === i.height && (i.height = this.EPSILON), {
            id: t.id,
            link: !e,
            x: i.x,
            y: i.y,
            width: i.width,
            height: i.height
        }
    }

    queryQuadTreeRect(t, e = !1, i) {
        return this.qtDirty && this.buildQuadTree(), this.qt.queryRect(t, e, i)
    }

    queryQuadTreePoint(t, e = !1, i) {
        return this.qtDirty && this.buildQuadTree(), this.qt.queryPoint(t, e, i)
    }

    getInitialQuadTreeBoundary() {
        return this.qtUserBoundary || this.computeInitialQuadTreeBoundary(this.qtNodeInitialSize)
    }

    computeInitialQuadTreeBoundary(t, e = t) {
        var i = {x: 0, y: 0, width: t, height: e}, n = this.getFirstCell();
        return n && (n = n.getBBox(), i.x = Math.floor(n.x / t) * t, i.y = Math.floor(n.y / e) * e), i
    }

    invalidateQuadTree() {
        this.qtDirty = !0
    }

    buildQuadTree() {
        this.qtSearchObjectMap.clear(), this.qt.initialBoundary = this.getInitialQuadTreeBoundary(), this.indexCells(), this.qtDirty = !1
    }

    indexCells() {
        this.qt.clear();
        for (var t of this.getCells()) this.qtIndexFilter && !this.qtIndexFilter(t) || this.indexCell(t)
    }

    setQuadTreeBoundary(t, e = !1) {
        this.qtUserBoundary = t, this.qt.autoGrow = !t || e, this.invalidateQuadTree()
    }

    setQuadTreeMaxDepth(t) {
        this.qt.maxDepth = t, this.invalidateQuadTree()
    }

    setQuadTreeCapacity(t) {
        this.qt.nodeCapacity = t, this.invalidateQuadTree()
    }

    setQuadTreeLazyMode(t) {
        this.qtLazyMode !== t && (this.qtLazyMode = t, this.invalidateQuadTree())
    }

    setQuadTreeIndexFilter(t) {
        this.qtIndexFilter = t, this.invalidateQuadTree()
    }

    findElementsInArea(t, e = {}) {
        return !1 === e.useIndex ? super.findElementsInArea(t, e) : this.queryQuadTreeRect(t, e.strict, SearchGraph.isObjectElement).map(t => this.getCell(t.id))
    }

    findLinksInArea(t, e = {}) {
        return !1 === e.useIndex ? super.findLinksInArea(t, e) : this.queryQuadTreeRect(t, e.strict, SearchGraph.isObjectLink).map(t => this.getCell(t.id))
    }

    findCellsInArea(t, e = {}) {
        return !1 === e.useIndex ? super.findCellsInArea(t, e) : this.queryQuadTreeRect(t, e.strict).map(t => this.getCell(t.id))
    }

    findElementsAtPoint(t, e = {}) {
        return !1 === e.useIndex ? super.findElementsAtPoint(t, e) : this.queryQuadTreePoint(t, e.strict, SearchGraph.isObjectElement).map(t => this.getCell(t.id))
    }

    findLinksAtPoint(t, e = {}) {
        return !1 === e.useIndex ? super.findLinksAtPoint(t, e) : this.queryQuadTreePoint(t, e.strict, SearchGraph.isObjectLink).map(t => this.getCell(t.id))
    }

    findCellsAtPoint(t, e = {}) {
        return !1 === e.useIndex ? super.findCellsAtPoint(t, e) : this.queryQuadTreePoint(t, e.strict).map(t => this.getCell(t.id))
    }

    findElementsUnderElement(t, e = {}) {
        return !1 === e.useIndex ? super.findElementsUnderElement(t, e) : this.findUnderElement(t, this.findElementsInArea, this.findElementsAtPoint, e)
    }

    findLinksUnderElement(t, e = {}) {
        return !1 === e.useIndex ? super.findLinksUnderElement(t, e) : this.findUnderElement(t, this.findLinksInArea, this.findLinksAtPoint, e)
    }

    findCellsUnderElement(t, e = {}) {
        return !1 === e.useIndex ? super.findCellsUnderElement(t, e) : this.findUnderElement(t, this.findCellsInArea, this.findCellsAtPoint, e)
    }

    findUnderElement(t, e, i, n = {}) {
        var o = this._getFindUnderElementGeometry(t, n.searchBy),
            i = (o.type === g.types.Point ? i : e).call(this, o, n);
        return this._validateCellsUnderElement(i, t)
    }

    hasElementsInArea(t, e = {}) {
        return !1 === e.useIndex ? this.hasInAreaNoIndex(this.getElements(), t, e) : this.hasInArea(t, e.strict, SearchGraph.isObjectElement)
    }

    hasLinksInArea(t, e = {}) {
        return !1 === e.useIndex ? this.hasInAreaNoIndex(this.getLinks(), t, e) : this.hasInArea(t, e.strict, SearchGraph.isObjectLink)
    }

    hasCellsInArea(t, e = {}) {
        return !1 === e.useIndex ? this.hasInAreaNoIndex(this.getCells(), t, e) : this.hasInArea(t, e.strict, null)
    }

    hasInArea(t, e = !1, i) {
        return this.qtDirty && this.buildQuadTree(), this.qt.hasRect(t, e, i)
    }

    hasInAreaNoIndex(e, t, i = {}) {
        var n = new g.Rect(t), o = {rotate: !0};
        for (let t = 0; t < e.length; t++) {
            var s = e[t].getBBox(o);
            if (i.strict) {
                if (n.containsRect(s)) return !0
            } else if (n.intersect(s)) return !0
        }
        return !1
    }

    hasElementsAtPoint(t, e = {}) {
        return !1 === e.useIndex ? this.hasAtPointNoIndex(this.getElements(), t, e) : this.hasAtPoint(t, e.strict, SearchGraph.isObjectElement)
    }

    hasLinksAtPoint(t, e = {}) {
        return !1 === e.useIndex ? this.hasAtPointNoIndex(this.getLinks(), t, e) : this.hasAtPoint(t, e.strict, SearchGraph.isObjectLink)
    }

    hasCellsAtPoint(t, e = {}) {
        return !1 === e.useIndex ? this.hasAtPointNoIndex(this.getCells(), t, e) : this.hasAtPoint(t, e.strict, null)
    }

    hasAtPoint(t, e = !1, i) {
        return this.qtDirty && this.buildQuadTree(), this.qt.hasPoint(t, e, i)
    }

    hasAtPointNoIndex(e, i, n = {}) {
        var o = {rotate: !0};
        for (let t = 0; t < e.length; t++) if (e[t].getBBox(o).containsPoint(i, n)) return !0;
        return !1
    }

    static isObjectLink(t) {
        return t.link
    }

    static isObjectElement(t) {
        return !t.link
    }
}

let $$l = mvc.$, FreeTransform = mvc.View.extend({
        className: "free-transform",
        events: {
            "mousedown .resize": "startResizing",
            "mousedown .rotate": "startRotating",
            "touchstart .resize": "startResizing",
            "touchstart .rotate": "startRotating",
            wheel: "onMousewheel",
            mousewheel: "onMousewheel"
        },
        DIRECTIONS: ["nw", "n", "ne", "e", "se", "s", "sw", "w"],
        POSITIONS: ["top-left", "top", "top-right", "right", "bottom-right", "bottom", "bottom-left", "left"],
        options: {
            cellView: void 0,
            rotateAngleGrid: 15,
            resizeGrid: void 0,
            preserveAspectRatio: !1,
            minWidth: 0,
            minHeight: 0,
            maxWidth: 1 / 0,
            maxHeight: 1 / 0,
            allowOrthogonalResize: !0,
            resizeDirections: null,
            allowRotation: !0,
            clearAll: !0,
            clearOnBlankPointerdown: !0,
            usePaperScale: !1,
            padding: 3,
            useBordersToResize: !1
        },
        documentEvents: {mousemove: "pointermove", touchmove: "pointermove", mouseup: "pointerup", touchend: "pointerup"},
        init: function () {
            var t = this.options, {paper: t, clearAll: e} = (t.cellView ? util.defaults(t, {
                cell: t.cellView.model,
                paper: t.cellView.paper,
                graph: t.cellView.paper.model
            }) : t.paper && t.cell && util.defaults(t, {cellView: t.cell.findView(t.paper), graph: t.paper.model}), t);
            e && this.constructor.clear(t), this.startListening(), t.$el.append(this.el), this.constructor.registerInstanceToPaper(this, t)
        },
        startListening: function () {
            var {cell: t, paper: e, graph: i, clearOnBlankPointerdown: n} = this.options;
            this.listenTo(t, "change:size change:position change:angle", this.onCellAttributeChange), this.listenTo(e, "transform", () => this.requestUpdate()), this.listenTo(i, "reset", () => this.remove()), this.listenTo(t, "remove", () => this.remove()), n && this.listenTo(e, "blank:pointerdown", () => this.remove())
        },
        onCellAttributeChange: function (t, e, i) {
            i.updateHandled || this.requestUpdate()
        },
        renderHandles: function () {
            let {options: t, POSITIONS: i} = this;
            var e = $$l("<div/>").prop("draggable", !1), n = e.clone().addClass("rotate"),
                o = i.map(t => e.clone().addClass("resize").data("position", t));
            let s = t.resizeDirections;
            Array.isArray(s) && o.forEach((t, e) => {
                s.includes(i[e]) || t.css("display", "none")
            }), this.$el.empty().append(o, n)
        },
        render: function () {
            var {options: t, $el: e} = this, {
                cell: t,
                preserveAspectRatio: i,
                allowRotation: n,
                allowOrthogonalResize: o,
                useBordersToResize: s
            } = t;
            e.data("type", t.get("type")), e.toggleClass("no-orthogonal-resize", i || !o), e.toggleClass("no-rotation", !n), e.toggleClass("use-borders-to-resize", !!s), this.renderHandles(), this.requestUpdate()
        },
        requestUpdate: function (t) {
            var {UPDATE_PRIORITY: e, options: i} = this;
            i.paper.requestViewUpdate(this, 1, e, t)
        },
        confirmUpdate: function () {
            this.update()
        },
        update: function () {
            this.options.usePaperScale ? this.updateFrameScaled() : this.updateFrameNoScale(), this.updateHandleDirections()
        },
        updateFrameScaled: function () {
            var {paper: t, cell: e, padding: i} = this.options, {
                    left: i,
                    right: n,
                    top: o,
                    bottom: s
                } = util.normalizeSides(i), {x: i, y: n, width: o, height: s} = e.getBBox().moveAndExpand({
                    x: -i,
                    y: -o,
                    width: i + n,
                    height: o + s
                }), e = e.angle(), t = t.matrix().translate(i, n).translate(o / 2, s / 2).rotate(e).translate(-o / 2, -s / 2),
                i = V.matrixToTransformString(t);
            this.$el.css({
                width: o,
                height: s,
                left: 0,
                top: 0,
                "transform-origin": "0 0",
                transform: i,
                "-webkit-transform": i,
                "-ms-transform": i
            })
        },
        updateFrameNoScale: function () {
            var {paper: t, cell: e, padding: i} = this.options, {
                    left: i,
                    right: n,
                    top: o,
                    bottom: s
                } = util.normalizeSides(i), {a: t, d: r, e: a, f: l} = t.matrix(), h = e.getBBox(), e = e.angle(),
                a = (h.x *= t, h.x += a, h.y *= r, h.y += l, h.width *= t, h.height *= r, h.moveAndExpand({
                    x: -i,
                    y: -o,
                    width: i + n,
                    height: o + s
                }), `rotate(${e}deg)`);
            this.$el.css({
                width: h.width,
                height: h.height,
                left: h.x,
                top: h.y,
                "transform-origin": "50% 50%",
                transform: a,
                "-webkit-transform": a,
                "-ms-transform": a
            })
        },
        updateHandleDirections: function () {
            var i, t = this.options.cell.angle(), t = Math.floor(t * (this.DIRECTIONS.length / 360));
            t != this._previousDirectionsShift && (i = this.DIRECTIONS.slice(t).concat(this.DIRECTIONS.slice(0, t)), Array.from(this.$(".resize").removeClass(this.DIRECTIONS.join(" "))).forEach(function (t, e) {
                $$l(t).addClass(i[e])
            }), this._previousDirectionsShift = t)
        },
        calculateTrueDirection: function (t) {
            var e = this.options.cell, e = g.normalizeAngle(e.get("angle")), t = this.POSITIONS.indexOf(t),
                t = (t += Math.floor(e * (this.POSITIONS.length / 360))) % this.POSITIONS.length;
            return this.POSITIONS[t]
        },
        startResizing: function (t) {
            t.stopPropagation();
            var e = this.options, {cell: i, graph: n, paper: o} = e,
                n = (n.startBatch("free-transform", {freeTransform: this.cid}), t.target.dataset.position),
                s = this.calculateTrueDirection(n), r = 0, a = 0, l = (n.split("-").forEach(function (t) {
                    r = {left: -1, right: 1}[t] || r, a = {top: -1, bottom: 1}[t] || a
                }), this.toValidResizeDirection(n)), h = {
                    "top-right": "bottomLeft",
                    "top-left": "corner",
                    "bottom-left": "topRight",
                    "bottom-right": "origin"
                }[l], {minWidth: e, minHeight: c, maxWidth: d, maxHeight: u} = e,
                e = "function" == typeof e ? e.call(this, i, this, n) : e,
                c = "function" == typeof c ? c.call(this, i, this, n) : c,
                d = "function" == typeof d ? d.call(this, i, this, n) : d,
                u = "function" == typeof u ? u.call(this, i, this, n) : u, h = {
                    action: "resize",
                    angle: i.angle(),
                    resizeX: r,
                    resizeY: a,
                    selector: h,
                    direction: l,
                    relativeDirection: n,
                    trueDirection: s,
                    maxHeight: u,
                    minHeight: c,
                    maxWidth: d,
                    minWidth: e,
                    cellView: i.findView(o)
                };
            this.startOp(t.target), this.eventData(t, h), this.trigger(h.action + ":start", t), this.delegateDocumentEvents(null, t.data)
        },
        toValidResizeDirection: function (t) {
            return {top: "top-left", bottom: "bottom-right", left: "bottom-left", right: "top-right"}[t] || t
        },
        startRotating: function (t) {
            t.stopPropagation();
            var e = util.normalizeEvent(t),
                i = (this.options.graph.startBatch("free-transform", {freeTransform: this.cid}), this.options.cell.getCenter()),
                e = this.options.paper.snapToGrid({x: e.clientX, y: e.clientY}), e = {
                    action: "rotate",
                    centerRotation: i,
                    modelAngle: g.normalizeAngle(this.options.cell.get("angle") || 0),
                    startAngle: g.point(e).theta(i)
                };
            this.startOp(t.target), this.eventData(t, e), this.trigger(e.action + ":start", t), this.delegateDocumentEvents(null, t.data)
        },
        pointermove: function (t) {
            var e = this.eventData(t), {action: i, maxHeight: n, maxWidth: o, minHeight: s, minWidth: r, cellView: a} = e;
            if (i) {
                t = util.normalizeEvent(t);
                var l = this.options, h = l.cell, c = l.paper.snapToGrid({x: t.clientX, y: t.clientY}), {
                    width: d,
                    height: u
                } = this.getResizeGrid();
                switch (i) {
                    case"resize":
                        var p, m = h.getBBox(), f = g.point(c).rotate(m.center(), e.angle).difference(m[e.selector]()),
                            v = e.resizeX ? f.x * e.resizeX : m.width, f = e.resizeY ? f.y * e.resizeY : m.height,
                            v = g.snapToGrid(v, d), f = g.snapToGrid(f, u);
                        v = Math.max(v, r || d), f = Math.max(f, s || u), v = Math.min(v, o), f = Math.min(f, n), l.preserveAspectRatio && (y = m.width * f / m.height, p = m.height * v / m.width, v < y ? f = p : v = y), m.width == v && m.height == f || (p = {
                            freeTransform: this.cid,
                            direction: e.direction,
                            relativeDirection: e.relativeDirection,
                            trueDirection: e.trueDirection,
                            ui: !0,
                            minWidth: r,
                            minHeight: s,
                            maxWidth: o,
                            maxHeight: n,
                            preserveAspectRatio: l.preserveAspectRatio
                        }, a.scalableNode && (p.async = !1), h.resize(v, f, p));
                        break;
                    case"rotate":
                        var y = e.startAngle - g.point(c).theta(e.centerRotation);
                        h.rotate(g.snapToGrid(e.modelAngle + y, l.rotateAngleGrid), !0, null, {freeTransform: this.cid})
                }
                this.trigger("" + i, t)
            }
        },
        getResizeGrid: function () {
            var t = this.options.paper.options.gridSize, e = this.options.resizeGrid || {};
            return {width: e.width || t, height: e.height || t}
        },
        pointerup: function (t) {
            this.undelegateDocumentEvents();
            var e = this.eventData(t);
            e.action && (this.stopOp(), this.trigger(e.action + ":stop", t), this.options.graph.stopBatch("free-transform", {freeTransform: this.cid}))
        },
        onMousewheel: function (t) {
            t.preventDefault()
        },
        onRemove: function () {
            FreeTransform.unregisterInstanceFromPaper(this, this.options.paper)
        },
        startOp: function (t) {
            t && ($$l(t).addClass("in-operation"), this._elementOp = t), this.$el.addClass("in-operation"), this.options.paper.undelegateEvents()
        },
        stopOp: function () {
            this._elementOp && ($$l(this._elementOp).removeClass("in-operation"), this._elementOp = null), this.$el.removeClass("in-operation"), this.options.paper.delegateEvents()
        }
    }, {
        instancesByPaper: {}, clear: function (t) {
            t.trigger("freetransform:create"), this.removeInstancesForPaper(t)
        }, removeInstancesForPaper: function (t) {
            util.invoke(this.getInstancesForPaper(t), "remove")
        }, getInstancesForPaper: function (t) {
            return this.instancesByPaper[t.cid] || {}
        }, registerInstanceToPaper: function (t, e) {
            this.instancesByPaper[e.cid] || (this.instancesByPaper[e.cid] = {}), this.instancesByPaper[e.cid][t.cid] = t
        }, unregisterInstanceFromPaper: function (t, e) {
            this.instancesByPaper[e.cid] && (this.instancesByPaper[e.cid][t.cid] = null)
        }
    }), BPMNFreeTransform = FreeTransform.extend({
        className: FreeTransform.prototype.className + " bpmn-free-transform",
        options: util.merge({}, FreeTransform.prototype.options, {
            allowRotation: !1,
            resizeGrid: {width: 1, height: 1},
            useBordersToResize: !0,
            minLaneSize: 10
        }),
        init: function () {
            if (FreeTransform.prototype.init.apply(this, arguments), this.options.allowRotation) throw new Error("BPMNFreeTransform: `allowRotation` option cannot be used.");
            var t = this.options.cell;
            (CompositePool.isPool(t) || Swimlane.isSwimlane(t) || Phase.isPhase(t)) && (this.options.resizeDirections = ["bottom", "right", "top", "left"], this.options.minHeight = (t, e, i) => e.minHeight(t, i, e.options), this.options.minWidth = (t, e, i) => e.minWidth(t, i, e.options)), this.addResizeListeners(), this.render()
        },
        minHeight(t, e, i) {
            i = i.minLaneSize, t = this.minSize(t, e).minHeight;
            return t ?? i
        },
        minWidth(t, e, i) {
            i = i.minLaneSize, t = this.minSize(t, e).minWidth;
            return t ?? i
        },
        minSize(t, e) {
            let i;
            return CompositePool.isPool(t) ? i = this.poolMinSize(t, e) : Swimlane.isSwimlane(t) ? i = this.swimlaneMinSize(t, e) : Phase.isPhase(t) && (i = this.phaseMinSize(t, e)), i ?? {}
        },
        poolMinSize(t, e) {
            var i = t.getBBox(), n = t.getPadding(), o = t.getSwimlanePadding(), s = t.getPhasePadding();
            switch (e) {
                case"bottom":
                    var r = t.getMinimalYRange();
                    return r ? {minHeight: r[1] + n.bottom - i.y} : {minHeight: t.getMinimalHeight()};
                case"top":
                    r = t.getMinimalYRange();
                    return r ? {minHeight: i.y + i.height - r[0] + n.top + o.top + s.top} : {minHeight: t.getMinimalHeight()};
                case"right":
                    r = t.getMinimalXRange();
                    return r ? {minWidth: r[1] + n.right - i.x} : {minWidth: t.getMinimalWidth()};
                case"left":
                    r = t.getMinimalXRange();
                    return r ? {minWidth: i.x + i.width - r[0] + n.left + o.left + s.left} : {minWidth: t.getMinimalWidth()}
            }
        },
        swimlaneMinSize(t, e) {
            var i = t.getParentCell();
            if (i) {
                var n, o = i.getMinimumLaneSize(), s = t.getBBox(), r = i.getSwimlanePadding(), a = i.isHorizontal();
                switch (e) {
                    case"bottom":
                        return a ? (n = t.getElementsBBox()) ? {minHeight: (n = n.inflate(t.getContentMargin())).y + n.height - s.y} : {minHeight: r.top + o} : (n = i.getMinimalYRange()) ? {minHeight: n[1] - s.y} : {minHeight: r.top + o};
                    case"top":
                        return a ? (n = t.getElementsBBox()) ? (n = n.inflate(t.getContentMargin()), {minHeight: s.y + s.height - n.y}) : {minHeight: r.top + o} : (n = i.getMinimalYRange()) ? {minHeight: s.y + s.height - n[0] + r.top} : {minHeight: r.top + o};
                    case"right":
                        return a ? (n = i.getMinimalXRange()) ? {minWidth: n[1] - s.x} : {minWidth: r.left + o} : (n = t.getElementsBBox()) ? {minWidth: (n = n.inflate(t.getContentMargin())).x + n.width - s.x} : {minWidth: r.left + o};
                    case"left":
                        return a ? (n = i.getMinimalXRange()) ? {minWidth: s.x + s.width - n[0] + r.left} : {minWidth: r.left + o} : (n = t.getElementsBBox()) ? (n = n.inflate(t.getContentMargin()), {minWidth: s.x + s.width - n.x}) : {minWidth: r.left + o}
                }
            }
        },
        phaseMinSize(e, t) {
            var i = e.graph;
            if (i) {
                var n = e.getParentCell();
                if (n) {
                    var o = n.getContentMargin(), s = n.getMinimumLaneSize(), r = e.getBBox(), a = n.getPhasePadding(),
                        l = n.getSwimlanePadding(), h = n.isHorizontal();
                    switch (t) {
                        case"bottom":
                            if (h) return (c = n.getMinimalYRange()) ? {minHeight: c[1] - r.y} : {minHeight: a.top + s};
                        {
                            var c = e.getElements(), c = i.getCellsBBox(c), d = n.getPhases().indexOf(e);
                            let t = a.top + s;
                            return c ? (c.inflate(o), t = c.y + c.height - r.y) : 0 === d && (t += l.top), {minHeight: t}
                        }
                        case"top":
                            if (h) return (c = n.getMinimalYRange()) ? {minHeight: r.y + r.height - c[0] + a.top} : {minHeight: a.top + s};
                        {
                            var d = e.getElements(), c = i.getCellsBBox(d), d = n.getPhases().indexOf(e);
                            let t = a.top + s;
                            return c && (c.inflate(o), t = r.y + r.height - c.y), 0 === d && (t += l.top), {minHeight: t}
                        }
                        case"right":
                            if (h) {
                                c = e.getElements(), d = i.getCellsBBox(c), c = n.getPhases().indexOf(e);
                                let t = a.left + s;
                                return d ? (d.inflate(o), t = d.x + d.width - r.x) : 0 === c && (t += l.left), {minWidth: t}
                            }
                            return (d = n.getMinimalXRange()) ? {minWidth: d[1] - r.x} : {minWidth: a.left + s};
                        case"left":
                            if (h) {
                                c = e.getElements(), d = i.getCellsBBox(c), c = n.getPhases().indexOf(e);
                                let t = a.left + s;
                                return d && (d.inflate(o), t = r.x + r.width - d.x), 0 === c && (t += l.left), {minWidth: t}
                            }
                            return (d = n.getMinimalXRange()) ? {minWidth: r.x + r.width - d[0] + a.left} : {minWidth: a.left + s}
                    }
                }
            }
        },
        addResizeListeners() {
            let o = this.options.cell;
            var t = o.graph;
            this.on("resize:start", t => {
                var {cellView: t, relativeDirection: e} = this.eventData(t), t = t.model;
                o === t && this.onResizeStart(o, e)
            }), this.listenTo(t, "batch:stop", t => {
                var {freeTransform: t, cell: e, relativeDirection: i, batchName: n} = t;
                t === this.cid && "resize" === n && o === e && this.onResize(o, i)
            })
        },
        onResizeStart(i, n) {
            if (CompositePool.isPool(i) || Swimlane.isSwimlane(i) || Phase.isPhase(i)) {
                var {width: o, height: s} = this.getResizeGrid();
                let {width: t, height: e} = i.getBBox();
                var r = t % o, r = (1e-6 < r && (t = t - r + o), e % s),
                    o = (1e-6 < r && (e = e - r + s), {left: "bottom", top: "left", right: "top", bottom: "right"}[n]),
                    r = "left" === o || "right" === o ? t : e;
                CompositePool.isPool(i) ? this.onPoolResize(i, o, r) : Swimlane.isSwimlane(i) ? this.onSwimlaneResize(i, o, r) : Phase.isPhase(i) && this.onPhaseResize(i, o, r)
            }
        },
        onResize(t, e) {
            CompositePool.isPool(t) ? this.onPoolResize(t, e) : Swimlane.isSwimlane(t) ? this.onSwimlaneResize(t, e) : Phase.isPhase(t) ? this.onPhaseResize(t, e) : this.onElementResize(t)
        },
        onPoolResize(t, e, i = null) {
            t.changeSize(e, i)
        },
        onSwimlaneResize(t, e, i = null) {
            var n = t.getParentCell();
            n && n.changeSwimlaneSize(t, e, i)
        },
        onPhaseResize(t, e, i = null) {
            var n = t.getParentCell();
            n && n.changePhaseSize(t, e, i)
        },
        onElementResize(t) {
            var e, t = t.getParentCell();
            t && (e = t.getParentCell()) && e.adjustToContainElements(t)
        }
    }), Clipboard = mvc.Collection.extend({
        LOCAL_STORAGE_KEY: "joint.ui.Clipboard.cells",
        defaults: {useLocalStorage: !0, deep: !1, origin: "center", translate: {dx: 20, dy: 20}},
        constructor: function (t) {
            mvc.Collection.prototype.constructor.call(this, [], t), this.defaults = util.assign({}, this.defaults, t), this.cid = util.guid()
        },
        copyElements: function (t, e, i) {
            i = util.assign({}, this.defaults, i);
            t = Array.isArray(t) ? t : t.toArray();
            let n;
            i.deep ? (n = [], t.forEach(t => {
                n.push(t, ...t.getEmbeddedCells({deep: !0}))
            })) : n = t;
            t = this.cloneCells(e.getSubgraph(n), i);
            return this.saveCells(t, i), n
        },
        cloneCells: function (t, e) {
            let i;
            if ("function" == typeof e.cloneCells) {
                if (i = e.cloneCells(t), !Array.isArray(i) || !i.every(t => t instanceof dia$1.Cell)) throw new Error("ui.Clipboard: the `cloneCells` function must return an array of cells.")
            } else i = Object.values(util.cloneCells(t));
            return util.sortBy(i, t => t.attributes.z || 0)
        },
        cutElements: function (t, e, i) {
            i = util.assign({}, this.defaults, i);
            t = this.copyElements(t, e, i), i = i.removeCellOptions || {};
            return i.clipboard = this.cid, e.startBatch("cut"), util.invoke(t, "remove", i), e.stopBatch("cut"), t
        },
        pasteCells: function (t, e) {
            (e = util.assign({}, this.defaults, e)).useLocalStorage && this.updateFromStorage(t);
            let i = t.maxZIndex();
            var n = this.toArray().map(t => (i += 1, this.modifyCell(t, e, i))), o = e.addCellOptions || {},
                n = (o.clipboard = this.cid, util.sortBy(n, t => t.isLink() ? 2 : 1));
            return t.startBatch("paste"), t.addCells(n, o), t.stopBatch("paste"), this.copyElements(this, t, e), n
        },
        pasteCellsAtPoint: function (t, e, i) {
            (i = util.assign({}, this.defaults, i)).useLocalStorage && this.updateFromStorage(t);
            var n = this.toArray(), o = this.cloneCells(n, i), o = (this.saveCells(o, i), t.layerCollection.cellNamespace),
                o = new dia$1.Graph([], {cellNamespace: o, ignoreLayers: !0}),
                n = (o.resetCells(n, {sort: !1}), this.getOriginPoint(n, o, i.origin));
            if (!n) return [];
            o = {dx: e.x - n.x, dy: e.y - n.y};
            i.translate = o;
            let s = t.maxZIndex();
            e = this.toArray().map(t => (s += 1, this.modifyCell(t, i, s))), n = i.addCellOptions || {}, n.clipboard = this.cid, o = util.sortBy(e, t => t.isLink() ? 2 : 1);
            return t.startBatch("paste"), t.addCells(o, n), t.stopBatch("paste"), o
        },
        isEmpty: function (t) {
            if (t = util.assign({}, this.defaults, t), 0 < this.length) return !1;
            if (t.useLocalStorage) {
                t = this.getJSONFromStorage();
                if (t && t.length) return !1
            }
            return !0
        },
        clear: function (t) {
            t = util.assign({}, this.defaults, t), this.saveCells([], t)
        },
        modifyCell: function (t, e, i) {
            return t.set("z", i), t.isLink() && e.link && t.set(e.link), e.translate && ({
                dx: i,
                dy: e
            } = e.translate, t.translate(isFinite(i) ? i : 0, isFinite(e) ? e : 0)), t.collection = null, t
        },
        saveCells: function (t, e = {}) {
            this.reset(t), e.useLocalStorage && window.localStorage && this.saveToLocalStorage()
        },
        saveToLocalStorage: function () {
            if (!window.localStorage) throw new Error("localStorage is not available");
            var t = this.LOCAL_STORAGE_KEY, e = this.toJSON();
            0 < e.length ? localStorage.setItem(t, JSON.stringify(e)) : localStorage.removeItem(t)
        },
        fetchCellsFromLocalStorage: function (t) {
            var e = this.getJSONFromStorage();
            return e ? (e = {cells: e}, (t = new dia$1.Graph([], {
                cellNamespace: t,
                ignoreLayers: !0
            })).fromJSON(e, {sort: !1, dry: !0}), t.getCells()) : []
        },
        updateFromStorage: function (t) {
            t = this.fetchCellsFromLocalStorage(t.layerCollection.cellNamespace);
            this.reset(t)
        },
        getJSONFromStorage: function () {
            return window.localStorage && JSON.parse(localStorage.getItem(this.LOCAL_STORAGE_KEY)) || null
        },
        getOriginPoint: function (t, e, i) {
            e = e.getCellsBBox(t);
            return e ? util.getRectPoint(e, i) : null
        }
    }), $$k = mvc.$, SelectBox = mvc.View.extend({
        className: "select-box",
        events: {"click .select-box-selection": "onToggle"},
        options: {
            options: [],
            width: void 0,
            openPolicy: "auto",
            target: null,
            keyboardNavigation: !0,
            selected: void 0,
            selectBoxOptionsClass: void 0,
            disabled: !1
        },
        init: function () {
            this.options.target = this.options.target || document.body, util.bindAll(this, "onOutsideClick", "onOptionSelect"), $$k(document).on("click.selectBox", this.onOutsideClick), $$k.data.set(this.el, "view", this), void 0 === this.options.selected ? this.selection = util.toArray(this.options.options).find(function (t) {
                return !0 === t.selected
            }) || this.options.options[0] : this.selection = this.options.options[this.options.selected]
        },
        render: function () {
            return this.$el.empty(), this.$selection = null, this.renderSelection(this.selection), this.options.width && this.$el.css("width", this.options.width), this.options.disabled && this.disable(), this.$el.append(this.$options), this
        },
        renderOptions: function () {
            this.removeOptions();
            var t = this.options, e = {
                    selectBoxView: this,
                    parentClassName: util.result(this, "className") || null,
                    extraClassName: util.result(t, "selectBoxOptionsClass") || null,
                    options: t.options
                },
                e = (t.width && (e.width = t.width), t.theme && (e.theme = t.theme), this.optionsView = new this.constructor.OptionsView(e));
            e.render(), this.listenTo(e, "option:select", this.onOptionSelect), this.listenTo(e, "option:hover", this.onOptionHover), this.listenTo(e, "options:mouseout", this.onOptionsMouseOut), this.$options = e.$el, this.$optionsArrow = e.$arrow, this.$target = $$k(t.target)
        },
        setOptions: function (t, e) {
            this.options.options = t;
            let i = this.getSelectionValue(this.selection);
            i || null == e || (i = t[e].value);
            var n = this.options.options || [];
            for (let t = 0; t < n.length; t++) {
                var o = n[t];
                if (void 0 === o.value && o.content === i) return this.select(t);
                if (void 0 !== o.value && util.isEqual(o.value, i)) return this.select(t)
            }
            this.selection = null, this.renderSelection(), this.trigger("option:select"), this.selectByValue(i, null)
        },
        onOptionHover: function (t, e) {
            this.trigger("option:hover", t, e)
        },
        onOptionsMouseOut: function (t) {
            this.trigger("options:mouseout", t)
        },
        onOptionSelect: function (t, e) {
            this.select(t, e)
        },
        removeOptions: function () {
            this.optionsView && (this.stopListening(this.optionsView), this.optionsView.remove(), this.optionsView = null)
        },
        renderSelection: function (t) {
            this.$selection || (this.$selection = $$k("<div/>").addClass("select-box-selection"), this.$el.append(this.$selection)), this.$selection.empty(), t ? (t = this.constructor.OptionsView.prototype.renderOptionContent.call(void 0, t), this.$selection.append(t)) : this.options.placeholder && (t = $$k("<div/>").addClass("select-box-placeholder").html(this.options.placeholder), this.$selection.append(t))
        },
        onToggle: function (t) {
            this.toggle()
        },
        onOutsideClick: function (t) {
            !this.el.contains(t.target) && this.$el.hasClass("opened") && this.close()
        },
        getSelection: function () {
            return this.selection
        },
        getSelectionValue: function (t) {
            return (t = t || this.selection) && (void 0 === t.value ? t.content : t.value)
        },
        getSelectionIndex: function () {
            return util.toArray(this.options.options).findIndex(function (t) {
                return t === this.selection
            }.bind(this))
        },
        select: function (t, e = {}) {
            this.selection = this.options.options[t], this.renderSelection(this.selection), this.trigger("option:select", this.selection, t, e), this.close()
        },
        selectByValue: function (t, e) {
            for (var i = this.options.options || [], n = 0; n < i.length; n++) {
                var o = i[n];
                if (void 0 === o.value && o.content === t) return this.select(n, e);
                if (void 0 !== o.value && util.isEqual(o.value, t)) return this.select(n, e)
            }
        },
        isOpen: function () {
            return this.$el.hasClass("opened")
        },
        toggle: function () {
            this.isOpen() ? this.close() : this.open()
        },
        position: function () {
            var t = this.$(".select-box-selection"), e = t.outerHeight(), t = t.offset(), i = t.left, n = t.top,
                o = this.$options.outerHeight(), s = {left: 0, top: 0},
                t = (this.options.target !== document.body ? ((s = this.$target.offset()).width = this.$target.outerWidth(), s.height = this.$target.outerHeight(), s.left -= this.$target.scrollLeft(), s.top -= this.$target.scrollTop()) : (s.width = $$k(window).width(), s.height = $$k(window).height()), i),
                r = "auto", i = this.options.openPolicy;
            switch (i = "selected" !== i || this.selection ? i : "auto") {
                case"above":
                    r = n - o;
                    break;
                case"coverAbove":
                    r = n - o + e;
                    break;
                case"below":
                    r = n + e;
                    break;
                case"coverBelow":
                    r = n;
                    break;
                case"selected":
                    r = n - this.$options.find(".selected").position().top;
                    break;
                default:
                    r = n - this.$target.scrollTop() + o > s.top + s.height ? n - o + e : n
            }
            t -= s.left, r -= s.top, this.$options.css({left: t, top: r})
        },
        open: function () {
            this.isDisabled() || (this.renderOptions(), this.$options.appendTo(this.options.target), this.$options.addClass("rendered"), this.position(), this.$el.addClass("opened"), this.respectWindowBoundaries(), this.alignOptionsArrow())
        },
        respectWindowBoundaries: function () {
            var t = this.calculateElOverflow(this.$options, this.$target), e = {left: 0, top: 0},
                t = (this.$options.outerWidth() <= this.$target.innerWidth() && (t.left && t.right || (t.left ? e.left = t.left : t.right && (e.left = -t.right))), this.$options.outerHeight() <= this.$target.innerHeight() && (t.top && t.bottom || (t.top ? e.top = t.top : t.bottom && (e.top = -t.bottom))), parseFloat(this.$options.css("left")) || 0),
                i = parseFloat(this.$options.css("top")) || 0;
            this.$options.css({left: t + e.left, top: i + e.top})
        },
        alignOptionsArrow: function () {
            var t = this.$el[0].getBoundingClientRect(), e = this.$options[0].getBoundingClientRect(),
                t = t.left + t.width / 2, t = (t -= e.left) - this.$optionsArrow.outerWidth() / 2;
            this.$optionsArrow.css({left: t})
        },
        close: function () {
            this.removeOptions(), this.$el.removeClass("opened"), this.trigger("close")
        },
        onRemove: function () {
            this.removeOptions(), $$k(document).off(".selectBox", this.onOutsideClick)
        },
        isDisabled: function () {
            return this.$el.hasClass("disabled")
        },
        enable: function () {
            this.$el.removeClass("disabled")
        },
        disable: function () {
            this.close(), this.$el.addClass("disabled")
        },
        onSetTheme: function (t, e) {
            this.$options && (t && this.$options.removeClass(this.themeClassNamePrefix + t), this.$options.addClass(this.themeClassNamePrefix + e))
        },
        calculateElOverflow: function (t, e) {
            e = e || window, t instanceof $$k && (t = t[0]), e instanceof $$k && (e = e[0]);
            var i, n, o = {}, s = t.getBoundingClientRect();
            return n = e === window ? {
                width: t = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth,
                height: i = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight,
                left: 0,
                top: 0,
                right: t,
                bottom: i
            } : e.getBoundingClientRect(), ["left", "top"].forEach(function (t) {
                o[t] = Math.min(0, s[t] - n[t])
            }), ["right", "bottom"].forEach(function (t) {
                o[t] = Math.min(0, n[t] - s[t])
            }), util.forIn(o, function (t, e) {
                o[e] = Math.abs(Math.round(t))
            }), o
        }
    }, {
        OptionsView: mvc.View.extend({
            events: {"mouseover .select-box-option": "onOptionHover", "click .select-box-option": "onOptionClick"},
            className: function () {
                var t = ["select-box-options"], e = this.options.parentClassName;
                return e && t.push(e), t.join(" ")
            },
            init: function () {
                util.bindAll(this, "onMouseout", "onKeydown"), $$k(document).on({
                    "keydown.selectBoxOptions": this.onKeydown,
                    "mouseleave.selectBoxOptions mouseout.selectBoxOptions": this.onMouseout
                })
            },
            render: function () {
                var t = this.options.extraClassName;
                return t && this.$el.addClass(t), this.options.width && this.$el.css("width", this.options.width), util.toArray(this.options.options).forEach(function (t, e) {
                    e = this.renderOption(t, e);
                    this.options.selectBoxView.selection === t && e.addClass("selected hover"), this.$el.append(e)
                }, this), this.$arrow = $$k("<div/>").addClass("select-box-options-arrow").appendTo(this.$el), this
            },
            renderOption: function (t, e) {
                t = this.renderOptionContent(t);
                return t.addClass("select-box-option"), t.data("index", e), t
            },
            renderOptionContent: function (t) {
                var e = $$k("<div/>").addClass("select-box-option-content").html(t.content);
                return t.icon && e.prepend($$k("<img/>").addClass("select-box-option-icon").attr("src", t.icon)), e
            },
            select: function (t, e = {}) {
                this.trigger("option:select", t, e)
            },
            hover: function (t) {
                var e = this.options.options[t];
                this.markOptionHover(t), this.trigger("option:hover", e, t)
            },
            onOptionClick: function (t) {
                t = this.getOptionIndex(t.target);
                this.select(t, {ui: !0})
            },
            onOptionHover: function (t) {
                t = this.getOptionIndex(t.target);
                this.hover(t)
            },
            onMouseout: function (t) {
                this.trigger("options:mouseout", t)
            },
            onKeydown: function (t) {
                var e, i = this.options.selectBoxView;
                if (i.options.keyboardNavigation && i.isOpen()) {
                    switch (t.which) {
                        case 39:
                        case 40:
                            e = 1;
                            break;
                        case 38:
                        case 37:
                            e = -1;
                            break;
                        case 13:
                            var n = this.getOptionHoverIndex();
                            return void (0 <= n && this.select(n));
                        case 27:
                            return i.close();
                        default:
                            return
                    }
                    t.preventDefault();
                    var t = this.getOptionHoverIndex() + e, o = this.options.options;
                    (t = t < 0 ? o.length - 1 : t) >= o.length && (t = 0), this.hover(t)
                }
            },
            onRemove: function () {
                $$k(document).off(".selectBoxOptions")
            },
            markOptionHover: function (t) {
                this.$el.find(".hover").removeClass("hover"), $$k(this.$el.find(".select-box-option")[t]).addClass("hover")
            },
            getOptionHoverIndex: function () {
                var t = this.el.querySelector(".select-box-option.hover");
                return Array.prototype.indexOf.call(t.parentNode.children, t)
            },
            getOptionIndex: function (t) {
                return Number(t.closest(".select-box-option").dataset.index)
            }
        })
    }), $$j = mvc.$, ColorPalette = SelectBox.extend({
        className: "select-box color-palette", position: function () {
            var t = this.$(".select-box-selection"), e = t.outerHeight(), t = t.offset(), i = t.left, t = t.top + e;
            this.options.target !== document.body && (this.$target = this.$target || $$j(this.options.target), i -= (e = this.$target.offset()).left - this.$target.scrollLeft(), t -= e.top - this.$target.scrollTop()), this.$options.css({
                left: i,
                top: t
            })
        }
    }, {
        OptionsView: SelectBox.OptionsView.extend({
            renderOptionContent: function (t) {
                var e = $$j("<div/>").addClass("select-box-option-content");
                return e.css("background-color", t.content), t.icon && e.prepend($$j("<img/>").addClass("select-box-option-icon").attr("src", t.icon)), e
            }
        })
    }), $$i = mvc.$, ContextToolbar = mvc.View.extend({
        className: "context-toolbar",
        eventNamespace: "context-toolbar",
        events: {"click .tool": "onToolPointerdown", "touchstart .tool": "onToolPointerdown"},
        options: {padding: 20, autoClose: !0, vertical: !1, anchor: "top", position: "bottom", scale: 1},
        documentEvents: {mousedown: "onDocumentPointerdown", touchstart: "onDocumentPointerdown"},
        init: function () {
            util.bindAll(this, "onDocumentPointerdown")
        },
        render: function () {
            var t = this.options, e = this.constructor;
            return e.opened && e.close(), t.autoClose && setTimeout(this.delegateAutoCloseEvents.bind(this), 0), t.type && (this.el.dataset.type = t.type), this.beforeMount(), this.getRoot().append(this.el), this.renderContent(), this.position(), this.scale(), e.opened = this
        },
        delegateAutoCloseEvents: function () {
            this.delegateDocumentEvents(), document.addEventListener("mousedown", this.onDocumentPointerdown, !0), document.addEventListener("touchstart", this.onDocumentPointerdown, !0)
        },
        undelegateAutoCloseEvents: function () {
            this.undelegateDocumentEvents(), document.removeEventListener("mousedown", this.onDocumentPointerdown, !0), document.removeEventListener("touchstart", this.onDocumentPointerdown, !0)
        },
        beforeMount: function () {
            this.$el.toggleClass("joint-vertical", !!this.options.vertical)
        },
        renderContent: function () {
            let i = $$i("<div/>").addClass("tools");
            this.options.tools && util.toArray(this.options.tools).forEach(function (t) {
                var e = t.icon ? $$i("<img/>").prop("src", t.icon) : t.content,
                    e = $$i("<button/>").addClass("tool").html(e).data("action", t.action);
                t.attrs && e.attr(t.attrs), i.append(e)
            }), this.$el.append(i)
        },
        getRoot: function () {
            return $$i(this.options.root || document.documentElement)[0]
        },
        position: function () {
            var {target: t, padding: e, position: i, anchor: n} = this.options, o = this.$el, s = {x: 0, y: 0},
                i = (void 0 !== V.toNode(t) ? (r = util.getElementBBox(t), r = util.getRectPoint(r, i), s.x = r.x, s.y = r.y, r = util.getRectPoint((new g.Rect).inflate(e), i), s.x += r.x, s.y += r.y) : (e = new g.Point(t), s.x = e.x, s.y = e.y), o.outerWidth()),
                r = o.outerHeight(), t = util.getRectPoint(new g.Rect(0, 0, i, r), n),
                e = (s.x -= t.x, s.y -= t.y, util.getElementBBox(this.getRoot()));
            s.x -= e.x, s.y -= e.y, o.css({left: s.x, top: s.y})
        },
        scale() {
            var {scale: t, anchor: e} = this.options;
            t && (this.el.style.transform = `scale(${t}, ${t})`, "corner" === (t = util.toKebabCase(e).split("-"))[0] && (t[0] = "bottom", t[1] = "right"), "origin" === t[0] && (t[0] = "top", t[1] = "left"), "middle" === t[1] && (t[1] = null), this.el.style.transformOrigin = t[0] + " " + (t[1] || ""))
        },
        onRemove: function () {
            this.undelegateAutoCloseEvents(), this.constructor.opened = void 0
        },
        onToolPointerdown: function (t) {
            var e = t.currentTarget.dataset.action;
            e && this.trigger("action:" + e, t)
        },
        onDocumentPointerdown: function (t) {
            var {el: e, options: i} = this, i = i.target, t = t.target;
            void 0 !== V.toNode(i) && (!i || i.contains(t)) || e.contains(t) || (this.constructor.close(), this.remove())
        }
    }, {
        opened: void 0, close: function () {
            var t = this.opened;
            t && (t.trigger("close"), t.remove(), this.opened = null)
        }, update: function () {
            this.opened && this.opened.position()
        }
    }), $$h = mvc.$, Dialog = mvc.View.extend({
        className: "dialog",
        events: {
            "click .bg": "action",
            "click .btn-close": "action",
            "click .controls button": "action",
            "mousedown .titlebar": "onDragStart",
            "touchstart .titlebar": "onDragStart"
        },
        options: {
            draggable: !1,
            closeButtonContent: "&times;",
            closeButton: !0,
            inlined: !1,
            modal: !0,
            width: 0,
            title: "",
            buttons: null,
            type: "",
            content: null
        },
        init: function () {
            util.bindAll(this, "onDrag", "onDragEnd"), this.buttons = this.options.buttons
        },
        render: function () {
            var i, n, o, t = $$h("<div/>").addClass("bg").data("action", "close"), e = $$h("<div/>").addClass("fg"),
                s = $$h("<div/>").addClass("titlebar"), r = $$h("<div/>").addClass("body"),
                a = $$h("<button/>").addClass("btn-close").html(this.options.closeButtonContent).data("action", "close"),
                l = $$h("<div/>").addClass("controls");
            return this.$el.toggleClass("draggable", !!this.options.draggable), this.options.type && (this.el.dataset.type = this.options.type), this.options.inlined && this.$el.addClass("inlined"), this.options.modal && this.$el.addClass("modal"), this.options.width && e.css("width", this.options.width), this.options.title ? s.append(this.options.title) : s.addClass("empty"), this.options.content && r.append(this.options.content), this.buttons && (i = [], n = [], o = [], this.buttons.forEach(function (t) {
                var e = $$h("<button/>").addClass("control-button").html(t.content).data("action", t.action);
                (t.position ? "left" === t.position ? (e.addClass(t.position), o) : "center" === t.position ? (e.addClass(t.position), n) : (e.addClass(t.position), i) : i).push(e)
            }), i.reverse(), i.forEach(function (t) {
                l.append(t)
            }), o.forEach(function (t) {
                l.append(t)
            }), n.forEach(function (t) {
                l.append(t)
            })), e.append(s, r, l), this.options.closeButton && e.append(a), this.$el.empty().append(t, e), this
        },
        open: function (t) {
            return this.delegateEvents(), this.on("action:close", this.close, this), $$h(t || document.body).append(this.render().el), this.$el.addClass("rendered"), this
        },
        close: function () {
            return this.remove(), this.trigger("close"), this
        },
        action: function (t) {
            t = t.target.closest("[data-action]").dataset.action;
            t && this.trigger("action:" + t)
        },
        onDragStart: function (t) {
            var e;
            this.options.draggable && (t.preventDefault(), t = util.normalizeEvent(t), e = this.$el.find(".fg").offset(), this.delegateDocumentEvents({
                mousemove: this.onDrag,
                touchmove: this.onDrag,
                mouseup: this.onDragEnd,
                touchend: this.onDragEnd
            }, {dx: t.clientX - e.left, dy: t.clientY - e.top}))
        },
        onDrag: function (t) {
            var e = (t = util.normalizeEvent(t)).data;
            this.$(".fg").offset({top: t.clientY - e.dy, left: t.clientX - e.dx})
        },
        onDragEnd: function () {
            this.undelegateDocumentEvents()
        }
    }), FlashMessage = Dialog.extend({
        className: Dialog.prototype.className + " flash-message",
        options: util.merge({}, Dialog.prototype.options, {
            closeButton: !0,
            modal: !1,
            cascade: !0,
            closeAnimation: {delay: 2e3, duration: 200, easing: "ease-in-out", properties: {opacity: 0}},
            openAnimation: {duration: 200, easing: "ease-in-out", properties: {opacity: 1}}
        }),
        init: function () {
            util.bindAll(this, "startCloseAnimation"), Dialog.prototype.init.apply(this, arguments), this.on("close:animation:complete", this.close, this)
        },
        open: function () {
            Dialog.prototype.open.apply(this, arguments);
            var t = this.$(".fg");
            return this._foregroundHeight = t.height(), this.addToCascade(), t.css("height", 0), this.startOpenAnimation(), this.options.closeAnimation && this.options.closeAnimation.delay && setTimeout(this.startCloseAnimation, this.options.closeAnimation.delay), this
        },
        close: function () {
            return Dialog.prototype.close.apply(this, arguments), this.removeFromCascade(), this
        },
        addToCascade: function () {
            var t;
            this.options.cascade && (t = this.constructor.top, this.$(".fg").css("top", t), this.constructor.top += this._foregroundHeight + this.constructor.padding), this.constructor.opened.push(this)
        },
        removeFromCascade: function () {
            if (this.options.cascade) {
                for (var t = this.constructor.opened, e = !1, i = 0; i < t.length; i++) {
                    var n, o = t[i];
                    o.options.cascade && e && (n = parseInt(o.$(".fg").css("top"), 10), o.$(".fg").css("top", n - this._foregroundHeight - this.constructor.padding)), o === this && (e = !0)
                }
                e && (this.constructor.top -= this._foregroundHeight + this.constructor.padding)
            }
            this.constructor.opened = util.without(this.constructor.opened, this)
        },
        startCloseAnimation: function () {
            var t = this.options.closeAnimation, e = t.properties;
            this.$(".fg").animate(e, util.assign({complete: () => this.trigger("close:animation:complete")}, util.omit(t, "delay")))
        },
        startOpenAnimation: function () {
            var t = this.options.openAnimation, e = util.assign({}, t.properties, {height: this._foregroundHeight});
            this.$(".fg").animate(e, util.assign({complete: () => this.trigger("open:animation:complete")}, t))
        }
    }, {
        top: 20, padding: 15, opened: [], open: function (t, e, i) {
            return i = i || {}, new FlashMessage(util.assign({title: e, type: "info", content: t}, i)).open(i.target)
        }, close: function () {
            util.invoke(this.opened, "close")
        }
    }), HaloType = {Surrounding: "surrounding", Overlay: "overlay", Toolbar: "toolbar", Pie: "pie"},
    HandlePosition$2 = {N: "n", NW: "nw", W: "w", SW: "sw", S: "s", SE: "se", E: "e", NE: "ne"}, DefaultAction = {
        Remove: "remove",
        Resize: "resize",
        Rotate: "rotate",
        Clone: "clone",
        Fork: "fork",
        Link: "link",
        Unlink: "unlink",
        Direction: "direction"
    }, defaultHandles$1 = {
        [DefaultAction.Remove]: {position: HandlePosition$2.NW, events: {pointerdown: "removeElement"}, icon: null},
        [DefaultAction.Resize]: {
            position: HandlePosition$2.SE,
            events: {pointerdown: "startResizing", pointermove: "doResize", pointerup: "stopResizing"},
            icon: null
        },
        [DefaultAction.Rotate]: {
            position: HandlePosition$2.SW,
            events: {pointerdown: "startRotating", pointermove: "doRotate", pointerup: "stopRotating"},
            icon: null
        },
        [DefaultAction.Clone]: {
            position: HandlePosition$2.N,
            events: {pointerdown: "startCloning", pointermove: "doClone", pointerup: "stopCloning"},
            icon: null
        },
        [DefaultAction.Fork]: {
            position: HandlePosition$2.NE,
            events: {pointerdown: "startForking", pointermove: "doFork", pointerup: "stopForking"},
            icon: null
        },
        [DefaultAction.Link]: {
            position: HandlePosition$2.E,
            events: {pointerdown: "startLinking", pointermove: "doLink", pointerup: "stopLinking"},
            icon: null
        },
        [DefaultAction.Unlink]: {position: HandlePosition$2.W, events: {pointerdown: "unlinkElement"}, icon: null},
        [DefaultAction.Direction]: {position: HandlePosition$2.SE, events: {pointerdown: "directionSwap"}, icon: null}
    }, TrackDirection = {Column: "column", Row: "row"}, VerticalAlign = {Top: "top", Middle: "middle", Bottom: "bottom"},
    HorizontalAlign = {Left: "left", Middle: "middle", Right: "right"}, gap = "4px", trackCount = 3,
    offsetVar = "--jj-halo-group-offset", sideTop = `calc(-1 * var(${offsetVar}, 0))`,
    sideBottom = `calc(100% + var(${offsetVar}, 0))`, sideLeft = `calc(-1 * var(${offsetVar}, 0))`,
    sideRight = `calc(100% + var(${offsetVar}, 0))`, sideCenter = "50%", defaultGroups = {
        [HandlePosition$2.S]: {
            top: sideBottom,
            left: sideCenter,
            trackDirection: TrackDirection.Column,
            trackCount: trackCount,
            gap: gap,
            verticalAlign: VerticalAlign.Top,
            horizontalAlign: HorizontalAlign.Middle
        },
        [HandlePosition$2.N]: {
            top: sideTop,
            left: sideCenter,
            trackDirection: TrackDirection.Column,
            trackCount: trackCount,
            gap: gap,
            verticalAlign: VerticalAlign.Bottom,
            horizontalAlign: HorizontalAlign.Middle
        },
        [HandlePosition$2.E]: {
            top: sideCenter,
            left: sideRight,
            trackDirection: TrackDirection.Row,
            trackCount: trackCount,
            gap: gap,
            verticalAlign: VerticalAlign.Middle,
            horizontalAlign: HorizontalAlign.Left
        },
        [HandlePosition$2.W]: {
            top: sideCenter,
            left: sideLeft,
            trackDirection: TrackDirection.Row,
            trackCount: trackCount,
            gap: gap,
            verticalAlign: VerticalAlign.Middle,
            horizontalAlign: HorizontalAlign.Right
        },
        [HandlePosition$2.NE]: {
            top: sideTop,
            left: sideRight,
            trackDirection: TrackDirection.Column,
            trackCount: trackCount,
            gap: gap,
            verticalAlign: VerticalAlign.Bottom,
            horizontalAlign: HorizontalAlign.Left
        },
        [HandlePosition$2.NW]: {
            top: sideTop,
            left: sideLeft,
            trackDirection: TrackDirection.Column,
            trackCount: trackCount,
            gap: gap,
            verticalAlign: VerticalAlign.Bottom,
            horizontalAlign: HorizontalAlign.Right
        },
        [HandlePosition$2.SE]: {
            top: sideBottom,
            left: sideRight,
            trackDirection: TrackDirection.Column,
            trackCount: trackCount,
            gap: gap,
            verticalAlign: VerticalAlign.Top,
            horizontalAlign: HorizontalAlign.Left
        },
        [HandlePosition$2.SW]: {
            top: sideBottom,
            left: sideLeft,
            trackDirection: TrackDirection.Column,
            trackCount: trackCount,
            gap: gap,
            verticalAlign: VerticalAlign.Top,
            horizontalAlign: HorizontalAlign.Right
        }
    }, $$g = mvc.$;

function getDefaultHandle$1(t) {
    var e = defaultHandles$1[t];
    if (e) return {...util.cloneDeep(e), defaultAction: t, name: t};
    throw new Error("ui.Halo: default handle not found: " + t)
}

var LinkHalo = function () {
    this.options = {
        handles: [DefaultAction.Remove, DefaultAction.Direction].map(getDefaultHandle$1),
        bbox: function (t) {
            var e = t.paper;
            return e.localToPaperPoint(t.getPointAtRatio(.5))
        },
        typeCssName: "type-link",
        tinyThreshold: -1,
        smallThreshold: -1,
        boxContent: !1
    }
}, ElementHalo = (LinkHalo.prototype.directionSwap = function () {
    var t = this.options.cellView.model;
    t.set({source: t.target(), target: t.source(), vertices: t.vertices().reverse()}, {halo: this.cid})
}, function () {
    this.options = {
        handles: [DefaultAction.Remove, DefaultAction.Resize, DefaultAction.Clone, DefaultAction.Link, DefaultAction.Fork, DefaultAction.Unlink, DefaultAction.Rotate].map(getDefaultHandle$1),
        bbox: function (t, e) {
            return t.getBBox({useModelGeometry: e.options.useModelGeometry})
        },
        typeCssName: "type-element",
        tinyThreshold: 40,
        smallThreshold: 80,
        boxContent: function (t, e) {
            var i = util.template("x: <%= x %>, y: <%= y %>, width: <%= width %>, height: <%= height %>, angle: <%= angle %>"),
                t = t.model, n = t.getBBox();
            return i({
                x: Math.floor(n.x),
                y: Math.floor(n.y),
                width: Math.floor(n.width),
                height: Math.floor(n.height),
                angle: Math.floor(t.get("angle") || 0)
            })
        },
        magnet: function (t) {
            return t.el
        },
        makeLink: null,
        makeElement: null,
        loopLinkPreferredSide: "top",
        loopLinkWidth: 40,
        rotateAngleGrid: 15,
        rotateEmbeds: !1,
        linkAttributes: {},
        smoothLinks: void 0
    }
});
ElementHalo.prototype.startLinking = function (t) {
    this.startBatch();
    var e = this.options, i = e.paper, e = e.graph,
        t = this.makeLink(t, {defaultAction: DefaultAction.Link, targetView: null});
    t.addTo(e, {
        validation: !1,
        halo: this.cid,
        async: !1
    }), i.undelegateEvents(), (this._linkView = t.findView(i)).startArrowheadMove("target", {whenNotAllowed: "remove"})
}, ElementHalo.prototype.startForking = function (t, e, i) {
    var n = this.options, o = n.paper,
        n = n.graph, [s, ...r] = (this.startBatch(), this.makeElement(t, {defaultAction: DefaultAction.Fork})),
        r = [s, ...util.sortBy(r, t => t.isLink())],
        r = (n.addCells(r, {halo: this.cid, async: !1}), this.centerElementAtCursor(s, e, i), s.findView(o));
    this.makeLink(t, {defaultAction: DefaultAction.Fork, targetView: r}).addTo(n, {
        halo: this.cid,
        async: !1
    }), r.eventData(t, {
        initialParentId: "halo-initial-parent-id",
        whenNotAllowed: "remove"
    }), r.pointerdown(t, e, i), o.options.embeddingMode && r.drag(t, e, i), this.eventData(t, {cloneView: r})
}, ElementHalo.prototype.getElementMagnet = function (t, e, i) {
    var n = this.options.magnet;
    if (util.isFunction(n)) {
        n = n.call(this, t, e, i);
        if (n instanceof SVGElement) return n
    }
    throw new Error("ui.Halo: magnet() has to return an SVGElement.")
}, ElementHalo.prototype.getLinkEnd = function (t, e, i) {
    var n, o = {id: t.model.id};
    return e !== t.el && ((n = t.findAttribute("port", e)) ? o.port = n : o.selector = t.getSelector(e)), o
}, ElementHalo.prototype.makeLink = function (t, e = {}) {
    var i, n = this.options, {paper: o, cellView: s, makeLink: r} = n, {
        action: e = this._action,
        defaultAction: a = null,
        targetView: l
    } = e, h = this.getElementMagnet(s, "source", t), c = this.getLinkEnd(s, h, t);
    let d = null, u = null;
    d = l ? (u = this.getElementMagnet(l, "target", t), this.getLinkEnd(l, u, t)) : ({
        x: g,
        y: i
    } = o.snapToGrid({x: t.clientX, y: t.clientY}), {x: g, y: i});
    let p;
    if (util.isFunction(r)) {
        var g = {
            action: e,
            defaultAction: a,
            source: c,
            sourceMagnet: h,
            sourceView: s,
            target: d,
            targetMagnet: u,
            targetView: l
        };
        if (this.extendWithHandleData(e, g), !((p = r.call(this, g, t, this)) instanceof dia$1.Link)) throw new Error("ui.Halo: makeLink() has to return a dia.Link.")
    } else p = o.getDefaultLink(s, h);
    return p.set({
        source: c,
        target: d
    }), n.linkAttributes && p.attr(n.linkAttributes), util.isBoolean(n.smoothLinks) && p.connector("smooth"), p
}, ElementHalo.prototype.startResizing = function (t) {
    this.startBatch(), this._flip = [1, 0, 0, 1, 1, 0, 0, 1][Math.floor(g.normalizeAngle(this.options.cellView.model.get("angle")) / 45)]
}, ElementHalo.prototype.startRotating = function (t, e, i) {
    this.startBatch();
    var n = this.options.cellView.model, o = n.getCenter(), s = [n];
    this.options.rotateEmbeds && n.getEmbeddedCells({deep: !0}).reduce(function (t, e) {
        return e.isElement() && t.push(e), t
    }, s), this.eventData(t, {
        center: o, elements: s, rotationStartAngles: s.map(function (t) {
            return t.angle()
        }), clientStartAngle: new g.Point(e, i).theta(o)
    })
}, ElementHalo.prototype.doResize = function (t, e, i, n, o) {
    var s = this.options.cellView.model.get("size"), r = Math.max(s.width + (this._flip ? n : o), 1),
        s = Math.max(s.height + (this._flip ? o : n), 1);
    this.options.cellView.model.resize(r, s, {absolute: !0, halo: this.cid})
}, ElementHalo.prototype.doRotate = function (t, e, i) {
    var n = this.eventData(t), o = n.clientStartAngle - new g.Point(e, i).theta(n.center);
    n.elements.forEach(function (t, e) {
        e = n.rotationStartAngles[e], e = g.snapToGrid(e + o, this.options.rotateAngleGrid);
        t.rotate(e, !0, n.center, {halo: this.cid})
    }, this)
}, ElementHalo.prototype.doClone = function (t, e, i) {
    var n = this.eventData(t).cloneView;
    n && n.pointermove(t, e, i)
}, ElementHalo.prototype.startCloning = function (t, e, i) {
    var n = this.options, n = n.paper,
        o = n.model, [s, ...r] = (this.startBatch(), this.makeElement(t, {defaultAction: DefaultAction.Clone})),
        r = [s, ...util.sortBy(r, t => t.isLink())],
        o = (o.addCells(r, {halo: this.cid, async: !1}), this.centerElementAtCursor(s, e, i), s.findView(n));
    o.eventData(t, {
        initialParentId: "halo-initial-parent-id",
        whenNotAllowed: "remove"
    }), o.pointerdown(t, e, i), n.options.embeddingMode && o.drag(t, e, i), this.eventData(t, {cloneView: o})
}, ElementHalo.prototype.centerElementAtCursor = function (t, e, i) {
    var n = t.getCenter(), e = e - n.x;
    t.translate(e, i - n.y, {deep: !0, halo: this.cid})
}, ElementHalo.prototype.doFork = function (t, e, i) {
    var n = this.eventData(t).cloneView;
    n && n.pointermove(t, e, i)
}, ElementHalo.prototype.doLink = function (t, e, i) {
    this._linkView && this._linkView.pointermove(t, e, i)
}, ElementHalo.prototype.stopLinking = function (t, e, i) {
    var n = this._linkView;
    n && (n.pointerup(t, e, i), (t = n.model).hasLoop() && this.makeLoopLink(t), this.triggerAction(this._action, "add", t), this.stopBatch(), this._linkView = null), this.options.paper.delegateEvents()
}, ElementHalo.prototype.stopForking = function (t, e, i) {
    var n = this.eventData(t).cloneView;
    n && n.pointerup(t, e, i), this.stopBatch()
}, ElementHalo.prototype.stopCloning = function (t, e, i) {
    var n = this.eventData(t).cloneView;
    n && n.pointerup(t, e, i), this.stopBatch()
}, ElementHalo.prototype.stopResizing = function () {
    this.stopBatch()
}, ElementHalo.prototype.stopRotating = function () {
    this.stopBatch()
}, ElementHalo.prototype.unlinkElement = function (t) {
    this.startBatch(), this.options.graph.removeLinks(this.options.cellView.model), this.stopBatch()
}, ElementHalo.prototype.makeLoopLink = function (t) {
    let {loopLinkPreferredSide: e, loopLinkWidth: o, paper: i} = this.options;
    var {width: n, height: s} = i.getComputedSize();
    let r = new g.Rect({x: 0, y: 0, width: n, height: s}), a = i.paperToLocalRect(this.options.cellView.getBBox()), l,
        h;
    util.uniq([e, "top", "bottom", "left", "right"]).find(function (t) {
        let e, i = 0, n = 0;
        switch (t) {
            case"top":
                e = new g.Point(a.x + a.width / 2, a.y - o), i = o / 2;
                break;
            case"bottom":
                e = new g.Point(a.x + a.width / 2, a.y + a.height + o), i = o / 2;
                break;
            case"left":
                e = new g.Point(a.x - o, a.y + a.height / 2), n = o / 2;
                break;
            case"right":
                e = new g.Point(a.x + a.width + o, a.y + a.height / 2), n = o / 2
        }
        return l = e.clone().offset(-i, -n), h = e.clone().offset(i, n), r.containsPoint(l) && r.containsPoint(h)
    }, this) && t.set("vertices", [l, h], {halo: this.cid})
};
let Halo = mvc.View.extend({
    PIE_INNER_RADIUS: 20,
    PIE_OUTER_RADIUS: 50,
    DETACHABLE: !1,
    className: "halo",
    events: {
        "mousedown .handle": "onHandlePointerDown",
        "touchstart .handle": "onHandlePointerDown",
        "mousedown .pie-toggle": "onPieTogglePointerDown",
        "touchstart .pie-toggle": "onPieTogglePointerDown",
        wheel: "onMousewheel",
        mousewheel: "onMousewheel"
    },
    documentEvents: {mousemove: "pointermove", touchmove: "pointermove", mouseup: "pointerup", touchend: "pointerup"},
    options: {
        clearAll: !0,
        clearOnBlankPointerdown: !0,
        useModelGeometry: !1,
        clone: function (t, e) {
            return t.clone().unset("z")
        },
        type: "surrounding",
        pieSliceAngle: 45,
        pieStartAngleOffset: 0,
        pieIconSize: 14,
        pieToggles: [{name: "default", position: "e"}]
    },
    init: function () {
        var t = this.options, e = t.cellView, i = e.model, n = new (i.isLink() ? LinkHalo : ElementHalo),
            e = (util.assign(this, util.omit(n, "options")), e.paper), o = e.model;
        util.defaults(t, n.options, {
            paper: e,
            graph: o
        }), util.bindAll(this, "render", "update"), t.clearAll && this.constructor.clear(e), this.listenTo(o, "reset", this.close), this.listenTo(i, "remove", this.close), this.listenTo(e, "halo:create", this.close), t.clearOnBlankPointerdown && this.listenTo(e, "blank:pointerdown", this.close), this.listenTo(o, "all", () => this.requestUpdate()), this.listenTo(e, "transform", () => this.requestUpdate({async: !1})), this.groups = util.merge({}, defaultGroups, t.groups), this.handles = [], util.toArray(t.handles).forEach(this.addHandle, this)
    },
    renderHandles: function () {
        var t;
        this.options.type === HaloType.Overlay ? this.$handles.append(this.renderOverlayHandles(this.handles)) : (t = util.toArray(this.handles).map(t => this.renderHandle(t)), this.$handles.append(t))
    },
    renderOverlayGroup: function (t) {
        var e = this.getGroupConfig(t), i = document.createElement("div"),
            t = (i.dataset.groupName = t, i.className = "joint-handle-group", e.className && $$g(i).addClass(e.className), i.style.position = "absolute", i.style.top = e.top, i.style.left = e.left, "row" === e.trackDirection);
        i.style.display = "grid", i.style.gap = e.gap, i.style.gridAutoFlow = t ? "column" : "row", i.style[t ? "gridTemplateRows" : "gridTemplateColumns"] = `repeat(min(var(--jj-halo-group-size), ${e.trackCount}), 1fr)`;
        let n, o;
        switch (e.horizontalAlign) {
            case"left":
                n = "0";
                break;
            case"middle":
                n = "-50%";
                break;
            case"right":
                n = "-100%"
        }
        switch (e.verticalAlign) {
            case"top":
                o = "0";
                break;
            case"middle":
                o = "-50%";
                break;
            case"bottom":
                o = "-100%"
        }
        return i.style.transform = `translate(${n}, ${o})`, i
    },
    getGroupHandleNode: function (t) {
        return this.el.querySelector(`.joint-handle-group[data-group-name="${t}"]`)
    },
    getHandleNode: function (t) {
        return this.el.querySelector(`.handle[data-action="${t}"]`)
    },
    ensureOverlayGroup: function (t) {
        let e = this.getGroupHandleNode(t);
        var i;
        return e || (i = this.getGroupConfig(t), e = this.renderOverlayGroup(t, i), this.$handles.append(e)), e
    },
    renderOverlayGroupHandles: function (e, t) {
        let i = document.createDocumentFragment();
        return t.filter(t => t.position === e).forEach(t => {
            var [t] = this.renderHandle(t);
            i.appendChild(t)
        }), i
    },
    renderOverlayHandles: function (i) {
        return Object.keys(this.groups).map(t => {
            var e = this.renderOverlayGroup(t), t = this.renderOverlayGroupHandles(t, i);
            return e.appendChild(t), this.updateOverlayGroupSize(e), e
        })
    },
    updateOverlayGroupSize: function (t) {
        var e = t.querySelectorAll(".handle:not(.hidden)").length;
        t.style.setProperty("--jj-halo-group-size", e)
    },
    getGroupConfig: function (t) {
        var e = this.groups[t];
        if (e) return e;
        throw new Error("ui.Halo: unknown group " + t)
    },
    render: function () {
        var t = this.options;
        switch (this.$el.empty(), this.$handles = $$g("<div/>").addClass("handles").appendTo(this.el), this.$box = $$g("<label/>").addClass("box").appendTo(this.el), this.$pieToggles = {}, this.$el.addClass(t.type), this.$el.addClass(this.cellTypeCssClass()), this.el.dataset.type = t.cellView.model.get("type"), this.renderHandles(), t.type) {
            case HaloType.Overlay:
            case HaloType.Toolbar:
            case HaloType.Surrounding:
                this.toggleFork();
                break;
            case HaloType.Pie:
                util.toArray(this.options.pieToggles).forEach(function (t) {
                    var e = $$g("<div/>");
                    e.addClass("pie-toggle " + (t.position || "e")), e.data("name", t.name), util.setAttributesBySelector(e, t.attrs), e.appendTo(this.el), this.$pieToggles[t.name] = e
                }, this);
                break;
            default:
                throw new Error("ui.Halo: unknown type")
        }
        return this.update(), this.$el.addClass("animate").appendTo(t.paper.el), this.setPieIcons(), this
    },
    setPieIcons: function () {
        if ("pie" === this.options.type) {
            var e = this.$el.find(".handle");
            for (let t = 0; t < e.length; t++) {
                var i = e[t], n = $$g(i), o = i.dataset.action, o = this.getHandle(o);
                if (o && o.icon) return;
                var s, o = window.getComputedStyle(i, ":before").getPropertyValue("content"),
                    o = (o && "none" !== o && 0 < (s = n.find(".slice-text-icon")).length && V(s[0]).text(o.replace(/['"]/g, "")), window.getComputedStyle(i)),
                    i = o.backgroundImage;
                i && (o = i.match(/url\(['"]?([^'"]+)['"]?\)/)) && (i = o[1], 0 < (s = n.find(".slice-img-icon")).length) && V(s[0]).attr("xlink:href", i)
            }
        }
    },
    requestUpdate(t) {
        this.options.paper.requestViewUpdate(this, 1, this.UPDATE_PRIORITY, t)
    },
    confirmUpdate() {
        return this.update(), 0
    },
    update: function () {
        var t;
        this.isRendered() && (this.updateBoxContent(), t = this.getBBox(), this.$el.toggleClass("tiny", t.width < this.options.tinyThreshold && t.height < this.options.tinyThreshold), this.$el.toggleClass("small", !this.$el.hasClass("tiny") && t.width < this.options.smallThreshold && t.height < this.options.smallThreshold), this.$el.css({
            width: t.width,
            height: t.height,
            left: t.x,
            top: t.y
        }), this.toggleUnlink())
    },
    getBBox: function () {
        var t = this.options.cellView, e = this.options.bbox, t = util.isFunction(e) ? e(t, this) : e,
            t = util.defaults({}, t, {x: 0, y: 0, width: 1, height: 1});
        return g.rect(t)
    },
    cellTypeCssClass: function () {
        return this.options.typeCssName
    },
    updateBoxContent: function () {
        var t = this.options.boxContent, e = this.options.cellView;
        util.isFunction(t) ? (e = t.call(this, e, this.$box[0])) && this.$box.html(e) : t ? this.$box.html(t) : this.$box.remove()
    },
    extendHandles: function (t) {
        util.forIn(t, function (t) {
            var e = this.getHandle(t.name);
            e && util.assign(e, t)
        }.bind(this))
    },
    addHandles: function (t) {
        return util.toArray(t).forEach(this.addHandle, this), this
    },
    addHandle: function (i) {
        var t;
        return this.getHandle(i.name) || (this.handles.push(i), util.forIn(i.events, function (t, e) {
            util.isString(t) ? this.on("action:" + i.name + ":" + e, this[t], this) : this.on("action:" + i.name + ":" + e, t)
        }.bind(this)), this.$handles && (t = this.renderHandle(i), this.options.type === HaloType.Overlay ? t.appendTo(this.ensureOverlayGroup(i.position)) : t.appendTo(this.$handles))), this
    },
    renderHandle: function (t) {
        var e = this.getHandleIdx(t.name),
            i = $$g("<div/>").addClass("handle").addClass(t.name).data("action", t.name).prop("draggable", !1),
            n = this.options.type;
        switch (n === HaloType.Overlay && i.css("position", "relative"), t.className && i.addClass(t.className), n) {
            case HaloType.Overlay:
            case HaloType.Toolbar:
            case HaloType.Surrounding:
                n !== HaloType.Overlay && i.addClass(t.position), t.content && i.html(t.content);
                break;
            case HaloType.Pie:
                var o = this.PIE_OUTER_RADIUS, s = this.PIE_INNER_RADIUS, r = (o + s) / 2, a = g.point(o, o),
                    l = g.toRad(this.options.pieSliceAngle), h = e * l + g.toRad(this.options.pieStartAngleOffset),
                    s = V.createSlicePathData(s, o, h, h + l), c = V("svg").addClass("slice-svg"),
                    s = V("path").attr("d", s).translate(o, o).addClass("slice"),
                    o = g.point.fromPolar(r, -h - l / 2, a), r = this.options.pieIconSize,
                    h = V("image").attr(o).addClass("slice-img-icon"),
                    l = (o.y = o.y + r - 2, V("text", {"font-size": r}).attr(o).addClass("slice-text-icon"));
                h.attr({
                    width: r,
                    height: r
                }), h.translate(-r / 2, -r / 2), l.translate(-r / 2, -r / 2), c.append([s, h, l]), i.append(c.node)
        }
        return util.setAttributesBySelector(i, t.attrs), t.icon && this.setHandleIcon(i, t.icon), i
    },
    setHandleIcon: function (t, e) {
        switch (this.options.type) {
            case HaloType.Pie:
                var i = t.find(".slice-img-icon");
                V(i[0]).attr("xlink:href", e);
                break;
            case HaloType.Overlay:
            case HaloType.Toolbar:
            case HaloType.Surrounding:
                t.css("background-image", "url(" + e + ")")
        }
    },
    removeHandles: function () {
        for (; this.handles.length;) this.removeHandle(this.handles[0].name);
        return this
    },
    removeHandle: function (i) {
        var t = this.getHandleIdx(i), e = this.handles[t];
        return e && (util.forIn(e.events, function (t, e) {
            this.off("action:" + i + ":" + e)
        }.bind(this)), this.$(".handle." + i).remove(), this.handles.splice(t, 1)), this
    },
    changeHandle: function (t, e) {
        var i = this.getHandle(t);
        return i && (this.removeHandle(t), this.addHandle(util.merge({name: t}, i, e))), this
    },
    hasHandle: function (t) {
        return -1 !== this.getHandleIdx(t)
    },
    getHandleIdx: function (e) {
        return util.toArray(this.handles).findIndex(function (t) {
            return t.name === e
        })
    },
    getHandle: function (e) {
        return util.toArray(this.handles).find(function (t) {
            return t.name === e
        })
    },
    toggleHandle: function (t, e) {
        var i = this.getHandle(t);
        return i && (t = this.$(".handle." + t), void 0 === e && (e = !t.hasClass("selected")), t.toggleClass("selected", e), e = e ? i.iconSelected : i.icon) && this.setHandleIcon(t, e), this
    },
    selectHandle: function (t) {
        return this.toggleHandle(t, !0)
    },
    deselectHandle: function (t) {
        return this.toggleHandle(t, !1)
    },
    deselectAllHandles: function () {
        return util.toArray(this.handles).forEach(function (t) {
            this.deselectHandle(t.name)
        }, this), this
    },
    onHandlePointerDown: function (t) {
        var e, i, n, o = this._action = t.currentTarget.dataset.action;
        o && (t.preventDefault(), t.stopPropagation(), t = util.normalizeEvent(t), {
            x: e,
            y: i
        } = this.options.paper.snapToGrid({
            x: t.clientX,
            y: t.clientY
        }), this._localX = e, this._localY = i, this._evt = t, this.extendWithHandleData(o, t), "mousedown" === t.type && 2 === t.button ? this.triggerAction(o, "contextmenu", t, e, i) : ((n = this.getHandle(o)) && n.hideOnDrag && this.$handles.addClass("hidden"), this.triggerAction(o, "pointerdown", t, e, i), this.delegateDocumentEvents(null, t.data)))
    },
    extendWithHandleData: function (t, e) {
        e.data || (e.data = {});
        t = this.getHandle(t);
        t && Object.assign(e.data, t.data)
    },
    onPieTogglePointerDown: function (t) {
        t.stopPropagation();
        t = t.target.closest(".pie-toggle").dataset.name;
        this.isOpen(t) || this.isOpen() && this.toggleState(), this.toggleState(t)
    },
    onMousewheel: function (t) {
        t.preventDefault()
    },
    triggerAction: function (t, e, i) {
        var n = Array.prototype.slice.call(arguments, 2);
        n.unshift("action:" + t + ":" + e), this.trigger.apply(this, n)
    },
    stopBatch: function () {
        var t = this.options.graph;
        t.hasActiveBatch("halo") && t.stopBatch("halo", {halo: this.cid})
    },
    startBatch: function () {
        this.options.graph.startBatch("halo", {halo: this.cid})
    },
    pointermove: function (t) {
        var e, i, n;
        this._action && (t.preventDefault(), t.stopPropagation(), t = util.normalizeEvent(t), i = (e = this.options.paper.snapToGrid({
            x: t.clientX,
            y: t.clientY
        })).x - this._localX, n = e.y - this._localY, this._localX = e.x, this._localY = e.y, this._evt = t, this.triggerAction(this._action, "pointermove", t, e.x, e.y, i, n))
    },
    pointerup: function (t) {
        this.$handles.removeClass("hidden");
        var e, i = this._action;
        i && (this._evt = null, e = this.options.paper.snapToGrid({
            x: t.clientX,
            y: t.clientY
        }), this.triggerAction(i, "pointerup", t, e.x, e.y), this.undelegateDocumentEvents(), this._action = null)
    },
    onRemove: function () {
        this._action && this._evt && this.pointerup(this._evt), this.stopBatch()
    },
    close: function () {
        return this.closed || (this.closed = !0, this.remove(), this.trigger("close")), this
    },
    onSetTheme: function () {
        this.setPieIcons()
    },
    removeElement: function () {
        this.options.cellView.model.remove()
    },
    toggleUnlink: function () {
        var t = this.handles.filter(t => t.defaultAction === DefaultAction.Unlink);
        if (0 !== t.length) {
            let i = new Set, n = 0 < this.options.graph.getConnectedLinks(this.options.cellView.model).length;
            t.forEach(t => {
                var e = this.getHandleNode(t.name);
                e && (e.classList.toggle("hidden", !n), e = this.getGroupHandleNode(t.position)) && i.add(e)
            }), Array.from(i).forEach(t => this.updateOverlayGroupSize(t))
        }
    },
    toggleFork: function () {
        var t = this.handles.filter(t => t.defaultAction === DefaultAction.Fork);
        let n = new Set;
        t.forEach(t => {
            var e = this.canFork(t.name), i = this.getHandleNode(t.name);
            i && (i.classList.toggle("hidden", !e), i = this.getGroupHandleNode(t.position)) && n.add(i)
        }), Array.from(n).forEach(t => this.updateOverlayGroupSize(t))
    },
    canFork: function (t) {
        var {cellView: e, paper: i} = this.options, n = i.options.validateConnection;
        return "function" != typeof n || ([t] = this.makeElement(this.getSyntheticHandleEvent(DefaultAction.Fork), {
            validation: !0,
            action: t,
            defaultAction: DefaultAction.Fork
        }), t = i.createViewForModel(t), n = n.call(i, e, null, t, null, "target"), t.remove(), n)
    },
    cloneCell: function (t = {}) {
        var {cellView: e, clone: i} = this.options, i = i(e.model, t);
        return this.ensureCellArray(i, "clone")
    },
    makeElement: function (t, e = {}) {
        var {cellView: i, makeElement: n} = this.options, {
            action: e = this._action,
            defaultAction: o = null,
            validation: s = !1
        } = e;
        return util.isFunction(n) ? (this.extendWithHandleData(e, e = {
            action: e,
            defaultAction: o,
            validation: s,
            elementView: i
        }), i = n.call(this, e, t, this), this.ensureCellArray(i, "makeElement")) : (n = {
            clone: o === DefaultAction.Clone,
            fork: o === DefaultAction.Fork,
            validation: s
        }, this.cloneCell(n))
    },
    getSyntheticHandleEvent: function (t) {
        var e = new MouseEvent("mousedown", {
            view: window,
            bubbles: !0,
            cancelable: !0
        }), [t] = this.renderHandle(Halo.getDefaultHandle(t));
        return t.dispatchEvent(e), new mvc.Event(e)
    },
    ensureCellArray: function (t, e) {
        if (t instanceof dia$1.Cell) return [t];
        if (Array.isArray(t) && 0 < t.length && t.every(t => t instanceof dia$1.Cell)) return t;
        throw new Error(`ui.Halo: option "${e}" has to return a cell.`)
    },
    toggleState: function (e) {
        var t, i;
        this.isRendered() && (t = this.$el, util.forIn(this.$pieToggles, function (t) {
            t.removeClass("open")
        }), this.isOpen() ? (this.trigger("state:close", e), t.removeClass("open")) : (this.trigger("state:open", e), e && ((i = util.toArray(this.options.pieToggles).find(function (t) {
            return t.name === e
        })) && (this.el.dataset.pieTogglePosition = i.position, this.el.dataset.pieToggleName = i.name), this.$pieToggles[e].addClass("open")), t.addClass("open")))
    },
    isOpen: function (t) {
        return !!this.isRendered() && (t ? this.$pieToggles[t] : this.$el).hasClass("open")
    },
    isRendered: function () {
        return void 0 !== this.$box
    }
}, {
    clear: function (t) {
        t.trigger("halo:create")
    }, HandlePosition: HandlePosition$2, getDefaultHandle: getDefaultHandle$1
}), $$f = mvc.$, SelectButtonGroup = mvc.View.extend({
    className: "select-button-group",
    events: {
        "click .select-button-group-button": "onSelect",
        "mouseover .select-button-group-button": "onOptionHover",
        mouseleave: "onMouseOut",
        "mousedown .select-button-group-button": "pointerdown",
        "touchstart .select-button-group-button": "pointerdown",
        "mouseup .select-button-group-button": "pointerup",
        "touchend .select-button-group-button": "pointerup"
    },
    options: {
        options: [],
        disabled: !1,
        multi: !1,
        selected: void 0,
        singleDeselect: !1,
        noSelectionValue: void 0,
        width: void 0,
        buttonWidth: void 0,
        buttonHeight: void 0,
        iconWidth: void 0,
        iconHeight: void 0
    },
    init: function () {
        util.bindAll(this, "onSelect", "pointerup"), $$f.data.set(this.el, "view", this);
        var t, e = this.options.options, i = this.options.multi, n = this.options.selected;
        void 0 === n ? (t = util.toArray(e).filter(function (t) {
            return t && !0 === t.selected
        }), this.selection = i ? t : t[0]) : this.selection = i ? Array.isArray(n) ? e.filter(function (t, e) {
            return n.includes(e)
        }) : [e[n]] : e[n]
    },
    render: function () {
        return this.renderOptions(this.selection), this.options.width && this.$el.css("width", this.options.width), this.options.disabled && this.disable(), this.$el.append(this.$options), this
    },
    renderOptions: function () {
        this.removeOptions(), util.toArray(this.options.options).forEach(function (t, e) {
            var i = this.options.multi ? this.selection.includes(t) : this.selection === t,
                t = this.renderOption(t, e, i);
            this.$el.append(t), i && t.addClass("selected")
        }, this)
    },
    removeOptions: function () {
        this.$el.empty()
    },
    renderOption: function (t, e, i) {
        i = this.renderOptionContent(t, i), i.data("index", e), e = t.buttonWidth || this.options.buttonWidth, e && i.css("width", e), e = t.buttonHeight || this.options.buttonHeight;
        return e && i.css("height", e), i
    },
    renderOptionContent: function (t, e) {
        var i, n = $$f("<div/>").addClass("select-button-group-button").html(t.content);
        return (t.icon || e && t.iconSelected) && (e = $$f("<img/>").addClass("select-button-group-button-icon").attr("src", e && t.iconSelected ? t.iconSelected : t.icon), (i = t.iconWidth || this.options.iconWidth) && e.css("width", i), (i = t.iconHeight || this.options.iconHeight) && e.css("height", i), n.prepend(e)), util.setAttributesBySelector(n, t.attrs), n
    },
    setOptions: function (t, e) {
        this.options.options = t, this.selection = e, this.render(), this.trigger("option:select", this.selection)
    },
    getOptionIndex: function (t) {
        return Number(t.closest(".select-button-group-button").dataset.index)
    },
    onSelect: function (t) {
        this.isDisabled() || (t = this.getOptionIndex(t.target), this.select(t, {ui: !0}))
    },
    onOptionHover: function (t) {
        this.isDisabled() || (t = this.getOptionIndex(t.target), this.trigger("option:hover", this.options.options[t], t))
    },
    onMouseOut: function (t) {
        this.isDisabled() || this.trigger("mouseout", t)
    },
    getSelection: function () {
        return this.selection
    },
    getSelectionValue: function (t) {
        t = t || this.selection;
        var e, i = this.options.noSelectionValue;
        return this.options.multi ? 0 === (e = util.toArray(t)).length ? void 0 !== i ? i : [] : e.map(function (t) {
            var e = t.value;
            return void 0 !== e ? e : t.content
        }) : t ? void 0 !== (e = t.value) ? e : t.content : void 0 !== i ? i : void 0
    },
    select: function (i, t) {
        var n = $$f(this.$(".select-button-group-button")[i]), o = this.options.options[i], s = null, r = null,
            a = null, l = null;
        if (this.options.multi) n.toggleClass("selected"), n.hasClass("selected") ? (a = i, -1 === this.selection.indexOf(l = o) && this.selection.push(o), o.iconSelected && n.find(".select-button-group-button-icon").attr("src", o.iconSelected)) : (s = i, this.selection = util.without(this.selection, r = o), o.iconSelected && n.find(".select-button-group-button-icon").attr("src", o.icon)); else {
            let t = this.$(".selected"), e = -1;
            0 < t.length && ([h] = t, e = Array.prototype.indexOf.call(h.parentNode.children, h));
            var h = this.options.options[e];
            n.toggleClass("selected"), n.hasClass("selected") ? (h && (s = e, r = h, t.removeClass("selected"), h.iconSelected) && t.find(".select-button-group-button-icon").attr("src", h.icon), a = i, (this.selection = l = o).iconSelected && n.find(".select-button-group-button-icon").attr("src", o.iconSelected)) : this.options.singleDeselect ? (s = i, r = o, this.selection = void 0, o.iconSelected && n.find(".select-button-group-button-icon").attr("src", o.icon)) : n.addClass("selected")
        }
        h = util.assign({}, t);
        h.deselectedIndex = s, h.deselectedOption = r, h.selectedIndex = a, h.selectedOption = l, this.trigger("option:select", this.selection, i, h)
    },
    selectByValue: function (t, e) {
        Array.isArray(t) || (t = [t]);
        for (var i = this.options.options || [], n = 0; n < i.length; n++) {
            var o = i[n];
            (void 0 === o.value && t.includes(o.content) || void 0 !== o.value && t.find(function (t) {
                return util.isEqual(t, o.value)
            })) && this.select(n, e)
        }
    },
    deselect: function () {
        this.$(".selected").removeClass("selected"), this.options.multi ? this.selection = [] : this.selection = void 0
    },
    isDisabled: function () {
        return this.$el.hasClass("disabled")
    },
    enable: function () {
        this.$el.removeClass("disabled")
    },
    disable: function () {
        this.$el.addClass("disabled")
    },
    pointerdown: function (t) {
        t = this.getOptionIndex(t.target);
        $$f(this.$(".select-button-group-button")[t]).addClass("is-in-action"), $$f(document).on("mouseup.select-button-group touchend.select-button-group", this.pointerup)
    },
    pointerup: function () {
        this.$(".is-in-action").removeClass("is-in-action"), $$f(document).off("mouseup.select-button-group touchend.select-button-group")
    }
}), RadioGroup = mvc.View.extend({
    className: "radio-group",
    events: {"click input": "onOptionClick"},
    options: {options: [], name: void 0},
    currentValue: void 0,
    groupOptions: void 0,
    name: void 0,
    inputOptions: {},
    init: function () {
        this.groupOptions = this.options.options || [], this.name = this.options.name || this.cid
    },
    render: function () {
        return this.renderOptions(), this
    },
    renderOptions: function () {
        this.el.innerHTML = "", this.inputOptions = {}, this.groupOptions.forEach((t, e) => {
            this.renderOption(t, e)
        })
    },
    renderOption: function (t, e) {
        var i = document.createElement("label"), n = (i.setAttribute("tabindex", 0), document.createElement("input")),
            n = (n.type = "radio", n.value = t.value, n.name = this.name, i.appendChild(n), this.inputOptions[t.value] = {
                input: n,
                index: e
            }, document.createElement("span"));
        n.innerHTML = t.content, i.appendChild(n), this.el.appendChild(i)
    },
    getSelectionIndex: function () {
        return this.inputOptions[this.currentValue].index
    },
    getCurrentValue: function () {
        return this.currentValue
    },
    select: function (t) {
        t = this.groupOptions[t].value;
        t && this.selectByValue(t)
    },
    selectByValue: function (t) {
        var t = this.inputOptions[t];
        t && (t = t.input) && t.value !== this.currentValue && (t.checked = !0, this.currentValue = t.value, this.trigger("option:select", this.currentValue, this))
    },
    onOptionClick: function (t) {
        t = t.target;
        t.value !== this.currentValue && this.selectByValue(t.value)
    },
    setOptions: function (t) {
        this.groupOptions = t, this.renderOptions();
        t = this.inputOptions[this.currentValue];
        t && t.input ? t.input.checked = !0 : (this.currentValue = null, this.trigger("option:select", this.currentValue, this))
    }
});

class DependencyService {
    constructor() {
        this.dependencies = {}
    }

    subscribe(t, i) {
        t.forEach(t => {
            var e = t.path;
            this.dependencies[e] || (this.dependencies[e] = []), this.dependencies[e].push({callback: i, dependency: t})
        })
    }

    changed(e) {
        Object.getOwnPropertyNames(this.dependencies).filter(t => this.isSubPathOrSuperPath(t, e)).forEach(t => {
            this.dependencies[t].forEach(t => {
                t.callback(t.dependency, e)
            })
        })
    }

    clear() {
        this.dependencies = {}
    }

    isSubPathOrSuperPath(t, e) {
        let i = t.split("/"), n = e.split("/");
        return i.length > n.length ? !n.some((t, e) => !util.isEqual(t, i[e])) : !i.some((t, e) => !util.isEqual(t, n[e]))
    }
}

class SourceService {
    constructor(t, e, i) {
        this.inspector = t, this.dependencyService = e, this.sources = {}, this.options = i || {}
    }

    add(n, t, e) {
        this.sources[n] = {
            sourceOption: t,
            updateFunction: e,
            initialized: !1
        }, t.dependencies && (e = t.dependencies.map(t => ({
            name: t,
            path: this.resolveDependency(n, t)
        })), this.dependencyService.subscribe(e, (t, e) => {
            var i = {};
            i[t.name] = {path: t.path, changedPath: e}, this.refresh(n, {dependencies: i})
        }))
    }

    initSources() {
        for (var t in this.sources) {
            var e = this.sources[t];
            e.initialized || (this.refresh(t, {initialized: !0}), e.initialized = !0)
        }
    }

    refresh(o, t = {}) {
        let e = this.sources[o];
        if (e) {
            let i = this.inspector.getModel(), n = t.dependencies || {};
            e.sourceOption.dependencies && e.sourceOption.dependencies.forEach(t => {
                var e = this.resolveDependency(o, t);
                n[t] || (n[t] = {path: e, changedPath: null}), n[t].value = i.prop(e)
            });
            t = e.sourceOption.source({
                dependencies: n,
                inspector: this.inspector,
                model: i,
                initialized: Boolean(t.initialized),
                path: o
            });
            t instanceof Promise ? t.then(t => {
                e.updateFunction(t)
            }).catch(t => {
                console.error("Inspector source resolving: " + t)
            }) : e.updateFunction(t)
        }
    }

    refreshAll() {
        for (var t in this.sources) this.refresh(t)
    }

    resolveDependency(t, e) {
        let n = this.options.wildcard;
        e = e.split("/");
        let o = t.split("/");
        return e.reduce((t, e, i) => e === n ? t + o[i] + "/" : t + e + "/", "").slice(0, -1)
    }

    clear() {
        this.sources = {}
    }
}

let $$e = mvc.$;

function not(e, i) {
    var n = [];
    for (let t = 0; t < e.length; t++) {
        var o = e[t];
        o.matches(i) || n.push(o)
    }
    return n
}

let BATCH_NAME = "inspector", Inspector = mvc.View.extend({
    className: "inspector",
    options: {
        cellView: void 0,
        cell: void 0,
        live: !0,
        validateInput: function (t, e, i, n) {
            return !t.validity || t.validity.valid
        },
        renderFieldContent: void 0,
        renderLabel: void 0,
        focusField: void 0,
        operators: {},
        multiOpenGroups: !0,
        container: null,
        stateKey: function (t) {
            return t.id
        }
    },
    events: {
        "change [data-attribute]:not([data-custom-field])": "onChangeInput",
        "click .group-label": "onGroupLabelClick",
        "click .btn-list-add": "addListItem",
        "click .btn-list-del": "deleteListItem",
        "mousedown .field": "pointerdown",
        "touchstart .field": "pointerdown",
        "focusin .field": "pointerfocusin",
        "focusout .field": "pointerfocusout"
    },
    HTMLEntities: {
        lt: "<",
        gt: ">",
        amp: "&",
        nbsp: " ",
        quot: '"',
        cent: "\xa2",
        pound: "\xa3",
        euro: "\u20ac",
        yen: "\xa5",
        copy: "\xa9",
        reg: "\xae"
    },
    init: function () {
        var t, e = this.options.groups = this.options.groups || {},
            i = (util.bindAll(this, "stopBatchCommand", "pointerup", "onContentEditableBlur", "replaceHTMLEntity"), this.DEFAULT_PATH_WILDCARD = "${index}", this.pathWildcard = this.options.pathWildcard, this.widgets = {}, this._byPath = {}, this._attributeKeysInUse = [], this.flatAttributes = this.flattenInputs(this.options.inputs), this.expandAttributes = this.expandAttrs(this.options.inputs || {}), this._when = {}, this.dependencyService = new DependencyService, this.sourceService = new SourceService(this, this.dependencyService, {wildcard: this.pathWildcard || this.DEFAULT_PATH_WILDCARD}), Object.keys(this.flatAttributes).map(function (t) {
                var e = this.flatAttributes[t];
                return this._registerDependants.call(this, e, t), e.path = t, e
            }, this));
        for (t in e) {
            var n = e[t];
            n && e.hasOwnProperty(t) && this.extractExpressionPaths(n.when).forEach(function (t) {
                this._when[t] || (this._when[t] = [])
            }, this)
        }
        i = util.sortBy(i, "index");
        this.groupedFlatAttributes = util.sortBy(i, function (t) {
            t = this.options.groups[t.group];
            return t && t.index || Number.MAX_VALUE
        }.bind(this)), this.listenTo(this.getModel(), "all", this.onCellChange, this)
    },
    _registerDependants: function (t, i) {
        if (t.when) {
            var n = t.when;
            let e = {expression: n, path: i};
            this.extractExpressionPaths(n).forEach(function (t) {
                (this._when[t] || (this._when[t] = [])).push(e)
            }, this)
        }
        this._registerNestedDependants.call(this, t, i)
    },
    _registerNestedDependants: function (n, t) {
        let o = Array.isArray(t) ? t : t.split("/");
        if ("object" === n.type && n.properties) {
            let i = n.properties;
            Object.keys(i).forEach(function (t) {
                var e = i[t], t = o.concat(t);
                this._registerDependants(e, t)
            }, this)
        } else {
            var e;
            "list" === n.type && n.item ? (t = n.item, e = o.concat(null), this._registerDependants(t, e)) : "string" != typeof n.type && Object.keys(n).forEach(function (t) {
                var e = n[t];
                "object" == typeof e && (t = o.concat(t), this._registerDependants(e, t))
            }, this)
        }
    },
    cacheInputs: function () {
        var i = {};
        Array.from(this.$("[data-attribute]")).forEach(function (t) {
            var e = t.dataset.attribute;
            i[e] = $$e(t)
        }, this), this._byPath = i, this._attributeKeysInUse = this.getAttributeKeysInUse()
    },
    updateGroupsVisibility: function () {
        for (var t = this.$groups, e = 0, i = t.length; e < i; e++) {
            var n = $$e(t[e]), o = n.data("name"), o = this.options.groups[o],
                s = 0 === n.find(":scope > .field:not(.hidden)").length,
                s = (n.toggleClass("empty", s), !(!o || !o.when || this.isExpressionValid(o.when)));
            n.toggleClass("hidden", s)
        }
    },
    expandAttrs: function (t) {
        for (var e = {}, i = Object.keys(t), n = 0; n < i.length; n++) {
            var o = i[n], s = t[o], o = o.split("/");
            util.setByPath(e, o, util.isPlainObject(s) ? this.expandAttrs(s) : s)
        }
        return e
    },
    flattenInputs: function (t) {
        return util.flattenObject(t, "/", function (t) {
            return "string" == typeof t.type
        })
    },
    getModel: function () {
        return this.options.cell || this.options.cellView.model
    },
    onCellChange: function (t, e, i, n) {
        if ((n = n || {}).inspector != this.cid) switch (t) {
            case"remove":
                this.constructor.instance && this.trigger("close"), this.remove();
                break;
            case"change:position":
                this.updateInputPosition();
                break;
            case"change:size":
                this.updateInputSize();
                break;
            case"change:angle":
                this.updateInputAngle();
                break;
            case"change:source":
            case"change:target":
            case"change:vertices":
                break;
            default:
                var o = "change:";
                t.slice(0, o.length) === o && (o = t.slice(o.length), this._attributeKeysInUse.includes(o) ? this.render({refresh: !0}) : this.dependencyService.changed(o))
        }
    },
    render: function (t) {
        var i, n, o = t && t.refresh,
            s = (o && this.options.storeGroupsState && this.storeGroupsState(), this.sourceService.clear(), this.dependencyService.clear(), this.$el.empty(), this.removeWidgets(), []);
        return this.groupedFlatAttributes.forEach(function (t) {
            var e;
            i !== t.group && (e = this.options.groups[t.group], n = $$e(this.renderGroup({
                name: t.group,
                label: e && e.label
            })), o || (e && e.closed ? this.closeGroup(n, {init: !0}) : this.openGroup(n, {init: !0})), s.push(n)), this.renderTemplate(n, t, t.path), i = t.group
        }, this), this.$document = $$e(this.el.ownerDocument), this.$groups = $$e(s), this.$el.append(s), o && this.options.restoreGroupsState && this.restoreGroupsState(), this.afterRender(), this
    },
    getAttributeKeysInUse: function () {
        var t = Object.keys(this._byPath).map(function (t) {
            return t.substring(0, t.indexOf("/")) || t
        }), e = util.toArray(this._bound), i = Object.keys(this._when);
        return util.uniq([].concat(t, e, i))
    },
    getCellAttributeValue: function (t, e) {
        var i = this.getModel(), n = util.getByPath(i.attributes, t, "/");
        if ((e = e || this.flatAttributes[t]) && (void 0 === n && void 0 !== e.defaultValue && "function" == typeof (n = e.defaultValue) && (n = n.call(this, i, t)), e.valueRegExp)) {
            if (void 0 === n) throw new Error("Inspector: defaultValue must be present when valueRegExp is used.");
            i = n.match(new RegExp(e.valueRegExp)), n = i && i[2]
        }
        return n
    },
    resolvableTypes: ["select", "select-box", "color-palette", "select-button-group", "radio-group"],
    resolveBindings: function (t) {
        if (-1 < this.resolvableTypes.indexOf(t.type)) {
            var i = t.options || [];
            if (util.isString(i)) {
                let e = i;
                i = {
                    dependencies: [e], source: t => {
                        t = t.dependencies[e].value;
                        return Array.isArray(t) ? t.map(t => util.isString(t) ? {value: t, content: t} : t) : []
                    }
                }
            }
            (i = Array.isArray(i) && !util.isObject(i[0]) ? util.toArray(i).map(function (t) {
                return {value: t, content: t}
            }) : i).source ? (t._optionsSource = i, t.items = []) : t.items = i
        }
    },
    renderFieldContent: function (a, o, n) {
        var t, s;
        if (util.isFunction(this.options.renderFieldContent) && 0 < (t = $$e(this.options.renderFieldContent(a, o, n, this))).length) t.data("attribute", o), t.data("type", a.type), t.data("customField", !0); else switch (a.type) {
            case"select-box":
                var r, i = util.toArray(a.items).findIndex(function (t) {
                    var e = t.value, i = n;
                    return void 0 === e && t.content === i || ((t = a.key) && (i = util.getByPath(i, t, "/"), e = util.getByPath(e, t, "/")), util.isEqual(e, i))
                }), l = util.assign({
                    theme: this.options.theme,
                    target: this.options.container
                }, util.omit(a, "type", "group", "index", "selectBoxOptionsClass", "options"), {
                    options: a.items,
                    selected: i,
                    selectBoxOptionsClass: [util.addClassNamePrefix("inspector-select-box-options"), a.selectBoxOptionsClass].filter(function (t) {
                        return !!t
                    }).join(" ")
                });
                (r = new SelectBox(l)).el.dataset.attribute = o, r.el.dataset.type = a.type, null != a.overwrite && (r.el.dataset.overwrite = a.overwrite), r.render(), l = $$e(this.renderOwnLabel(a, o)), t = $$e("<div/>").append(l, r.el), a.previewMode ? (s = r.selection, r.on("options:mouseout close", function () {
                    r.selection = s, this.processInput(r.el, {previewCancel: !0, dry: !0})
                }, this), r.on("option:hover", function (t, e) {
                    r.selection = t, this.processInput(r.el, {dry: !0})
                }, this), r.on("option:select", function (t, e) {
                    var i = void 0 === s ? void 0 : r.getSelectionValue(s), n = r.getSelectionValue(t);
                    this.processInput(r.el, {previewDone: !0, dry: i === n, originalValue: i}), s = t
                }, this)) : r.on("option:select", function (t, e) {
                    this.processInput(r.el)
                }, this), a._optionsSource && this.sourceService.add(o, a._optionsSource, t => {
                    let n = this.getModel().prop(o), e = t.findIndex(t => {
                        var e = t.value, i = n;
                        return void 0 === e && t.content === i || ((t = a.key) && (i = util.getByPath(i, t, "/"), e = util.getByPath(e, t, "/")), util.isEqual(e, i))
                    });
                    -1 === e && (e = void 0), r.setOptions(t, e)
                }), this.widgets[o] = r;
                break;
            case"color-palette":
                i = util.toArray(a.items).findIndex(function (t) {
                    return t.value === n || void 0 === t.value && t.content === n
                });
                i = util.assign({
                    theme: this.options.theme,
                    target: this.options.container
                }, util.omit(a, "type", "group", "index", "options"), {options: a.items, selected: i});
                (r = new ColorPalette(i)).el.dataset.attribute = o, r.el.dataset.type = a.type, r.render(), l = $$e(this.renderOwnLabel(a, o)), t = $$e("<div/>").append(l, r.el), a.previewMode ? (s = r.selection, r.on("options:mouseout close", function () {
                    r.selection = s, this.processInput(r.el, {previewCancel: !0, dry: !0})
                }, this), r.on("option:hover", function (t, e) {
                    r.selection = t, this.processInput(r.el, {dry: !0})
                }, this), r.on("option:select", function (t, e) {
                    var i = void 0 === s ? void 0 : r.getSelectionValue(s), n = r.getSelectionValue(t);
                    this.processInput(r.el, {previewDone: !0, dry: i === n, originalValue: i}), s = t
                }, this)) : r.on("option:select", function (t, e) {
                    this.processInput(r.el)
                }, this), a._optionsSource && this.sourceService.add(o, a._optionsSource, t => {
                    let e = this.getModel().prop(o),
                        i = t.findIndex(t => t.value === e || void 0 === t.value && t.content === e);
                    -1 === i && (i = void 0), r.setOptions(t, i)
                }), this.widgets[o] = r;
                break;
            case"select-button-group":
                var h = (t, o) => {
                    var s, r, t = util.toArray(t);
                    return a.multi ? (s = [], r = [], t.forEach(function (t, e) {
                        var i = void 0 === t.value ? t.content : t.value, n = a.key;
                        n && (i = util.getByPath(i, n, "/")), util.toArray(o).find(function (t) {
                            return n && (t = util.getByPath(t, n, "/")), util.isEqual(i, t)
                        }) && (r.push(t), s.push(e))
                    })) : (r = void 0, -1 < (s = t.findIndex(function (t) {
                        var e = t.value, i = o;
                        return void 0 === e && t.content === i || ((t = a.key) && (i = util.getByPath(i, t, "/"), e = util.getByPath(e, t, "/")), util.isEqual(e, i))
                    })) && (r = t[s])), {selectedIndex: s, selected: r}
                }, i = util.assign({theme: this.options.theme}, util.omit(a, "type", "group", "index", "options"), {
                    options: a.items,
                    selected: h(a.items, n).selectedIndex
                });
                (r = new SelectButtonGroup(i)).el.dataset.attribute = o, r.el.dataset.type = a.type, null != a.overwrite && (r.el.dataset.overwrite = a.overwrite), r.render(), l = $$e(this.renderOwnLabel(a, o)), t = $$e("<div/>").append(l, r.el), a.previewMode ? (s = r.selection, r.on("mouseout", function () {
                    r.selection = s, this.processInput(r.el, {previewCancel: !0, dry: !0})
                }, this), r.on("option:hover", function (t, e) {
                    a.multi ? r.selection = util.uniq(r.selection.concat([t])) : r.selection = t, this.processInput(r.el, {dry: !0})
                }, this), r.on("option:select", function (t, e) {
                    var i = void 0 === s ? void 0 : r.getSelectionValue(s), n = r.getSelectionValue(t),
                        n = util.isEqual(i, n);
                    this.processInput(r.el, {previewDone: !0, dry: n, originalValue: i}), s = t
                }, this)) : r.on("option:select", function (t, e) {
                    this.processInput(r.el)
                }, this), a._optionsSource && this.sourceService.add(o, a._optionsSource, t => {
                    var e = this.getModel().prop(o), e = h(t, e).selected;
                    r.setOptions(t, e)
                }), this.widgets[o] = r;
                break;
            case"radio-group": {
                i = util.assign({theme: this.options.theme}, util.omit(a, "type", "group", "index", "options"), {
                    options: a.items,
                    name: o
                });
                let e = new RadioGroup(i);
                e.render(), e.el.setAttribute("data-attribute", o), e.el.setAttribute("data-type", a.type), null != a.overwrite && e.el.setAttribute("data-overwrite", a.overwrite), l = $$e(this.renderOwnLabel(a, o)), t = $$e("<div/>").append(l, e.el), e.selectByValue(n), e.on("option:select", t => {
                    this.processInput(e.el)
                }), a._optionsSource && this.sourceService.add(o, a._optionsSource, t => {
                    e.setOptions(t)
                }), this.widgets[o] = e;
                break
            }
            default:
                return this.renderOwnFieldContent({
                    options: a,
                    type: a.type,
                    overwrite: a.overwrite,
                    label: a.label || o,
                    attribute: o,
                    value: n
                })
        }
        return t.toArray()
    },
    renderGroup: function (t) {
        var e = document.createElement("div"),
            i = (e.classList.add("group"), e.dataset.name = t.name, document.createElement("h3"));
        return i.classList.add("group-label"), i.textContent = t.label || t.name, e.appendChild(i), e
    },
    renderOwnLabel: function (t, e) {
        var i, n = this.options.renderLabel;
        return (void 0 !== (i = "function" == typeof n ? n(t, e, this) : i) ? $$e(i) : $$e("<label/>").html(t.label || e)).toArray()
    },
    renderOwnFieldContent: function (o) {
        var e, t, i, n, s, r = $$e(this.renderOwnLabel(o.options, o.attribute));
        switch (o.type) {
            case"number":
                c = $$e("<input/>").attr({
                    type: "number",
                    min: o.options.min,
                    max: o.options.max,
                    step: o.options.step
                }).val(o.value), e = [r, $$e("<div/>").addClass("input-wrapper").append(c)];
                break;
            case"range":
                r.addClass("with-output"), t = $$e("<output/>").text(o.value), a = $$e("<span/>").addClass("units").text(o.options.unit), (c = $$e("<input/>").attr({
                    type: "range",
                    name: o.type,
                    min: o.options.min,
                    max: o.options.max,
                    step: o.options.step
                }).val(o.value)).on("change input", function () {
                    t.text(c.val())
                }), e = [r, t, a, c];
                break;
            case"textarea":
                c = $$e("<textarea/>").text(o.value), e = [r, $$e("<div/>").addClass("input-wrapper").append(c)];
                break;
            case"content-editable": {
                var {value: a, options: l = {}} = o, {html: l = !0, readonly: h = !1} = l;
                let t;
                t = util.isString(a) ? (l ? util.sanitizeHTML(a) : this.encodeHTMLEntities(a)).replace(/\n/g, "<br>") : "", c = $$e("<div/>").prop("contentEditable", !h).toggleClass("content-editable-readonly", Boolean(h)).css("display", "inline-block").html(t).on("blur", this.onContentEditableBlur), e = [r, $$e("<div/>").addClass("input-wrapper").append(c)];
                break
            }
            case"select":
                var l = o.options.items, c = $$e("<select/>");
                o.options.multiple && (c.prop("size", o.options.size || l.length), c.prop("multiple", !0));
                util.toArray(l).forEach(function (t) {
                    var e, i = $$e("<option/>").text(t.content).val(t.value);
                    e = t.value, (o.options.multiple ? util.toArray(o.value).find(function (t) {
                        return util.isEqual(e, t)
                    }) : util.isEqual(e, o.value)) && i.attr("selected", "selected"), c.append(i)
                }), o.options._optionsSource && this.sourceService.add(o.attribute, o.options._optionsSource, t => {
                    c.empty();
                    let n = this.getModel().prop(o.attribute);
                    t.forEach(t => {
                        var e, i = $$e("<option/>", {value: t.value}).text(t.content);
                        e = t.value, (o.options.multiple ? util.toArray(n).find(function (t) {
                            return util.isEqual(e, t)
                        }) : util.isEqual(e, n)) && i.attr("selected", "selected"), c.append(i)
                    })
                }), e = [r, c];
                break;
            case"toggle":
                i = $$e("<span><i/></span>"), c = $$e("<input/>").attr("type", "checkbox").prop("checked", !!o.value), e = [r, $$e("<div/>").addClass(o.type).append(c, i)];
                break;
            case"color":
                e = [r, c = $$e("<input/>").attr("type", "color").val(o.value)];
                break;
            case"text":
                c = $$e("<input/>").attr("type", "text").val(o.value), e = [r, $$e("<div/>").addClass("input-wrapper").append(c)];
                break;
            case"object":
                c = $$e("<div/>"), n = $$e("<div/>").addClass("object-properties"), e = [r, c.append(n)];
                break;
            case"list":
                i = $$e("<button/>").addClass("btn-list-add").text(o.options.addButtonLabel || "+"), n = $$e("<div/>").addClass("list-items"), e = [r, (c = $$e("<div/>")).append(i, n)]
        }
        return c && 0 < c.length && (c.addClass(o.type), [s] = c, s.dataset.type = o.type, s.dataset.attribute = o.attribute, null != o.overwrite) && (s.dataset.overwrite = o.overwrite), e.map(t => t.toArray()).flat()
    },
    onContentEditableBlur: function (t) {
        var e = $$e("<input/>").prop("disabled", !0).prop("tabIndex", -1).css({
            width: "1px",
            height: "1px",
            border: "none",
            margin: 0,
            padding: 0
        }).appendTo(this.$el), [i] = e;
        i.focus(), i.setSelectionRange(0, 0), i.blur(), e.remove(), t.target.dispatchEvent(new CustomEvent("change", {bubbles: !0}))
    },
    replaceHTMLEntity: function (t, e) {
        return this.HTMLEntities[e] || ""
    },
    encodeHTMLEntities: function (t) {
        return t.replace(/[\u00A0-\u9999<>&]/g, function (t) {
            return `&#${t.charCodeAt(0)};`
        })
    },
    renderObjectProperty: function (t = {}) {
        var e = document.createElement("div");
        return e.classList.add("object-property"), e.dataset.property = t.property, e
    },
    renderListItem: function (t = {}) {
        var e = document.createElement("button"),
            i = (e.classList.add("btn-list-del"), e.textContent = t.options.removeButtonLabel || "-", document.createElement("div"));
        return i.classList.add("list-item"), i.dataset.index = t.index, i.appendChild(e), i
    },
    renderFieldContainer: function (t = {}) {
        var e = document.createElement("div");
        return e.classList.add("field"), e.classList.add(t.type + "-field"), e.dataset.field = t.path, e
    },
    renderTemplate: function (t, n, o, e) {
        var t = $$e(t || this.el), i = (e = e || {}, this.resolveBindings(n), "string" != typeof n.type && (n = {
                type: "object",
                properties: n
            }), $$e(this.renderFieldContainer({path: o, type: n.type}))),
            s = (e.hidden && i.addClass("hidden"), this.getCellAttributeValue(o, n));
        let r = $$e(this.renderFieldContent(n, o, s));
        if (i.append(r), util.setAttributesBySelector(i, n.attrs), "list" === n.type && n.item) {
            util.toArray(s).forEach(function (t, e) {
                var i = this.renderListItem({index: e, options: n});
                this.renderTemplate(i, n.item, o + "/" + e), r.children(".list-items").append(i)
            }, this);
            var s = s && s.length, a = n && n.min, l = n && n.max;
            this.fixListButtons(r, s, a, l)
        } else if ("object" === n.type && n.properties) {
            let i = this.flattenInputs(n.properties);
            s = Object.keys(i).map(function (t) {
                var e = i[t];
                return e.path = t, e
            });
            (s = util.sortBy(s, function (t) {
                return t.index
            })).forEach(function (t) {
                var e = this.renderObjectProperty({property: t.path});
                this.renderTemplate(e, t, o + "/" + t.path), r.children(".object-properties").append(e)
            }, this)
        }
        e.replace ? ([a] = t.find('[data-field="' + o + '"]'), a && 0 < i.length && a.parentNode.replaceChild(i[0], a)) : t.append(i)
    },
    updateInputPosition: function () {
        var t = this._byPath["position/x"], e = this._byPath["position/y"], i = this.getModel().get("position");
        t && t.val(i.x), e && e.val(i.y)
    },
    updateInputSize: function () {
        var t = this._byPath["size/width"], e = this._byPath["size/height"], i = this.getModel().get("size");
        t && t.val(i.width), e && e.val(i.height)
    },
    updateInputAngle: function () {
        var t = this._byPath.angle, e = this.getModel().get("angle");
        t && t.val(e)
    },
    validateInput: function (t, e, i) {
        switch (t) {
            case"select-box":
            case"color-palette":
                var n = this.widgets[i];
                return n ? -1 !== n.getSelectionIndex() : !1;
            case"select-button-group":
                return !!this.widgets[i];
            default:
                return this.options.validateInput(e, i, t, this)
        }
    },
    refreshSources: function () {
        this.sourceService.refreshAll()
    },
    refreshSource: function (t) {
        this.sourceService.refresh(t)
    },
    focusField: function (t) {
        var e = this.getOptionsFromPath(t), i = this._byPath[t];
        if (!i) throw new Error("path not found");
        this._focusFieldInternal(e, t, i[0])
    },
    _focusListField(t, e, i) {
        i = i.querySelector("[data-attribute]:not(.hidden)");
        i && this._focusFieldInternal(t.item, i.getAttribute("data-attribute"), i)
    },
    _focusObjectField(t, e, i) {
        var n, o, i = i.querySelector("[data-attribute]:not(.hidden)");
        i && (n = i.getAttribute("data-attribute"), o = this.getOptionsFromPath(n), this._focusFieldInternal(o, n, i))
    },
    _focusFieldInternal(t, e, i) {
        switch (t.type) {
            case"number":
            case"text":
            case"range":
            case"color":
            case"toggle":
            case"select":
            case"textarea":
            case"content-editable":
                i.focus();
                break;
            case"object":
                this._focusObjectField(t, e, i);
                break;
            case"list":
                this._focusListField(t, e, i);
                break;
            default:
                this.options.focusField && this.options.focusField(t, e, i, this)
        }
    },
    onChangeInput: function (t) {
        t.target === t.currentTarget && this.processInput(t.target)
    },
    processInput: function (t, e) {
        var i, n = t.dataset.attribute, o = t.dataset.type;
        this.validateInput(o, t, n) && (this.options.live && this.updateCell(t, n, e), i = this.getFieldValue(t, o), o = this.parse(o, i, t), e && e.dry || this.dependencyService.changed(n), this.trigger("change:" + n, o, t, e))
    },
    updateFieldsVisibility: function () {
        this._attributeKeysInUse.forEach(t => {
            this.updateDependants(t)
        })
    },
    updateDependants: function (t) {
        let e = this._when;
        var i = Object.keys(e);
        let a = this._byPath, n = Object.keys(a), l = this.flatAttributes;

        function u(t, e) {
            var i, n = {};
            for (i in t) {
                var o, s, r = t[i];
                if (Array.isArray(r)) {
                    var a = i, l = r, h = (n[a] = [], l.length);
                    for (let t = 0; t < h; t++) {
                        var c = l[t], c = u.call(this, c, e);
                        n[a].push(c)
                    }
                } else this._isComposite(t) ? (s = i, o = u.call(this, r, e), n[s] = o) : (s = i, d.call(this, s, r, e, n))
            }
            return n;

            function d(t, e, i, n) {
                for (var o in n[t] = {}, e) {
                    var s = e[o], o = r.call(this, o, i);
                    n[t][o] = s
                }

                function r(t, i) {
                    var n = this.pathWildcard || this.DEFAULT_PATH_WILDCARD, o = [];
                    let s = 0;
                    var r = t.split("/"), a = r.length;
                    for (let e = 0; e < a; e++) {
                        let t = r[e];
                        t === n && (t = i[s] || n, s += 1), o.push(t)
                    }
                    return o.join("/")
                }
            }
        }

        function o(e, i, t) {
            var n, {pathWildcard: o, comparisonWildcard: s} = t, r = [], a = i.length, l = e.length;
            for (let t = 0; t < l; t++) {
                var h = e[t], c = (n = h, Array.isArray(n) ? n : n.split("/")), d = c.length;
                if (d === a) {
                    let e = !0;
                    var u = [], p = [];
                    for (let t = 0; t < d; t++) {
                        var g = c[t], m = i[t], f = g === o, v = m === s;
                        if (g !== m && !f && !v) {
                            e = !1;
                            break
                        }
                        f ? u.push(m) : v && p.push(g)
                    }
                    e && r.push({path: h, pathWildcardValues: u, comparisonWildcardValues: p})
                }
            }
            return r
        }

        (function (t, e) {
            var e = e.split("/"), i = this.pathWildcard || this.DEFAULT_PATH_WILDCARD;
            return o(t, e, {pathWildcard: i})
        }).call(this, i, t).forEach(t => {
            t = t.path;
            util.toArray(e[t]).forEach(t => {
                var e = t.path, t = t.expression;
                let s = this._getBareExpression(t), r = this._getExpressionExtras(t);
                ((t, e) => Array.isArray(e) ? -1 !== e.indexOf(null) ? o(t, e, {comparisonWildcard: null}) : [{
                    path: e.join("/"),
                    pathWildcardValues: [],
                    comparisonWildcardValues: []
                }] : [{path: e, pathWildcardValues: [], comparisonWildcardValues: []}])(n, e).forEach(t => {
                    var e = t.path, t = t.comparisonWildcardValues, i = a[e], n = i.closest(".field"),
                        o = n.hasClass("hidden"), t = u.call(this, s, t), t = this.isExpressionValid(t),
                        n = (n.toggleClass("hidden", !t), r.otherwise);
                    n && n.unset && this.options.live && (t ? o && this.updateCell(i, e) : (this.unsetProperty(e), (n = ((n, t) => {
                        let o = n[t];
                        if (null == o) {
                            var s = t.split("/"), r = s.length;
                            let e = s[0], i = o = n[e];
                            for (let t = 1; t < r; t++) {
                                var a = s[t];
                                if (void 0 === o) e += "/" + a, o = (void 0 === i ? n : i)[e]; else {
                                    if ("object" === (i = o).type && o.properties) o = o.properties[a]; else if ("list" === o.type && o.item) o = o.item; else {
                                        if ("string" == typeof o.type) break;
                                        o = o[a]
                                    }
                                    e = a
                                }
                            }
                        }
                        return o
                    })(l, e)) && this.renderTemplate(null, n, e, {
                        replace: !0,
                        hidden: !0
                    }), this.afterPartialRender([e])))
                }, this)
            }, this)
        }, this)
    },
    unsetProperty: function (t, e) {
        (e = e || {}).inspector = this.cid, e["inspector_" + this.cid] = !0, this.getModel().removeProp(t, e)
    },
    getOptions: function (t) {
        if (0 !== t.length) return t = t.data("attribute"), this.getOptionsFromPath(t)
    },
    markForRemoval: function (t, e) {
        var i = this.findParentListByPath(t);
        i && (t = t.substr(i.length + 1), t = parseInt(t, 10), Number.isFinite(t)) && (e.remove[i] = e.remove[i] || [], e.remove[i].includes(t) || e.remove[i].push(t))
    },
    markForUpdate: function (t, e, i, n) {
        t = t.substr(n.length + 1);
        e.update[n] && util.setByPath(e.update[n].value, t, i, "/")
    },
    updateCell: function (t, e, i) {
        var d = this.getModel(), n = {}, u = (t ? n[e] = $$e(t) : n = this._byPath, this.startBatchCommand(), {}),
            p = {update: {}, remove: {}};
        util.forIn(n, function (t, e) {
            if (!t.closest(".field").hasClass("hidden")) {
                var i, n, o, s, [r] = t, a = r.dataset.type, l = r.dataset.overwrite, h = "false" !== l && void 0 !== l,
                    c = t.hasClass("remove");
                switch (a) {
                    case"list":
                    case"object":
                        c && this.markForRemoval(e, p);
                        break;
                    default:
                        this.validateInput(a, r, e) && (i = this.getFieldValue(r, a), i = this.parse(a, i, r), (o = this.getOptionsFromPath(e)).valueRegExp && ((n = util.getByPath(d.attributes, e, "/")) || "function" == typeof (n = o.defaultValue) && (n = n.call(this, d, e)), i = n.replace(new RegExp(o.valueRegExp), "$1" + i + "$3")), c ? this.markForRemoval(e, p) : (n = o.parent) && "object" === n.type && void 0 !== n.overwrite && !1 !== n.overwrite ? ((o = {})[(s = e.split("/"))[s.length - 1]] = i, p.update[n.path] = {
                            value: o,
                            overwrite: !0
                        }) : u[e] = {value: i, overwrite: h})
                }
            }
        }.bind(this)), util.forIn(u, function (t, e) {
            this.setProperty(e, t.value, util.assign({overwrite: t.overwrite}, i))
        }.bind(this)), util.sortBy(Object.keys(p.remove), function (t) {
            return t.split("/").length
        }).reverse().forEach(function (t) {
            var e = p.remove[t];
            this.removeProperty(t, e, util.assign({rewrite: !0}, i))
        }.bind(this)), util.forIn(p.update, function (t, e) {
            this.setProperty(e, this.compactDeep(t.value), util.assign({rewrite: !0, overwrite: t.overwrite}, i))
        }.bind(this)), this.updateFieldsVisibility(), this.updateGroupsVisibility(), this.stopBatchCommand()
    },
    compactDeep: function (t) {
        return Array.isArray(t) ? t.reduce(function (t, e) {
            return e && t.push(this.compactDeep(e)), t
        }.bind(this), []) : t
    },
    findParentListByPath: function (t) {
        for (var e = t.split("/"), i = (e.pop(), e); i.length;) {
            var n = this.getOptionsFromPath(i.join("/"));
            if (n && "list" === n.type) return e.slice(0, i.length).join("/");
            i.pop()
        }
        return null
    },
    getOptionsFromPath: function (t) {
        for (var e, i = t.split("/"), n = this.expandAttributes, o = []; i.length;) {
            var s = r;
            n && "object" === n.type ? r = "properties" : (r = i.shift(), !i.length && "list" !== n.type || (e = n, o.push(r)));
            var r = !Number.isNaN(parseInt(r)) && "list" === n.type ? "item" : r;
            if (Object(n) !== n || !(r in n || n[t])) return {};
            n = n[r] || n[t]
        }
        return n = util.assign({}, n), (e = util.assign({}, e)).path = o.join("/"), s && "properties" === s && (e.type = "object"), n.parent = e, n
    },
    getFieldValue: function (t, e) {
        if (util.isFunction(this.options.getFieldValue)) {
            var i = this.options.getFieldValue(t, e, this);
            if (i) return i.value
        }
        var n = $$e(t);
        switch (e) {
            case"select-box":
            case"color-palette":
            case"select-button-group":
                var o = t.dataset.attribute;
                return this.widgets[o].getSelectionValue();
            case"radio-group":
                return this.widgets[t.dataset.attribute].currentValue;
            case"select":
                return t.multiple ? Array.from(t.selectedOptions).map(t => t.value) : t.value;
            case"content-editable":
                return n.html().replace(/((<br\s*\/*>)?<\/div>)|(((&nbsp;)|(<br\s*\/*>))?<\/p>)|(<br\s*\/*>)/gi, "\n").replace(/(<([^>]+)>)/gi, "").replace(/&(\w+);/gi, this.replaceHTMLEntity).replace(/\n$/, "");
            default:
                return t.value
        }
    },
    removeProperty: function (t, n, e) {
        var i, o = this.getModel(), s = dia$1.Cell.prototype.prop, r = s.call(o, t);
        r && (r = r.reduce(function (t, e, i) {
            return n.includes(i) || t.push(e), t
        }, []), i = this.flatAttributes[t], Array.isArray(r) && 0 === r.length && !i && (r = null), s.call(o, t, r, e))
    },
    setProperty: function (t, e, i) {
        (i = i || {}).inspector = this.cid;
        var n, o, s = dia$1.Cell.prototype.prop, r = this.getModel(), a = i.overwrite || !1;
        i.previewDone && s.call(r, t, i.originalValue, {
            rewrite: !0,
            silent: !0
        }), void 0 === e ? dia$1.Cell.prototype.removeProp.call(r, t, i) : (o = util.isObject(e) && !a ? (n = s.call(r, t), o = Array.isArray(e) ? [] : {}, util.merge(o, n, e)) : util.clone(e), a && (i.rewrite = !0), s.call(r, t, o, i))
    },
    parse: function (t, e, i) {
        switch (t) {
            case"number":
            case"range":
                e = parseFloat(e);
                break;
            case"toggle":
                e = i.checked
        }
        return e
    },
    startBatchCommand: function () {
        var t;
        this.inBatch || (this.inBatch = !0, (t = this.getModel()) instanceof dia$1.Cell && t.graph ? t.startBatch(BATCH_NAME, {cid: this.cid}) : t.trigger("batch:start", {
            batchName: BATCH_NAME,
            cid: this.cid
        }))
    },
    stopBatchCommand: function () {
        var t;
        this.inBatch && ((t = this.getModel()) instanceof dia$1.Cell && t.graph ? t.stopBatch(BATCH_NAME, {cid: this.cid}) : t.trigger("batch:stop", {
            batchName: BATCH_NAME,
            cid: this.cid
        }), this.inBatch = !1)
    },
    afterRender: function () {
        this.cacheInputs(), this.updateFieldsVisibility(), this.updateGroupsVisibility(), this.sourceService.initSources(), this.trigger("render")
    },
    afterPartialRender: function (t) {
        this.cacheInputs(), this.updateGroupsVisibility(), this.sourceService.initSources(), t && t.forEach(t => {
            this.dependencyService.changed(t)
        }), this.trigger("render")
    },
    addListItem: function (t) {
        var t = t.target.parentNode, t = t.matches("[data-attribute]") ? $$e(t) : $$e(), e = this.getOptions(t),
            i = t.children(".list-items"), n = i.children(".list-item"), n = $$e(n[n.length - 1]),
            n = (0 === n.length ? -1 : Number(n.data("index"))) + 1, o = this.renderListItem({index: n, options: e}),
            n = t.data("attribute") + "/" + n,
            i = (this.renderTemplate(o, e.item, n), i.append(o), not(i.children(".list-item"), ".remove").length);
        this.fixListButtons(t, i, e.min, e.max), this.afterPartialRender([n]);
        let s = o;
        "object" !== e.item.type && "list" !== e.item.type && (s = s.querySelector("[data-attribute]")), this.options.live && this.updateCell(), this._focusFieldInternal(e.item, n, s)
    },
    deleteListItem: function (t) {
        var t = $$e(t.target), e = t.closest("[data-attribute]"), i = this.getOptions(e), t = t.closest(".list-item");
        t.css("display", "none"), t.addClass("remove"), t.find("[data-field]").css("display", "none").addClass("remove"), t.find("[data-attribute]").css("display", "none").addClass("remove");
        t = not(e.children(".list-items").children(".list-item"), ".remove").length, this.fixListButtons(e, t, i.min, i.max), t = e.data("attribute");
        this.afterPartialRender([t]), this.options.live && this.updateCell()
    },
    fixListButtons: function (t, e, i, n) {
        var o = t.children(".btn-list-add");
        s = e;
        "number" != typeof (n = n) || "number" != typeof s || s < n ? o.removeClass("hidden") : o.addClass("hidden");
        var s = t.children(".list-items").children(".list-item").children(".btn-list-del");
        n = e, "number" != typeof (o = i) || o <= 0 || !("number" != typeof n || n <= 0) && o < n ? s.removeClass("hidden") : s.addClass("hidden")
    },
    bindDocumentEvents: function () {
        var t = this.getEventNamespace();
        this.$document.on("mouseup" + t + " touchend" + t, this.pointerup)
    },
    unbindDocumentEvents: function () {
        this.$document.off(this.getEventNamespace())
    },
    pointerdown: function (t) {
        t.stopPropagation(), this.bindDocumentEvents(), this.startBatchCommand(), this._$activeField = $$e(t.currentTarget).addClass("is-in-action")
    },
    pointerup: function () {
        this.unbindDocumentEvents(), this.stopBatchCommand(), this._$activeField && (this._$activeField.removeClass("is-in-action"), this._$activeField = null)
    },
    pointerfocusin: function (t) {
        t.stopPropagation(), $$e(t.currentTarget).addClass("is-focused")
    },
    pointerfocusout: function (t) {
        t.stopPropagation(), $$e(t.currentTarget).removeClass("is-focused")
    },
    onRemove: function () {
        this.unbindDocumentEvents(), this.removeWidgets(), this === this.constructor.instance && (this.constructor.instance = null)
    },
    removeWidgets: function () {
        var t, e = this.widgets;
        for (t in e) e[t].remove();
        this.widgets = {}
    },
    onGroupLabelClick: function (t) {
        t.preventDefault(), this.options.multiOpenGroups || this.closeGroups();
        t = $$e(t.target.closest(".group"));
        this.toggleGroup(t)
    },
    toggleGroup: function (t) {
        t = util.isString(t) ? this.$('.group[data-name="' + t + '"]') : $$e(t);
        t.hasClass("closed") ? this.openGroup(t) : this.closeGroup(t)
    },
    closeGroup: function (t, e) {
        e = e || {};
        t = util.isString(t) ? this.$('.group[data-name="' + t + '"]') : $$e(t);
        !e.init && t.hasClass("closed") || (t.addClass("closed"), this.trigger("group:close", t.data("name"), e))
    },
    openGroup: function (t, e) {
        e = e || {};
        t = util.isString(t) ? this.$('.group[data-name="' + t + '"]') : $$e(t);
        (e.init || t.hasClass("closed")) && (t.removeClass("closed"), this.trigger("group:open", t.data("name"), e))
    },
    closeGroups: function () {
        for (var t = 0, e = this.$groups.length; t < e; t++) this.closeGroup(this.$groups[t])
    },
    openGroups: function () {
        for (var t = 0, e = this.$groups.length; t < e; t++) this.openGroup(this.$groups[t])
    },
    COMPOSITE_OPERATORS: ["not", "and", "or", "nor"],
    PRIMITIVE_OPERATORS: ["eq", "ne", "regex", "text", "lt", "lte", "gt", "gte", "in", "nin", "equal"],
    _isComposite: function (t) {
        return 0 < util.intersection(this.COMPOSITE_OPERATORS, Object.keys(t)).length
    },
    _isPrimitive: function (t) {
        var e = Object.keys(this.options.operators).concat(this.PRIMITIVE_OPERATORS);
        return 0 < util.intersection(e, Object.keys(t)).length
    },
    _evalCustomPrimitive: function (t, e, i, n) {
        return !!this.options.operators[t].apply(this, [this.getModel(), e].concat(i).concat([n]))
    },
    _evalPrimitive: function (e) {
        return Object.keys(e).reduce(function (t, o) {
            var s = e[o];
            return Object.keys(s).reduce(function (t, e) {
                var i = s[e], n = this.getCellAttributeValue(e);
                if (util.isFunction(this.options.operators[o])) return this._evalCustomPrimitive(o, n, i, e);
                switch (o) {
                    case"eq":
                        return i == n;
                    case"ne":
                        return i != n;
                    case"regex":
                        return new RegExp(i).test(n);
                    case"text":
                        return !i || util.isString(n) && -1 < n.toLowerCase().indexOf(i);
                    case"lt":
                        return n < i;
                    case"lte":
                        return n <= i;
                    case"gt":
                        return i < n;
                    case"gte":
                        return i <= n;
                    case"in":
                        return Array.isArray(i) && i.includes(n);
                    case"nin":
                        return Array.isArray(i) && !i.includes(n);
                    case"equal":
                        return util.isEqual(i, n);
                    default:
                        return t
                }
            }.bind(this), !1)
        }.bind(this), !1)
    },
    _evalExpression: function (o) {
        if (this._isPrimitive(o)) return this._evalPrimitive(o);
        if (this._isComposite(o)) return Object.keys(o).reduce(function (t, e) {
            var i = o[e];
            if ("not" == e) return !this._evalExpression(i);
            var n = util.toArray(i).map(this._evalExpression, this);
            switch (e) {
                case"and":
                    return n.every(function (t) {
                        return !!t
                    });
                case"or":
                    return n.some(function (t) {
                        return !!t
                    });
                case"nor":
                    return !n.some(function (t) {
                        return !!t
                    });
                default:
                    return t
            }
        }.bind(this), !1);
        throw new Error('Inspector: Invalid custom operator used in an expression. The operator "' + Object.keys(o)[0] + '" must be registered in the `operators` property.')
    },
    _getBareExpression: function (t) {
        return util.omit(t, "otherwise", "dependencies")
    },
    _getExpressionExtras: function (t) {
        return {otherwise: util.clone(t.otherwise), dependencies: util.clone(t.dependencies)}
    },
    _extractVariables: function (t) {
        return Array.isArray(t) || this._isComposite(t) ? util.toArray(t).reduce(function (t, e) {
            return t.concat(this._extractVariables(e))
        }.bind(this), []) : util.toArray(t).reduce(function (t, e) {
            return Object.keys(e)
        }, [])
    },
    isExpressionValid: function (t) {
        t = this._getBareExpression(t);
        return this._evalExpression(t)
    },
    extractExpressionPaths: function (t) {
        var e = t && t.dependencies || [], t = this._getBareExpression(t);
        return util.uniq(this._extractVariables(t).concat(e))
    },
    getGroupsStateKey: function () {
        if (util.isFunction(this.options.stateKey)) return this.options.stateKey(this.getModel());
        throw new Error("Inspector: Option stateKey must be a function")
    },
    storeGroupsState: function () {
        var t = this.getGroupsStateKey(), e = util.toArray(this.$(".group.closed"));
        Inspector.groupStates[t] = e.map(function (t) {
            return t.dataset.name
        })
    },
    getGroupsState: function () {
        return Inspector.groupStates[this.getGroupsStateKey()]
    },
    restoreGroupsState: function () {
        function t(i, t) {
            util.forIn(t.options.groups, function (t, e) {
                i(t, e) ? this.closeGroup(e) : this.openGroup(e)
            }.bind(t))
        }

        var i = this.getGroupsStateKey();
        Inspector.groupStates[i] ? t(function (t, e) {
            return Inspector.groupStates[i].includes(e)
        }, this) : t(function (t) {
            return t.closed
        }, this)
    }
}, {
    groupStates: {}, instance: null, create: function (t, e) {
        util.defaults(e = e || {}, {updateCellOnClose: !0, restoreGroupsState: !0, storeGroupsState: !0});
        var i = e.cell || e.cellView.model, n = this.instance;
        return n && n.getModel() === i || (n && n.el.parentNode && (e.storeGroupsState && n.storeGroupsState(), e.updateCellOnClose && n.updateCell(), n.trigger("close"), n.remove()), n = new this(e).render(), this.instance = n, $$e(t).html(n.el), e.restoreGroupsState && n.restoreGroupsState()), n
    }, close: function () {
        var t, e = this.instance;
        e && (t = document.activeElement, e.el !== t && e.el.contains(t) && t.blur(), e.trigger("close"), e.remove())
    }
}), Keyboard = function (t = {}) {
    util.bindAll(this, "handleKey"), this.options = util.assign({}, t), this.parser = new KeyboardParser, this.enable()
};
util.assign(Keyboard.prototype, mvc.Events), Keyboard.prototype.on = function (t, e, i) {
    return mvc.Events.on.call(this, this.normalizeEvent(t), e, i), this
}, Keyboard.prototype.off = function (t, e, i) {
    t = t ? this.normalizeEvent(t) : null;
    return mvc.Events.off.call(this, t, e, i), this
}, Keyboard.prototype.normalizeEvent = function (t) {
    if ("object" != typeof t) return this.normalizeShortcut(t);
    for (var e = Object.keys(t), i = {}, n = 0, o = e.length; n < o; n++) {
        var s = e[n];
        i[this.normalizeEvent(s)] = t[s]
    }
    return i
}, Keyboard.prototype.normalizeShortcut = function (t) {
    var e = t.toLowerCase();
    if (e in eventNamesMap) return eventNamesMap[e];
    for (var i = this.parser.toEventObjectList(t), n = [], o = 0; o < i.length; o++) n.push(this.hash(i[o]));
    return n.join(" ")
}, Keyboard.prototype.enable = function () {
    window.addEventListener ? (document.addEventListener("keydown", this.handleKey, !1), document.addEventListener("keypress", this.handleKey, !1), document.addEventListener("keyup", this.handleKey, !1)) : window.attachEvent && (document.attachEvent("keydown", this.handleKey, !1), document.attachEvent("keypress", this.handleKey, !1), document.attachEvent("keyup", this.handleKey, !1))
}, Keyboard.prototype.disable = function () {
    window.removeEventListener ? (document.removeEventListener("keydown", this.handleKey, !1), document.removeEventListener("keypress", this.handleKey, !1), document.removeEventListener("keyup", this.handleKey, !1)) : window.detachEvent && (document.detachEvent("keydown", this.handleKey, !1), document.detachEvent("keypress", this.handleKey, !1), document.detachEvent("keyup", this.handleKey, !1))
}, Keyboard.prototype.isActive = function (t, e) {
    return this.isModifierActive(t, e)
}, Keyboard.prototype.isModifierActive = function (t, e) {
    for (var i = this.parser.toEventObjectList(t), n = 0; n < i.length; n++) if (i[n].modifiersCompare(e)) return !0;
    return !1
}, Keyboard.prototype.isKeyPrintable = function (t) {
    return !(!t || (t = t.key, !t) || 1 !== t.length && "Unidentified" !== t)
}, Keyboard.prototype.hash = function (t) {
    return [t.type, ":", t.which, t.shiftKey ? 1 : 0, t.ctrlKey ? 1 : 0, t.altKey ? 1 : 0, t.metaKey ? 1 : 0].join("")
}, Keyboard.prototype.handleKey = function (t) {
    var e = this.options.filter;
    if ("function" == typeof e) {
        if (!e.call(this, t, this)) return
    } else if (this.isConsumerElement(t)) return;
    e = KeyboardEvent.fromNative(t);
    mvc.Events.trigger.call(this, this.hash(e), t), this.isKeyPrintable(t) && mvc.Events.trigger.call(this, t.type + ":printable", t)
}, Keyboard.prototype.isConsumerElement = function (t) {
    var e, t = t.target || t.srcElement;
    return !!t && ("INPUT" === (e = t.tagName.toUpperCase()) || "SELECT" === e || "TEXTAREA" === e || t.isContentEditable)
};
var KeyboardParser = function () {
    }, modifiers = (KeyboardParser.prototype = {
        constructor: KeyboardParser, parseEventString: function (t) {
            for (var e = (t = t || "").split("+"), i = new KeyboardEvent(0), n = 0; n < e.length; n++) {
                var o = e[n], s = this.getModifierPropertyName(o);
                s && (i[s] = !0), 1 !== e.length && void 0 !== s || (i.which = KeyboardParser.getCode(o))
            }
            return i
        }, toEventObjectList: function (t) {
            return t.replace(/\s*\+\s*/gi, "+").split(" ").map(this.composeEventObject, this)
        }, composeEventObject: function (t) {
            var e = t.split(":"), i = Types.KEYDOWN, n = e[0];
            if (1 < e.length && (n = e[1], i = e[0]), -1 === AvailableEventTypes.indexOf(i)) throw t + ": invalid shortcut definition";
            e = this.parseEventString(n);
            return i === Types.KEYUP && modifierMap[e.which] && (e[modifierMap[e.which]] = !1), e.setType(i)
        }, getModifierPropertyName: function (t) {
            t = modifiers[t];
            return modifierMap[t]
        }
    }, KeyboardParser.getCode = function (t) {
        return keyMap[t] || t.toUpperCase().charCodeAt(0)
    }, {
        "\u21e7": 16,
        shift: 16,
        "\u2325": 18,
        alt: 18,
        option: 18,
        "\u2303": 17,
        ctrl: 17,
        control: 17,
        "\u2318": 91,
        command: 91,
        meta: 91
    }), modifierMap = {16: "shiftKey", 18: "altKey", 17: "ctrlKey", 91: "metaKey"},
    charCodeAlternatives = {226: "\\", 57392: "ctrl", 63289: "num", 59: ";", 61: "=", 173: "-"}, keyMap = {
        backspace: 8,
        tab: 9,
        shift: 16,
        ctrl: 17,
        alt: 18,
        meta: 91,
        clear: 12,
        enter: 13,
        return: 13,
        esc: 27,
        escape: 27,
        capslock: 20,
        space: 32,
        left: 37,
        up: 38,
        right: 39,
        down: 40,
        del: 46,
        delete: 46,
        home: 36,
        end: 35,
        insert: 45,
        ins: 45,
        pageup: 33,
        pagedown: 34,
        plus: 187,
        minus: 189,
        "-": 189,
        ",": 188,
        ".": 190,
        "/": 191,
        "`": 192,
        "=": 187,
        ";": 186,
        "'": 222,
        "[": 219,
        "]": 221,
        "\\": 220,
        F1: 112,
        F2: 113,
        F3: 114,
        F4: 115,
        F5: 116,
        F6: 117,
        F7: 118,
        F8: 119,
        F9: 120,
        F10: 121,
        F11: 122,
        F12: 123
    }, eventNamesMap = {
        all: "all",
        printable: "keypress:printable",
        "keypress:printable": "keypress:printable",
        "keydown:printable": "keydown:printable",
        "keyup:printable": "keyup:printable"
    }, Types = (util.assign(Keyboard, {
        keyMap: keyMap,
        modifierMap: modifierMap,
        modifiers: modifiers,
        charCodeAlternatives: charCodeAlternatives,
        eventNamesMap: eventNamesMap
    }), {KEYPRESS: "keypress", KEYDOWN: "keydown", KEYUP: "keyup"}),
    AvailableEventTypes = [Types.KEYPRESS, Types.KEYDOWN, Types.KEYUP], KeyboardEvent = function (t, e, i, n, o, s) {
        this.which = t, this.shiftKey = e || !1, this.ctrlKey = i || !1, this.altKey = n || !1, this.metaKey = o || !1, this.type = s || Types.KEYDOWN
    };
KeyboardEvent.fromNative = function (t) {
    var e = t.which,
        i = (t.type === Types.KEYPRESS && (e = String.fromCharCode(t.which).toUpperCase().charCodeAt(0)), charCodeAlternatives[e] && (e = KeyboardParser.getCode(charCodeAlternatives[e])), new KeyboardEvent(e, t.shiftKey, t.ctrlKey, t.altKey, t.metaKey, t.type));
    return t.type === Types.KEYUP && modifierMap[e] && (i[modifierMap[e]] = !1), i
}, KeyboardEvent.prototype.modifiersCompare = function (t) {
    return !!this.shiftKey && this.shiftKey === t.shiftKey || !!this.ctrlKey && this.ctrlKey === t.ctrlKey || !!this.altKey && this.altKey === t.altKey || !!this.metaKey && this.metaKey === t.metaKey
}, KeyboardEvent.prototype.setType = function (t) {
    return this.type = t, this
};
let $$d = mvc.$, Lightbox = Dialog.extend({
    className: Dialog.prototype.className + " lightbox",
    options: util.merge({}, Dialog.prototype.options, {
        closeButton: !0,
        modal: !0,
        downloadable: !1,
        downloadAction: "download",
        fileName: "Image",
        closeAnimation: {duration: 200, easing: "ease-in-out", properties: {opacity: 0}},
        top: 100,
        windowArea: .8,
        openAnimation: !1
    }),
    init: function () {
        var t;
        util.bindAll(this, "startCloseAnimation", "positionAndScale"), Dialog.prototype.init.apply(this, arguments), this.options.image && (this.$image = $$d("<img/>").on("load", this.positionAndScale), this.options.content = this.$image), this.options.downloadable && (t = {
            action: this.options.downloadAction,
            content: "Download",
            position: "center"
        }, this.buttons = Array.isArray(this.buttons) ? this.buttons.slice() : [], this.buttons.push(t)), this.on("action:" + this.options.downloadAction, this.download), $$d(window).on("resize", this.positionAndScale), this.on("close:animation:complete", () => {
            Dialog.prototype.close.apply(this, arguments)
        })
    },
    open: function () {
        return Dialog.prototype.open.apply(this, arguments), this.$image && this.$image.attr("src", this.options.image), this.positionAndScale(), this.startOpenAnimation(), this
    },
    positionAndScale: function () {
        var t = this.$(".fg"), e = this.$(".body > img"), i = this.$(".titlebar"), n = this.$(".controls"),
            o = this.options.windowArea, s = window.innerWidth * o,
            r = (this.$el.css("margin-top", this.options.top), i.css("width", s), i.height()), a = n.height(),
            o = window.innerHeight * o - this.options.top - r - a, r = (t.css({width: s, height: o}), e.width()),
            a = e.height();
        t.css({width: r, height: a}), i.css("width", "auto"), i.hasClass("empty") || n.css("top", i.outerHeight())
    },
    download: function () {
        util.imageToDataUri(this.options.image, function (t, e) {
            util.downloadDataUri(e, this.options.fileName)
        }.bind(this))
    },
    close: function () {
        return this.options.closeAnimation ? this.startCloseAnimation() : Dialog.prototype.close.apply(this, arguments), this
    },
    onRemove: function () {
        Dialog.prototype.onRemove.apply(this, arguments), $$d(window).off("resize", this.positionAndScale), this.$image && this.$image.off("load", this.positionAndScale)
    },
    startCloseAnimation: function () {
        this.$el.animate(this.options.closeAnimation.properties, util.assign({
            complete: function () {
                this.trigger("close:animation:complete")
            }.bind(this)
        }, this.options.closeAnimation))
    },
    startOpenAnimation: function () {
        this.$el.animate(util.assign({}, this.options.openAnimation.properties, {height: this._foregroundHeight}), util.assign({
            complete: function () {
                this.trigger("open:animation:complete")
            }.bind(this)
        }, this.options.openAnimation))
    }
}), $$c = mvc.$, Navigator = mvc.View.extend({
    className: "navigator",
    events: {mousedown: "startAction", touchstart: "startAction"},
    documentEvents: {mousemove: "doAction", touchmove: "doAction", mouseup: "stopAction", touchend: "stopAction"},
    options: {
        paperConstructor: dia$1.Paper,
        paperOptions: {},
        zoomOptions: null,
        zoom: {min: .5, max: 2},
        width: 300,
        height: 200,
        padding: 10
    },
    init: function () {
        this.options.zoomOptions ? this.options.zoom = util.assign({}, this.options.zoom, this.options.zoomOptions) : this.options.zoom && (this.options.zoom = util.defaults({}, this.options.zoom, this.constructor.prototype.options.zoom)), util.bindAll(this, "updateCurrentView", "doAction", "stopAction", "scrollTo"), this.updateCurrentView = util.debounce(this.updateCurrentView, 0);
        var t = this.options.paperScroller, t = this.sourcePaper = t.options.paper;
        this.toggleUseContentBBox(this.options.useContentBBox), this.targetPaper = new this.options.paperConstructor(util.merge({
            model: t.model,
            interactive: !1,
            frozen: !0
        }, this.options.paperOptions))
    },
    startListening: function () {
        var {options: t, sourcePaper: e} = this, {useContentBBox: t, paperScroller: i, dynamicZoom: n} = t;
        t ? this.listenTo(e, "render:done", this.onPaperRenderDone) : this.listenTo(e, "resize", (t, e, i) => {
            i.aspectRatioPreserved || this.updatePaper()
        }), n ? this.listenTo(i, "scroll", () => this.updatePaper()) : this.listenTo(i, "scroll", () => this.updateCurrentView())
    },
    render: function () {
        var t;
        return this.targetPaper.$el.appendTo(this.el), this.targetPaper.unfreeze(), this.$currentView = $$c("<div>").addClass("current-view"), this.options.zoom && (t = $$c("<div>").addClass("current-view-control"), this.$currentView.append(t)), this.$el.append(this.$currentView).css({
            width: this.options.width,
            height: this.options.height,
            padding: this.options.padding
        }), this.updatePaper(), this
    },
    freeze(t) {
        this.targetPaper.freeze(t)
    },
    unfreeze(t) {
        this.targetPaper.unfreeze(t)
    },
    CONTENT_BBOX_CLASS_NAME: "navigator-use-content-bbox",
    NO_CONTENT_CLASS_NAME: "navigator-no-content",
    toggleUseContentBBox: function (t = !1) {
        var {CONTENT_BBOX_CLASS_NAME: e, $el: i, targetPaper: n} = this;
        this.options.useContentBBox = t, this.stopListening(), this.startListening(), i.toggleClass(e, Boolean(t)), n && this.updatePaper()
    },
    onPaperRenderDone: function (t) {
        t.priority < 2 && this.updatePaper()
    },
    updatePaper: function () {
        var {sourcePaper: t, targetPaper: e, options: i, $el: n, NO_CONTENT_CLASS_NAME: o} = this, {
            useContentBBox: i,
            dynamicZoom: s
        } = i;
        let r;
        r = i ? t.getContentBBox(i) : t.getComputedSize(), s && (r = this.getDynamicContentBBox(r));
        i = n.hasClass(o);
        0 < r.width && 0 < r.height ? (i && (n.removeClass(o), e.unfreeze({key: "navigator"})), this.updatePaperWithBBox(r), this.updateCurrentView()) : i || (n.addClass(o), e.freeze({key: "navigator"}))
    },
    getDynamicContentBBox: function (t) {
        var {sourcePaper: e, options: i} = this;
        return e.localToPaperRect(i.paperScroller.getVisibleArea()).union(t)
    },
    updatePaperWithBBox: function (i) {
        var {width: i, height: n, x: o = 0, y: s = 0} = i;
        if (i && n) {
            var {
                    borderLeftWidth: r,
                    borderRightWidth: a,
                    borderTopWidth: l,
                    borderBottomWidth: h
                } = getComputedStyle(this.el), r = parseFloat(r) + parseFloat(a), a = parseFloat(l) + parseFloat(h),
                r = isFinite(r) ? r : 0, a = isFinite(a) ? a : 0, {
                    sourcePaper: l,
                    targetPaper: h,
                    options: c
                } = this, {a: l, d, e: u, f: p} = l.matrix(), {padding: g, preserveAspectRatio: m = !0} = c;
            let t = (c.width - 2 * g - r) / (i /= l), e = (c.height - 2 * g - a) / (n /= d);
            m && (r = Math.min(t, e), t = r, e = r), this.ratioX = t, this.ratioY = e, i *= t, n *= e;
            c = (u - o) * t / l, g = (p - s) * e / d, a = (h.setDimensions(i, n), h.matrix());
            a.e = c, a.f = g, a.a = t, a.d = e, h.matrix(a)
        }
    },
    updateCurrentView: function () {
        var t, e, i, n, o, s, r;
        this.$currentView && (t = this.ratioX, e = this.ratioY, i = this.sourcePaper.scale(), o = (n = this.options.paperScroller).clientToLocalPoint(0, 0), s = this.targetPaper.$el.position(), (r = this.targetPaper.translate()).ty = r.ty || 0, this.currentViewGeometry = {
            top: s.top + o.y * e + r.ty,
            left: s.left + o.x * t + r.tx,
            width: n.el.clientWidth * t / i.sx,
            height: n.el.clientHeight * e / i.sy
        }, this.$currentView.css(this.currentViewGeometry))
    },
    startAction: function (t) {
        var {clientX: e, clientY: i} = t = util.normalizeEvent(t),
            n = t.target.classList.contains("current-view-control"),
            n = (!n && !t.target.classList.contains("current-view") && this.scrollTo(t), n ? "zooming" : "panning"), {
                options: o,
                currentViewGeometry: s,
                sourcePaper: r
            } = this, o = o.paperScroller;
        switch (this.delegateDocumentEvents(null, {
            action: n,
            startClientX: e,
            startClientY: i,
            startScrollLeft: o.el.scrollLeft,
            startScrollTop: o.el.scrollTop,
            startZoom: o.zoom(),
            startGeometry: s,
            startScale: r.scale()
        }), n) {
            case"panning":
                this.trigger("pan:start", t);
                break;
            case"zooming":
                this.trigger("zoom:start", t)
        }
    },
    doAction: function (t) {
        var {clientX: e, clientY: i, data: n} = t = util.normalizeEvent(t), {
            sourcePaper: o,
            options: t,
            ratioX: s,
            ratioY: r
        } = this;
        let {
            action: a,
            startClientX: l,
            startClientY: h,
            startScrollLeft: c,
            startScrollTop: d,
            startZoom: u,
            startGeometry: p,
            startScale: g,
            frameId: m
        } = n, {paperScroller: f, zoom: v} = t;
        switch (a) {
            case"panning":
                var {sx: y, sy: x} = o.scale(), x = (i - h) * x;
                f.el.scrollLeft = c + (e - l) * y / s, f.el.scrollTop = d + x / r;
                break;
            case"zooming": {
                y = p.width;
                let t = 1 + (l - e) / y / g.sx;
                util.cancelFrame(m), n.frameId = util.nextFrame(() => {
                    f.zoom(t * u, util.defaults({absolute: !0}, v))
                });
                break
            }
        }
    },
    stopAction: function (t) {
        switch (this.undelegateDocumentEvents(), t.data.action) {
            case"panning":
                this.trigger("pan:stop", t);
                break;
            case"zooming":
                this.trigger("zoom:stop", t)
        }
    },
    scrollTo: function (t) {
        t = util.normalizeEvent(t);
        var {x: t, y: e} = this.targetPaper.clientToLocalPoint({x: t.clientX, y: t.clientY}),
            i = this.options.paperScroller;
        i.scroll(t, e)
    },
    onRemove: function () {
        this.targetPaper.remove()
    }
}), Inertia = function (t, e) {
    this.options = util.assign({friction: .92}, e), this.onInertiaMove = t, this._isDragging = !1, this.initialize()
};

function swing(t) {
    return t <= 0 ? 0 : 1 <= t ? 1 : .5 - Math.cos(t * Math.PI) / 2
}

function animateScroll(o, t, e) {
    let {duration: i = 400, timingFunction: s = swing, complete: r} = e, a = Date.now(), l = a + i, h = o.scrollLeft,
        c = o.scrollTop;
    e = t.scrollLeft || h, t = t.scrollTop || c;
    let d = e - h, u = t - c, p;
    return function t() {
        var e = Date.now(), i = (e - a) / (l - a), i = s(i), n = Math.round(h + d * i), i = Math.round(c + u * i);
        o.scrollLeft = n, o.scrollTop = i, e >= l ? r && r() : p = setTimeout(t, 0)
    }(), () => clearTimeout(p)
}

Inertia.prototype.initialize = function () {
    this._dragLastX = 0, this._dragLastY = 0, this._dragDeltaX = 0, this._dragDeltaY = 0, this._dragLastDeltaX = 0, this._dragLastDeltaY = 0, this._velocityX = 0, this._velocityY = 0, this._requestAnimationFrameId = -1
}, Inertia.prototype.approxZero = function (t) {
    return Math.abs(t) < .5
}, Inertia.prototype.updateVelocity = function () {
    var {_velocityX: t, _velocityY: e, _isDragging: i, options: n, onInertiaMove: o} = this;
    !i && this.approxZero(t) && this.approxZero(e) ? this.initialize() : (this._requestAnimationFrameId = util.nextFrame(this.updateVelocity.bind(this)), i ? (this._dragLastDeltaX = this._dragDeltaX, this._dragLastDeltaY = this._dragDeltaY, this._dragDeltaX = this._dragLastX, this._dragDeltaY = this._dragLastY, this._velocityX = this._dragDeltaX - this._dragLastDeltaX, this._velocityY = this._dragDeltaY - this._dragLastDeltaY) : (i = t, t = e, e = n.friction, this._velocityX *= e, this._velocityY *= e, "function" == typeof o && o(i, t)))
}, Inertia.prototype.handleDragStart = function (t) {
    this._isDragging = !0, util.cancelFrame(this._requestAnimationFrameId), this.initialize(), this._dragLastX = t.clientX, this._dragLastY = t.clientY, this._dragDeltaX = t.clientX, this._dragDeltaY = t.clientY, this.updateVelocity()
}, Inertia.prototype.handleDragMove = function (t) {
    this._dragLastX = t.clientX, this._dragLastY = t.clientY
}, Inertia.prototype.handleDragEnd = function (t) {
    this._isDragging = !1
};
let MIN_CELL_SIZE = 1;

class VirtualRenderingController extends mvc.Listener {
    frameId = null;
    viewportBBox = null;
    _isRunning = !1;

    constructor(t, e = {}) {
        super(), this.callbackArguments = [], this.options = util.defaults({}, e, {
            cellVisibility: null,
            margin: 0,
            prioritizedCellVisibility: !0
        }), this.paperScroller = t, this.paper = t.options.paper, this.viewportBBox = null, this.frameId = null, this.start()
    }

    start() {
        this.setPaperCellVisibility(), this.cacheCurrentViewportBBox(), this.requestUpdate(), this.startListening(), this._isRunning = !0
    }

    stop() {
        this.stopListening(), this.cancelUpdate(), this.paper && (this.paper.options.cellVisibility = null), this._isRunning = !1
    }

    get isRunning() {
        return this._isRunning
    }

    startListening() {
        this.stopListening();
        var t = () => this.requestUpdate();
        this.listenTo(this.paperScroller, "scroll", t), this.listenTo(this.paper, "transform", t)
    }

    setPaperCellVisibility() {
        var t = this.paper;
        t.legacyMode && this.throwError("Paper cannot be in legacy mode to enable virtual rendering."), t.isAsync() || this.throwError("Paper must be in async mode to enable virtual rendering."), t.options.cellVisibility && this.throwError('Paper "cellVisibility" is already set. The controller cannot override it.'), t.options.cellVisibility = this.getPaperCellVisibilityCallback()
    }

    getPaperCellVisibilityCallback() {
        let n = this.options.cellVisibility;
        return "function" == typeof n ? (t, e, i) => !!n.call(i, t, e, i) && this.isCellInCachedViewport(t) : t => this.isCellInCachedViewport(t)
    }

    isCellInCachedViewport(t) {
        var e = t.getBBox();
        return t.isLink() && (0 === e.width && (e.width = MIN_CELL_SIZE), 0 === e.height) && (e.height = MIN_CELL_SIZE), g.intersection.exists(this.viewportBBox, e)
    }

    cacheCurrentViewportBBox() {
        var {paperScroller: t, options: e} = this;
        this.viewportBBox = t.getVisibleArea().inflate(e.margin)
    }

    requestUpdate() {
        this.frameId || (this.frameId = util.nextFrame(() => {
            this.frameId = null, this.updateViewportCellsVisibility()
        }))
    }

    cancelUpdate() {
        this.frameId && (util.cancelFrame(this.frameId), this.frameId = null)
    }

    updateViewportCellsVisibility() {
        var {paperScroller: t, paper: e} = this, i = this.options.prioritizedCellVisibility;
        this.cacheCurrentViewportBBox(), i && ("function" != typeof i || i(t)) && this.prioritizeViewportCellsVisibility(), e.wakeUp()
    }

    prioritizeViewportCellsVisibility() {
        var {paper: e, viewportBBox: t} = this;
        if (t) {
            var i = e.model.findCellsInArea(t);
            for (let t = 0; t < i.length; t++) e.prioritizeCellViewMount(i[t])
        }
    }

    throwError(t) {
        throw new Error("VirtualRenderingController: " + t)
    }
}

let $$b = mvc.$, PaperScroller = mvc.View.extend({
    className: "paper-scroller",
    events: {scroll: "onScroll"},
    options: {
        paper: void 0,
        padding: function () {
            var t = this.getClientSize(), e = Math.max(this.options.minVisiblePaperSize, 1) || 1, i = {};
            return i.left = i.right = Math.max(t.width - e, 0), i.top = i.bottom = Math.max(t.height - e, 0), i
        },
        scrollWhileDragging: !1,
        minVisiblePaperSize: 50,
        autoResizePaper: !1,
        baseWidth: void 0,
        baseHeight: void 0,
        contentOptions: void 0,
        cursor: "default",
        inertia: !1,
        borderless: !1
    },
    _padding: {left: 0, top: 0},
    virtualRenderingController: null,
    DETACHABLE: !1,
    init: function () {
        util.bindAll(this, "startPanning", "stopPanning", "pan", "onBackgroundEvent");
        var {options: t, el: e} = this, {
            paper: i,
            autoResizePaper: n,
            scrollWhileDragging: o,
            cursor: s,
            inertia: r,
            baseWidth: a,
            baseHeight: l,
            virtualRendering: h
        } = t, c = i.scale(), {width: c, height: d} = (this._sx = c.sx, this._sy = c.sy, i.options);
        if (!Number.isFinite(c) || !Number.isFinite(d)) throw new Error("PaperScroller: paper dimension must be a number");
        void 0 === a && (t.baseWidth = c), void 0 === l && (t.baseHeight = d), i.el.style.setProperty("position", "absolute"), this.$background = $$b("<div/>").addClass("paper-scroller-background").css({
            width: i.options.width,
            height: i.options.height
        }).append(i.el).appendTo(e), this.listenTo(i, "scale", this.onPaperScale).listenTo(i, "resize translate", this.onPaperResize).listenTo(i, "beforeprint beforeexport", this.storeScrollPosition).listenTo(i, "afterprint afterexport", this.restoreScrollPosition), n && (h || n.useGraphEvents ? (this.listenTo(i.model, "add remove change reset", this.onGraphChange), this.requestPaperSizeUpdate()) : this.listenTo(i, "render:done", this.onPaperRenderDone)), o && (this.listenTo(i, "cell:pointermove", this.onCellPointermove), this.listenTo(i, "cell:pointerup", this.onCellPointerup)), this.debouncedStoreCenter = util.debounce(() => this.storeCenter()), this.storeCenter(i.options.width / 2, i.options.height / 2), this.delegateBackgroundEvents(), this.setCursor(s), r && (this.inertia = new Inertia(function (t, e) {
            var i = this.el;
            i.scrollTop -= e, i.scrollLeft -= t
        }.bind(this), r)), this.createObservers(), h && (this.virtualRenderingController = new VirtualRenderingController(this, h))
    },
    createObservers: function () {
        var t = new ResizeObserver(() => this.onResize());
        t.observe(this.el), this.resizeObserver = t
    },
    onCellPointermove: function (t, e, i, n) {
        var o = this.options.scrollWhileDragging;
        o && this.scrollWhileDragging(e, i, n, o)
    },
    onCellPointerup: function (t, e) {
        this.stopScrollWhileDragging(e)
    },
    scrollWhileDragging: function (t, e, i, n = {}) {
        var o = this.el, {interval: n = 25, padding: s = -20, scrollingFunction: r = t => t < 20 ? 5 : 20} = n,
            a = this.eventData(t).scrollId, l = new g.Point(e, i), {
                top: s,
                left: h,
                right: c,
                bottom: d
            } = util.normalizeSides(s),
            h = this.getVisibleArea().moveAndExpand({x: -h, y: -s, width: h + c, height: s + d});
        h.containsPoint(l) ? (clearInterval(a), this.eventData(t, {scrollId: null})) : (c = h.pointNearestToPoint(l).distance(l), s = r.call(this, c, t), {
            x: d,
            y: l,
            width: r,
            height: c
        } = h, this.eventData(t, {
            scrollX: e < d ? -1 : d + r < e ? 1 : 0,
            scrollY: i < l ? -1 : l + c < i ? 1 : 0,
            scrollPerTick: s,
            container: o
        }), a || (h = this.eventData(t), a = setInterval(({scrollPerTick: t, scrollX: e, scrollY: i, container: n}) => {
            n.scrollLeft += t * e, n.scrollTop += t * i
        }, n, h), h.scrollId = a))
    },
    stopScrollWhileDragging: function (t) {
        t = this.eventData(t).scrollId;
        t && clearInterval(t)
    },
    requestPaperSizeUpdate: function () {
        var t = this.options.paper;
        t.requestViewUpdate(this, 1, this.UPDATE_PRIORITY)
    },
    confirmUpdate: function () {
        return this.adjustPaper(), 0
    },
    onPaperRenderDone: function (t) {
        t.priority < 2 && this.adjustPaper()
    },
    onGraphChange: function () {
        this.requestPaperSizeUpdate()
    },
    lock: function () {
        return this.$el.css("overflow", "hidden"), this
    },
    unlock: function () {
        return this.$el.css("overflow", "scroll"), this
    },
    setCursor: function (t) {
        return "grab" === t ? this.$el.css("cursor", "") : this.$el.css("cursor", t), this.$el.attr("data-cursor", t), this.options.cursor = t, this
    },
    delegateBackgroundEvents: function (n) {
        n = n || util.result(this.options.paper, "events");
        var t = this.paperEvents = Object.keys(n || {}).reduce(function (t, e) {
            var i = n[e];
            -1 === e.indexOf(" ") && (t[e] = util.isFunction(i) ? i : this.options.paper[i]);
            return t
        }.bind(this), {});
        return Object.keys(t).forEach(function (t) {
            this.delegate(t, {guarded: !1}, this.onBackgroundEvent)
        }, this), this
    },
    onBackgroundEvent: function (t) {
        var [e] = this.$background;
        e === t.target && (e = this.paperEvents[t.type], util.isFunction(e)) && e.apply(this.options.paper, arguments)
    },
    onScroll: function (t) {
        this.trigger("scroll", t), this.debouncedStoreCenter()
    },
    onResize: function () {
        this.storeCenter(), this.virtualRenderingController?.isRunning && this.virtualRenderingController.requestUpdate()
    },
    onPaperResize: function () {
        this.restoreCenter()
    },
    onPaperScale: function (t, e) {
        this.adjustScale(t, e);
        var {contentOptions: t, borderless: e} = this.options;
        "function" != typeof t && !e || this.adjustPaper()
    },
    storeScrollPosition: function () {
        this._scrollLeftBeforePrint = this.el.scrollLeft, this._scrollTopBeforePrint = this.el.scrollTop
    },
    restoreScrollPosition: function () {
        this.el.scrollLeft = this._scrollLeftBeforePrint, this.el.scrollTop = this._scrollTopBeforePrint, this._scrollLeftBeforePrint = null, this._scrollTopBeforePrint = null
    },
    beforePaperManipulation: function () {
        (env.test("msie") || env.test("msedge")) && this.$el.css("visibility", "hidden")
    },
    afterPaperManipulation: function () {
        (env.test("msie") || env.test("msedge")) && this.$el.css("visibility", "visible")
    },
    clientToLocalPoint: function (t, e) {
        var i = this.options.paper.matrix();
        return t = (t += this.getLTRScrollLeft() - this._padding.left - i.e) / i.a, e = (e += this.el.scrollTop - this._padding.top - i.f) / i.d, new g.Point(t, e)
    },
    localToBackgroundPoint: function (t, e) {
        var t = new g.Point(t, e), e = this.options.paper.matrix(), i = this._padding;
        return V.transformPoint(t, e).offset(i.left, i.top)
    },
    getPadding: function () {
        var t = this.options.padding;
        return util.isFunction(t) && (t = t.call(this, this)), util.normalizeSides(t)
    },
    computeRequiredPadding: function (t) {
        var {sx: e, sy: i} = this.options.paper.scale(), {x: n, y: o} = this.getCenter(), e = (n *= e, o *= i, t.x),
            i = t.y, s = e + t.width, t = i + t.height, r = this.getClientSize(), a = r.width / 2,
            r = r.height / 2, {left: l, right: h, top: c, bottom: d} = this.getPadding();
        return {
            left: Math.max(a - l - n + e, 0) + l,
            right: Math.max(a - h + n - s, 0) + h,
            top: Math.max(r - c - o + i, 0) + c,
            bottom: Math.max(r - d + o - t, 0) + d
        }
    },
    addPadding: function () {
        var t, {borderless: e, paper: i} = this.options;
        let n, o, s, r, a;
        e ? (n = {left: 0, right: 0, top: 0, bottom: 0}, o = s = r = a = 0) : ({
            sx: e,
            sy: t
        } = i.scale(), l = i.getArea(), n = this.computeRequiredPadding(l.scale(e, t, {
            x: 0,
            y: 0
        })), o = Math.round(n.left), s = Math.round(n.right), r = Math.round(n.top), a = Math.round(n.bottom)), this._padding = {
            left: o,
            top: r,
            bottom: a,
            right: s
        };
        var {width: l, height: e} = i.getComputedSize();
        return this.$background.css({
            width: Math.round(n.left + l + n.right),
            height: Math.round(n.top + e + n.bottom)
        }), i.$el.css({left: o, top: r}), this
    },
    storeCenter: function (t, e) {
        t = util.isNumber(t) ? new g.Point(t, e) : this.computeCenter();
        this._center = t
    },
    restoreCenter: function () {
        var t = this._center;
        t && this.center(t.x, t.y)
    },
    getCenter: function () {
        return this._center || (this._center = this.options.paper.getArea().center()), this._center
    },
    computeCenter: function () {
        var {width: t, height: e} = this.getClientSize();
        return this.clientToLocalPoint(t / 2, e / 2)
    },
    adjustPaper: function () {
        let {paper: t, borderless: e, contentOptions: i} = this.options;
        "function" == typeof i && (i = i.call(this, this));
        var n, o, s, r, a, l = util.assign({
            useModelGeometry: !!this.options.virtualRendering,
            gridWidth: this.options.baseWidth,
            gridHeight: this.options.baseHeight,
            allowNewOrigin: "negative"
        }, i);
        return e ? (n = t.getFitToContentArea(this.transformContentOptions(l)), {sx: o, sy: s} = t.scale(), {
            left: o,
            right: s,
            top: r,
            bottom: a
        } = (n.x *= o, n.y *= s, n.width *= o, n.height *= s, this.computeRequiredPadding(n)), n.moveAndExpand({
            x: -o,
            y: -r,
            width: o + s,
            height: r + a
        }), t.translate(-n.x, -n.y), t.setDimensions(n.width, n.height)) : t.fitToContent(this.transformContentOptions(l)), this
    },
    adjustScale: function (t, e) {
        var i = this.options.paper, n = i.options, o = t / this._sx, s = e / this._sy, {tx: r, ty: a} = i.translate();
        this._sx = t, this._sy = e, i.translate(r * o, a * s), i.setDimensions(n.width * o, n.height * s, {aspectRatioPreserved: !0})
    },
    transformContentOptions: function (t) {
        var e = this._sx, i = this._sy;
        return t.gridWidth && (t.gridWidth *= e), t.gridHeight && (t.gridHeight *= i), t.minWidth && (t.minWidth *= e), t.minHeight && (t.minHeight *= i), util.isObject(t.padding) ? t.padding = {
            left: (t.padding.left || 0) * e,
            right: (t.padding.right || 0) * e,
            top: (t.padding.top || 0) * i,
            bottom: (t.padding.bottom || 0) * i
        } : util.isNumber(t.padding) && (t.padding = t.padding * e), t
    },
    center: function (t, e, i) {
        var n = this.options.paper, {a: o, d: s, e: r, f: a} = n.matrix(), l = util.isNumber(t), h = util.isNumber(e);
        let c;
        return l || h ? (c = i, l || (t = this.getVisibleArea().center().x), h || (e = this.getVisibleArea().center().y)) : (c = t, t = -r + (i = n.getComputedSize()).width / 2, e = -a + i.height / 2, t /= o, e /= s), this.storeCenter(t, e), this.addPadding(), this.scroll(t, e, c), this
    },
    centerContent: function (t) {
        return this.positionContent("center", t)
    },
    centerElement: function (t, e) {
        return this.checkElement(t, "centerElement"), this.positionElement(t, "center", e)
    },
    positionContent: function (t, e) {
        var i = this.options.paper.getContentArea(e);
        return this.positionRect(i, t, e)
    },
    positionElement: function (t, e, i) {
        this.checkElement(t, "positionElement");
        t = t.getBBox();
        return this.positionRect(t, e, i)
    },
    positionRect: function (t, e, i) {
        var n;
        switch (e) {
            case"center":
                return n = t.center(), this.positionPoint(n, "50%", "50%", i);
            case"top":
                return n = t.topMiddle(), this.positionPoint(n, "50%", 0, i);
            case"top-right":
                return n = t.topRight(), this.positionPoint(n, "100%", 0, i);
            case"right":
                return n = t.rightMiddle(), this.positionPoint(n, "100%", "50%", i);
            case"bottom-right":
                return n = t.bottomRight(), this.positionPoint(n, "100%", "100%", i);
            case"bottom":
                return n = t.bottomMiddle(), this.positionPoint(n, "50%", "100%", i);
            case"bottom-left":
                return n = t.bottomLeft(), this.positionPoint(n, 0, "100%", i);
            case"left":
                return n = t.leftMiddle(), this.positionPoint(n, 0, "50%", i);
            case"top-left":
                return n = t.topLeft(), this.positionPoint(n, 0, 0, i);
            default:
                throw new Error("Provided positionName ('" + e + "') was not recognized.")
        }
    },
    positionPoint: function (t, e, i, n) {
        var o = util.normalizeSides((n = n || {}).padding), s = new g.Rect(this.getClientSize()),
            o = s.clone().moveAndExpand({x: o.left, y: o.top, width: -o.right - o.left, height: -o.top - o.bottom}),
            r = util.isPercentage(e),
            r = (e = parseFloat(e), (e = r ? e / 100 * Math.max(0, o.width) : e) < 0 && (e = o.width + e), util.isPercentage(i)),
            r = (i = parseFloat(i), (i = r ? i / 100 * Math.max(0, o.height) : i) < 0 && (i = o.height + i), o.origin().offset(e, i)),
            o = s.center().difference(r), e = this.zoom(), i = o.scale(1 / e, 1 / e), s = t.clone().offset(i);
        return this.center(s.x, s.y, n)
    },
    scroll: function (t, e, i) {
        var n, o = this.options.paper.matrix(), s = this.getClientSize(), r = {};
        util.isNumber(t) && (n = s.width / 2, r.scrollLeft = this.getScrollLeftFromLTR(t * o.a - n + o.e + (this._padding.left || 0))), util.isNumber(e) && (t = s.height / 2, r.scrollTop = e * o.d - t + o.f + (this._padding.top || 0)), i && i.animation ? (this._cancelAnimation && this._cancelAnimation(), this._cancelAnimation = animateScroll(this.el, r, i.animation)) : (n = this.el, void 0 !== r.scrollLeft && (n.scrollLeft = r.scrollLeft), void 0 !== r.scrollTop && (n.scrollTop = r.scrollTop))
    },
    scrollToContent: function (t) {
        var e = this.options.paper.getContentArea(t).center();
        return this.scroll(e.x, e.y, t)
    },
    scrollToElement: function (t, e) {
        this.checkElement(t, "scrollToElement");
        t = t.getCenter();
        return this.scroll(t.x, t.y, e)
    },
    zoom: function (t, e = {}) {
        if (void 0 === t) return this._sx;
        var i, n, o = this.computeCenter(), s = t;
        if (!e.absolute) {
            let i = 1e12;
            var r = (t, e) => (t * i + e * i) / i, s = r(this._sx, s), t = r(this._sy, t)
        }
        return e.grid && (s = Math.round(s / e.grid) * e.grid, t = Math.round(t / e.grid) * e.grid), e.max && (s = Math.min(e.max, s), t = Math.min(e.max, t)), e.min && (s = Math.max(e.min, s), t = Math.max(e.min, t)), r = void 0 === e.ox || void 0 === e.oy ? (n = o.x, o.y) : (r = s / this._sx, i = t / this._sy, n = e.ox - (e.ox - o.x) / r, e.oy - (e.oy - o.y) / i), this.beforePaperManipulation(), this.options.paper.scale(s, t), this.center(n, r), this.afterPaperManipulation(), this
    },
    zoomToRect: function (t, e = {}) {
        t = new g.Rect(t);
        var i, n = this.options.paper, o = util.assign({}, n.options.origin),
            o = (e.fittingBBox || (i = this.el.getBoundingClientRect(), e.fittingBBox = util.assign({}, new g.Point(o), {
                width: i.width,
                height: i.height
            })), e.contentArea = t, this.beforePaperManipulation(), n.scaleContentToFit(e), t.center());
        return this.adjustPaper(), this.center(o.x, o.y), this.afterPaperManipulation(), this
    },
    zoomToFit: function (t = {}) {
        var e = this.options.paper.getContentArea(t);
        return this.zoomToRect(e, t), this
    },
    transitionClassName: "transition-in-progress",
    transitionEventName: "transitionend.paper-scroller-transition",
    transitionToPoint: function (t, e, i) {
        util.isObject(t) && (i = e, e = t.y, t = t.x), i = i || {};
        var n, o, s = this._sx, r = Math.max(i.scale || s, 1e-6), a = new g.Point(t, e), l = this.computeCenter();
        return s === r ? n = "translate(" + (n = l.difference(a).scale(s, s).round()).x + "px," + n.y + "px)" : (o = r / (s - r) * a.distance(l), l = l.clone().move(a, o), n = "scale(" + r / s + ")", o = (a = this.localToBackgroundPoint(l).round()).x + "px " + a.y + "px"), this.$el.addClass(this.transitionClassName), this.$background.off(this.transitionEventName).on(this.transitionEventName, function (t) {
            var e = this.paperScroller,
                i = (e.syncTransition(this.scale, {x: this.x, y: this.y}), this.onTransitionEnd);
            util.isFunction(i) && i.call(e, t)
        }.bind({
            paperScroller: this,
            scale: r,
            x: t,
            y: e,
            onTransitionEnd: i.onTransitionEnd
        })).css({
            transition: "transform",
            transitionDuration: i.duration || "1s",
            transitionDelay: i.delay,
            transitionTimingFunction: i.timingFunction,
            transformOrigin: o,
            transform: n
        }), this
    },
    syncTransition: function (t, e) {
        return this.beforePaperManipulation(), this.options.paper.scale(t), this.removeTransition().center(e.x, e.y), this.afterPaperManipulation(), this
    },
    removeTransition: function () {
        return this.$el.removeClass(this.transitionClassName), this.$background.off(this.transitionEventName).css({
            transition: "",
            transitionDuration: "",
            transitionDelay: "",
            transitionTimingFunction: "",
            transform: "",
            transformOrigin: ""
        }), this
    },
    transitionToRect: function (t, e = {}) {
        t = new g.Rect(t);
        var i = e.maxScale || 1 / 0, n = e.minScale || Number.MIN_VALUE, o = e.scaleGrid || null, s = e.visibility || 1,
            r = e.center ? new g.Point(e.center) : t.center(), a = this.getClientSize(), l = a.width * s,
            a = a.height * s;
        let h = new g.Rect({x: r.x - l / 2, y: r.y - a / 2, width: l, height: a}).maxRectUniformScaleToFit(t, r);
        return h = Math.min(h, i), o && (h = Math.floor(h / o) * o), h = Math.max(n, h), this.transitionToPoint(r, util.defaults({scale: h}, e)), this
    },
    startPanning: function (t) {
        t = util.normalizeEvent(t), this._clientX = t.clientX, this._clientY = t.clientY, this.trigger("pan:start", t), this.delegatePanning(), this.options.inertia && this.inertia.handleDragStart(t)
    },
    pan: function (t) {
        var e = (t = util.normalizeEvent(t)).clientX - this._clientX, i = t.clientY - this._clientY;
        this.el.scrollTop -= i, this.el.scrollLeft -= e, this._clientX = t.clientX, this._clientY = t.clientY, this.options.inertia && this.inertia.handleDragMove(t)
    },
    stopPanning: function (t) {
        this.undelegatePanning(), t = t && util.normalizeEvent(t), this.trigger("pan:stop", t), this.options.inertia && this.inertia.handleDragEnd(t)
    },
    delegatePanning() {
        this.$el.addClass("is-panning"), this.delegateDocumentEvents({
            mousemove: "pan",
            touchmove: "pan",
            mouseup: "stopPanning",
            touchend: "stopPanning",
            touchcancel: "stopPanning"
        })
    },
    undelegatePanning() {
        this.$el.removeClass("is-panning"), this.undelegateDocumentEvents()
    },
    getClientSize: function () {
        var {clientWidth: t, clientHeight: e} = this.el;
        return {width: t, height: e}
    },
    getVisibleArea: function () {
        var t = this.options.paper.matrix(), e = this.getClientSize(),
            e = {x: this.getLTRScrollLeft(), y: this.el.scrollTop || 0, width: e.width, height: e.height},
            e = V.transformRect(e, t.inverse());
        return e.x -= (this._padding.left || 0) / this._sx, e.y -= (this._padding.top || 0) / this._sy, new g.Rect(e)
    },
    isElementVisible: function (t, e) {
        this.checkElement(t, "isElementVisible");
        e = (e = e || {}).strict ? "containsRect" : "intersect";
        return !!this.getVisibleArea()[e](t.getBBox())
    },
    isPointVisible: function (t) {
        return this.getVisibleArea().containsPoint(t)
    },
    checkElement: function (t, e) {
        if (!(t && t instanceof dia$1.Element)) throw new TypeError("ui.PaperScroller." + e + "() accepts instance of dia.Element only")
    },
    onRemove: function () {
        this.undelegatePanning(), this.resizeObserver.disconnect(), this.virtualRenderingController?.stop()
    },
    isRTLDirection() {
        return "rtl" === getComputedStyle(this.el).direction
    },
    getLTRScrollLeft() {
        var t, e, i, n = this.el;
        return this.isRTLDirection() ? ({scrollLeft: t, scrollWidth: e, clientWidth: i} = n, e - i + t) : n.scrollLeft
    },
    getScrollLeftFromLTR(t) {
        var e, i;
        return this.isRTLDirection() ? ({scrollWidth: e, clientWidth: i} = this.el, t - (e - i)) : t
    }
}, {VirtualRenderingController: VirtualRenderingController}), $$a = (env.addTest("msie", function () {
    var t = window.navigator.userAgent;
    return -1 !== t.indexOf("MSIE") || -1 !== t.indexOf("Trident")
}), env.addTest("msedge", function () {
    return /Edge\/\d+/.test(window.navigator.userAgent)
}), mvc.$), PathDrawer = mvc.View.extend({
    tagName: "g",
    svgElement: !0,
    className: "path-drawer",
    events: {
        "mousedown .start-point": "onStartPointPointerDown",
        mousedown: "onPointerDown",
        "touchstart .start-point": "onStartPointPointerDown",
        touchstart: "onPointerDown",
        dblclick: "onDoubleClick",
        contextmenu: "onContextMenu"
    },
    documentEvents: {
        mousemove: "onPointerMove",
        touchmove: "onPointerMove",
        mouseup: "onPointerUp",
        touchend: "onPointerUp",
        touchcancel: "onPointerUp"
    },
    options: {
        pathAttributes: {
            class: null,
            fill: "#ffffff",
            stroke: "#000000",
            "stroke-width": 1,
            "pointer-events": "none"
        }, startPointMarkup: '<circle r="5"/>', snapRadius: 0, enableCurves: !0
    },
    init: function () {
        var t = this.svgTarget = V(this.options.target);
        this.path = new g.Path, this.$document = $$a(t.node.ownerDocument), this.action = "awaiting-input", this.render()
    },
    onRemove: function () {
        var t = this.pathNode;
        t && V(t).remove(), this.clear()
    },
    clear: function () {
        var {path: t, pathNode: e} = this;
        e && t && t.segments.length <= 1 && V(e).remove(), this.svgStart.remove(), this.svgControl.remove(), this.pathNode = null, this.path = new g.Path, this.undelegateDocumentEvents(), this.action = "awaiting-input", this.trigger("clear")
    },
    render: function () {
        var t = this.options;
        return this.svgPathTemplate = V("path").attr(t.pathAttributes), this.svgStart = V(t.startPointMarkup).addClass("start-point"), this.svgControl = V("path").addClass("control-path"), this.vel.append(V("rect", {
            x: 0,
            y: 0,
            width: "100%",
            height: "100%",
            fill: "transparent",
            stroke: "none"
        })), this.svgTarget.append(this.el), this
    },
    createPath: function (t, e) {
        var i = this.svgPathTemplate.clone(), n = this.pathNode = i.node,
            o = this.svgStart.translate(t, e, {absolute: !0});
        this.trigger("path:create", n), this.addMoveSegment(t, e), this.vel.before(i), this.vel.append(o)
    },
    closePath: function () {
        var {path: t, pathNode: e} = this, i = t.getSegment(0), n = t.getSegment(t.segments.length - 1);
        "L" === n.type ? t.replaceSegment(t.segments.length - 1, g.Path.createSegment("Z")) : (n.end.x = i.end.x, n.end.y = i.end.y, t.appendSegment(g.Path.createSegment("Z"))), e.setAttribute("d", t.toString()), this.finishPath("path:close")
    },
    finishPath: function (t) {
        var {path: e, pathNode: i} = this;
        e && 0 < this.numberOfVisibleSegments() ? (this.trigger("path:finish", i), this.trigger(t, i)) : this.trigger("path:abort", i), this.clear()
    },
    numberOfVisibleSegments: function () {
        var t = this.path;
        let e = t.segments.length;
        return --e, "Z" === t.getSegment(t.segments.length - 1).type && --e, e
    },
    addMoveSegment: function (t, e) {
        var {path: i, pathNode: n} = this, t = g.Path.createSegment("M", t, e);
        i.appendSegment(t), n.setAttribute("d", i.toString()), this.trigger("path:segment:add", n), this.trigger("path:move-segment:add", n)
    },
    addLineSegment: function (t, e) {
        var {path: i, pathNode: n} = this, t = g.Path.createSegment("L", t, e);
        i.appendSegment(t), n.setAttribute("d", i.toString()), this.trigger("path:segment:add", n), this.trigger("path:line-segment:add", n)
    },
    addCurveSegment: function (t, e, i, n, o, s) {
        var {path: r, pathNode: a} = this, i = g.Path.createSegment("C", i, n, o || t, s || e, t, e);
        r.appendSegment(i), a.setAttribute("d", r.toString()), this.trigger("path:segment:add", a), this.trigger("path:curve-segment:add", a)
    },
    adjustLastSegment: function (t, e, i, n, o, s) {
        var {path: r, pathNode: a} = this, l = this.options.snapRadius,
            l = (l && (t = (l = this.snapLastSegmentCoordinates(t, e, l)).x, e = l.y), r.getSegment(r.segments.length - 1));
        null != t && (l.end.x = t), null != e && (l.end.y = e), null != i && (l.controlPoint1.x = i), null != n && (l.controlPoint1.y = n), null != o && (l.controlPoint2.x = o), null != s && (l.controlPoint2.y = s), a.setAttribute("d", r.toString()), this.trigger("path:edit", a), this.trigger("path:last-segment:adjust", a)
    },
    snapLastSegmentCoordinates: function (e, i, n) {
        var o = this.path;
        let s = !1, r = !1, a = e, l = i;
        for (let t = o.segments.length - 2; 0 <= t && (!s || !r); t--) {
            var h = o.getSegment(t), c = h.end.x, h = h.end.y;
            !s && Math.abs(c - e) < n && (a = c, s = !0), !r && Math.abs(h - i) < n && (l = h, r = !0)
        }
        return new g.Point(a, l)
    },
    removeLastSegment: function () {
        var {path: t, pathNode: e} = this;
        t.removeSegment(t.segments.length - 1), e.setAttribute("d", t.toString()), this.trigger("path:edit", e), this.trigger("path:last-segment:remove", e)
    },
    findControlPoint: function (t, e) {
        var i = this.path, i = i.getSegment(i.segments.length - 1);
        return new g.Point(t, e).reflection({x: i.end.x, y: i.end.y})
    },
    replaceLastSegmentWithCurve: function () {
        var {path: t, pathNode: e} = this, i = t.getSegment(t.segments.length - 1),
            n = t.getSegment(t.segments.length - 2),
            n = g.Path.createSegment("C", n.end.x, n.end.y, i.end.x, i.end.y, i.end.x, i.end.y);
        t.replaceSegment(t.segments.length - 1, n), e.setAttribute("d", t.toString()), this.trigger("path:edit", e), this.trigger("path:last-segment:replace-with-curve", e)
    },
    adjustControlPath: function (t, e, i, n) {
        var o = this.pathNode, s = this.svgControl.node,
            t = new g.Path([g.Path.createSegment("M", t, e), g.Path.createSegment("L", i, n)]);
        s.setAttribute("d", t.toString()), this.vel.append(s), this.trigger("path:interact", o), this.trigger("path:control:adjust", o)
    },
    removeControlPath: function () {
        var t = this.pathNode, e = this.svgControl.node;
        e.removeAttribute("d"), this.vel.append(e), this.trigger("path:interact", t), this.trigger("path:control:remove", t)
    },
    onPointerDown: function (t) {
        t = util.normalizeEvent(t);
        if (t.stopPropagation(), !(1 < t.which) && !(1 < t.originalEvent.detail) && this.el.parentNode) {
            var e = this.vel.toLocalPoint(t.clientX, t.clientY);
            switch (this.action) {
                case"awaiting-input":
                    this.createPath(e.x, e.y), this.options.enableCurves ? this.action = "path-created" : (this.addLineSegment(e.x, e.y), this.action = "adjusting-line-end"), this.delegateDocumentEvents();
                    break;
                case"adjusting-line-end":
                    this.options.enableCurves ? this.action = "awaiting-line-end" : this.addLineSegment(e.x, e.y);
                    break;
                case"adjusting-curve-end":
                    this.action = "awaiting-curve-control-2"
            }
            this._timeStamp = t.timeStamp
        }
    },
    MOVEMENT_DETECTION_THRESHOLD: 150,
    onPointerMove: function (e) {
        e = util.normalizeEvent(e);
        if (e.stopPropagation(), "awaiting-input" != this.action) {
            let t;
            var i, n = this.vel.toLocalPoint(e.clientX, e.clientY), o = this._timeStamp;
            if (o) if (e.timeStamp - o < this.MOVEMENT_DETECTION_THRESHOLD) switch (this.action) {
                case"path-created":
                    this.options.enableCurves && (t = this.svgStart.translate(), this.adjustControlPath(t.tx, t.ty, n.x, n.y));
                    break;
                case"adjusting-line-end":
                case"awaiting-line-end":
                case"adjusting-curve-control-1":
                    this.adjustLastSegment(n.x, n.y);
                    break;
                case"awaiting-curve-control-2":
                    this.adjustLastSegment(n.x, n.y, null, null, n.x, n.y)
            } else switch (this.action) {
                case"path-created":
                    this.options.enableCurves && (this.action = "adjusting-curve-control-1");
                    break;
                case"awaiting-line-end":
                    this.options.enableCurves && (this.replaceLastSegmentWithCurve(), this.action = "adjusting-curve-control-2");
                    break;
                case"adjusting-line-end":
                    this.options.enableCurves || this.adjustLastSegment(n.x, n.y);
                    break;
                case"awaiting-curve-control-2":
                    this.action = "adjusting-curve-control-2";
                    break;
                case"adjusting-curve-control-1":
                    t = this.svgStart.translate(), this.adjustControlPath(t.tx, t.ty, n.x, n.y);
                    break;
                case"adjusting-curve-control-2":
                    i = this.findControlPoint(n.x, n.y), this.adjustLastSegment(null, null, null, null, i.x, i.y), this.adjustControlPath(i.x, i.y, n.x, n.y)
            } else switch (this.action) {
                case"adjusting-line-end":
                    this.adjustLastSegment(n.x, n.y);
                    break;
                case"adjusting-curve-end":
                    this.adjustLastSegment(n.x, n.y, null, null, n.x, n.y)
            }
        }
    },
    onPointerUp: function (t) {
        this._timeStamp = null;
        t = util.normalizeEvent(t);
        if (t.stopPropagation(), !(1 < t.which || 1 < t.originalEvent.detail)) {
            var e = this.vel.toLocalPoint(t.clientX, t.clientY);
            switch (this.action) {
                case"path-created":
                case"awaiting-line-end":
                    this.addLineSegment(e.x, e.y), this.action = "adjusting-line-end";
                    break;
                case"awaiting-curve-control-2":
                    this.removeControlPath(), this.addLineSegment(e.x, e.y), this.action = "adjusting-line-end";
                    break;
                case"adjusting-curve-control-1":
                case"adjusting-curve-control-2":
                    this.addCurveSegment(e.x, e.y, e.x, e.y), this.action = "adjusting-curve-end"
            }
        }
    },
    onStartPointPointerDown: function (t) {
        t = util.normalizeEvent(t);
        t.stopPropagation(), 1 < t.which || 1 < t.originalEvent.detail || this.closePath()
    },
    onDoubleClick: function (t) {
        t = util.normalizeEvent(t);
        t.preventDefault(), t.stopPropagation(), 1 < t.which || this.pathNode && 0 < this.numberOfVisibleSegments() && (this.removeLastSegment(), this.finishPath("path:stop"))
    },
    onContextMenu: function (t) {
        t = util.normalizeEvent(t);
        t.preventDefault(), t.stopPropagation(), 1 < t.originalEvent.detail || this.pathNode && 0 < this.numberOfVisibleSegments() && (this.removeLastSegment(), this.finishPath("path:stop"))
    }
}), $$9 = mvc.$, PathEditor = mvc.View.extend({
    tagName: "g",
    svgElement: !0,
    className: "path-editor",
    events: {
        "mousedown .anchor-point": "onAnchorPointPointerDown",
        "mousedown .control-point": "onControlPointPointerDown",
        "mousedown .segment-path": "onSegmentPathPointerDown",
        "touchstart .anchor-point": "onAnchorPointPointerDown",
        "touchstart .control-point": "onControlPointPointerDown",
        "touchstart .segment-path": "onSegmentPathPointerDown",
        "dblclick .anchor-point": "onAnchorPointDoubleClick",
        "dblclick .control-point": "onControlPointDoubleClick",
        "dblclick .segment-path": "onSegmentPathDoubleClick"
    },
    documentEvents: {
        mousemove: "onPointerMove",
        touchmove: "onPointerMove",
        mouseup: "onPointerUp",
        touchend: "onPointerUp",
        touchcancel: "onPointerUp"
    },
    options: {anchorPointMarkup: '<circle r="2.5"/>', controlPointMarkup: '<circle r="2.5"/>'},
    init: function () {
        var t = this.pathNode = V(this.options.pathElement).normalizePath().node;
        this.path = g.Path.parse(this.options.pathElement.getAttribute("d")), this.svgRoot = V(t.ownerSVGElement), this.$document = $$9(t.ownerDocument), this.render()
    },
    onRemove: function () {
        this.undelegateDocumentEvents(), this.clear()
    },
    clear: function () {
        var t = this.vel;
        t.empty(), this.directionPaths = [], this.segmentPaths = [], this.segmentPathElements = [], this.controlPoints = [], this.anchorPoints = [], this._subPathIndices = [0], this.trigger("clear", this.pathNode)
    },
    _transformPoint: function (t, e, i) {
        return V.transformPoint(new g.Point(t, e), i)
    },
    _getPathCTM: function () {
        return this.pathNode.getCTM()
    },
    render: function () {
        this.clear();
        var {
                path: s,
                vel: t,
                anchorPoints: r,
                controlPoints: a,
                directionPaths: l,
                segmentPaths: h,
                segmentPathElements: c
            } = this, d = this._getPathCTM(), u = V(this.options.anchorPointMarkup).addClass("anchor-point"),
            p = V(this.options.controlPointMarkup).addClass("control-point"), m = V('<path class="direction-path"/>'),
            f = V('<path class="segment-path"/>'), v = this._subPathIndices;
        for (let i = 0, n = 0, o = 0; i < s.segments.length; i++) {
            var y = s.getSegment(i), x = this._transformPoint(y.end.x, y.end.y, d);
            let t = x.x, e = x.y;
            if ("Z" !== y.type && (r[i] = u.clone().attr({index: i, cx: t, cy: e})), "M" !== y.type) {
                var b = new g.Path;
                switch (b.appendSegment(g.Path.createSegment("M", n, o)), y.type) {
                    case"Z":
                        var w = s.getSegment(v[0]), w = this._transformPoint(w.end.x, w.end.y, d);
                        t = w.x, e = w.y, b.appendSegment(g.Path.createSegment("L", t, e)), v.unshift(i + 1);
                        break;
                    case"L":
                        b.appendSegment(g.Path.createSegment("L", t, e));
                        break;
                    case"C":
                        var w = this._transformPoint(y.controlPoint1.x, y.controlPoint1.y, d),
                            S = p.clone().attr({index: i, "attribute-index": 1, cx: w.x, cy: w.y}),
                            P = this._transformPoint(y.controlPoint2.x, y.controlPoint2.y, d),
                            C = p.clone().attr({index: i, "attribute-index": 2, cx: P.x, cy: P.y});
                        a[i] = [S, C], b.appendSegment(g.Path.createSegment("C", w.x, w.y, P.x, P.y, t, e)), l[i] = [m.clone().attr("d", ["M", n, o, "L", w.x, w.y].join(" ")), m.clone().attr("d", ["M", t, e, "L", P.x, P.y].join(" "))]
                }
                h[i] = b;
                x = f.clone().attr("index", i).node;
                x.setAttribute("d", b.toString()), c[i] = x
            }
            n = t, o = e
        }
        let e = [];
        c.forEach(function (t) {
            t && e.push(t)
        }), l.forEach(function (t) {
            t && Array.prototype.push.apply(e, t)
        }), r.forEach(function (t) {
            t && e.push(t)
        }), a.forEach(function (t) {
            t && Array.prototype.push.apply(e, t)
        }), t.append(e), this.svgRoot.append(t)
    },
    startMoving: function (t) {
        var t = util.normalizeEvent(t), e = this.$point = $$9(t.target),
            i = (this.prevClientX = t.clientX, this.prevClientY = t.clientY, parseInt(this.$point.attr("index"), 10));
        this.trigger("path:interact"), e.hasClass("anchor-point") ? this.trigger("path:anchor-point:select", i) : e.hasClass("control-point") ? (e = parseInt(this.$point.attr("attribute-index"), 10), this.trigger("path:control-point:select", i, e)) : this.trigger("path:segment:select", i), t.stopPropagation(), t.preventDefault(), this.index = void 0, this.controlPointIndex = void 0, this.segPoint = void 0, this.pathEditedEventType = void 0
    },
    move: function (t) {
        var e, i, n, o = this.$point;
        o && (e = (t = util.normalizeEvent(t)).clientX - this.prevClientX, i = t.clientY - this.prevClientY, n = parseInt(o.attr("index"), 10), o.hasClass("anchor-point") ? this.adjustAnchorPoint(n, e, i, t) : o.hasClass("control-point") ? (o = parseInt(o.attr("attribute-index"), 10), this.adjustControlPoint(n, o, e, i, t)) : this.adjustSegment(n, e, i, t), this.prevClientX = t.clientX, this.prevClientY = t.clientY)
    },
    adjustSegment: function (t, e, i, n, {dry: o = void 0} = {}) {
        this.adjustAnchorPoint(t - 1, e, i, {dry: !0}), this.adjustAnchorPoint(t, e, i, {dry: !0}), o || (this.pathEditedEventType = "path:segment:adjust", this.index = t, this.trigger("path:editing", this.pathNode, n), this.trigger("path:segment:adjusting", this.pathNode, n, {index: t}))
    },
    adjustControlPoint: function (t, e, i, n, o, {dry: s = void 0} = {}) {
        var r, a, l, h = this._getPathCTM(), {path: c, controlPoints: d} = this, u = c.getSegment(t), p = h.inverse(),
            i = (p.e = 0, p.f = 0, this._transformPoint(i, n, p)), n = "controlPoint" + e,
            p = (u[n].x += i.x, u[n].y += i.y, this._transformPoint(u[n].x, u[n].y, h)), i = new g.Point(p);
        d[t][e - 1].attr({
            cx: p.x,
            cy: p.y
        }).hasClass("locked") && (p = this.getBoundIndex(t, e), r = 1 === e ? 2 : 1, c = c.getSegment(p), a = "controlPoint" + r, l = new g.Point((1 === e ? c : u).end.x, (1 === e ? c : u).end.y), u = new g.Point(u[n].x, u[n].y), n = l.distance(new g.Point(c[a].x, c[a].y)), l = l.move(u, n), c[a].x = l.x, c[a].y = l.y, u = this._transformPoint(c[a].x, c[a].y, h), d[p][r - 1].attr({
            cx: u.x,
            cy: u.y
        }), this.updateDirectionPaths(p), this.updateSegmentPath(p)), this.updateDirectionPaths(t), this.updateSegmentPath(t), s || (this.pathEditedEventType = "path:control-point:adjust", this.index = t, this.controlPointIndex = e, this.segPoint = i, this.trigger("path:editing", this.pathNode, o), this.trigger("path:control-point:adjusting", this.pathNode, o, {
            index: t,
            controlPointIndex: e,
            segPoint: i
        }))
    },
    findSubpathIndex: function (i) {
        var n = this._subPathIndices;
        for (let t = 0, e = n.length; t < e; t++) if (n[t] < i) return n[t]
    },
    findReversedSubpathIndex: function (e) {
        var i = this._subPathIndices;
        for (let t = i.length - 1; 0 <= t; t--) if (i[t] > e) return i[t]
    },
    adjustAnchorPoint: function (t, e, i, n, {dry: o = void 0} = {}) {
        var s = this._getPathCTM(), {path: r, anchorPoints: a, controlPoints: l} = this;
        let h = r.getSegment(t);
        "Z" === h.type && (t = this.findSubpathIndex(t), h = r.getSegment(t));
        var c = a.length - 1,
            d = ((0 === t || t === c) && l[1] && l[c] && (d = l[1][0], c = l[c][1], d && d.hasClass("locked") && d.removeClass("locked"), c) && c.hasClass("locked") && c.removeClass("locked"), s.inverse()),
            c = (d.e = 0, d.f = 0, this._transformPoint(e, i, d)),
            e = (h.end.x += c.x, h.end.y += c.y, this._transformPoint(h.end.x, h.end.y, s)), i = new g.Point(e),
            a = (a[t].attr({
                cx: e.x,
                cy: e.y
            }), "C" === h.type && (h.controlPoint2.x += c.x, h.controlPoint2.y += c.y, d = this._transformPoint(h.controlPoint2.x, h.controlPoint2.y, s), l[t][1].attr({
                cx: d.x,
                cy: d.y
            })), t + 1 < r.segments.length ? r.getSegment(t + 1) : 0);
        a && ("C" === a.type && (a.controlPoint1.x += c.x, a.controlPoint1.y += c.y, e = this._transformPoint(a.controlPoint1.x, a.controlPoint1.y, s), l[t + 1][0].attr({
            cx: e.x,
            cy: e.y
        }), this.updateDirectionPaths(t + 1)), this.updateSegmentPath(t + 1)), this.updateDirectionPaths(t), this.updateSegmentPath(t), o || (this.pathEditedEventType = "path:anchor-point:adjust", this.index = t, this.segPoint = i, this.trigger("path:editing", this.pathNode, n), this.trigger("path:anchor-point:adjusting", this.pathNode, n, {
            index: t,
            segPoint: i
        }))
    },
    updateDirectionPaths: function (t) {
        let n = this._getPathCTM();
        var e = this.path;
        let o = e.getSegment(t), s = this._transformPoint(o.end.x, o.end.y, n), r = 0 < t ? e.getSegment(t - 1) : null,
            a = r ? this._transformPoint(r.end.x, r.end.y, n) : null;
        e = this.directionPaths[t];
        Array.isArray(e) && e.forEach(function (t, e) {
            e++;
            var i = this._transformPoint(o["controlPoint" + e].x, o["controlPoint" + e].y, n);
            t.attr("d", ["M", (1 < e || !r ? s : a).x, (1 < e || !r ? s : a).y, i.x, i.y].join(" "))
        }, this)
    },
    updateSegmentPath: function (e) {
        var {path: i, _subPathIndices: n} = this;
        if (n.includes(e)) {
            n = this.findReversedSubpathIndex(e) || this.path.segments.length;
            if ("Z" !== i.getSegment(--n).type) return;
            e = n
        }
        if (n = this.segmentPaths[e]) {
            var o = this._getPathCTM(), s = i.getSegment(e - 1), s = this._transformPoint(s.end.x, s.end.y, o),
                n = new g.Path;
            let t = g.Path.createSegment("M", s.x, s.y);
            n.appendSegment(t);
            var r = i.getSegment(e), a = this._transformPoint(r.end.x, r.end.y, o);
            switch (r.type) {
                case"Z":
                    var l = i.getSegment(this.findSubpathIndex(e)), l = this._transformPoint(l.end.x, l.end.y, o);
                    t = g.Path.createSegment("L", l.x, l.y);
                    break;
                case"L":
                    t = g.Path.createSegment("L", a.x, a.y);
                    break;
                case"C":
                    var l = this._transformPoint(r.controlPoint1.x, r.controlPoint1.y, o),
                        h = this._transformPoint(r.controlPoint2.x, r.controlPoint2.y, o);
                    t = g.Path.createSegment("C", l.x, l.y, h.x, h.y, a.x, a.y)
            }
            n.appendSegment(t), this.segmentPaths[e] = n;
            s = this.segmentPathElements[e];
            s && s.setAttribute("d", n.toString()), this.pathNode.setAttribute("d", i.toString())
        }
    },
    stopMoving: function (t) {
        var e, i, n, o, t = util.normalizeEvent(t);
        this.$point = void 0, this.pathEditedEventType && ({
            pathNode: e,
            index: i,
            controlPointIndex: n,
            segPoint: o
        } = this, this.trigger("path:edit", e, t), this.trigger(this.pathEditedEventType, e, t, {
            index: i,
            controlPointIndex: n,
            segPoint: o
        })), this.index = void 0, this.controlPointIndex = void 0, this.segPoint = void 0, this.pathEditedEventType = void 0
    },
    createAnchorPoint: function (t) {
        var t = util.normalizeEvent(t), e = V(t.target).attr("index"), {pathNode: i, path: n} = this,
            o = V(i).toLocalPoint(t.pageX, t.pageY), s = n.getSegment(e);
        switch (s.type) {
            case"Z":
                var r = new g.Line(s.start, s.end).closestPoint(o);
                n.insertSegment(e, g.Path.createSegment("L", r.x, r.y));
                break;
            case"L":
                r = new g.Line(s.start, s.end).closestPoint(o);
                n.insertSegment(e, g.Path.createSegment("L", r.x, r.y));
                break;
            case"C":
                r = new g.Curve(s.start, s.controlPoint1, s.controlPoint2, s.end).closestPointT(o), r = s.divideAtT(r);
                n.insertSegment(e, r[0]), s.controlPoint1.x = r[1].controlPoint1.x, s.controlPoint1.y = r[1].controlPoint1.y, s.controlPoint2.x = r[1].controlPoint2.x, s.controlPoint2.y = r[1].controlPoint2.y
        }
        this.render(), this.pathNode.setAttribute("d", n.toString()), this.trigger("path:edit", i, t), this.trigger("path:anchor-point:create", i, t)
    },
    removeAnchorPoint: function (t) {
        var e, t = util.normalizeEvent(t), i = parseInt($$9(t.target).attr("index"), 10), {pathNode: n, path: o} = this,
            s = o.getSegment(i);
        let r;
        switch (s.type) {
            case"M":
                r = o.getSegment(i + 1), e = g.Path.createSegment("M", r.end.x, r.end.y), o.replaceSegment(i + 1, e), o.removeSegment(i);
                break;
            case"L":
                o.removeSegment(i);
                break;
            case"C":
                i + 1 <= o.segments.length - 1 && "C" === (r = o.getSegment(i + 1)).type && (r.controlPoint1.x = s.controlPoint1.x, r.controlPoint1.y = s.controlPoint1.y), o.removeSegment(i)
        }
        this.render(), this.pathNode.setAttribute("d", o.toString()), this.trigger("path:edit", n, t), this.trigger("path:anchor-point:remove", n, t);
        let a = o.segments.length;
        "Z" === o.getSegment(o.segments.length - 1).type && --a, a < 2 && this.trigger("path:invalid", n, t)
    },
    lockControlPoint: function (t) {
        var e, t = util.normalizeEvent(t), t = $$9(t.target), i = parseInt(t.attr("index")),
            n = parseInt(t.attr("attribute-index"), 10), o = this.getBoundIndex(i, n), s = 1 === n ? 2 : 1,
            o = this.controlPoints[o];
        o && (e = t.hasClass("locked"), t.toggleClass("locked"), o[s - 1].toggleClass("locked"), this.trigger("path:interact"), e ? this.trigger("path:control-point:unlock", i, n) : (this.trigger("path:control-point:lock", i, n), this.adjustControlPoint(i, n, 0, 0, {dry: !0})))
    },
    getBoundIndex: function (t, e) {
        let i;
        var {path: n, anchorPoints: o} = this;
        let s, r, a;
        var l = o.length - 1;
        let h, c;
        return 1 === e ? 0 === (i = t - 1) && (s = n.segments.length - 1, r = n.getSegment(s).type, a = "Z" === r, h = o[0].attr("cx") === o[l].attr("cx"), c = o[0].attr("cy") === o[l].attr("cy"), a) && h && c && (i = l) : (i = t + 1) === 1 + l && (s = n.segments.length - 1, r = n.getSegment(s).type, a = "Z" === r, h = o[0].attr("cx") === o[l].attr("cx"), c = o[0].attr("cy") === o[l].attr("cy"), a) && h && c && (i = 1), i
    },
    getControlPointLockedStates: function () {
        var i, n = this.controlPoints, o = [];
        for (let e = 0; e < n.length; e++) if (n[e]) {
            o[e] = [];
            for (let t = 0; t <= 1; t++) n[e][t] && (i = t + 1, n[e][t].hasClass("locked") ? o[e][i] = !0 : o[e][i] = !1)
        }
        return o
    },
    setControlPointLockedStates: function (i) {
        var n = this.controlPoints;
        for (let e = 0; e < n.length; e++) if (i[e] && n[e]) for (let t = 1; t <= 2; t++) i[e][t] && n[e][t - 1] && (!0 === i[e][t] ? n[e][t - 1].addClass("locked") : n[e][t - 1].removeClass("locked"))
    },
    convertSegmentPath: function (t) {
        var t = util.normalizeEvent(t), e = V(t.target).attr("index"), {pathNode: i, path: n} = this,
            o = n.getSegment(e);
        switch (o.type) {
            case"Z":
                n.insertSegment(e, g.Path.createSegment("C", o.start.x, o.start.y, o.end.x, o.end.y, o.end.x, o.end.y));
                break;
            case"L":
                n.replaceSegment(e, g.Path.createSegment("C", o.start.x, o.start.y, o.end.x, o.end.y, o.end.x, o.end.y));
                break;
            case"C":
                n.replaceSegment(e, g.Path.createSegment("L", o.end.x, o.end.y))
        }
        this.render(), this.pathNode.setAttribute("d", n.toString()), this.trigger("path:edit", i, t), this.trigger("path:segment:convert", i, t)
    },
    addClosePathSegment: function (t) {
        var t = util.normalizeEvent(t), e = parseInt($$9(t.target).attr("index"), 10), {path: i, pathNode: n} = this;
        0 !== e && e !== i.segments.length - 1 || "Z" !== i.getSegment(i.segments.length - 1).type && (i.appendSegment(g.Path.createSegment("Z")), this.render(), this.pathNode.setAttribute("d", i.toString()), this.trigger("path:edit", n, t), this.trigger("path:closepath-segment:add", n, t))
    },
    removeClosePathSegment: function (t) {
        var t = util.normalizeEvent(t), e = V(t.target).attr("index"), {path: i, pathNode: n} = this;
        "Z" === i.getSegment(e).type && (i.removeSegment(e), this.render(), this.pathNode.setAttribute("d", i.toString()), this.trigger("path:edit", n, t), this.trigger("path:closepath-segment:remove", n, t))
    },
    isMoreThanFirstClick: function () {
        return this.clickCounter = this.clickCounter || 0, this.clickCounter += 1, this.timeout && clearTimeout(this.timeout), this.timeout = setTimeout(() => {
            this.clickCounter = 0
        }, 400), 2 <= this.clickCounter && (this.clickCounter = 0, clearTimeout(this.timeout), !0)
    },
    onAnchorPointPointerDown: function (t) {
        t = util.normalizeEvent(t);
        t.stopPropagation(), 1 !== t.which || this.isMoreThanFirstClick() || (this.startMoving(t), this.delegateDocumentEvents())
    },
    onControlPointPointerDown: function (t) {
        t = util.normalizeEvent(t);
        t.stopPropagation(), 1 !== t.which || this.isMoreThanFirstClick() || (this.startMoving(t), this.delegateDocumentEvents())
    },
    onSegmentPathPointerDown: function (t) {
        t = util.normalizeEvent(t);
        t.stopPropagation(), 1 !== t.which || this.isMoreThanFirstClick() || (this.startMoving(t), this.delegateDocumentEvents())
    },
    onPointerMove: function (t) {
        t = util.normalizeEvent(t);
        t.stopPropagation(), this.move(t)
    },
    onPointerUp: function (t) {
        this.undelegateDocumentEvents();
        t = util.normalizeEvent(t);
        t.stopPropagation(), this.stopMoving(t)
    },
    onAnchorPointDoubleClick: function (t) {
        t = util.normalizeEvent(t);
        t.stopPropagation(), t.preventDefault(), 1 === t.which && this.removeAnchorPoint(t)
    },
    onControlPointDoubleClick: function (t) {
        t = util.normalizeEvent(t);
        t.stopPropagation(), t.preventDefault(), 1 === t.which && this.lockControlPoint(t)
    },
    onSegmentPathDoubleClick: function (t) {
        t = util.normalizeEvent(t);
        t.stopPropagation(), t.preventDefault(), 1 === t.which && this.createAnchorPoint(t)
    }
}), Popup = ContextToolbar.extend({
    className: "popup", eventNamespace: "popup", events: {}, beforeMount() {
        var {anchor: t, arrowPosition: e} = this.options;
        this.$el.removeClass("left right top bottom top-left top-right bottom-left bottom-right"), e ? this.$el.addClass("none" === e ? "" : e) : this.$el.addClass("center" === t ? "" : t)
    }, renderContent: function () {
        var {content: t, arrowPosition: e, anchor: i} = this.options, t = util.isFunction(t) ? t(this.el) : t;
        t && this.$el.html(t), "none" === e && "center" !== i || ((t = document.createElement("div")).classList.add("popup-arrow"), (e = document.createElement("div")).classList.add("popup-arrow-mask"), this.el.append(t, e))
    }
});

class SelectionFrameList {
    constructor(t = {}) {
        this.options = t
    }

    setSelection(t) {
        this.selection = t, this.paper = t.options.paper, this.initialize()
    }

    initialize() {
    }

    count() {
    }

    getBBox() {
        var i = this.selection.collection, n = [];
        for (let t = 0, e = i.length; t < e; t++) {
            var o = i.at(t), o = this.getCellBBox(o);
            o && n.push(o)
        }
        return g.Rect.fromRectUnion(...n)
    }

    destroy() {
        this.clear()
    }

    add(t) {
    }

    remove(t) {
    }

    getCellBBox(t) {
        return t.getBBox({rotate: !0})
    }

    update() {
    }

    clear() {
    }

    translate(t, e) {
        this.update()
    }
}

class OverlaySelectionFrameList extends SelectionFrameList {
    DEFAULT_MARGIN = 5;
    DEFAULT_ROTATE = !1;
    SELECTION_FRAME_CLASS = "joint-selection-frame";

    initialize() {
        var {allowCellInteraction: t = this.selection.options.allowCellInteraction} = this.options;
        this.allowCellInteraction = t, this.items = {}, t || (this.eventNamespace = ".joint-selection-frame-ns-" + this.selection.cid, ["mousedown", "touchstart"].forEach(t => {
            this.paper.$el.on("" + t + this.eventNamespace, "." + this.SELECTION_FRAME_CLASS, t => this.onPointerDown(t))
        }))
    }

    destroy() {
        super.destroy(), this.allowCellInteraction || this.paper.$el.off(this.eventNamespace)
    }

    onPointerDown(t) {
        this.selection.onSelectionBoxPointerDown(t)
    }

    count() {
        let t = 0;
        for (var e in this.items) t++;
        return t
    }

    add(t) {
        var e;
        this.items[t.id] || ((e = this.renderItem(t)).classList.add(this.SELECTION_FRAME_CLASS), e.dataset.model = t.id, this.allowCellInteraction && e.classList.add("selection-box-no-events"), e = this.items[t.id] = {
            node: e,
            cell: t
        }, this._updateItem(e), this.updateItem(e), this.transformItem(e), this.mountItem(e))
    }

    remove(t) {
        var e = this.items[t.id];
        e && (e.node.remove(), delete this.items[t.id])
    }

    clear() {
        for (var t in this.items) this.items[t].node.remove();
        this.items = {}
    }

    update() {
        for (var t in this.items) this.paper.model.getCell(t) && (t = this.items[t], this._updateItem(t), this.updateItem(t), this.transformItem(t))
    }

    translate(t, e) {
        for (var i in this.items) this.paper.model.getCell(i) && (i = this.items[i], this._updateItemTranslation(i, t, e), this.transformItem(i))
    }

    renderItem(t) {
    }

    mountItem(t) {
    }

    transformItem(t) {
    }

    updateItem(t) {
    }

    _updateItemTranslation(t, e, i) {
        t.x += e, t.cx += e, t.y += i, t.cy += i
    }

    _updateItemBoundingBox(t, {x: e, y: i, width: n, height: o}) {
        t.x = e, t.y = i, t.width = n, t.height = o
    }

    _updateItemTransformation(t, e) {
        var i = t.cell, n = i.getCenter();
        t.cx = n.x, t.cy = n.y, t.angle = e ? i.angle() : 0
    }

    _updateItem(t) {
        var {rotate: e = this.DEFAULT_ROTATE} = this.options, i = t.cell,
            i = e ? this.getCellUnrotatedBBox(i) : this.getCellBBox(i);
        i && (this._updateItemTransformation(t, e), this._updateItemBoundingBox(t, i))
    }

    getCellBBox(t) {
        var e, i, n = this.getCellUnrotatedBBox(t);
        return n ? (i = t.angle()) ? ({
            x: t,
            y: e
        } = t.getCenter(), i = V.createSVGMatrix().translate(t, e).rotate(i).translate(-t, -e), V.transformRect(n, i)) : n : null
    }

    shouldUseModelGeometry(t) {
        var {useModelGeometry: e = this.selection.options.useModelGeometry} = this.options;
        return "boolean" == typeof e ? e : "function" == typeof e && e.call(this, t)
    }

    getCellUnrotatedBBox(t) {
        let e;
        if (this.shouldUseModelGeometry(t)) e = t.getBBox(); else {
            var i = t.findView(this.paper);
            if (!i) return null;
            e = i.getNodeUnrotatedBBox(i.el)
        }
        return this.addCellBBoxMargin(e, t), e
    }

    addCellBBoxMargin(t, e) {
        let {margin: i = this.DEFAULT_MARGIN} = this.options;
        var n, o, s;
        i && ("function" == typeof i && (i = i.call(this, e)), {
            left: e,
            right: n,
            top: o,
            bottom: s
        } = util.normalizeSides(i), t.moveAndExpand({x: -e, y: -o, width: e + n, height: o + s}))
    }
}

class LegacySelectionFrameList extends OverlaySelectionFrameList {
    DEFAULT_MARGIN = 0;

    renderItem() {
        var t = document.createElement("div");
        return t.classList.add("selection-box"), t
    }

    updateItem({node: t, width: e, height: i}) {
        t.style.width = e + "px", t.style.height = i + "px"
    }

    transformItem({node: t, x: e, y: i}) {
        t.style.left = e + "px", t.style.top = i + "px"
    }

    mountItem({node: t}) {
        this.selection.el.appendChild(t)
    }

    _updateItemTranslation(t, e, i) {
        var {sx: n, sy: o} = this.paper.scale();
        t.x += e * n, t.y += i * o
    }

    _updateItemBoundingBox(t, e) {
        e = this.paper.localToPaperRect(e);
        t.x = e.x, t.y = e.y, t.width = e.width, t.height = e.height
    }

    _updateItemTransformation(t, e) {
    }
}

let SelectionWrapper = mvc.View.extend({
    defaultTheme: null,
    className: "selection-wrapper",
    DEFAULT_MARGIN: 7,
    visible: !1,
    setSelection(t) {
        this.selection = t, this.paper = t.options.paper
    },
    render() {
        return this.renderChildren(), this.el.classList.toggle("selection-wrapper", Boolean(this.options.legacy)), this
    },
    update() {
        let t;
        this.el.dataset.selectionLength = this.selection.collection.length, this.shouldBeVisible() && (t = this.getBBox()) ? (this._update(t), this.show()) : this.hide()
    },
    translate(t, e) {
        this.isVisible() && this._translate(t, e)
    },
    shouldBeVisible() {
        var t;
        return 0 !== this.selection.collection.length && ({visibility: t = !0} = this.options, util.isFunction(t) ? t(this.selection) : Boolean(t))
    },
    isVisible() {
        return this.visible
    },
    show() {
        this.visible = !0, this._show()
    },
    hide() {
        this.visible = !1, this._hide()
    },
    getBBox() {
        var t, e = this.selection.frames.getBBox();
        return e ? ({margin: t = this.DEFAULT_MARGIN} = this.options, t && e.inflate(t), e) : null
    },
    _update(t) {
    },
    _translate(t, e) {
    },
    _show() {
    },
    _hide() {
    }
}), HTMLSelectionWrapper = SelectionWrapper.extend({
    tagName: "div",
    style: {border: "2px solid #C94A46"},
    children: [{tagName: "div", className: "box", selector: "box"}],
    USE_PAPER_SCALE: !1,
    left: 0,
    top: 0,
    _update(t) {
        let {x: e, y: i, width: n, height: o} = t;
        var s, r, a, l, h, {usePaperScale: c = this.USE_PAPER_SCALE} = this.options;
        c ? ({
            a: c,
            b: s,
            c: r,
            d: a,
            e: l,
            f: h
        } = this.paper.matrix(), this.el.style.transform = `matrix(${c}, ${s}, ${r}, ${a}, ${l}, ${h})`, this.el.style.transformOrigin = `${-e}px ${-i}px`) : {
            x: e,
            y: i,
            width: n,
            height: o
        } = this.paper.localToPaperRect(t), this.$el.css({
            left: e,
            top: i,
            width: n,
            height: o
        }), this.left = e, this.top = i, this.updateBoxContent()
    },
    _translate(t, e) {
        var {usePaperScale: i = this.USE_PAPER_SCALE} = this.options, {el: n, left: o, top: s, paper: r} = this;
        let a, l;
        i ? (a = o + t, l = s + e, this.el.style.transformOrigin = `${-a}px ${-l}px`) : ({
            sx: i,
            sy: r
        } = r.scale(), a = o + t * i, l = s + e * r), n.style.left = a + "px", n.style.top = l + "px", this.left = a, this.top = l
    },
    _show() {
        this.el.isConnected || this.$el.prependTo(this.selection.el)
    },
    _hide() {
        this.el.isConnected && this.$el.detach()
    },
    updateBoxContent() {
        var {selection: t, childNodes: {box: e}} = this, i = t.options.boxContent;
        util.isFunction(i) && (i = i.call(t, e)) && mvc.$(e).html(i)
    }
});

class SVGSelectionFrameList extends OverlaySelectionFrameList {
    itemAttributes() {
        return {fill: "transparent", stroke: "#C94A46", strokeWidth: 2}
    }

    renderItem(t) {
        var {attributes: e = this.itemAttributes} = this.options, t = "function" == typeof e ? e(t, this) : e,
            e = V("rect", t).node;
        return e
    }

    updateItem({node: t, x: e, y: i, cx: n, cy: o, width: s, height: r}) {
        t.setAttribute("x", e - n), t.setAttribute("y", i - o), t.setAttribute("width", s), t.setAttribute("height", r)
    }

    transformItem({node: t, angle: e, cx: i, cy: n}) {
        let o = `translate(${i}, ${n})`;
        e && (o += ` rotate(${e})`), t.setAttribute("transform", o)
    }

    mountItem({node: t}) {
        var {layer: e = dia$1.Paper.Layers.FRONT} = this.options;
        this.paper.getLayerView(e).el.appendChild(t)
    }
}

class HTMLSelectionFrameList extends OverlaySelectionFrameList {
    itemStyle() {
        return {border: "2px solid #C94A46", borderRadius: "2px", background: "transparent"}
    }

    renderItem(t) {
        var {style: e = this.itemStyle} = this.options, i = document.createElement("div"),
            t = (i.style.position = "absolute", i.style.boxSizing = "border-box", i.style.padding = "0", i.style.margin = "0", "function" == typeof e ? e(t, this) : e);
        return Object.assign(i.style, t), i
    }

    updateItem({node: t, width: e, height: i}) {
        t.style.width = e + "px", t.style.height = i + "px"
    }

    transformItem({node: t, x: e, y: i, cx: n, cy: o, angle: s}) {
        t.style.left = e + "px", t.style.top = i + "px", t.style.transform = s ? `rotate(${s}deg)` : "", t.style.transformOrigin = s ? n - e + `px ${o - i}px` : ""
    }

    mountItem({node: t}) {
        this.selection.el.appendChild(t)
    }

    _updateItemTranslation(t, e, i) {
        var {sx: n, sy: o} = this.paper.scale(), e = e * n, n = i * o;
        t.x += e, t.cx += e, t.y += n, t.cy += n
    }

    _updateItemBoundingBox(t, e) {
        e = this.paper.localToPaperRect(e);
        t.x = e.x, t.y = e.y, t.width = e.width, t.height = e.height
    }

    _updateItemTransformation(t, e) {
        var i = t.cell, n = this.paper.localToPaperPoint(i.getCenter());
        t.cx = n.x, t.cy = n.y, t.angle = e ? i.angle() : 0
    }
}

class HighlighterSelectionFrameList extends SelectionFrameList {
    DEFAULT_SELECTOR = "root";

    initialize() {
        var {highlighter: t, options: e = {}, selector: i = this.DEFAULT_SELECTOR} = this.options;
        if (!t) throw new Error("HighlighterSelectionFrameList: highlighter is required.");
        this.highlighter = t, this.highlighterSelector = i, this.highlighterOptions = e, this.highlighterId = "selection-box-" + this.selection.cid
    }

    count() {
        return this.highlighter.getAll(this.paper, this.highlighterId).length
    }

    add(t) {
        var e, i = t.findView(this.paper);
        i && (e = "function" == typeof this.highlighterSelector ? this.highlighterSelector.call(this, t, this) : this.highlighterSelector, t = "function" == typeof this.highlighterOptions ? this.highlighterOptions.call(this, t, this) : this.highlighterOptions, this.highlighter.add(i, e, this.highlighterId, t))
    }

    remove(t) {
        t = t.findView(this.paper);
        t && this.highlighter.remove(t, this.highlighterId)
    }

    clear() {
        this.highlighter.removeAll(this.paper, this.highlighterId)
    }
}

let $$8 = mvc.$, HandlePosition$1 = {N: "n", NW: "nw", W: "w", SW: "sw", S: "s", SE: "se", E: "e", NE: "ne"},
    ConnectedLinksTranslation = {NONE: "none", SUBGRAPH: "subgraph", ALL: "all"}, defaultHandles = {
        remove: {position: "nw", events: {pointerdown: "removeElements"}},
        rotate: {
            position: "sw",
            events: {pointerdown: "startRotating", pointermove: "doRotate", pointerup: "stopRotating"}
        },
        resize: {
            position: "se",
            events: {pointerdown: "startResizing", pointermove: "doResize", pointerup: "stopResizing"}
        },
        clone: {position: "ne", events: {pointerdown: "startCloning", pointermove: "doClone", pointerup: "stopCloning"}}
    };

function getDefaultHandle(t) {
    var e = defaultHandles[t];
    if (e) return {...util.cloneDeep(e), name: t};
    throw new Error("ui.Selection: default handle not found: " + t)
}

let Selection = mvc.View.extend({
    options: {
        paperScroller: void 0,
        paper: void 0,
        graph: void 0,
        boxContent: function (t) {
            return util.template("<%= length %> elements selected.")({length: this.collection.length})
        },
        handles: [getDefaultHandle("remove"), getDefaultHandle("rotate"), getDefaultHandle("resize")],
        useModelGeometry: !1,
        strictSelection: !1,
        selectLinks: !1,
        rotateAngleGrid: 15,
        allowTranslate: !0,
        translateConnectedLinks: ConnectedLinksTranslation.ALL,
        allowCellInteraction: !1,
        frames: null,
        wrapper: {margin: 0, style: {}, legacy: !0}
    },
    className: "selection",
    events: {
        "mousedown .handle": "onHandlePointerDown",
        "touchstart .handle": "onHandlePointerDown",
        wheel: "onMousewheel",
        mousewheel: "onMousewheel"
    },
    documentEvents: {
        mousemove: "adjustSelection",
        touchmove: "adjustSelection",
        mouseup: "pointerup",
        touchend: "pointerup",
        touchcancel: "pointerup"
    },
    _action: null,
    init: function () {
        this.options.model && (this.options.collection = this.options.model);
        var t = this.collection = this.options.collection || this.collection || new mvc.Collection,
            t = (t.comparator || (t.comparator = this.constructor.depthComparator, t.sort()), this.model = t, this.options.paper);
        if (t instanceof dia$1.Paper) util.defaults(this.options, {graph: t.model}); else {
            if (!("function" == typeof PaperScroller && t instanceof PaperScroller)) throw new Error("ui.Selection: paper required");
            this.options.paperScroller = t, this.options.paper = t.options.paper, this.options.graph = t.options.paper.model
        }
        util.bindAll(this, "startSelecting", "stopSelecting", "adjustSelection", "pointerup"), this.options.paper.$el.append(this.$el), this.wrapper = this.createSelectionWrapper(), this.handles = [], util.toArray(this.options.handles).forEach(this.addHandle, this), this.startListening(), this.setUpdateStrategy(), this.options.frames instanceof SelectionFrameList ? this.frames = this.options.frames : this.frames = new LegacySelectionFrameList({useModelGeometry: this.options.useModelGeometry}), this.frames.setSelection(this)
    },
    onCellPointerdown: function (t, e) {
        var i = this.collection;
        0 !== i.length && i.has(t.model) && (1 < i.length ? t.preventDefaultInteraction(e) : this.eventData(e, {defaultCellViewInteraction: !0}), this.startSelectionInteraction(e, t))
    },
    startListening: function () {
        var t = this.options.paper,
            t = (this.listenTo(t, "transform", this.onPaperTransformation), this.options.allowCellInteraction && this.listenTo(t, "cell:pointerdown", this.onCellPointerdown, this), this.options.graph),
            t = (this.listenTo(t, "reset", this.cancelSelection), this.listenTo(t, "remove", this.onGraphRemove), this.listenTo(t, "change", this.onChangeElement), this.collection);
        this.listenTo(t, "remove", this.onRemoveElement), this.listenTo(t, "reset", this.onResetElements), this.listenTo(t, "add", this.onAddElement)
    },
    onPaperTransformation: function () {
        this.updateSelectionBoxes({async: !1})
    },
    onChangeElement(t, e) {
        e.selection !== this.cid && (this.updateStrategy?.includesLinks || this.collection.includes(t)) && this.updateSelectionBoxes()
    },
    onGraphRemove: function (t, e) {
        e.selection !== this.cid && this.collection.remove(t)
    },
    cancelSelection: function () {
        this.collection.reset([], {ui: !0})
    },
    addHandle: function (i) {
        this.handles.push(i);
        var t = $$8("<div/>").addClass("handle " + (i.position || "") + " " + (i.name || "")).data("action", i.name);
        return t.html(i.content || ""), util.setAttributesBySelector(t, i.attrs), i.icon && t.css("background-image", "url(" + i.icon + ")"), this.wrapper.$el.append(t), util.forIn(i.events, function (t, e) {
            util.isString(t) ? this.on("action:" + i.name + ":" + e, this[t], this) : this.on("action:" + i.name + ":" + e, t)
        }.bind(this)), this
    },
    stopSelecting: function (t) {
        var e = this.options.paper, i = this.eventData(t), n = i.action;
        switch (n) {
            case"selecting":
                var o = this.$el.offset(), s = this.$el.width(), r = this.$el.height(),
                    o = e.pageToLocalPoint(o.left, o.top), a = e.scale(),
                    s = (s /= a.sx, g.rect(o.x, o.y, s, r /= a.sy)), a = this.getCellsInSelectedArea(s),
                    l = this.options.filter, r = (Array.isArray(l) ? a = a.filter(function (t) {
                        return !l.includes(t.model) && !l.includes(t.model.get("type"))
                    }) : util.isFunction(l) && (a = a.filter(function (t) {
                        return !l(t.model)
                    })), a.map(function (t) {
                        return t.model
                    }));
                this.hide(), this.collection.reset(r, {ui: !0});
                break;
            case"translating":
                i.interactionPrevented || this.options.graph.stopBatch("selection-translate"), o = e.snapToGrid(t.clientX, t.clientY), this.notify("selection-box:pointerup", t, o.x, o.y);
                break;
            default:
                n || this.cancelSelection()
        }
        this._action = null
    },
    removeHandle: function (i) {
        var t = util.toArray(this.handles).findIndex(function (t) {
            return t.name === i
        }), e = this.handles[t];
        return e && (util.forIn(e.events, function (t, e) {
            this.off("action:" + i + ":" + e)
        }.bind(this)), this.wrapper.$(".handle." + i).remove(), this.handles.splice(t, 1)), this
    },
    startSelecting: function (t) {
        t = util.normalizeEvent(t), this.cancelSelection();
        var {paperScroller: e, paper: i} = this.options,
            i = i.localToPaperPoint(i.clientToLocalPoint({x: t.clientX, y: t.clientY})), e = (this.$el.css({
                width: 0,
                height: 0,
                left: i.x,
                top: i.y
            }), this.showLasso(), e && e.options.scrollWhileDragging);
        this.eventData(t, {
            action: "selecting",
            clientX: t.clientX,
            clientY: t.clientY,
            origin: i,
            scrollWhileDragging: e
        }), this.delegateDocumentEvents(null, t.data), this._action = "selecting"
    },
    changeHandle: function (e, t) {
        var i = util.toArray(this.handles).find(function (t) {
            return t && t.name === e
        });
        return i && (this.removeHandle(e), this.addHandle(util.merge({name: e}, i, t))), this
    },
    onMousewheel: function (t) {
        t.preventDefault()
    },
    onSelectionBoxPointerDown: function (t) {
        t.stopPropagation(), t = util.normalizeEvent(t);
        var e = this.getCellView(t.target);
        this.startSelectionInteraction(t, e)
    },
    startSelectionInteraction: function (t, e) {
        var {paper: i, allowTranslate: n} = this.options, n = (!n || e && !e.can("elementMove") ? this.eventData(t, {
            action: "translating",
            interactionPrevented: !0
        }) : this.startTranslatingSelection(t), this.eventData(t, {activeElementView: e}), i.snapToGrid(t.clientX, t.clientY));
        this.notify("selection-box:pointerdown", t, n.x, n.y), this.delegateDocumentEvents(null, t.data)
    },
    startTranslatingSelection: function (t) {
        var {paperScroller: e, paper: i, graph: n} = this.options,
            n = (n.startBatch("selection-translate"), i.snapToGrid(t.clientX, t.clientY)),
            i = e && e.options.scrollWhileDragging;
        this.eventData(t, {
            action: "translating",
            snappedClientX: n.x,
            snappedClientY: n.y,
            scrollWhileDragging: i
        }), this._action = "translating"
    },
    adjustSelection: function (t) {
        t = util.normalizeEvent(t);
        let e, i;
        var n = this.collection, {paperScroller: o, paper: s, graph: r} = this.options,
            a = s.clientToLocalPoint({x: t.clientX, y: t.clientY}), l = this.eventData(t), {
                action: h,
                scrollWhileDragging: c,
                interactionPrevented: d = !1,
                defaultCellViewInteraction: u = !1
            } = l;
        switch (h) {
            case"selecting":
                var p = s.localToPaperPoint(a), g = (e = p.x - l.origin.x, i = p.y - l.origin.y, Math.abs(e)),
                    m = Math.abs(i), f = parseFloat(window.getComputedStyle(this.el).getPropertyValue("border-width"));
                this.$el.css({
                    left: (e < 0 ? p : l.origin).x,
                    top: (i < 0 ? p : l.origin).y,
                    width: g - 2 * f,
                    height: m - 2 * f
                });
                break;
            case"translating":
                var p = s.snapToGrid(t.clientX, t.clientY), g = p.x, m = p.y;
                d || u ? this.notify("selection-box:pointermove", t, g, m) : (e = g - l.snappedClientX, i = m - l.snappedClientY, f = this.collection.filter(t => t.isElement()), p = r.getCellsBBox(f), [e, i] = this.respectRestrictTranslate(e, i, p), (e || i) && (this.translateSelectedElements(e, i), this.framesUpdated ? (1 < n.length || s.isAsync() || this.options.allowCellInteraction) && this.updateSelectionBoxes() : this.updateStrategy?.translationAvailable ? (this.frames.translate(e, i), this.wrapper.translate(e, i)) : this.updateSelectionBoxes(), l.snappedClientX = g, l.snappedClientY = m), this.notify("selection-box:pointermove", t, g, m));
                break;
            default:
                h && this.pointermove(t)
        }
        this.framesUpdated = !1, c && o.scrollWhileDragging(t, a.x, a.y, c)
    },
    respectRestrictTranslate: function (t, e, i) {
        var n, o, s;
        return i && (n = this.options.paper.getRestrictedArea()) && (s = n.x - i.x, (o = n.x + n.width - (i.x + i.width)) < (t = t < s ? s : t) && (t = o), (s = n.y + n.height - (i.y + i.height)) < (e = e < (o = n.y - i.y) ? o : e)) && (e = s), [t, e]
    },
    translateSelectedElements: function (o, s) {
        var r = {};
        let a = this.collection, {graph: e, translateConnectedLinks: l} = this.options;
        a.toArray().forEach(t => {
            if (!r[t.id]) {
                let n = {selection: this.cid};
                t.translate(o, s, n), r[t.id] = !0, t.getEmbeddedCells({deep: !0}).forEach(function (t) {
                    r[t.id] = !0
                }), l !== ConnectedLinksTranslation.NONE && e.getConnectedLinks(t).forEach(function (t) {
                    if (!r[t.id]) {
                        if (l === ConnectedLinksTranslation.SUBGRAPH) {
                            var e = t.getSourceCell();
                            if (e && !a.get(e)) return;
                            var i = t.getTargetCell();
                            if (i && !a.get(i)) return;
                            if (!e || !i) return
                        }
                        t.translate(o, s, n), r[t.id] = !0
                    }
                })
            }
        })
    },
    notify: function (t, e) {
        var e = this.eventData(e), i = Array.prototype.slice.call(arguments, 1);
        this.trigger.apply(this, [t, e.activeElementView].concat(i))
    },
    getCellsInSelectedArea: function (t) {
        let {paper: e, useModelGeometry: i, strictSelection: n, selectLinks: o} = this.options;
        var s, r = {strict: n};
        return i ? (s = e.model, (o ? s.findCellsInArea(t, r) : s.findElementsInArea(t, r)).map(t => t.findView(e)).filter(t => !!t)) : o ? e.findCellViewsInArea(t, r) : e.findElementViewsInArea(t, r)
    },
    pointerup: function (t) {
        var e, i, n, {action: o, scrollWhileDragging: s} = this.eventData(t);
        o && (t = util.normalizeEvent(t), {paper: i, paperScroller: e} = this.options, {
            x: i,
            y: n
        } = i.snapToGrid({
            x: t.clientX,
            y: t.clientY
        }), "selecting" !== o && "translating" !== o && this.triggerAction(o, "pointerup", t, i, n), s && e.stopScrollWhileDragging(t), this.stopSelecting(t), this.undelegateDocumentEvents(), this._action = null)
    },
    destroySelectionBox: function (t) {
        this.frames.remove(t), 0 === this.frames.count() && this.hide()
    },
    hide: function () {
        this.$el.removeClass("lasso selected")
    },
    showSelected: function () {
        this.$el.addClass("selected")
    },
    showLasso: function () {
        this.$el.addClass("lasso")
    },
    destroyAllSelectionBoxes: function () {
        this.hide(), this.frames.clear()
    },
    createSelectionBox: function (t) {
        this.frames.add(t), this.showSelected()
    },
    createSelectionWrapper: function () {
        let t, e = this.options.wrapper;
        return !1 === e && (e = {visibility: () => !1}), (t = e instanceof SelectionWrapper ? e : new HTMLSelectionWrapper(e)).setSelection(this), t.render(), t
    },
    setWrapperVisibility: function (t) {
        this.wrapper.options.visibility = t, this.wrapper.update()
    },
    updateSelectionWrapper: function () {
        this.wrapper.update()
    },
    updateSelectionBoxes: function (t) {
        0 !== this.collection.length && (this.framesUpdated = !0, this.options.paper.requestViewUpdate(this, 1, this.UPDATE_PRIORITY, t))
    },
    confirmUpdate: function () {
        this._updateSelectionBoxes()
    },
    _updateSelectionBoxes: function () {
        0 !== this.frames.count() && (this.hide(), this.frames.update(), this.showSelected(), this.updateSelectionWrapper())
    },
    onHandlePointerDown: function (t) {
        var e, i, n, o = t.currentTarget.dataset.action;
        o && ({paperScroller: e, paper: n} = this.options, {
            x: n,
            y: i
        } = (t.preventDefault(), t.stopPropagation(), t = util.normalizeEvent(t), n.snapToGrid({
            x: t.clientX,
            y: t.clientY
        })), "mousedown" === t.type && 2 === t.button ? this.triggerAction(o, "contextmenu", t, n, i) : (this.triggerAction(o, "pointerdown", t, n, i), n = e && e.options.scrollWhileDragging, this.eventData(t, {
            action: o,
            clientX: t.clientX,
            clientY: t.clientY,
            startClientX: t.clientX,
            startClientY: t.clientY,
            scrollWhileDragging: n
        }), this.delegateDocumentEvents(null, t.data)), this._action = o)
    },
    getCellView: function (t) {
        t = this.collection.get(t.getAttribute("data-model"));
        return t && t.findView(this.options.paper)
    },
    pointermove: function (t) {
        var e, i, n, o, s, r, a = this.eventData(t), l = a.action;
        l && ({clientX: e, clientY: i} = t, s = this.options.paper, {x: n, y: o} = s.snapToGrid(e, i), {
            x: s,
            y: r
        } = s.snapToGrid(a.clientX, a.clientY), this.triggerAction(l, "pointermove", t, n, o, n - s, o - r), a.clientX = e, a.clientY = i)
    },
    triggerAction: function (t, e, i) {
        var n = Array.prototype.slice.call(arguments, 2);
        n.unshift("action:" + t + ":" + e), this.trigger.apply(this, n)
    },
    onRemoveElement: function (t) {
        this.setUpdateStrategy(), this.destroySelectionBox(t), this.updateSelectionWrapper()
    },
    onResetElements: function (e, {previousModels: t}) {
        this.setUpdateStrategy();
        let i = new Set(t);
        i.forEach(t => {
            e.has(t) || this.destroySelectionBox(t)
        }), e.each(t => {
            i.has(t) || this.createSelectionBox(t)
        }), this.updateSelectionWrapper()
    },
    onAddElement: function (t) {
        this.setUpdateStrategy(), this.createSelectionBox(t), this.updateSelectionWrapper()
    },
    setUpdateStrategy: function () {
        var t = this.collection, e = t.find(t => t.isLink()), i = this.updateStrategy;
        if (i) {
            if (0 === t.length) return;
            if (i.includesLinks === e) return
        }
        this.updateStrategy = {includesLinks: e, translationAvailable: !e}
    },
    removeElements: function (t) {
        var e = this.collection.toArray();
        this.cancelSelection(), this.options.graph.removeCells(e, {selection: this.cid})
    },
    startRotating: function (t) {
        var {paper: e, graph: i} = this.options, n = (i.trigger("batch:start"), this.collection.toArray()),
            i = i.getCellsBBox(this.collection.models).center(), e = e.snapToGrid(t.clientX, t.clientY),
            o = n.reduce(function (t, e) {
                return t[e.id] = e.angle(), t
            }, {}), n = n.reduce(function (t, e) {
                return e.isLink() && (t[e.id] = {
                    source: e.getSourceCell() ? null : e.get("source"),
                    target: e.getTargetCell() ? null : e.get("target"),
                    vertices: e.vertices()
                }), t
            }, {});
        this.eventData(t, {center: i, clientAngle: e.theta(i), initialAngles: o, initialPoints: n})
    },
    startResizing: function (t) {
        var {options: e, collection: i} = this, {paperScroller: e, paper: n, graph: o} = e, s = n.options.gridSize,
            i = i.toArray(), {width: r, height: a} = o.getCellsBBox(i), {
                x: n,
                y: l
            } = n.snapToGrid(t.clientX, t.clientY), h = i.filter(t => t.isElement()), c = h.map(t => {
                var e = t.angle(), t = t.getBBox(), i = t.bbox(e);
                let n;
                return {
                    angle: e,
                    unrotatedBBox: t,
                    bbox: i,
                    factor: n = e <= 90 ? e / 90 : e <= 270 ? Math.abs(180 - e) / 90 : Math.abs(e - 360) / 90,
                    center: i.center()
                }
            }), d = c.reduce((t, e) => {
                e = e.unrotatedBBox;
                return e.width < t ? e.width : t
            }, 1 / 0), u = c.reduce((t, e) => {
                e = e.unrotatedBBox;
                return e.height < t ? e.height : t
            }, 1 / 0), i = o.getSubgraph(i), p = i.filter(t => t.isLink()), g = p.map(t => ({
                source: t.getSourceCell() ? null : t.get("source"),
                target: t.getTargetCell() ? null : t.get("target"),
                vertices: t.vertices()
            })), i = o.getCellsBBox(i), e = e && e.options.scrollWhileDragging;
        this.eventData(t, {
            size: {width: r, height: a},
            rotatedBBox: o.getCellsBBox(h),
            minWidth: s * r / d,
            minHeight: s * a / u,
            x0: n,
            y0: l,
            pointerX: n,
            pointerY: l,
            elements: h,
            elementsRecords: c,
            links: p,
            linksRecords: g,
            cellsBBox: i,
            scrollWhileDragging: e
        }), o.trigger("batch:start")
    },
    startCloning: function (t, n, o) {
        var s = this.options.paper.model, e = (s.startBatch("selection-clone"), this.cloneSelectedCells()),
            r = e.filter(t => !t.isEmbedded()), i = e.filter(t => t.isElement()), s = s.getCellsBBox(i);
        if (s) {
            var a = s.center();
            let e = n - a.x, i = o - a.y;
            [e, i] = this.respectRestrictTranslate(e, i, s), r.forEach(t => t.translate(e, i))
        }
        t.data = {clonedRootCells: r, clonedCells: e, clonedElements: i, lastX: n, lastY: o}
    },
    cloneSelectedCells: function () {
        var t = this.options.paper.model, e = Object.values(t.cloneSubgraph(this.collection.toArray()));
        return t.addCells(e, {selection: this.cid, ui: !0}), e
    },
    doResize: function (i) {
        var n = this.eventData(i);
        let {
            size: o,
            rotatedBBox: a,
            minWidth: l,
            minHeight: h,
            x0: c,
            y0: d,
            pointerX: t,
            pointerY: e,
            elements: u,
            elementsRecords: p,
            links: m,
            linksRecords: f,
            cellsBBox: v
        } = n;
        var {x: i, y} = this.options.paper.snapToGrid(i.clientX, i.clientY);
        if (i !== t || y !== e) {
            n.lastX = i, n.lastY = y;
            var {width: n, height: x} = o;
            let t = Math.max(n + i - c, l), e = Math.max(x + y - d, h),
                s = (this.options.preserveAspectRatio && (i = n * e / x, y = x * t / n, i > t ? e = y : t = i), Math.max(t / n, 0)),
                r = Math.max(e / x, 0);
            for (let o = 0, t = u.length; o < t; o++) {
                var b = u[o], {bbox: w, unrotatedBBox: S, factor: P, center: C, angle: A} = p[o],
                    P = new g.Point(s, r).lerp(new g.Point(r, s), P), S = S.clone().scale(P.x, P.y, C), P = S.bbox(A);
                let t = P.width - w.width, e = P.height - w.height;
                Math.abs(t) < .001 && (t = 0), Math.abs(e) < .001 && (e = 0);
                C = new g.Point(a.x, 0).distance(new g.Point(w.x, 0)), A = new g.Point(0, a.y).distance(new g.Point(0, w.y));
                let i = t / 2 + C * s - C, n = e / 2 + A * r - A;
                if (Math.abs(i) < .001 && (i = 0), Math.abs(n) < .001 && (n = 0), S.translate(i, n), 0 === o && b.getBBox().equals(S)) return;
                b.set({position: {x: S.x, y: S.y}, size: {width: S.width, height: S.height}}, {selection: this.cid})
            }
            for (let t = 0, e = m.length; t < e; t++) {
                var k = m[t], {source: E, target: B, vertices: L} = f[t], T = {};
                0 < L.length && (T.vertices = L.map(t => {
                    t = new g.Point(t);
                    return t.scale(s, r, v.origin()), t.toJSON()
                })), E && ((L = new g.Point(E)).scale(s, r, v.origin()), T.source = L.toJSON()), B && ((E = new g.Point(B)).scale(s, r, v.origin()), T.target = E.toJSON()), k.set(T, {selection: this.cid})
            }
            this.updateSelectionBoxes()
        }
    },
    doRotate: function (t) {
        var a = this.eventData(t), l = this.options.rotateAngleGrid,
            t = this.options.paper.snapToGrid(t.clientX, t.clientY), h = a.clientAngle - g.point(t).theta(a.center);
        .001 < Math.abs(h) && (this.collection.toArray().forEach(t => {
            let e = g.snapToGrid(a.initialAngles[t.id] + h, l);
            var i, n, o, s, r;
            if (t.isLink()) return {
                source: i,
                target: n,
                vertices: o
            } = a.initialPoints[t.id], s = t => g.Point(t).rotate(a.center, -e), r = {}, i && (r.source = s(i)), n && (r.target = s(n)), 0 < o.length && (r.vertices = o.map(s)), t.set(r, {selection: this.cid});
            t.rotate(e, !0, a.center, {selection: this.cid})
        }), this.updateSelectionBoxes())
    },
    doClone: function (t, e, i) {
        var n = this.options.paper.model, {clonedElements: o, clonedRootCells: s, lastX: r, lastY: a} = t.data,
            n = n.getCellsBBox(o);
        let l = e - r, h = i - a;
        [l, h] = this.respectRestrictTranslate(l, h, n), (l || h) && (s.forEach(t => t.translate(l, h, {
            selection: this.cid,
            ui: !0
        })), t.data.lastX = e, t.data.lastY = i)
    },
    stopRotating: function (t) {
        this.stopBatch()
    },
    stopResizing: function (t) {
        this.stopBatch()
    },
    stopCloning: function (t) {
        t = t.data.clonedCells;
        this.options.paper.model.stopBatch("selection-clone"), this.collection.reset(t, {ui: !0})
    },
    stopBatch: function () {
        this.options.graph.trigger("batch:stop")
    },
    getAction: function () {
        return this._action
    },
    onRemove: function () {
        this.frames.destroy(), this.wrapper.remove()
    }
}, {
    depthComparator: function (t) {
        return t.getAncestors().length
    },
    HandlePosition: HandlePosition$1,
    ConnectedLinksTranslation: ConnectedLinksTranslation,
    getDefaultHandle: getDefaultHandle
});
var __awaiter = function (t, r, a, l) {
    return new (a = a || Promise)(function (i, e) {
        function n(t) {
            try {
                s(l.next(t))
            } catch (t) {
                e(t)
            }
        }

        function o(t) {
            try {
                s(l.throw(t))
            } catch (t) {
                e(t)
            }
        }

        function s(t) {
            var e;
            t.done ? i(t.value) : ((e = t.value) instanceof a ? e : new a(function (t) {
                t(e)
            })).then(n, o)
        }

        s((l = l.apply(t, r || [])).next())
    })
};
let COLOR_DEFAULT = "#ED2637", CURSOR_DEFAULT = "crosshair", LAYER_DEFAULT = dia$1.Paper.Layers.FRONT,
    NORMALIZE_DEFAULT = !0;

class SelectionRegion extends mvc.View {
    constructor(t) {
        if (super(t), this.paper = t.paper, !this.paper) throw new Error("The `paper` option is required.");
        this.resetPoints(), this.renderChildren(), this.setCursor(), this.setColor()
    }

    getUserSelectionAsync() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.beforeUserSelect(), new Promise((t, e) => {
                this.delegateDocumentEvents(null, {resolve: t, reject: e})
            }).finally(() => {
                this.afterUserSelect()
            }).catch(t => {
                if (t instanceof UserCanceledError) return null;
                throw t
            })
        })
    }

    getCurrentSelection() {
        return this.internalToUserGeometry(this.usePoints())
    }

    draw(t) {
        t ? (this.update(t), this.show()) : this.hide()
    }

    setCursor() {
        this.vel.attr("cursor", CURSOR_DEFAULT)
    }

    setColor() {
        var {color: t = COLOR_DEFAULT} = this.options;
        this.vel.attr({fill: t, stroke: t, strokeWidth: 1, fillOpacity: .1})
    }

    beforeUserSelect() {
        this.resetPoints(), this.draw(null), this.mount()
    }

    afterUserSelect() {
        this.unmount(), this.undelegateDocumentEvents()
    }

    mount() {
        var {layer: t = LAYER_DEFAULT} = this.options;
        this.el.isConnected || this.paper.getLayerView(t).el.appendChild(this.el)
    }

    show() {
        this.vel.removeAttr("display"), this.mount()
    }

    hide() {
        this.vel.attr("display", "none")
    }

    onDrag(t) {
        var e = t.data.elementCaptured,
            e = (e || (this.el.setPointerCapture(t.pointerId), t.data.elementCaptured = !0), util.normalizeEvent(t)), {
                x: t,
                y: i
            } = this.paper.clientToLocalPoint(e.clientX, e.clientY).round();
        this.validatePoint(t, i) || (this.addPoint(t, i), this.onPointsChange(e))
    }

    onPointsChange(t) {
        var e, i = this.usePoints();
        this.draw(i), i && (e = this.options.onChange, "function" == typeof e) && e.call(this, this.internalToUserGeometry(i), t)
    }

    internalToUserGeometry(t) {
        var e;
        return t ? ({normalize: e = NORMALIZE_DEFAULT} = this.options, e ? this.normalizeGeometry(t) : t) : null
    }

    normalizeGeometry(t) {
        return t
    }

    onDragEnd(t) {
        var {resolve: t, reject: e} = t.data, i = this.getCurrentSelection();
        i ? t(i) : e(new UserCanceledError)
    }

    onDragCancel(t) {
        t.preventDefault();
        t = t.data.reject;
        t(new UserCanceledError)
    }
}

SelectionRegion.prototype.svgElement = !0, SelectionRegion.prototype.className = "joint-selection-region", SelectionRegion.prototype.documentEvents = {
    pointermove: "onDrag",
    pointerup: "onDragEnd",
    pointercancel: "onDragCancel",
    contextmenu: "onDragCancel"
};

class UserCanceledError extends Error {
    constructor() {
        super(), this.message = "The user has canceled the interaction."
    }
}

class RectangularSelectionRegion extends SelectionRegion {
    preinitialize() {
        this.tagName = "rect"
    }

    update(t) {
        this.vel.attr(this.normalizeGeometry(t).toJSON())
    }

    validatePoint(t, e) {
        var i = this.points;
        return !(i.length < 2) && (i = i[1]) && i.x === t && i.y === e
    }

    addPoint(t, e) {
        var i = this.points;
        i[Math.min(i.length, 1)] = new g.Point(t, e)
    }

    resetPoints() {
        this.points = []
    }

    usePoints() {
        var t, e = this.points;
        return e.length < 2 ? null : ([e, t = e] = e, new g.Rect({x: e.x, y: e.y, width: t.x - e.x, height: t.y - e.y}))
    }

    normalizeGeometry(t) {
        t = t.clone().normalize();
        return t.width || (t.width = 1), t.height || (t.height = 1), t
    }
}

class PolygonalSelectionRegion extends SelectionRegion {
    preinitialize() {
        this.tagName = "g", this.children = [{
            tagName: "path",
            selector: "drawnPath",
            attributes: {fillRule: "evenodd"}
        }, {tagName: "path", selector: "closePath", attributes: {strokeWidth: 1, strokeDasharray: "6,3"}}]
    }

    update(t) {
        var {drawnPath: e, closePath: i} = this.childNodes, {start: n, end: o} = t;
        e.setAttribute("d", "M " + t.serialize()), i.setAttribute("d", `M ${n.serialize()} ` + o.serialize())
    }

    validatePoint(t, e) {
        var i = this.points, [i] = i;
        return i && i.x === t && i.y === e
    }

    addPoint(t, e) {
        var i = this.points, [n] = i, t = new g.Point(t, e);
        n && n.equals(t) || (i.push(t), this.simplifyPoints())
    }

    resetPoints() {
        this.points = []
    }

    usePoints() {
        var t = this.points;
        return t.length < 2 ? null : new g.Polygon(t)
    }

    simplifyPoints() {
        var t, {threshold: e = 1} = this.options, i = this.points;
        i.length <= 3 || (t = i.slice(0, -3), i = i.slice(-4), g.Polygon.prototype.simplify.call({points: i}, {threshold: e}), this.points = t.concat(i))
    }
}

let DisplayMode = {RECT: "rect", LINE: "line"}, VERTICAL_DEFAULT = !1, DISPLAY_MODE_DEFAULT = DisplayMode.RECT;

class RangeSelectionRegion extends SelectionRegion {
    preinitialize() {
        this.tagName = "path"
    }

    update(t) {
        var {vel: e, options: i} = this, {
            vertical: n = VERTICAL_DEFAULT,
            domain: i = this.getDefaultDomain(n),
            displayMode: o = DISPLAY_MODE_DEFAULT
        } = i, [s, r] = this.normalizeGeometry(t), [i, a] = i, [l, h, c, d] = n ? [i, s, a - i, r - s] : [s, i, r - s, a - i];
        let u = "";
        switch (o) {
            case DisplayMode.RECT:
                u = `M ${l} ${h} V ${h + d} H ${l + c} V ${h} Z`;
                break;
            case DisplayMode.LINE:
                var [p, p = p] = t;
                u = n ? `M ${l} ${p} H ` + (l + c) : `M ${p} ${h} V ` + (h + d);
                break;
            default:
                throw new Error("Unknown display mode: " + o)
        }
        e.attr("d", u)
    }

    validatePoint(t, e) {
        var {points: i, options: n} = this, {vertical: n = VERTICAL_DEFAULT} = n;
        return 0 !== i.length && (i = i.at(-1), n ? i.y === e : i.x === t)
    }

    addPoint(t, e) {
        var i = this.points;
        i[Math.min(i.length, 1)] = this.createPoint(t, e)
    }

    createPoint(t, e) {
        var t = new g.Point(t, e), e = this.options, {
            constraints: e = [-1 / 0, 1 / 0],
            vertical: i = VERTICAL_DEFAULT
        } = e, [e, n] = e, i = i ? "y" : "x";
        return t[i] = Math.max(Math.min(t[i], n), e), t
    }

    resetPoints() {
        this.points = []
    }

    usePoints() {
        var t, {points: e, options: i} = this, {vertical: i = VERTICAL_DEFAULT} = i;
        return 0 === e.length ? null : ([e, t = e] = e, [e[e = i ? "y" : "x"], t[e]])
    }

    getDefaultDomain(t) {
        var {x: e, y: i, width: n, height: o} = this.paper.getArea();
        return t ? [e, e + n] : [i, i + o]
    }

    setCursor() {
        var {vertical: t = VERTICAL_DEFAULT} = this.options;
        this.vel.attr("cursor", t ? "ns-resize" : "ew-resize")
    }

    normalizeGeometry([t, e]) {
        return [Math.min(t, e), Math.max(t, e)]
    }
}

let $$7 = mvc.$, HandlePosition = {N: "n", NW: "nw", W: "w", SW: "sw", S: "s", SE: "se", E: "e", NE: "ne"},
    Snaplines = mvc.View.extend({
        options: {paper: void 0, usePaperGrid: !1, distance: 10, canSnap: null, additionalSnapPoints: null},
        className: "snaplines",
        documentEvents: {mouseup: "hide", touchend: "hide"},
        init: function () {
            util.bindAll(this, "hide"), this.render(), this.enable(), this.prepareFilters()
        },
        render: function () {
            var {$el: t, options: e} = this, i = this.$horizontal = $$7("<div>").addClass("snapline horizontal"),
                n = this.$vertical = $$7("<div>").addClass("snapline vertical");
            t.css("display", "none").append([i, n]).appendTo(e.paper.el)
        },
        startListening: function () {
            this.enable()
        },
        _isEnabled: !1,
        enable: function () {
            var t = this.options.paper;
            this.disable(), this.listenTo(t, "element:pointermove", this.snapWhileMoving), this.listenTo(t.model, "batch:stop", this.onBatchStop), this.delegateDocumentEvents(), this._isEnabled = !0
        },
        disable: function () {
            var t = this.options.paper;
            this.stopListening(t, "element:pointermove", this.snapWhileMoving), this.stopListening(t.model, "batch:stop", this.onBatchStop), this.undelegateDocumentEvents(), this._isEnabled = !1
        },
        isDisabled: function () {
            return !this._isEnabled
        },
        prepareFilters: function () {
            this.filterTypes = {}, this.filterCells = {}, this.filterFunction = void 0, Array.isArray(this.options.filter) ? this.options.filter.forEach(function (t) {
                util.isString(t) ? this.filterTypes[t] = !0 : this.filterCells[t.id] = !0
            }, this) : util.isFunction(this.options.filter) && (this.filterFunction = this.options.filter)
        },
        onBatchStop: function (t) {
            "resize" === (t = t || {}).batchName && this.snapWhileResizing(t.cell, t)
        },
        snapWhileResizing: function (n, t) {
            if (t.ui && !t.snapped && t.direction && t.trueDirection) {
                var o = this.options, e = o.paper, i = e.findViewByModel(n);
                if (i && i.model.isElement() && this.canElementSnap(i)) {
                    var s = n.getBBox(), r = s.bbox(n.get("angle")), a = r.origin(), l = r.corner(),
                        h = g.normalizeAngle(n.get("angle")), c = o.distance, d = null, u = null,
                        p = e.options.gridSize, m = {vertical: 0, horizontal: 0}, f = t.direction, v = t.trueDirection,
                        y = t.relativeDirection;
                    if (-1 !== v.indexOf("right") ? m.vertical = l.x : m.vertical = a.x, -1 !== v.indexOf("bottom") ? m.horizontal = l.y : m.horizontal = a.y, util.isFunction(this.options.additionalSnapPoints)) {
                        var x = this.options.additionalSnapPoints.call(this, i, {type: "resize"});
                        for (let t = 0; t < x.length; t++) {
                            var b = x[t];
                            if (null === d && Math.abs(b.x - m.vertical) < c && (d = b.x), null === u && Math.abs(b.y - m.horizontal) < c && (u = b.y), util.isNumber(d) && util.isNumber(u)) break
                        }
                    }
                    if (util.isNumber(d) && util.isNumber(u) || e.model.getElements().find(function (t) {
                        var e, i;
                        return !(t.id === n.id || t.isEmbeddedIn(n) || this.filterTypes[t.get("type")] || this.filterCells[t.id] || this.filterFunction && this.filterFunction(t)) && (e = (t = t.getBBox().bbox(t.get("angle"))).origin(), t = t.corner(), o.usePaperGrid && (e.snapToGrid(p), t.snapToGrid(p)), i = {
                            vertical: [e.x, t.x],
                            horizontal: [e.y, t.y]
                        }, util.forIn(i, function (t, e) {
                            t = (t = t.map(function (t) {
                                return {position: t, distance: Math.abs(t - m[e])}
                            })).filter(function (t) {
                                return t.distance < c
                            }), t = util.sortBy(t, function (t) {
                                return t.distance
                            }), i[e] = t
                        }), null === d && 0 < i.vertical.length && (d = i.vertical[0].position), null === u && 0 < i.horizontal.length && (u = i.horizontal[0].position), util.isNumber(d)) && util.isNumber(u)
                    }, this), this.hide(), util.isNumber(d) || util.isNumber(u)) {
                        var w = 0,
                            S = (util.isNumber(d) && (w = -1 !== v.indexOf("right") ? d - r.corner().x : r.origin().x - d), 0),
                            P = (util.isNumber(u) && (S = -1 !== v.indexOf("bottom") ? u - r.corner().y : r.origin().y - u), 0),
                            C = 0;
                        if (!(h % 90)) C = 90 === h || 270 === h ? (P = S, w) : (P = w, S); else {
                            var l = 0 <= h && h < 90 ? 1 : 90 <= h && h < 180 ? 4 : 180 <= h && h < 270 ? 3 : 2,
                                A = (u && d && (w < S ? (S = 0, u = null) : (w = 0, d = null)), g.toRad(h % 90)),
                                k = (w && (P = 3 === l ? w / Math.cos(A) : w / Math.sin(A)), S && (C = 3 === l ? S / Math.cos(A) : S / Math.sin(A)), 1 === l || 3 === l);
                            switch (y) {
                                case"top":
                                case"bottom":
                                    C = S ? S / (k ? Math.cos(A) : Math.sin(A)) : w / (k ? Math.sin(A) : Math.cos(A));
                                    break;
                                case"left":
                                case"right":
                                    P = w ? w / (k ? Math.cos(A) : Math.sin(A)) : S / (k ? Math.sin(A) : Math.cos(A))
                            }
                        }
                        switch (y) {
                            case"top":
                            case"bottom":
                                P = 0;
                                break;
                            case"left":
                            case"right":
                                C = 0
                        }
                        a = Math.max(s.width + P, p), i = Math.max(s.height + C, p), e = (t.minWidth && t.minWidth > p && (a = Math.max(a, t.minWidth)), t.minHeight && t.minHeight > p && (i = Math.max(i, t.minHeight)), t.maxWidth && (a = Math.min(a, t.maxWidth)), t.maxHeight && (i = Math.min(i, t.maxHeight)), t.preserveAspectRatio && (C < P ? i = a * (s.height / s.width) : a = i * (s.width / s.height)), a === s.width && i === s.height || n.resize(a, i, {
                            snaplines: this.cid,
                            direction: f,
                            relativeDirection: y,
                            trueDirection: v,
                            snapped: !0
                        }), n.getBBox().bbox(h));
                        d && 1 < Math.abs(e.x - d) && 1 < Math.abs(e.width + e.x - d) && (d = null), u && 1 < Math.abs(e.y - u) && 1 < Math.abs(e.height + e.y - u) && (u = null), this.show({
                            vertical: d,
                            horizontal: u
                        })
                    }
                }
            }
        },
        canElementSnap: function (t, e) {
            let i = !0, n = !1;
            return util.isFunction(this.options.canSnap) && (i = this.options.canSnap.call(this, t)), e && (n = t.isDefaultInteractionPrevented(e)), i && this.canElementMove(t) && !n
        },
        canElementMove: function (t) {
            return t && t.model.isElement() && t.can("elementMove")
        },
        initializeSnapWhileMoving: function (e, i, t, n) {
            if (e.getDelegatedView()) {
                let t;
                util.isFunction(this.options.additionalSnapPoints) && (t = this.options.additionalSnapPoints.call(this, e, {type: "move"}));
                e = e.eventData(i).pointerOffset, e = new g.Point(e).scale(-1, -1);
                this.eventData(i, {cursorOffset: e, points: t, initialized: !0})
            }
        },
        snapWhileMoving: function (t, e, i, n) {
            var o = t.eventData(e).delegatedView || t;
            if (this.canElementSnap(o, e)) {
                this.eventData(e).initialized || this.initializeSnapWhileMoving(t, e, i, n);
                var {cursorOffset: t, points: s} = this.eventData(e);
                if (t) {
                    var r, a, l = o.model, e = l.size(), t = new g.Rect(i - t.x, n - t.y, e.width, e.height),
                        h = t.center(), e = t.bbox(l.angle()), c = e.origin(), d = e.corner(), u = this.options,
                        p = u.paper, m = u.distance, f = null, v = null, y = 0, x = 0;
                    if (s) for (let e = 0; e < s.length; e++) {
                        let t = s[e];
                        if (null === f && (Math.abs(t.x - h.x) < m ? (f = t.x, y = .5) : Math.abs(t.x - c.x) < m ? f = t.x : Math.abs(t.x - d.x) < m && (f = t.x, y = 1)), null === v && (Math.abs(t.y - h.y) < m ? (v = t.y, x = .5) : Math.abs(t.y - c.y) < m ? v = t.y : Math.abs(t.y - d.y) < m && (v = t.y, x = 1)), util.isNumber(f) && util.isNumber(v)) break
                    }
                    util.isNumber(f) && util.isNumber(v) || p.model.getElements().find(function (t) {
                        var e, i;
                        return !(t === l || t.isEmbeddedIn(l) || this.filterTypes[t.get("type")] || this.filterCells[t.id] || this.filterFunction && this.filterFunction(t)) && (e = (t = t.getBBox().bbox(t.get("angle"))).center(), i = t.origin(), t = t.corner(), null === f && (Math.abs(e.x - h.x) < m ? (f = e.x, y = .5) : Math.abs(i.x - c.x) < m ? f = i.x : Math.abs(i.x - d.x) < m ? (f = i.x, y = 1) : Math.abs(t.x - d.x) < m ? (f = t.x, y = 1) : Math.abs(t.x - c.x) < m && (f = t.x)), null === v && (Math.abs(e.y - h.y) < m ? (v = e.y, x = .5) : Math.abs(i.y - c.y) < m ? v = i.y : Math.abs(i.y - d.y) < m ? (v = i.y, x = 1) : Math.abs(t.y - d.y) < m ? (v = t.y, x = 1) : Math.abs(t.y - c.y) < m && (v = t.y)), util.isNumber(f)) && util.isNumber(v)
                    }, this), this.hide(), (util.isNumber(f) || util.isNumber(v)) && (util.isNumber(f) && (e.x = f - y * e.width), util.isNumber(v) && (e.y = v - x * e.height), r = (e = e.center()).x - t.width / 2, e = e.y - t.height / 2, a = new g.Point(r, e), u.usePaperGrid && a.snapToGrid(p.options.gridSize), l.position(a.x, a.y, {
                        restrictedArea: p.getRestrictedArea(o, i, n),
                        deep: !0,
                        snapped: !0
                    }), this.show({vertical: f, horizontal: v}))
                }
            }
        },
        show: function (t = {}) {
            var {vertical: t, horizontal: e} = t, {options: i, $horizontal: n, $vertical: o, $el: s} = this, {
                a: i,
                d: r,
                e: a,
                f: l
            } = i.paper.matrix();
            util.isNumber(e) ? n.css("top", e * r + l).css("display", "") : n.css("display", "none"), util.isNumber(t) ? o.css("left", t * i + a).css("display", "") : o.css("display", "none"), s.css("display", "")
        },
        hide: function () {
            this.$el.css("display", "none")
        }
    }, {HandlePosition: HandlePosition});
Snaplines.prototype.captureCursorOffset = Snaplines.prototype.initializeSnapWhileMoving;

class StackLayoutModel extends mvc.Model {
    constructor(t) {
        super(t), this.update()
    }

    defaults() {
        return {
            stackGap: 10,
            stackElementGap: 10,
            direction: StackLayout.Directions.TopBottom,
            stackIndexAttributeName: "stackIndex",
            stackElementIndexAttributeName: "stackElementIndex"
        }
    }

    update() {
        var t = StackLayout.layout(this.elements, this.attributes);
        this.bbox = t.bbox, this.stacks = t.stacks, this.trigger("update")
    }

    getStackFromPoint(e) {
        for (let t = 0; t < this.stacks.length; t++) {
            var i = this.stacks[t], n = i.bbox;
            if ((this.direction === StackLayout.Directions.BottomTop || this.direction === StackLayout.Directions.TopBottom) && e.x >= n.x && e.x < n.x + n.width) return i;
            if ((this.direction === StackLayout.Directions.RightLeft || this.direction === StackLayout.Directions.LeftRight) && e.y >= n.y && e.y < n.y + n.height) return i
        }
        return null
    }

    getInsertElementIndexFromPoint(t, e) {
        var i = t.elements, n = i.length;
        if (0 === n) return 0;
        switch (this.direction) {
            case StackLayout.Directions.TopBottom:
                for (let t = 0; t < n; t++) {
                    var o = i[t], o = o.position().y + o.size().height / 2;
                    if (e.y < o) return t
                }
                return n;
            case StackLayout.Directions.BottomTop:
                for (let t = 0; t < n; t++) {
                    var s = i[t], s = s.position().y + s.size().height / 2;
                    if (e.y > s) return t
                }
                return n;
            case StackLayout.Directions.LeftRight:
                for (let t = 0; t < n; t++) {
                    var r = i[t], r = r.position().x + r.size().width / 2;
                    if (e.x < r) return t
                }
                return n;
            case StackLayout.Directions.RightLeft:
                for (let t = 0; t < n; t++) {
                    var a = i[t], a = a.position().x + a.size().width / 2;
                    if (e.x > a) return t
                }
                return n
        }
    }

    getStackFromElement(t) {
        return this.stacks[t.get(this.stackIndexAttributeName)]
    }

    hasElement(t) {
        return t.has(this.stackIndexAttributeName)
    }

    insertElement(t, e, i, n) {
        var o = this.get("graph"), {
            stackIndexAttributeName: s,
            stackElementIndexAttributeName: r
        } = (o.startBatch("stack-layout-insert"), o.getCell(t) || o.addCell(t, n), this), a = this.stacks[e];
        let l;
        if (a) {
            var h = a.elements, a = h[i], c = h.length;
            if (a) {
                l = a.get(r);
                for (let t = i; t < c; t++) {
                    var d = h[t], u = d.get(r) || 0;
                    d.set(r, u + 1, n)
                }
            } else l = 0 < c ? (h[h.length - 1].get(r) || 0) + 1 : 0
        } else l = 0;
        t.set({[s]: e, [r]: l}, n), this.update(), o.stopBatch("stack-layout-insert")
    }

    get elements() {
        return this.get("graph").getElements().filter(t => t.has(this.stackIndexAttributeName))
    }

    get direction() {
        return this.get("direction")
    }

    get stackIndexAttributeName() {
        return this.get("stackIndexAttributeName")
    }

    get stackElementIndexAttributeName() {
        return this.get("stackElementIndexAttributeName")
    }
}

let previewDefault = (t, e) => {
        var e = e.model.direction, {targetStack: i, invalid: t} = t,
            n = V("path", {stroke: t ? "#ccc" : "#333", "stroke-width": 2});
        switch (e) {
            case StackLayout.Directions.RightLeft:
            case StackLayout.Directions.LeftRight:
                var o = i.bbox.height;
                n.attr("d", `M 0 ${-o / 2} v ` + o);
                break;
            case StackLayout.Directions.TopBottom:
            case StackLayout.Directions.BottomTop:
            default:
                o = i.bbox.width;
                n.attr("d", `M ${-o / 2} 0 h ` + o)
        }
        return n.node
    }, validateMovingCallbackDefault = (t, e) => !0,
    modifyInsertElementIndexCallbackDefault = (t, e, i) => t.insertElementIndex,
    canInteractCallbackDefault = (t, e) => e.model.hasElement(t.model), insertElementCallbackDefault = (t, e) => {
        e.model.insertElement(t.sourceElement, t.targetStack.index, t.insertElementIndex, {stackLayoutView: e.cid})
    };

class StackLayoutView extends mvc.View {
    constructor(t) {
        super(t), this.currentEventData = {}, this.paper = t.paper, this.model || (this.model = new StackLayoutModel(Object.assign({}, t.layoutOptions, {graph: this.paper.model}))), this.previewFunction = t.preview || previewDefault, this.validateMoving = t.validateMoving || validateMovingCallbackDefault, this.canInteract = t.canInteract || canInteractCallbackDefault, this.modifyInsertElementIndex = t.modifyInsertElementIndex || modifyInsertElementIndexCallbackDefault, this.insertElement = t.insertElement || insertElementCallbackDefault, this.startListening()
    }

    preinitialize() {
        this.svgElement = !0, this.tagName = "g"
    }

    startListening() {
        var t = this.paper;
        this.listenTo(t, "element:pointerdown", this.onPaperPointerdown), this.listenTo(t, "element:pointermove", this.onPaperPointermove), this.listenTo(t, "element:pointerup", this.onPaperPointerup)
    }

    getPreviewPosition(t, e) {
        var i, n = this.model.get("stackElementGap") / 2, o = this.model.direction, {bbox: s, elements: r} = t,
            a = r.length, l = r[e], h = {x: 0, y: 0};
        switch (o) {
            case StackLayout.Directions.TopBottom:
                h.x = s.x + s.width / 2, l ? h.y = l.position().y - n : (i = r[a - 1], h.y = i ? i.position().y + i.size().height + n : s.y - n);
                break;
            case StackLayout.Directions.BottomTop:
                h.x = s.x + s.width / 2, l ? h.y = l.position().y + l.size().height + n : (i = r[a - 1], h.y = i ? i.position().y - n : s.y + s.height + n);
                break;
            case StackLayout.Directions.LeftRight:
                h.y = s.y + s.height / 2, l ? h.x = l.position().x - n : (i = r[a - 1], h.x = i ? i.position().x + i.size().width + n : s.x - n);
                break;
            case StackLayout.Directions.RightLeft:
                h.y = s.y + s.height / 2, l ? h.x = l.position().x + l.size().width + n : (i = r[a - 1], h.x = i ? i.position().x - n : s.x + s.width + n)
        }
        return h
    }

    createGhost(t) {
        t = t.vel, t = t.clone();
        return t.attr("opacity", .4), t.node.style.transform = "", t.addClass("stack-layout-ghost"), t
    }

    dragstart(t, e, i) {
        t = this.model.getStackFromElement(t);
        this.currentEventData || (this.currentEventData = {}), Object.assign(this.currentEventData, {sourceStack: t})
    }

    drag(i, n, o) {
        if (this.currentEventData) {
            n = {x: n, y: o}, o = this.currentEventData.sourceStack;
            let e = this.currentEventData.preview;
            var s = this.model.getStackFromPoint(n);
            if (s) {
                let t;
                o && (t = o.elements.findIndex(t => t.id === i.id));
                var r = this.model.getInsertElementIndexFromPoint(s, n), r = this.modifyInsertElementIndex({
                    sourceStack: o,
                    sourceElement: i,
                    targetStack: s,
                    insertElementIndex: r
                }, new g.Point(n), this);
                if (s !== o || r !== t && r !== t + 1) return void (s === this.currentEventData.targetStack && r === this.currentEventData.insertElementIndex || (n = !this.validateMoving({
                    sourceStack: o,
                    sourceElement: i,
                    targetStack: s,
                    insertElementIndex: r
                }, this), e && e.remove(), (e = V(this.previewFunction({
                    sourceStack: o,
                    sourceElement: i,
                    targetStack: s,
                    insertElementIndex: r,
                    invalid: n
                }, this))).addClass("stack-layout-preview"), n && e.addClass("stack-layout-preview-invalid"), e.appendTo(this.paper.getLayerView(dia$1.Paper.Layers.FRONT).el), o = this.getPreviewPosition(s, r), V(e).attr("transform", `translate(${o.x},${o.y})`), Object.assign(this.currentEventData, {
                    invalid: n,
                    preview: e,
                    targetStack: s,
                    insertElementIndex: r
                })))
            }
            e && e.remove(), delete this.currentEventData.invalid, delete this.currentEventData.preview, delete this.currentEventData.targetStack, delete this.currentEventData.insertElementIndex
        }
    }

    dragend(t, e, i) {
        var n, o, s, r, a;
        this.currentEventData && ({
            preview: n,
            sourceStack: o,
            targetStack: s,
            insertElementIndex: r,
            invalid: a
        } = this.currentEventData, n && n.remove(), s) && !a && (this.insertElement({
            sourceStack: o,
            sourceElement: t,
            targetStack: s,
            insertElementIndex: r
        }, this), delete this.currentEventData)
    }

    cancelDrag() {
        var t;
        this.currentEventData && (t = this.currentEventData.preview, t && t.remove(), delete this.currentEventData)
    }

    canDrop() {
        var t, e;
        return !!this.currentEventData && ({targetStack: t, invalid: e} = this.currentEventData, t) && !e
    }

    onPaperPointerdown(t, e, i, n) {
        if (this.canInteract(t, this, e)) {
            if (t.can("elementMove")) throw new Error('ui.StackLayoutView: requires the "elementMove" interactivity set to false. e.g. paper.setInteractivity(false)');
            e = t.model, e = (this.dragstart(e, i, n), e.position());
            Object.assign(this.currentEventData, {ghost: this.createGhost(t), dx: i - e.x, dy: n - e.y})
        } else delete this.currentEventData
    }

    onPaperPointermove(t, e, i, n) {
        var o, s, r = this.currentEventData;
        r && (t = t.model, {
            ghost: t,
            dx: r,
            dy: o,
            invalid: s
        } = (this.drag(t, i, n), r), t) && (t.attr("transform", `translate(${i - r},${n - o})`), t.parent() || t.appendTo(this.paper.getLayerView(dia$1.Paper.Layers.FRONT).el), t.toggleClass("stack-layout-ghost-invalid", Boolean(s)))
    }

    onPaperPointerup(t, e, i, n) {
        var o = this.currentEventData;
        o && (o = o.ghost, o = (o && o.remove(), t).model, this.dragend(o, i, n))
    }
}

let $$6 = mvc.$;
var layoutDefaults = {
    options: function () {
        return {
            columnWidth: (this.options.width - 20 - 10) / 2,
            columns: 2,
            rowHeight: 80,
            rowGap: 10,
            columnGap: 10,
            marginX: 10,
            marginY: 10,
            resizeToFit: !0
        }
    }, layoutGroup: function (t, e) {
        var i = this.options.layout;
        if (e = e || {}, !GridLayout) throw new Error("ui.Stencil: joint.layout.GridLayout is not available.");
        GridLayout.layout(t, util.assign({}, i, e.layout))
    }
};
let Stencil = mvc.View.extend({
    className: "stencil",
    events: {
        "click .btn-expand": "openGroups",
        "click .btn-collapse": "closeGroups",
        "click .groups-toggle > .group-label": "openGroups",
        "click .group > .group-label": "onGroupLabelClick",
        "touchstart .group > .group-label": "onGroupLabelClick",
        "input .search": "onSearch",
        "focusin .search": "pointerFocusIn",
        "focusout .search": "pointerFocusOut"
    },
    documentEvents: {
        mousemove: "onDrag",
        touchmove: "onDrag",
        mouseup: "onDragEnd",
        touchend: "onDragEnd",
        touchcancel: "onDragEnd"
    },
    options: {
        width: 200,
        height: 800,
        label: "Stencil",
        groups: null,
        groupsToggleButtons: !1,
        dropAnimation: !1,
        search: null,
        layout: null,
        snaplines: null,
        scaleClones: !1,
        usePaperGrid: !1,
        dragThreshold: "onpointerdown",
        dragStartClone: function (t) {
            return t.clone()
        },
        dragEndClone: function (t) {
            return t.clone()
        },
        autoZIndex: !0,
        canDrag: null,
        layoutGroup: null,
        paperOptions: null,
        paperDragOptions: null,
        paperPadding: 10,
        contentOptions: null,
        container: null,
        hostEl: null
    },
    DEFAULT_GROUP: "__default__",
    PAPER_DRAG_MIN_PADDING: 5,
    init: function () {
        this.setPaper(this.options.paperScroller || this.options.paper), this.graphs = {}, this.papers = {}, this.$groups = {}, this.onSearch = util.debounce(this.onSearch, 200), this.delegateEvents(), this.initializeLayout()
    },
    initializeLayout: function () {
        var t = this.options.layout;
        t && (util.isFunction(t) ? this.layoutGroup = t : (this.layoutGroup = layoutDefaults.layoutGroup.bind(this), this.options.layout = util.isObject(t) ? t : layoutDefaults.options.call(this)))
    },
    setPaper: function (t) {
        var e = this.options;
        if (t instanceof dia$1.Paper) e.paperScroller = null, e.paper = t, e.graph = t.model; else {
            if (!("function" == typeof PaperScroller && t instanceof PaperScroller)) throw new Error("ui.Stencil: paper required");
            e.paperScroller = t, e.paper = t.options.paper, e.graph = t.options.paper.model
        }
    },
    freeze(e) {
        let i = this.papers;
        Object.keys(i).forEach(t => {
            i[t].freeze(e)
        })
    },
    unfreeze(e) {
        let i = this.papers;
        Object.keys(i).forEach(t => {
            i[t].unfreeze(e)
        })
    },
    renderContent: function () {
        return $$6("<div/>").addClass("content")
    },
    createDraggingPaper: function () {
        var t, e, i;
        this._paperDrag || (e = this.options, (i = document.createElement("div")).classList.add("stencil-paper-drag"), t = util.result(e, "paperOptions") || {}, e = util.result(e, "paperDragOptions") || {}, t = this._graphDrag = e.model || t.model || new dia$1.Graph({}, {cellNamespace: this.defaultCellNamespace}), e = util.assign({
            cellViewNamespace: this.defaultCellViewNamespace,
            overflow: !0,
            background: {color: "transparent"}
        }, e, {
            el: i,
            width: 1,
            height: 1,
            model: t,
            sorting: dia$1.Paper.sorting.NONE
        }), (i = new dia$1.Paper(e)).el.style.position = "absolute", this._paperDrag = i)
    },
    renderSearch: function () {
        var t = $$6("<input/>").addClass("search").attr({type: "search", placeholder: "search"});
        return $$6("<div/>").addClass("search-wrap").append(t)
    },
    renderToggleAll: function () {
        return [$$6("<div/>").addClass("groups-toggle").append($$6("<label/>").addClass("group-label").html(this.options.label)).append($$6("<button/>").addClass("btn btn-expand").text("+")).append($$6("<button/>").addClass("btn btn-collapse").text("-"))]
    },
    renderElementsContainer: function () {
        return $$6("<div/>").addClass("elements")
    },
    renderGroup: function (t) {
        t = t || {};
        var e = $$6("<div/>").addClass("group").data("name", t.name).toggleClass("closed", !!t.closed),
            t = $$6("<h3/>").addClass("group-label").html(t.label || t.name), i = this.renderElementsContainer();
        return e.append(t, i)
    },
    render: function () {
        this.dispose();
        var t, s = this.options,
            e = (this.$content = this.renderContent(), this.$el.empty().append(this.$content), s.search && this.$el.addClass("searchable").prepend(this.renderSearch()), s.groupsToggleButtons && this.$el.addClass("collapsible").prepend(this.renderToggleAll()), this.el.dataset.textNoMatchesFound = "No matches found", Object.keys(s.groups || {})),
            i = 0 < e.length;
        if (s.paperOptions && !util.isFunction(s.paperOptions) && s.paperOptions.model) throw new Error("ui.Stencil: the `paperOptions` has to be a function if there is the property `model` defined.");
        let r = "onpointerdown" === s.dragThreshold ? 0 : s.dragThreshold;
        return i ? util.sortBy(e, function (t) {
            return this[t].index
        }.bind(s.groups)).forEach(function (t) {
            var e = this.options.groups[t], i = this.$groups[t] = this.renderGroup({
                name: t,
                label: e.label,
                closed: e.closed
            }).appendTo(this.$content);
            if (e.paperOptions && e.paperOptions.model) throw new Error("ui.Stencil: the `model` property is not allowed in the `paperOptions` for the groups.");
            var [i] = i.find(".elements"), n = this.getGroupPaperOptions(t), o = this.createGroupGraph(t, n),
                n = util.assign({cellViewNamespace: this.defaultCellViewNamespace, moveThreshold: r}, n, {
                    el: i,
                    model: o,
                    interactive: !1,
                    preventDefaultBlankAction: !1,
                    width: e.width || s.width,
                    height: e.height || s.height
                }), i = new dia$1.Paper(n);
            this.graphs[t] = o, this.papers[t] = i
        }, this) : ([i] = this.renderElementsContainer().appendTo(this.$content), e = this.getGroupPaperOptions(null), t = this.createGroupGraph(null, e), e = util.assign({
            cellViewNamespace: this.defaultCellViewNamespace,
            moveThreshold: r
        }, e, {
            el: i,
            model: t,
            width: s.width,
            height: s.height,
            interactive: !1,
            preventDefaultBlankAction: !1
        }), i = new dia$1.Paper(e), this.graphs[this.DEFAULT_GROUP] = t, this.papers[this.DEFAULT_GROUP] = i), this.createDraggingPaper(), this.startListening(), this.setCellCursor(s.cellCursor), this
    },
    setCellCursor: function (t = "") {
        this.el.style.setProperty("--jj-stencil-cell-cursor", t), this.el.classList.toggle("has-cell-cursor", Boolean(t))
    },
    getGroupPaperOptions: function (t) {
        var e = this.options, e = [{}, util.result(e, "paperOptions")];
        return t && (t = util.result(this.getGroup(t), "paperOptions"), e.push(t)), util.assign(...e)
    },
    createGroupGraph: function (t, e) {
        let i;
        return (i = e.model || new dia$1.Graph({}, {cellNamespace: this.defaultCellNamespace})).set("group", t), i
    },
    paperEvents: {"cell:pointerdown": "onCellPointerdown", "cell:pointermove": "onCellPointermove"},
    startListening: function () {
        this.stopListening();
        var {paperEvents: t, papers: n} = this;
        for (let i in t) {
            let e = t[i];
            (e = "function" != typeof e ? this[e] : e) && util.forIn(n, t => {
                this.listenTo(t, i, e)
            })
        }
        util.forIn(n, i => {
            this.listenTo(i, "all", (t, ...e) => {
                this.trigger("group:" + t, i, ...e)
            })
        })
    },
    load: function (i, t) {
        Array.isArray(i) ? this.loadGroup(i, t) : util.isObject(i) && util.forIn(this.options.groups, function (t, e) {
            i[e] && this.loadGroup(i[e], e)
        }.bind(this))
    },
    loadGroup: function (t, e) {
        var i = this.options, n = this.getGraph(e);
        n.resetCells(t);
        let o = i.height;
        e && (o = this.getGroup(e).height), this.isLayoutEnabled() && this.layoutGroup(n, this.getGroup(e)), o || this.fitPaperToContent(this.getPaper(e))
    },
    isLayoutEnabled: function () {
        return Boolean(this.options.layout)
    },
    getGraph: function (t) {
        var e = this.graphs[t || this.DEFAULT_GROUP];
        if (e) return e;
        throw new Error("ui.Stencil: group " + t + " does not exist.")
    },
    getPaper: function (t) {
        return this.papers[t || this.DEFAULT_GROUP]
    },
    hasSnaplinesEnabled: function () {
        var t = this.options.snaplines;
        return Boolean(t) && !t.isDisabled()
    },
    preparePaperForDragging: function (t, e, i) {
        var {_paperDrag: n, _graphDrag: o, options: s} = this, {
            snaplines: s,
            usePaperGrid: r,
            scaleClones: a,
            paper: l,
            container: h
        } = s;
        this.stopListening(o), n.$el.stop(), n.$el.addClass("dragging").appendTo(h || document.body), this.positionCell(t, 0, 0), o.resetCells([t]);
        let c = this.PAPER_DRAG_MIN_PADDING;
        s && (c += s.options.distance), s || r || a ? ({
            sx: o,
            sy: s
        } = l.scale(), n.scale(o, s), c *= Math.max(o, s)) : n.scale(1, 1), n.fitToContent({
            padding: c,
            allowNewOrigin: "any"
        });
        r = t.findView(n), a = r.getBBox({useModelGeometry: !0}), l = a.origin().difference(r.getBBox().origin()), o = this.setPaperDragOffset(e, i, {
            cloneGeometryBBox: a,
            cloneViewDeltaOrigin: l,
            paperDragPadding: c
        }), s = $$6(h).offset();
        return s && (o.left -= s.left, o.top -= s.top), {
            clone: t,
            cloneView: r,
            cloneBBox: t.getBBox(),
            cloneGeometryBBox: a,
            cloneViewDeltaOrigin: l,
            paperDragPadding: c,
            paperDragInitialOffset: o
        }
    },
    removePaperAfterDragging: function () {
        var {_paperDrag: t, _graphDrag: e} = this;
        e.resetCells([]), this.$el.append(t.$el).removeClass("dragging"), t.$el.removeClass("dragging")
    },
    setPaperDragOffset: function (t, e, {cloneViewDeltaOrigin: i, cloneGeometryBBox: n, paperDragPadding: o}) {
        var {body: s, documentElement: r} = document, s = s.scrollTop || r.scrollTop, r = t - i.x - n.width / 2 - o,
            t = e - i.y - n.height / 2 - o + s;
        return this._paperDrag.$el.offset({left: r, top: t}), {left: r, top: t}
    },
    onCloneSnapped: function (t, e, i) {
        var n, o, s, r = this._dragging;
        r && ({snapped: i, tx: n, ty: o} = i, i ? ({
            cloneBBox: i,
            cloneView: s
        } = r, this.positionCell(t, i.x + n, i.y + o, {silent: !0}), s.translate(), t.set("position", e, {silent: !0}), r.snapOffset = {
            x: n,
            y: o
        }) : r.snapOffset = null)
    },
    _dragging: null,
    onCellPointerdown: function (t, e) {
        var i = this.options.dragThreshold;
        "onpointerdown" === i && this.onDragStart(t, e)
    },
    onCellPointermove: function (t, e) {
        var i = this.eventData(e).dragStarted;
        i || this.onDragStart(t, e)
    },
    onDragStart: function (t, e) {
        this.eventData(e, {dragStarted: !0});
        var i = this.options.canDrag, n = t.model, {group: o = null} = n.graph.attributes;
        "function" == typeof i && !i.call(this, t, e, o) || (i = this.getDragStartClone(n), this.startDragging(i, e))
    },
    startDragging(t, e) {
        var {options: i, _graphDrag: n} = this, {} = i, {
                clientX: i = 0,
                clientY: o = 0
            } = (this.createDraggingPaper(), this.$el.addClass("dragging"), e), s = this.preparePaperForDragging(t, i, o),
            r = s.cloneView, a = (this._dragging = s, this.getCloneArea(r, e, !1)), s = (util.assign(s, {
                clientX: i,
                clientY: o,
                validDropTarget: !1,
                cloneArea: a
            }), this.positionCell(t, a.x, a.y, {silent: !0}), t.isElement() && this.hasSnaplinesEnabled() && this.listenTo(n, "change:position", this.onCloneSnapped.bind(this)), e.data || (e.data = {})),
            i = (this.delegateDocumentEvents(null, s), this.getCurrentDropTarget());
        this.trigger("element:dragstart", r, e, i, !1), r.stopListening(), this.isDragCanceled() && (this.notifyDragEnd(r, e, i, !1), this._dragging = null)
    },
    onDrag: function (n) {
        var {_dragging: o, options: s} = this;
        if (o) {
            n.preventDefault();
            var r = util.normalizeEvent(n);
            if (this.isDragCanceled()) {
                let {cloneView: t, validDropTarget: e} = o;
                this.notifyDragEnd(t, r, this.getCurrentDropTarget(), e), void (this._dragging = null)
            } else {
                let {clone: t, cloneView: e} = o;
                var {paper: s, snaplines: a, usePaperGrid: l} = s;
                let i = this.insideValidArea({x: r.clientX, y: r.clientY});
                var l = this.getCloneArea(e, r, i && l), {x: h, y: c} = l.center(), {
                        x: d,
                        y: u
                    } = s.localToClientPoint(h, c), d = (util.assign(o, {
                        clientX: d,
                        clientY: u,
                        validDropTarget: i,
                        cloneArea: l
                    }), this.setPaperDragOffset(d, u, o), this.positionCell(t, 0, 0, {silent: !0}), e.translate(), this.positionCell(t, l.x, l.y, {stencil: this.cid}), this.hasSnaplinesEnabled() && (i ? a.snapWhileMoving(e, r, l.x, l.y) : a.hide()), s.options).embeddingMode,
                    l = (d && t.isElement() && (e.eventData(r, {paper: s}), u = o.cloneViewEventData = e.eventData(r), i ? e.processEmbedding(u, n, h, c) : e.clearEmbedding(u)), e.startListening(), this.getCurrentDropTarget());
                this.trigger("element:drag", e, r, l, i), e.stopListening(), this.isDragCanceled() && (this.notifyDragEnd(e, r, l, i), this._dragging = null)
            }
        }
    },
    getCurrentDropTarget: function () {
        if (!this._dragging) return null;
        var {cloneArea: t, snapOffset: e} = this._dragging;
        let {x: i, y: n} = t;
        return e && (i += e.x, n += e.y), new g.Rect(i, n, t.width, t.height)
    },
    onDragEnd: function (i) {
        var n = this._dragging;
        if (n) {
            var i = util.normalizeEvent(i), {
                clone: n,
                validDropTarget: o,
                cloneView: s,
                cloneBBox: r,
                snapOffset: a
            } = n;
            let t = r.x, e = r.y;
            a && (t += a.x, e += a.y), this.positionCell(n, t, e, {silent: !0}), this.notifyDragEnd(s, i, this.getCurrentDropTarget(), o), this.isDragCanceled() || (o ? this.onDrop(s, i) : this.onDropInvalid(s, i)), this._dragging = null
        }
    },
    notifyDragEnd: function (t, e, i, n) {
        t.startListening(), this.trigger("element:dragend", t, e, i.clone(), n), t.stopListening(), this.undelegateDocumentEvents()
    },
    getDragEndClone: function (t) {
        var e = this.options.dragEndClone(t);
        if (t !== e && e instanceof dia$1.Cell) return e;
        throw new Error("ui.Stencil: `dragEndClone` must return a clone of the cell")
    },
    getDragStartClone: function (t) {
        var e = this.options.dragStartClone(t);
        if (t !== e && e instanceof dia$1.Cell) return e;
        throw new Error("ui.Stencil: `dragStartClone` must return a clone of the cell")
    },
    onDrop: function (t, e) {
        var i, n = this.options, {paper: n, graph: o} = n, s = n.options.embeddingMode, r = t.model,
            a = (o.startBatch("stencil-drag"), this.getDragEndClone(r));
        this.drop(a, this.getCurrentDropTarget().center()), s && r.isElement() && (t.eventData(e, {
            model: a,
            paper: n,
            initialParentId: "stencil-initial-parent-id",
            whenNotAllowed: "remove"
        }), t.finalizeEmbedding(t.eventData(e))), o.getCell(a) ? ({
            x: s,
            y: i
        } = n.clientToLocalPoint(e.clientX, e.clientY), a = a.findView(n), this.trigger("element:drop", a, e, s, i), this.removePaperAfterDragging(r)) : this.onDropInvalid(t, e), o.stopBatch("stencil-drag")
    },
    onDropInvalid: function (t, e) {
        var i = this.options.paper, t = t.model, {x: i, y: n} = i.clientToLocalPoint(e.clientX, e.clientY),
            t = this.getDragEndClone(t);
        this.trigger("drop:invalid", e, t, i, n), this.cancelDrag()
    },
    cancelDrag: function ({dropAnimation: t} = this.options) {
        var e, i, n, o, s, {_dragging: r, options: a, _paperDrag: l} = this;
        r && ({clone: e, cloneView: s, cloneViewEventData: i, paperDragInitialOffset: n} = r, {
            paper: a,
            snaplines: o
        } = a, a.options.embeddingMode && i && e.isElement() && s.clearEmbedding(i), this.hasSnaplinesEnabled() && o.hide(), r.canceled = !0, t ? ({
            duration: a = 150,
            easing: s = "ease-in-out"
        } = t, l.$el.animate(n, {
            duration: a,
            easing: s,
            complete: this.removePaperAfterDragging.bind(this, e)
        })) : this.removePaperAfterDragging(e))
    },
    isDragCanceled: function () {
        var t = this._dragging;
        return !!t && Boolean(t.canceled)
    },
    drop: function (t, e) {
        var {graph: i, paper: n, autoZIndex: o} = this.options, {width: s, height: r} = t.getBBox();
        o && t.unset("z");
        let a = new g.Point({x: e.x - s / 2, y: e.y - r / 2});
        this._dragging.snapOffset || (a = n.snapToGrid(n.localToClientPoint(a.x, a.y))), this.positionCell(t, a.x, a.y), i.addCell(t, {stencil: this.cid})
    },
    insideValidArea: function (t) {
        var {hostEl: e, paper: i, paperScroller: n} = this.options, e = this.getDropArea(e || this.el);
        let o;
        return !(!(o = n ? n.options.autoResizePaper ? this.getDropArea(n.el) : (n = this.getDropArea(n.el), this.getDropArea(i.el).intersect(n)) : this.getDropArea(i.el)) || !o.containsPoint(t) || e.containsPoint(t))
    },
    getDropArea: function (t) {
        var e = $$6(t), {left: i, top: n} = e.offset(), {body: o, documentElement: s} = document,
            r = o.scrollTop || s.scrollTop, o = o.scrollLeft || s.scrollLeft,
            s = parseInt(e.css("border-left-width"), 10) || 0, e = parseInt(e.css("border-top-width"), 10) || 0;
        return new g.Rect({x: i + s - o, y: n + e - r, width: t.clientWidth, height: t.clientHeight})
    },
    getCloneArea(t, e, i) {
        var n = this.options.paper, t = t.model, {clientX: e, clientY: o} = e, {
            x: e,
            y: o
        } = n.clientToLocalPoint(e, o).round(), {width: t, height: s} = t.getBBox();
        let r = e - t / 2, a = o - s / 2;
        return i && ({x: e, y: o} = n.snapToGrid(n.localToClientPoint(r, a)), r = e, a = o), new g.Rect(r, a, t, s)
    },
    filter: function (a, l = this.options.search) {
        var t = Object.keys(this.papers).reduce((t, e) => {
            var i = this.papers[e], n = e === this.DEFAULT_GROUP ? null : e, o = i.model.getCells().filter(t => {
                var e = !1,
                    t = (l && (e = util.isFunction(l) ? l.call(this, t, a, n, this) : this.isCellMatched(t, a, l, a.toLowerCase() !== a)), i.findViewByModel(t));
                return t && t.vel.toggleClass("unmatched", !e), e
            }), s = !util.isEmpty(o), r = this.getGroupPaperOptions(n), r = this.createGroupGraph(n, r);
            return r.resetCells(o), this.trigger("filter", r, e, a), this.isLayoutEnabled() && this.layoutGroup(r, this.getGroup(e)), this.$groups[e] && this.$groups[e].toggleClass("unmatched", !s), this.fitPaperToContent(i), t || s
        }, !1);
        this.$el.toggleClass("not-found", !t)
    },
    isCellMatched: function (i, n, o, s) {
        return !n || Object.keys(o).some(function (t) {
            var e = o[t];
            return ("*" == t || i.get("type") == t) && e.some(function (t) {
                t = util.getByPath(i.attributes, t, "/");
                return null != t && (t = t.toString(), 0 <= (t = s ? t : t.toLowerCase()).indexOf(n))
            })
        })
    },
    fitPaperToContent: function (t) {
        var e = this.options, i = t.getComputedSize().width,
            i = util.assign({minWidth: i, padding: e.paperPadding}, e.contentOptions);
        t.fitToContent(i)
    },
    getGroup: function (t) {
        return this.options.groups && this.options.groups[t] || {}
    },
    onSearch: function (t) {
        t = t.target.value;
        this.$el.toggleClass("stencil-filtered", 0 < t.length), this.filter(t, this.options.search)
    },
    pointerFocusIn: function () {
        this.$el.addClass("is-focused")
    },
    pointerFocusOut: function () {
        this.$el.removeClass("is-focused")
    },
    onGroupLabelClick: function (t) {
        if ("touchstart" === t.type) this._groupLabelClicked = !0; else if (this._groupLabelClicked && "click" === t.type) return void (this._groupLabelClicked = !1);
        t = t.target.closest(".group");
        this.toggleGroup(t.dataset.name)
    },
    toggleGroup: function (t) {
        this.isGroupOpen(t) ? this.closeGroup(t) : this.openGroup(t)
    },
    closeGroup: function (t) {
        var e = this.$groups[t];
        e && this.isGroupOpen(t) && (this.trigger("group:close", t), e.addClass("closed"))
    },
    openGroup: function (t) {
        var e = this.$groups[t];
        e && !this.isGroupOpen(t) && (this.trigger("group:open", t), e.removeClass("closed"))
    },
    isGroupOpen: function (t) {
        t = this.$groups[t];
        return !!t && !t.hasClass("closed")
    },
    closeGroups: function () {
        Object.keys(this.$groups).forEach(function (t) {
            this.closeGroup(t)
        }, this)
    },
    openGroups: function () {
        Object.keys(this.$groups).forEach(function (t) {
            this.openGroup(t)
        }, this)
    },
    positionCell: function (t, e, i, n) {
        var o;
        t.isElement() ? t.position(e, i, n) : (o = t.getBBox(), t.translate(e - o.x, i - o.y, n))
    },
    onRemove: function () {
        this.dispose()
    },
    dispose: function () {
        util.invoke(this.papers, "remove"), this.papers = {}, this._paperDrag && (this._paperDrag.remove(), this._paperDrag = null), this.undelegateDocumentEvents()
    }
}), mergeAttrs = (Object.defineProperty(Stencil.prototype, "defaultCellNamespace", {
    enumerable: !0, get: function () {
        return this.options.paper.model.layerCollection.cellNamespace
    }
}), Object.defineProperty(Stencil.prototype, "defaultCellViewNamespace", {
    enumerable: !0, get: function () {
        return this.options.paper.options.cellViewNamespace
    }
}), V).mergeAttrs, {isEqual, isEmpty, flattenObject, setByPath} = util;

function getCombinedAnnotationAttrsAtIndex(t, n, e = {}) {
    let {merge: o = mergeAttrs} = e, s = {};
    return t.forEach(t => {
        var {start: t, end: e, attrs: i} = t;
        (void 0 === t && void 0 === e || t <= n && n < e) && o(s, i)
    }), s
}

function getCombinedAnnotationAttrsBetweenIndexes(t, e, i, n = {}) {
    var {delim: o = "/", merge: s = mergeAttrs} = n, r = V.findAnnotationsBetweenIndexes(t, e, i);
    if (e === i) return getCombinedAnnotationAttrsAtIndex(r, e, n);
    let a;
    for (let t = e; t < i; t++) {
        var l = getCombinedAnnotationAttrsAtIndex(r, t, n);
        if (a && !isEqual(a, l)) {
            a = flattenObject(s({}, a), o);
            var h, c = {};
            for (h in l = flattenObject(s({}, l), o)) a[h] === l[h] && setByPath(c, h, l[h], o);
            a = c
        } else a = l
    }
    return a
}

function normalizeAnnotations(o, s = {}) {
    var {compare: r = isEqual} = s, a = [];
    for (let i = -1, n = o.reduce((t, e) => {
        e = e.end;
        return void 0 === e ? t : Math.max(t, e)
    }, 0); i < n; i++) {
        let e = null;
        for (let t = i + 1; t <= n; t++) {
            var l = getCombinedAnnotationAttrsBetweenIndexes(o, t - 1, t, s);
            e ? r(l, e) || (t--, isEmpty(e) || a.push({start: i, end: t, attrs: e}), e = null, i = t) : e = l
        }
        if (e) {
            i < n && !isEmpty(e) && a.push({start: i, end: n, attrs: e});
            break
        }
    }
    return a
}

let $$5 = mvc.$, TextEditor = mvc.View.extend({
    options: {
        text: void 0,
        newlineCharacterBBoxWidth: 10,
        placeholder: void 0,
        focus: !0,
        debug: !1,
        selectAllThreshold: 20,
        useNativeSelection: !0,
        annotateUrls: !1,
        urlAnnotation: {attrs: {class: "url-annotation", fill: "lightblue", "text-decoration": "underline"}},
        textareaAttributes: {
            autocorrect: "off",
            autocomplete: "off",
            autocapitalize: "off",
            spellcheck: "false",
            tabindex: "0"
        }
    },
    className: "text-editor",
    events: {
        "keyup textarea": "onKeyup",
        "input textarea": "onInput",
        "copy textarea": "onCopy",
        "cut textarea": "onCut",
        "paste textarea": "onPaste",
        "mousedown .char-selection-box": "onMousedown",
        "dblclick .char-selection-box": "onDoubleClick",
        "click .char-selection-box": "onTripleClick"
    },
    selection: {start: null, end: null},
    selecting: !1,
    _textCursor: null,
    AFTER_KEYDOWN_DELAY: 10,
    DEFAULT_FONT_SIZE: 12,
    init: function () {
        util.bindAll(this, "onMousedown", "onMousemove", "onMouseup", "onDoubleClick", "onTripleClick", "onKeydown", "onAfterPaste", "onAfterKeydown", "onDocumentPointerdown");
        var t = this.options.text;
        if (!t) throw new Error("ui.TextEditor: text option is mandatory");
        this.setTextElement(t), document.addEventListener("pointerdown", this.onDocumentPointerdown, {capture: !0}), $$5(document.body).on("mousemove", this.onMousemove), $$5(document.body).on("mouseup", this.onMouseup), $$5(document.body).on("keydown", this.onKeydown), this.$viewport = $$5(t), this.options.annotations && this.setAnnotations(this.options.annotations)
    },
    setTextElement: function (t) {
        this.options.text = t, this.bindTextElement(t)
    },
    bindTextElement: function (t) {
        var e;
        this.unbindTextElement(), t && ((e = $$5(t)).on("mousedown", this.onMousedown), e.on("dblclick", this.onDoubleClick), e.on("click", this.onTripleClick), this.elText = t)
    },
    unbindTextElement: function () {
        var t = this.elText;
        t && ((t = $$5(t)).off("mousedown", this.onMousedown), t.off("dblclick", this.onDoubleClick), t.off("click", this.onTripleClick), this.elText = null)
    },
    render: function (t) {
        this.$caret = $$5("<div>").addClass("caret"), this.$selection = $$5("<div>"), this.$selectionBox = $$5("<div>").addClass("char-selection-box"), this.$el.append(this.$caret, this.$selection), this.$textareaContainer = $$5("<div>").addClass("textarea-container"), this.$textarea = $$5("<textarea>").attr(this.options.textareaAttributes), this.textarea = this.$textarea[0], this._textContent = this.textarea.value = this.getTextContent(), this._textareaValueBeforeInput = this.textarea.value, this.$textareaContainer.append(this.textarea), this.options.focus && this.$el.append(this.$textareaContainer), $$5(t || document.body).append(this.$el);
        var t = V(this.options.text), e = t.bbox();
        return this.$textareaContainer.css({
            left: e.x,
            top: e.y
        }), this.focus(), this._textCursor = t.attr("cursor"), t.attr("cursor", "text"), this.selectAll(), this
    },
    annotateURLBeforeCaret: function (t) {
        var e, i;
        return 0 !== t && (t = Math.max(t - 1, 0), e = this.getURLBoundary(t), i = this.getAnnotations() || [], e ? (this.annotateURL(i, e[0], e[1]), !0) : !!V.findAnnotationsAtIndex(i, t).some(t => t.url))
    },
    hasSelection: function () {
        return util.isNumber(this.selection.start) && util.isNumber(this.selection.end) && this.selection.start !== this.selection.end
    },
    textContentHasChanged: function () {
        return this._textContent !== this.textarea.value
    },
    restoreTextAreaSelectionDirection: function () {
        this._selectionDirection && (this.textarea.selectionDirection = this._selectionDirection)
    },
    storeSelectionDirection: function () {
        this._selectionDirection = this.textarea.selectionDirection
    },
    updateSelectionFromTextarea: function () {
        var {selectionStart: t, selectionEnd: e} = this.textarea;
        t === e ? this.setCaret(t) : this.select(t, e)
    },
    textSelectionHasChanged: function () {
        var {selection: t, textarea: e} = this;
        return !(!t || !e || t.start === e.selectionStart && t.end === e.selectionEnd)
    },
    isModifierKey: function (e) {
        return [16, 18, 17, 91].some(t => e.which === t)
    },
    isArrowKey: function (t) {
        return 37 <= t.which && t.which <= 40
    },
    copyToClipboard: function () {
        document.queryCommandSupported && document.queryCommandSupported("copy") && (this._copied = !0, document.execCommand("copy"))
    },
    findAnnotationsUnderCursor: function (t, e) {
        return V.findAnnotationsAtIndex(t, e)
    },
    findAnnotationsInSelection: function (t, e, i) {
        return V.findAnnotationsBetweenIndexes(t, e, i)
    },
    inferTextOperationType: function (t, e, i) {
        return t.start === t.end && e.start === e.end && 0 < i ? "insert" : t.start === t.end && e.start === e.end && i <= 0 ? "delete-single" : t.start !== t.end && e.start === e.end && e.start === t.start ? "delete" : t.start !== t.end && e.start !== t.start ? "delete-insert" : void 0
    },
    annotate: function (t, o, s, r) {
        var a = [], l = this.inferTextOperationType(o, s, r);
        return util.toArray(t).forEach(function (t) {
            var e, i, n;
            switch (l) {
                case"insert":
                    t.start < o.start && o.start <= t.end ? t.end += r : t.start >= o.start && (t.start += r, t.end += r);
                    break;
                case"delete-single":
                    t.start < o.start && o.start <= t.end && o.start !== s.start || t.start <= o.start && o.start < t.end && o.start === s.start ? t.end += r : t.start >= o.start && (t.start += r, t.end += r);
                    break;
                case"delete":
                    t.start <= o.start && o.start <= t.end ? o.end <= t.end ? t.end += r : t.end += s.start - t.end : t.start >= o.start && t.start < o.end ? (n = t.end - t.start, i = o.end - t.start, t.start = o.start, t.end = t.start + n - i) : t.start >= o.end && (t.start += r, t.end += r);
                    break;
                case"delete-insert":
                    t.start <= o.start && o.start <= t.end ? o.start < t.end && (o.end > t.end ? t.end = s.end : t.end = s.end + (t.end - o.end)) : t.start >= o.start && t.start <= o.end ? (e = s.start - o.start, i = o.end - t.start, n = t.end - t.start, t.start = o.start + e, t.end = t.start + n - i) : t.start >= o.start && t.end <= o.end ? t.start = t.end = 0 : t.start >= o.end && (t.start += r, t.end += r);
                    break;
                default:
                    this.options.debug && console.log("ui.TextEditor: Unknown text operation.")
            }
            t.end > t.start && a.push(t)
        }, this), a
    },
    shiftAnnotations: function (t, e, i) {
        return V.shiftAnnotations(t, e, i)
    },
    setCurrentAnnotation: function (t) {
        this._currentAnnotationAttributes = t
    },
    setAnnotations: function (t) {
        this._annotations = t
    },
    getAnnotations: function () {
        return this._annotations
    },
    getCombinedAnnotationAttrsAtIndex: function (t, e) {
        return getCombinedAnnotationAttrsAtIndex(util.toArray(e), t)
    },
    getSelectionAttrs: function (t, e) {
        var {start: t, end: i = t} = t;
        return t === i ? getCombinedAnnotationAttrsAtIndex(e, t - 1) : getCombinedAnnotationAttrsBetweenIndexes(e, t, i)
    },
    getTextContent: function () {
        var t = this.options.text, e = V(t).find(".v-line");
        return 0 === e.length ? t.textContent : e.reduce(function (t, e, i, n) {
            var o = e.node.textContent;
            return e.hasClass("v-empty-line") && (o = ""), i === n.length - 1 ? t + o : t + o + "\n"
        }, "")
    },
    startSelecting: function () {
        this.selecting = !0
    },
    stopSelecting: function () {
        this.selecting = !1
    },
    selectionInProgress: function () {
        return !0 === this.selecting
    },
    selectAll: function () {
        return this.select(0, this.getNumberOfChars())
    },
    select: function (t, e) {
        var {options: i, selection: n} = this, i = (i.debug && console.log("select(", t, e, ")"), n.start), o = n.end, {
            start: t,
            end: e
        } = (void 0 === e && (e = t), util.isNumber(t) && (n.start = t), util.isNumber(e) && (n.end = e), util.isNumber(n.end) || (n.end = n.start), n);
        return util.isNumber(t) && util.isNumber(e) && (i === t && o === e || this.setCurrentAnnotation(null), t === e ? (this.clearSelection(), this.focus(), this.setCaret(t)) : (this.hideCaret(), this.setTextAreaSelection(t, e), n = this.textarea.value, e < t && this.constructor.isLineEnding(n, e) ? this.constructor.isLineStart(n, t) && e !== t - 1 ? this.renderSelection(e, t - 2) : this.renderSelection(e, t - 1) : this.renderSelection(t, e)), this.trigger("select:change", t, e)), this
    },
    setTextAreaSelection: function (t, e) {
        t = this.normalizeSelectionRange({start: t, end: e});
        this.textarea.focus(), this.textarea.selectionStart = t.start, this.textarea.selectionEnd = t.end
    },
    renderSelection: function (t, e) {
        this.options.debug && console.log("renderSelection()");
        t = this.normalizeSelectionRange({start: t, end: e});
        this.clearSelection(), this.options.useNativeSelection ? (this.$viewport && (this._viewportUserSelectBefore = this.$viewport.css("user-select"), this.$viewport.css({
            "-webkit-user-select": "all",
            "-moz-user-select": "all",
            "user-select": "all"
        })), e = t.end - t.start, this.selectTextInElement(this.options.text, t.start, e)) : this.renderSelectionBoxes(t.start, t.end)
    },
    normalizeSelectionStartAndLength: function (t, e, i) {
        var n = t.substr(0, e), t = t.substr(e, i),
            n = (e -= this.countLineBreaks(n), i -= this.countLineBreaks(t), this.countEmptyLines(n));
        return {start: e += n, length: i = (i += n) - n + this.countEmptyLines(t)}
    },
    selectTextInElement: function (e, i, n) {
        if (util.isFunction(e.selectSubString) && this.selectTextInElementUsingSelectSubString(e, i, n), !this.actualSelectionMatchesExpectedSelection(i, n)) try {
            this.selectTextInElementUsingRanges(e, i, n)
        } catch (t) {
            this.options.debug && console.log(t), util.isFunction(e.selectSubString) && this.selectTextInElementUsingSelectSubString(e, i, n)
        }
    },
    selectTextInElementUsingSelectSubString: function (t, e, i) {
        e = this.normalizeSelectionStartAndLength(this.getTextContent(), e, i);
        try {
            t.selectSubString(e.start, e.length)
        } catch (t) {
            this.options.debug && console.log(t)
        }
    },
    selectTextInElementUsingRanges: function (t, e, i) {
        for (var n, o, s, r = window.getSelection(), a = (r.removeAllRanges(), this.normalizeSelectionStartAndLength(this.getTextContent(), e, i)), l = (e = 0 + a.start, i = 0 + a.length, this.getTextNodesFromDomElement(t)), h = 0, c = e + i, d = document.createRange(); 0 < i && 0 < l.length;) s = (o = h) + (n = l.shift()).length, (e <= o && o < c || e < s && s <= c || o <= e && e < s || o < c && c <= s) && (o = Math.max(e - o, 0), s = Math.min(o + Math.min(i, n.length), s), d.collapsed && d.setStart(n, o), d.setEnd(n, s), i -= s - o), h += n.length;
        d.collapsed || r.addRange(d)
    },
    actualSelectionMatchesExpectedSelection: function (t, e) {
        var i = window.getSelection().toString();
        return this.getExpectedSelectedContent(t, e) === (i = i.replace(/\s/g, " "))
    },
    getExpectedSelectedContent: function (t, e) {
        t = this.getTextContent().substr(t, e);
        return t = (t = (t = (t = 0 === t.search(/(\n\r|\r|\n)/) ? "-" + t : t).replace(/(\n\r|\r|\n){2,}/g, t => Array.from({length: t.length - 1}, () => "-").join(""))).replace(/\n\r|\r|\n/g, "")).replace(/\s/g, " ")
    },
    getTextNodesFromDomElement: function (t) {
        for (var e = [], i = 0, n = t.childNodes.length; i < n; i++) {
            var o = t.childNodes[i];
            void 0 !== o.tagName ? e = e.concat(this.getTextNodesFromDomElement(o)) : e.push(o)
        }
        return e
    },
    renderSelectionBoxes: function (e, i) {
        this.options.debug && console.log("renderSelectionBoxes()"), this.$selection.empty();
        for (var t, n, o, s = this.getFontSize(), r = this.getTextTransforms(), a = r.rotation, l = e; l < i; l++) {
            var h, c = this.$selectionBox.clone();
            try {
                o = this.getCharBBox(l)
            } catch (t) {
                this.trigger("select:out-of-range", e, i);
                break
            }
            n && 0 === a && Math.round(o.y) === Math.round(n.y) && Math.round(o.height) === Math.round(n.height) && Math.round(o.x) === Math.round(n.x + n.width) ? (h = parseInt(t.css("width"), 10), t.css("width", h + o.width)) : (c.css({
                left: o.x,
                top: o.y - o.height,
                width: o.width,
                height: o.height,
                "-webkit-transform": "rotate(" + a + "deg)",
                "-webkit-transform-origin": "0% 100%",
                "-moz-transform": "rotate(" + a + "deg)",
                "-moz-transform-origin": "0% 100%"
            }), this.$selection.append(c), t = c), n = o
        }
        o && this.$textareaContainer.css({left: o.x, top: o.y - s * r.scaleY})
    },
    clearSelection: function () {
        return this.options.debug && console.log("clearSelection()"), this.$selection.empty(), this.options.text.selectSubString && (this.$viewport && this._viewportUserSelectBefore && this.$viewport.css({
            "-webkit-user-select": this._viewportUserSelectBefore,
            "-moz-user-select": this._viewportUserSelectBefore,
            "user-select": this._viewportUserSelectBefore
        }), window.getSelection().removeAllRanges()), this
    },
    deselect: function () {
        return this.options.debug && console.log("deselect()"), this.stopSelecting(), this.clearSelection(), this.setTextAreaSelection(this.selection.start, this.selection.end), this
    },
    getSelectionStart: function () {
        return this.selection.start
    },
    getSelectionEnd: function () {
        return this.selection.end
    },
    getSelectionRange: function () {
        return this.normalizeSelectionRange(this.selection)
    },
    normalizeSelectionRange: function (t) {
        return (t = util.clone(t)).start > t.end && (t.end = [t.start, t.start = t.end][0]), t
    },
    getSelectionLength: function () {
        var t = this.getSelectionRange();
        return t.end - t.start
    },
    getSelection: function () {
        var t = this.getSelectionRange();
        return this.getTextContent().slice(t.start, t.end)
    },
    getWordBoundary: function (t) {
        for (var e = this.textarea.value, i = /\W/, n = t; n;) {
            if (i.test(e[n])) {
                n += 1;
                break
            }
            --n
        }
        for (var o = this.getNumberOfChars(), s = t; s < o && !i.test(e[s]);) s += 1;
        return n < s ? [n, s] : [s, n]
    },
    getURLBoundary: function (t) {
        for (var e = this.textarea.value, i = /\s/, n = t; -1 < n;) {
            if (i.test(e[n])) {
                n += 1;
                break
            }
            --n
        }
        for (var n = Math.max(n, 0), o = this.getNumberOfChars(), s = Math.max(n, t); s <= o && !i.test(e[s]);) s += 1;
        if (s = Math.min(s, o), /[-a-zA-Z0-9@:%_+.~#?&//=]{2,256}\.[a-z]{2,4}\b(\/[-a-zA-Z0-9@:%_+.~#?&//=]*)?/.test(e.substring(n, s))) return [n, s]
    },
    annotateURL: function (e, i, n) {
        let o = this.textarea.value.substring(i, n);
        if (!e.some(t => t.url === o && t.start === i && t.end === n)) {
            let t;
            var s = this.options.urlAnnotation;
            if ("function" == typeof s) {
                if (!(t = s(o))) return e
            } else t = util.assign({}, s);
            util.assign(t, {url: o, start: i, end: n}), e.push(t)
        }
        return e
    },
    getCharBBox: function (t) {
        var e, i, n;
        return this.isLineEnding(t) ? ((n = this.getCharBBox(t - 1)).x = n.x2, n.y = n.y2, n.width = this.options.newlineCharacterBBoxWidth || 10, n) : (n = this.realToSvgCharNum(t), e = (t = this.options.text).getStartPositionOfChar(n), i = t.getEndPositionOfChar(n), t = t.getExtentOfChar(n), e = this.localToScreenCoordinates(e), i = this.localToScreenCoordinates(i), n = this.getTextTransforms(), {
            x: e.x,
            y: e.y,
            width: t.width * n.scaleX,
            height: t.height * n.scaleY,
            x2: i.x,
            y2: i.y
        })
    },
    realToSvgCharNum: function (t) {
        for (var e = 0, i = 0; i <= t; i++) this.isLineEnding(i) && (e += 1);
        return t - e
    },
    selectionStartToSvgCharNum: function (t) {
        return t - this.nonEmptyLinesBefore(t)
    },
    svgToRealCharNum: function (t) {
        for (var e = 0, i = 0; i <= t + e; i++) this.isLineEnding(i) && (e += 1);
        return t + e
    },
    localToScreenCoordinates: function (t) {
        return V.transformPoint(t, this.options.text.getCTM())
    },
    getNumberOfChars: function () {
        return this.getTextContent().length
    },
    getCharNumFromEvent: function (t) {
        var e = this.options.text, e = V(e).toLocalPoint(t.clientX, t.clientY);
        return this.getCharNumAtPosition(e)
    },
    getCharNumAtPosition: function (t) {
        var e = this.options.text, i = e.getCharNumAtPosition(t);
        if (i < 0) {
            var n = V(e).getBBox(), o = (n.inflate(-1), n.containsPoint(t));
            if (!o && this.hasSelection() && n.clone().inflate(this.options.selectAllThreshold).containsPoint(t)) return this.selection.end;
            var o = o ? t : n.pointNearestToPoint(t), s = V.createSVGPoint(o.x, o.y), r = e.getCharNumAtPosition(s),
                a = t.x > n.x;
            if (-1 === r) {
                var l, h = n.x, c = n.x + n.width, d = (h + c) / 2;
                do {
                    s.x = d;
                    var u = e.getCharNumAtPosition(s)
                } while (-1 < u && (r = u), l = d, a && -1 < u || !a && -1 === u ? (d = (d + c) / 2, h = l) : (d = (h + d) / 2, c = l), 1 < Math.abs(l - d))
            }
            return -1 < r ? (o = this.svgToRealCharNum(r), a && "\n" !== this.getTextContent()[o] ? o + 1 : o) : t.x < n.x && t.y < n.y + n.height ? 0 : this.getNumberOfChars()
        }
        o = this.localToScreenCoordinates(t), n = this.getCharBBox(this.svgToRealCharNum(i));
        return Math.abs(n.x - o.x) < Math.abs(n.x + n.width - o.x) ? this.svgToRealCharNum(i) : this.svgToRealCharNum(i) + 1
    },
    lineNumber: function (t) {
        t = this.textarea.value.substr(0, t);
        return this.countLineBreaks(t)
    },
    emptyLinesBefore: function (t) {
        for (var e = this.textarea.value.split(/\n\r|\r|\n/g), i = 0, n = this.lineNumber(t) - 1; 0 <= n; n--) e[n] || (i += 1);
        return i
    },
    countLineBreaks: function (t) {
        return (t.match(/\n\r|\r|\n/g) || []).length
    },
    countEmptyLines: function (t) {
        let e = (t.match(/(\n\r|\r|\n){2,}/g) || []).reduce((t, e) => t + (e.length - 1), 0);
        return 0 === t.search(/(\n\r|\r|\n)/) && e++, e
    },
    nonEmptyLinesBefore: function (t) {
        return this.lineNumber(t) - this.emptyLinesBefore(t)
    },
    isEmptyLine: function (t) {
        return !this.textarea.value.split(/\n\r|\r|\n/g)[t]
    },
    isEmptyLineUnderSelection: function (t) {
        t = this.lineNumber(t);
        return this.isEmptyLine(t)
    },
    isLineEnding: function (t) {
        return this.constructor.isLineEnding(this.textarea.value, t)
    },
    getTextTransforms: function () {
        var t = this.options.text.getCTM();
        return V.decomposeMatrix(t)
    },
    getFontSize: function () {
        var {DEFAULT_FONT_SIZE: t, options: e} = this, e = parseFloat(e.text.getAttribute("font-size"));
        return Number.isNaN(e) ? t : e
    },
    getFontFill: function () {
        var t = this.options;
        return t.text.getAttribute("fill") || ""
    },
    getTextAnchor: function () {
        var t = this.options;
        return t.text.getAttribute("text-anchor") || ""
    },
    getCaretAttrs(t) {
        var e = this.getAnnotations() || [], i = this._currentAnnotationAttributes;
        return 0 !== e.length || i ? (e = getCombinedAnnotationAttrsAtIndex([...e, {attrs: i}], t - 1), i = parseFloat(e["font-size"]), t = e.fill, {
            "font-size": Number.isNaN(i) ? this.getFontSize() : i,
            fill: t || this.getFontFill()
        }) : {"font-size": this.getFontSize(), fill: this.getFontFill()}
    },
    setCaret: function (t, e) {
        util.isObject(t) && (e = t, t = void 0), e = e || {};
        var i = this.getNumberOfChars(), n = this.selection.start;
        return void 0 !== t && (t = Math.min(Math.max(t, 0), i), n = this.selection.start = this.selection.end = t), e.silent || this.trigger("caret:change", n), this.options.debug && console.log("setCaret(", t, e, ")", "selectionStart", n, "isLineEnding", this.isLineEnding(n), "isEmptyLineUnderSelection", this.isEmptyLineUnderSelection(n), "svgCharNum", this.selectionStartToSvgCharNum(n), "nonEmptyLinesBefore", this.nonEmptyLinesBefore(n)), this.updateCaret(), this.setTextAreaSelection(n, n), this.focus(), this
    },
    updateCaret: function () {
        var {$caret: t, $textareaContainer: e, selection: i, options: n, textarea: o} = this, i = i.start, {
            text: n,
            placeholder: s
        } = n, r = this.getNumberOfChars();
        let a;
        try {
            let t;
            a = this.isEmptyLineUnderSelection(i) || !this.isLineEnding(i) && o.value.length !== i ? (t = this.selectionStartToSvgCharNum(i), n.getStartPositionOfChar(t)) : (t = this.selectionStartToSvgCharNum(i) - 1, n.getEndPositionOfChar(t))
        } catch (t) {
            this.trigger("caret:out-of-range", i), a = {x: 0, y: 0}
        }
        var {x: o, y: n} = this.localToScreenCoordinates(a), {rotation: l, scaleY: h} = this.getTextTransforms(),
            i = this.getCaretAttrs(i), h = i["font-size"] * h, i = i.fill, c = this.getTextAnchor();
        let d = "";
        s && (t.data("placeholderText", "string" == typeof s ? s : "Enter text..."), 0 === r ? (t.addClass("placeholder"), "middle" === c && (d = "translateX(-50%)"), "end" === c && (d = "translateX(-100%)")) : t.removeClass("placeholder")), t.css({
            left: o,
            top: n - h,
            height: h,
            "line-height": h + "px",
            "font-size": h + "px",
            "-webkit-transform": `rotate(${l}deg) ` + d,
            "-webkit-transform-origin": "0% 100%",
            "-moz-transform": `rotate(${l}deg) ` + d,
            "-moz-transform-origin": "0% 100%",
            "background-color": i
        }).attr({"text-anchor": this.getTextAnchor()}), t.css("display", ""), e.css({left: o, top: n - h})
    },
    focus: function () {
        return this.options.debug && console.log("focus()"), this.showCaret(), this
    },
    blur: function () {
        return this.options.debug && console.log("blur()"), this.hideCaret(), this
    },
    showCaret: function () {
        return this.options.debug && console.log("showCaret()"), this.$caret.css("display", ""), this
    },
    hideCaret: function () {
        return this.options.debug && console.log("hideCaret()"), this.$caret.css("display", "none"), this
    },
    onRemove: function () {
        var {text: t, cellView: e = null} = this.options;
        this.deselect(), this.unbindTextElement(), document.removeEventListener("pointerdown", this.onDocumentPointerdown, {capture: !0}), $$5(document.body).off("mousemove", this.onMousemove), $$5(document.body).off("mouseup", this.onMouseup), $$5(document.body).off("keydown", this.onKeydown), V(t).attr("cursor", this._textCursor), this.trigger("close", t, e)
    },
    onDocumentPointerdown: function (t) {
        var {text: e, onOutsidePointerdown: i} = this.options, n = t.target;
        e === n || e.contains(n) || "function" == typeof i && i.call(this, t, this)
    },
    onKeydown: function (t) {
        this.options.debug && console.log("onKeydown(): ", t.keyCode);
        var e = this.options.onKeydown;
        "function" == typeof e && (e.call(this, t, this), t.isPropagationStopped()) || this.isModifierKey(t) || (this.hasSelection() && (this.deselect(), this.restoreTextAreaSelectionDirection()), setTimeout(this.onAfterKeydown, this.AFTER_KEYDOWN_DELAY), this._copied = !1, this._selectionStartBeforeInput = this.textarea.selectionStart, this._selectionEndBeforeInput = this.textarea.selectionEnd)
    },
    onAfterKeydown: function () {
        this.textarea === document.activeElement && (this.storeSelectionDirection(), this.setCurrentAnnotation(null), this.updateSelectionFromTextarea())
    },
    onKeyup: function (t) {
        var e;
        this.textContentHasChanged() && this.onInput(t), this.textSelectionHasChanged() && !this.isArrowKey(t) && ({
            selectionEnd: t,
            selectionStart: e
        } = this.textarea, t !== e) && this.updateSelectionFromTextarea()
    },
    onCopy: function (t) {
        this._copied || this.copyToClipboard()
    },
    onCut: function (t) {
        this._copied || this.copyToClipboard()
    },
    onInput: function (t) {
        var e, i, n, o, s, r;
        this.textContentHasChanged() && (e = this.textarea.value.length - this._textareaValueBeforeInput.length, i = {
            start: this._selectionStartBeforeInput,
            end: this._selectionEndBeforeInput
        }, n = {
            start: this.textarea.selectionStart,
            end: this.textarea.selectionEnd
        }, this.selection.start = this.textarea.selectionStart, this.selection.end = this.textarea.selectionEnd, this.options.debug && console.log("onInput()", t, "selectionBeforeInput", i, "selectionAfterInput", n, "diffLength", e), t = this.inferTextOperationType(i, n, e), o = !1, s = this.getAnnotations(), (s = this.options.annotateUrls && "insert" === t && (r = this.textarea.value.substr(i.start, e), this.options.debug && console.log("onInput()", "inserted text", r), /\s/.test(r)) && (o = this.annotateURLBeforeCaret(i.start)) ? this.shiftAnnotations(s, n.end, e) : s) && (o || (s = this.annotate(s, i, n, e)), this.options.debug && console.log("onInput()", "modified annotations", s), this._currentAnnotationAttributes) && "insert" === t && (r = {
            start: i.start,
            end: n.end,
            attrs: this._currentAnnotationAttributes
        }, s.push(r), this.setCurrentAnnotation(null), this.options.debug) && console.log("onInput()", "insert annotation", r, "final annotations", s), this._annotations = s, this.trigger("text:change", this.textarea.value, this._textareaValueBeforeInput, s, i, n), this._selectionBeforeInput = n, this._textareaValueBeforeInput = this.textarea.value, this._textContent = this.textarea.value)
    },
    onPaste: function (t) {
        this.options.debug && console.log("onPaste()"), this._textareaValueBeforeInput = this.textarea.value, setTimeout(this.onAfterPaste, 0)
    },
    onAfterPaste: function () {
        this.setCaret(this.textarea.selectionStart)
    },
    onMousedown: function (t) {
        var e;
        3 !== t.originalEvent.detail && (this.options.debug && console.log("onMousedown()"), e = this.getCharNumFromEvent(t), this.startSelecting(), this.select(e), t.preventDefault(), t.stopPropagation())
    },
    onMousemove: function (t) {
        var e;
        this.selectionInProgress() && (this.options.debug && console.log("onMousemove()"), e = this.getCharNumFromEvent(t), this.storeSelectionDirection(), this.select(null, e), t.preventDefault(), t.stopPropagation())
    },
    onMouseup: function (t) {
        this.selectionInProgress() && (this.options.debug && console.log("onMouseup()"), this.stopSelecting(), this.trigger("select:changed", this.selection.start, this.selection.end))
    },
    onDoubleClick: function (t) {
        this.options.debug && console.log("onDoubleClick()");
        var e = this.getCharNumFromEvent(t), e = this.getWordBoundary(e);
        this.select(e[0], e[1]), t.preventDefault(), t.stopPropagation()
    },
    onTripleClick: function (t) {
        3 === t.originalEvent.detail && (this.options.debug && console.log("onTripleClick()"), this.hideCaret(), this.selectAll(), t.preventDefault(), t.stopPropagation())
    }
}, util.assign({
    getTextElement: function (t) {
        var e = t.tagName.toUpperCase();
        if ("TEXT" === e || "TSPAN" === e || "TEXTPATH" === e) return "TEXT" === e ? t : this.getTextElement(t.parentNode)
    },
    edit: function (t, e) {
        var i, n = !1 !== (e = e || {}).update,
            o = (this.options = util.assign({}, e, {update: n}), this.getTextElement(t));
        if (!o) return void (this.options.debug && console.log("ui.TextEditor: cannot find a text element."));
        this.close(), this.ed = new TextEditor(util.assign({text: o}, e)), this.ed.on("all", this.trigger, this);
        let {cellView: s = null} = e;
        return this.trigger("open", o, s), s ? (i = s.paper.el, this.cellViewUnderEdit = s, this.cellViewUnderEditInteractiveOption = this.cellViewUnderEdit.options.interactive, this.cellViewUnderEdit.options.interactive = !1, e.annotationsProperty && !this.ed.getAnnotations() && (t = this.cellViewUnderEdit.model.prop(e.annotationsProperty)) && this.ed.setAnnotations(cloneDeep(t))) : i = V(o).svg().parentNode, n && this.ed.on("text:change", (t, e, i) => {
            s ? this.updateCellView(s, t, i) : this.updateSVGTextNode(o, t, i)
        }), this.ed.render(i), this
    },
    updateCellView: function (t, e, i) {
        var {textProperty: n, annotationsProperty: o} = this.options, s = this.ed.cid, t = t.model;
        n && t.prop(n, e, {textEditor: s, async: !1}), o && t.prop(o, cloneDeep(i), {
            rewrite: !0,
            textEditor: s,
            async: !1
        })
    },
    updateSVGTextNode: function (t, e, i) {
        V(t).text(e, {annotations: i})
    },
    close: function () {
        var t;
        this.ed && (this.ed.options.annotateUrls && (t = this.ed.getSelectionStart(), this.findAnnotationsUnderCursor().find(function (t) {
            return !!t.url && t
        }) || this.ed.annotateURLBeforeCaret(t) && this.applyAnnotations(this.getAnnotations())), this.ed.remove(), this.cellViewUnderEdit && (this.cellViewUnderEdit.options.interactive = this.cellViewUnderEditInteractiveOption), this.ed = this.cellViewUnderEdit = this.cellViewUnderEditInteractiveOption = void 0)
    },
    applyAnnotations: function (t) {
        var e = this.options, i = this.ed;
        i && e.update && (e.cellView && e.annotationsProperty ? (e.cellView.model.prop(e.annotationsProperty, cloneDeep(t), {
            rewrite: !0,
            textEditor: i.cid
        }), i.setAnnotations(t)) : V(i.options.text).text(i.getTextContent(), {annotations: t}), e = this.getSelectionRange(), 0 < this.getSelectionLength() ? i.select(e.start, e.end) : i.setCaret())
    },
    proxy: function (t, e) {
        var i = this.ed;
        if (i) return i[t].apply(i, e)
    },
    isEmptyLine: function (t, e) {
        var i = t[e - 1], n = t[e];
        return 0 === e && "\n" === n || "\n" === n && "\n" === i || e === t.length && "\n" === i
    },
    isLineEnding: function (t, e) {
        return "\n" === t[e] && 0 < e && "\n" !== t[e - 1]
    },
    isLineStart: function (t, e) {
        return "\n" !== t[e] && (0 === e || "\n" === t[e - 1])
    },
    getCombinedAnnotationAttrsAtIndex: getCombinedAnnotationAttrsAtIndex,
    getCombinedAnnotationAttrsBetweenIndexes: getCombinedAnnotationAttrsBetweenIndexes,
    normalizeAnnotations: normalizeAnnotations
}, mvc.Events));

function cloneDeep(t) {
    try {
        return JSON.parse(JSON.stringify(t))
    } catch (t) {
    }
}

TextEditor.findAnnotationsUnderCursor = function () {
    var t = this.ed;
    return t ? this.proxy("findAnnotationsUnderCursor", [t.getAnnotations(), t.getSelectionStart()]) : null
}, TextEditor.findAnnotationsInSelection = function () {
    var t, e, i = this.ed;
    return i ? ({
        start: t,
        end: e
    } = i.getSelectionRange(), this.proxy("findAnnotationsInSelection", [i.getAnnotations(), t, e])) : null
}, TextEditor.getSelectionAttrs = function (t) {
    var e = this.ed;
    return e ? this.proxy("getSelectionAttrs", [e.getSelectionRange(), t]) : null
}, ["setCurrentAnnotation", "getAnnotations", "setCaret", "deselect", "selectAll", "select", "getNumberOfChars", "getCharNumFromEvent", "getWordBoundary", "getSelectionLength", "getSelectionRange"].forEach(t => {
    TextEditor[t] = function () {
        return this.proxy(t, arguments)
    }
});
let Widget = mvc.View.extend({
    className: "widget", references: [], constructor: function (t, e) {
        this.availableReferences = e || {}, mvc.View.prototype.constructor.call(this, t)
    }, updateAttrs: function (t) {
        util.setAttributesBySelector(this.$el, t)
    }, bindEvents: function () {
    }, validateReferences: function () {
        var t = this.references || [], e = [];
        return t.forEach(function (t) {
            void 0 === this.availableReferences[t] && e.push(t)
        }, this), e
    }, getReference: function (t) {
        return this.availableReferences[t]
    }, getReferences: function () {
        return this.availableReferences
    }, enable: function () {
    }, disable: function () {
    }, isDisabled: function () {
        return !1
    }
}, {
    create: function (t, e, i = {}) {
        var n = util.camelCase(util.isString(t) ? t : t.type);
        if (!util.isFunction(i[n])) throw new Error('Widget: unable to find widget: "' + n + '"');
        i = new i[n](t, e), e = i.validateReferences(e);
        if (0 < e.length) throw new Error('Widget: "' + n + '" missing dependency: ' + e.join(", "));
        return i.render(), i.updateAttrs(t.attrs), i.bindEvents(), i.el.dataset.type = n, t.name && (i.el.dataset.name = t.name), i
    }
}), $$4 = mvc.$, checkbox = Widget.extend({
    tagName: "label",
    events: {
        "input .input": "onInput",
        "change .input": "onChange",
        mousedown: "pointerdown",
        touchstart: "pointerdown",
        mouseup: "pointerup",
        touchend: "pointerup",
        click: "pointerclick"
    },
    documentEvents: {mouseup: "pointerup", touchend: "pointerup"},
    init: function () {
        util.bindAll(this, "pointerup")
    },
    render: function () {
        var t = this.options, e = $$4("<span/>").text(t.label || "");
        return this.$input = $$4("<input/>").addClass("input").attr("type", "checkbox").prop("checked", !!t.value), this.$span = $$4("<span/>"), this.$el.append([e, this.$input, this.$span]), this
    },
    onChange: function (t) {
        this.trigger("change", !!t.target.checked, t)
    },
    onInput: function (t) {
        this.trigger("input", !!t.target.checked, t)
    },
    pointerdown: function (t) {
        t = util.normalizeEvent(t), this.$el.addClass("is-in-action"), this.trigger("pointerdown", t), this.delegateDocumentEvents()
    },
    pointerclick: function (t) {
        t = util.normalizeEvent(t), this.trigger("pointerclick", t)
    },
    pointerup: function (t) {
        t = util.normalizeEvent(t), this.undelegateDocumentEvents(), this.trigger("pointerup", t), this.$el.removeClass("is-in-action"), "touchend" === t.type && (this.$input[0].click(), t.preventDefault())
    },
    isDisabled: function () {
        return this.$input.prop("disabled")
    },
    enable: function () {
        this.$el.removeClass("disabled"), this.$input.prop("disabled", !1)
    },
    disable: function () {
        this.$el.addClass("disabled"), this.$input.prop("disabled", !0)
    }
}), toggle = Widget.extend({
    tagName: "label",
    events: {
        "input input.toggle": "onInput",
        "change input.toggle": "onChange",
        "click input.toggle": "pointerclick",
        mousedown: "pointerdown",
        touchstart: "pointerdown",
        mouseup: "pointerup",
        touchend: "pointerup"
    },
    documentEvents: {mouseup: "pointerup", touchend: "pointerup"},
    init: function () {
        util.bindAll(this, "pointerup")
    },
    render: function () {
        var t = this.options, e = $$4("<span/>").text(t.label || ""), i = $$4("<span><i/></span>"),
            t = (this.$input = $$4("<input/>").addClass("toggle").attr("type", "checkbox").prop("checked", !!t.value), $$4("<div/>").addClass(t.type));
        return this.$el.append([e, t.append(this.$input, i)]), this
    },
    onInput: function (t) {
        this.trigger("input", !!t.target.checked, t)
    },
    onChange: function (t) {
        this.trigger("change", !!t.target.checked, t)
    },
    pointerclick: function (t) {
        t = util.normalizeEvent(t), this.trigger("pointerclick", t)
    },
    pointerdown: function (t) {
        t = util.normalizeEvent(t), this.$el.addClass("is-in-action"), this.trigger("pointerdown", t), this.delegateDocumentEvents()
    },
    pointerup: function (t) {
        t = util.normalizeEvent(t), this.undelegateDocumentEvents(), this.$el.removeClass("is-in-action"), this.trigger("pointerup", t), "touchend" === t.type && (this.$input[0].click(), t.preventDefault())
    },
    isDisabled: function () {
        return this.$input.prop("disabled")
    },
    enable: function () {
        this.$el.removeClass("disabled"), this.$input.prop("disabled", !1)
    },
    disable: function () {
        this.$el.addClass("disabled"), this.$input.prop("disabled", !0)
    }
}), separator = Widget.extend({
    render: function () {
        return this.options.width && this.$el.css({width: this.options.width}), this
    }
}), label = Widget.extend({
    tagName: "label", render: function () {
        return this.$el.text(this.options.text), this
    }
}), range = Widget.extend({
    events: {"change .input": "onChange", "input .input": "onChange"}, render: function () {
        var t, e = this.options;
        return this.$output = $$4("<output/>").text(e.value), t = $$4("<span/>").addClass("units").text(e.unit), this.$input = $$4("<input/>").addClass("input").attr({
            type: "range",
            name: e.type,
            min: e.min,
            max: e.max,
            step: e.step
        }).val(e.value), this.$el.append([this.$input, this.$output, t]), this
    }, onChange: function (t) {
        var e = this.getValue();
        e !== this.currentValue && (this.currentValue = e, this.$output.text(e), this.trigger("change", e, t))
    }, getValue: function () {
        return parseInt(this.$input.val(), 10)
    }, setValue: function (t, e = {}) {
        this.$input.val(t), e.silent ? (t = this.getValue(), this.currentValue = t, this.$output.text(t)) : this.$input[0].dispatchEvent(new CustomEvent("change", {bubbles: !0}))
    }, isDisabled: function () {
        return this.$input.prop("disabled")
    }, enable: function () {
        this.$input.prop("disabled", !1)
    }, disable: function () {
        this.$input.prop("disabled", !0)
    }
}), selectBox = Widget.extend({
    render: function () {
        var t = util.omit(this.options, "type", "group", "index");
        return this.selectBox = new SelectBox(t), this.selectBox.render().$el.appendTo(this.el), this
    }, bindEvents: function () {
        this.selectBox.on("all", this.trigger, this)
    }, isDisabled: function () {
        return this.selectBox.isDisabled()
    }, enable: function () {
        this.selectBox.enable()
    }, disable: function () {
        this.selectBox.disable()
    }
}), button = Widget.extend({
    events: {
        mousedown: "pointerdown",
        mouseup: "pointerup",
        touchend: "pointerup",
        touchstart: "pointerdown",
        click: "pointerclick"
    }, tagName: "button", render: function () {
        var t = this.options;
        return this.$el.text(t.text), this
    }, pointerclick: function (t) {
        t = util.normalizeEvent(t), this.trigger("pointerclick", t)
    }, pointerdown: function (t) {
        t = util.normalizeEvent(t), this.trigger("pointerdown", t)
    }, pointerup: function (t) {
        t = util.normalizeEvent(t), this.trigger("pointerup", t), "touchend" === t.type && (this.el.click(), t.preventDefault())
    }, isDisabled: function () {
        return this.$el.prop("disabled")
    }, enable: function () {
        this.$el.prop("disabled", !1)
    }, disable: function () {
        this.$el.prop("disabled", !0)
    }
}), inputText = Widget.extend({
    events: {
        mousedown: "pointerdown",
        touchstart: "pointerdown",
        mouseup: "pointerup",
        touchend: "pointerup",
        click: "pointerclick",
        focusin: "pointerfocusin",
        focusout: "pointerfocusout",
        input: "onInput",
        change: "onChange"
    }, tagName: "div", render: function () {
        var t = this.options;
        return this.$label = $$4("<label/>").text(t.label), this.$text = $$4("<input/>").addClass("input").attr("type", "text").val(t.value), this.$input = $$4("<div/>").addClass("input-wrapper").append(this.$text), this.$el.append([this.$label, this.$input]), this
    }, pointerclick: function (t) {
        t = util.normalizeEvent(t), this.trigger("pointerclick", t)
    }, pointerdown: function (t) {
        t = util.normalizeEvent(t), this.trigger("pointerdown", t), "touchstart" === t.type && this.$text[0].focus()
    }, pointerup: function (t) {
        t = util.normalizeEvent(t), this.trigger("pointerup", t), "touchend" === t.type && (this.$text[0].click(), t.preventDefault())
    }, pointerfocusin: function (t) {
        t = util.normalizeEvent(t), this.$el.addClass("is-focused"), this.trigger("pointerfocusin", t)
    }, pointerfocusout: function (t) {
        t = util.normalizeEvent(t), this.$el.removeClass("is-focused"), this.trigger("pointerfocusout", t)
    }, onInput: function (t) {
        this.trigger("input", t.target.value, t)
    }, onChange: function (t) {
        this.trigger("change", t.target.value, t)
    }, isDisabled: function () {
        return this.$text.prop("disabled")
    }, enable: function () {
        this.$text.prop("disabled", !1)
    }, disable: function () {
        this.$text.prop("disabled", !0)
    }
}), inputNumber = Widget.extend({
    events: {
        mousedown: "pointerdown",
        touchstart: "pointerdown",
        mouseup: "pointerup",
        touchend: "pointerup",
        click: "pointerclick",
        focusin: "pointerfocusin",
        focusout: "pointerfocusout",
        input: "onInput",
        change: "onChange"
    }, tagName: "div", render: function () {
        var t = this.options;
        return this.$label = $$4("<label/>").text(t.label), this.$number = $$4("<input/>").addClass("number").attr({
            type: "number",
            max: t.max,
            min: t.min
        }).val(t.value), this.$input = $$4("<div/>").addClass("input-wrapper").append(this.$number), this.$el.append([this.$label, this.$input]), this
    }, pointerclick: function (t) {
        t = util.normalizeEvent(t), this.trigger("pointerclick", t)
    }, pointerdown: function (t) {
        t = util.normalizeEvent(t), this.trigger("pointerdown", t), "touchstart" === t.type && this.$number[0].focus()
    }, pointerup: function (t) {
        t = util.normalizeEvent(t), this.trigger("pointerup", t), "touchend" === t.type && (this.$number[0].click(), t.preventDefault())
    }, pointerfocusin: function (t) {
        t = util.normalizeEvent(t), this.$el.addClass("is-focused"), this.trigger("pointerfocusin", t)
    }, pointerfocusout: function (t) {
        t = util.normalizeEvent(t), this.$el.removeClass("is-focused"), this.trigger("pointerfocusout", t)
    }, onInput: function (t) {
        this.trigger("input", t.target.value, t)
    }, onChange: function (t) {
        this.trigger("change", t.target.value, t)
    }, isDisabled: function () {
        return this.$number.prop("disabled")
    }, enable: function () {
        this.$number.prop("disabled", !1)
    }, disable: function () {
        this.$number.prop("disabled", !0)
    }
}), textarea = Widget.extend({
    events: {
        mousedown: "pointerdown",
        touchstart: "pointerdown",
        mouseup: "pointerup",
        touchend: "pointerup",
        click: "pointerclick",
        focusin: "pointerfocusin",
        focusout: "pointerfocusout",
        input: "onInput",
        change: "onChange"
    }, tagName: "div", render: function () {
        var t = this.options;
        return this.$label = $$4("<label/>").text(t.label), this.$textarea = $$4("<textarea/>").addClass("textarea").text(t.value), this.$input = $$4("<div/>").addClass("input-wrapper").append(this.$textarea), this.$el.append([this.$label, this.$input]), this
    }, pointerclick: function (t) {
        t.preventDefault(), t = util.normalizeEvent(t), this.trigger("pointerclick", t)
    }, pointerdown: function (t) {
        t = util.normalizeEvent(t), this.trigger("pointerdown", t), "touchstart" === t.type && this.$textarea[0].focus()
    }, pointerup: function (t) {
        t = util.normalizeEvent(t), this.trigger("pointerup", t), "touchend" === t.type && (this.$textarea[0].click(), t.preventDefault())
    }, pointerfocusin: function (t) {
        t = util.normalizeEvent(t), this.$el.addClass("is-focused"), this.trigger("pointerfocusin", t)
    }, pointerfocusout: function (t) {
        t = util.normalizeEvent(t), this.$el.removeClass("is-focused"), this.trigger("pointerfocusout", t)
    }, onInput: function (t) {
        this.trigger("input", t.target.value, t)
    }, onChange: function (t) {
        this.trigger("change", t.target.value, t)
    }, isDisabled: function () {
        return this.$textarea.prop("disabled")
    }, enable: function () {
        this.$textarea.prop("disabled", !1)
    }, disable: function () {
        this.$textarea.prop("disabled", !0)
    }
}), selectButtonGroup = Widget.extend({
    render: function () {
        var t = util.omit(this.options, "type", "group", "index");
        return this.selectButtonGroup = new SelectButtonGroup(t), this.selectButtonGroup.render().$el.appendTo(this.el), this
    }, bindEvents: function () {
        this.selectButtonGroup.on("all", this.trigger, this)
    }, isDisabled: function () {
        return this.selectButtonGroup.isDisabled()
    }, enable: function () {
        this.selectButtonGroup.enable()
    }, disable: function () {
        this.selectButtonGroup.disable()
    }
}), zoomIn = button.extend({
    references: ["paperScroller"],
    options: {min: .2, max: 5, step: .2},
    bindEvents: function () {
        if (this.options.autoToggle) {
            let t = this.getReferences().paperScroller;
            this.updateAvailability(t), this.listenTo(t.options.paper, "scale", () => this.updateAvailability(t))
        }
    },
    pointerdown: function (t) {
        var e = this.options;
        this.getReferences().paperScroller.zoom(e.step, {
            max: e.max,
            grid: e.step
        }), button.prototype.pointerdown.call(this, t)
    },
    updateAvailability: function (t) {
        t.zoom() < this.options.max ? this.enable() : this.disable()
    }
}), zoomOut = button.extend({
    references: ["paperScroller"],
    options: {min: .2, max: 5, step: .2},
    bindEvents: function () {
        if (this.options.autoToggle) {
            let t = this.getReferences().paperScroller;
            this.updateAvailability(t), this.listenTo(t.options.paper, "scale", () => this.updateAvailability(t))
        }
    },
    pointerdown: function (t) {
        var e = this.options;
        this.getReferences().paperScroller.zoom(-e.step, {
            min: e.min,
            grid: e.step
        }), button.prototype.pointerdown.call(this, t)
    },
    updateAvailability: function (t) {
        t.zoom() > this.options.min ? this.enable() : this.disable()
    }
}), zoomToFit = button.extend({
    references: ["paperScroller"],
    options: {min: .2, max: 5, step: .2, useModelGeometry: !1, padding: 20},
    pointerdown: function (t) {
        var e = this.options;
        this.getReferences().paperScroller.zoomToFit({
            padding: e.padding,
            scaleGrid: e.step,
            minScale: e.min,
            maxScale: e.max,
            useModelGeometry: e.useModelGeometry
        }), button.prototype.pointerdown.call(this, t)
    }
}), zoomSlider = range.extend({
    references: ["paperScroller"],
    options: {min: 20, max: 500, step: 20, value: 100, unit: " %"},
    bindEvents: function () {
        let e = this.getReferences().paperScroller;
        this.on("change", function (t) {
            e.zoom(t / 100, {absolute: !0, grid: this.options.step / 100})
        }, this), this.listenTo(e.options.paper, "scale", t => {
            this.setValue(Math.floor(100 * t), {silent: !0})
        })
    }
}), undo = button.extend({
    references: ["commandManager"], bindEvents: function () {
        if (this.options.autoToggle) {
            let t = this.getReferences().commandManager;
            this.updateAvailability(t), this.listenTo(t, "stack", () => this.updateAvailability(t))
        }
    }, pointerclick: function () {
        this.getReferences().commandManager.undo()
    }, updateAvailability: function (t) {
        t.hasUndo() ? this.enable() : this.disable()
    }
}), redo = button.extend({
    references: ["commandManager"], bindEvents: function () {
        if (this.options.autoToggle) {
            let t = this.getReferences().commandManager;
            this.updateAvailability(t), this.listenTo(t, "stack", () => this.updateAvailability(t))
        }
    }, pointerclick: function () {
        this.getReferences().commandManager.redo()
    }, updateAvailability: function (t) {
        t.hasRedo() ? this.enable() : this.disable()
    }
}), fullscreen = button.extend({
    onRender: function () {
        var [t] = $$4(this.options.target);
        !(this.target = t) || window.top.document !== t && window.top.document.contains(t) || (this.el.style.display = "none")
    }, pointerclick: function () {
        util.toggleFullScreen(this.target)
    }
}), colorPicker = Widget.extend({
    events: {"change .input ": "change", "input .input ": "input"}, render: function () {
        var t = this.options;
        return this.inputEl = document.createElement("input"), this.inputEl.classList.add("input"), this.inputEl.setAttribute("type", "color"), t.value ? this.setValue(t.value) : this.inputEl.value = "#FFFFFF", this.el.appendChild(this.inputEl), this
    }, _validateHexCode: function (t) {
        return /^#(?:[0-9a-fA-F]{6})$/.test(t)
    }, change: function (t) {
        t = util.normalizeEvent(t), this.trigger("change", t.target.value, t)
    }, input: function (t) {
        t = util.normalizeEvent(t), this.trigger("input", t.target.value, t)
    }, disable: function () {
        this.el.classList.add("disabled"), this.inputEl.disabled = !0
    }, enable: function () {
        this.el.classList.remove("disabled"), this.inputEl.disabled = !1
    }, setValue: function (t, e = {}) {
        this._validateHexCode(t) && (this.inputEl.value = t, e.silent || this.trigger("change"))
    }
}), widgets = {
    checkbox: checkbox,
    toggle: toggle,
    separator: separator,
    label: label,
    range: range,
    selectBox: selectBox,
    button: button,
    inputText: inputText,
    inputNumber: inputNumber,
    textarea: textarea,
    selectButtonGroup: selectButtonGroup,
    zoomIn: zoomIn,
    zoomOut: zoomOut,
    zoomToFit: zoomToFit,
    zoomSlider: zoomSlider,
    undo: undo,
    redo: redo,
    fullscreen: fullscreen,
    colorPicker: colorPicker
}, Align = {Left: "left", Right: "right"}, Toolbar = mvc.View.extend({
    options: {autoToggle: !1, widgetNamespace: null},
    align: ["left", "right"],
    className: "toolbar",
    defaultGroup: "default",
    widgets: [],
    groupViews: [],
    init: function () {
        this.tools = util.toArray(this.options.tools), this.groups = this.options.groups || {}
    },
    getWidgetByName: function (e) {
        return this.widgets.find(function (t) {
            return t.options.name === e
        })
    },
    getWidgets: function () {
        return this.widgets
    },
    groupsWithItemsPairs: function () {
        for (var i = {}, t = (this.tools.forEach(function (t) {
            var e = t.group || this.defaultGroup;
            i[e] = i[e] || {items: [], group: {}}, i[e].items.push(t), i[e].group = this.groups[e] || {}
        }, this), Object.keys(i)), e = [], n = 0, o = t.length; n < o; n++) {
            var s = t[n];
            e.push([s, i[s]])
        }
        var r = util.sortBy(e, function (t) {
            return t[1].group.index
        });
        return util.sortBy(r, function (t) {
            return t[1].group.align || "left"
        })
    },
    render: function () {
        var t = this.groupsWithItemsPairs(), i = !1;
        return t.forEach(function (t) {
            var e = t[0], t = t[1], e = this.renderGroup(e, t);
            !i && t.group.align && "right" === t.group.align && (i = !0, e.addClass("group-first")), e.appendTo(this.el)
        }, this), this
    },
    renderGroup: function (t, e) {
        var {references: i, autoToggle: n, widgetNamespace: o} = this.options, t = new ToolbarGroupView({
            name: t,
            align: e.group.align,
            items: e.items,
            references: i,
            autoToggle: n,
            widgetNamespace: o
        });
        return this.groupViews.push(t), t.on("all", function () {
            this.trigger.apply(this, arguments)
        }.bind(this)), t.render(), this.widgets = this.widgets.concat(t.widgets), t.$el
    },
    onRemove: function () {
        util.invoke(this.groupViews, "off"), util.invoke(this.groupViews, "remove")
    }
}, {Align: Align});
var ToolbarGroupView = mvc.View.extend({
    className: "toolbar-group", init: function () {
        this.widgets = []
    }, onRender: function () {
        this.el.dataset.group = this.options.name, this.$el.addClass(this.options.align), this.renderItems()
    }, renderItems: function () {
        util.toArray(this.options.items).forEach(function (t) {
            t = this.createWidget(t);
            this.$el.append(t.$el)
        }, this)
    }, createWidget: function (i) {
        var {references: t, autoToggle: e, widgetNamespace: n} = this.options,
            e = util.isString(i) ? {autoToggle: e, type: i} : util.assign({autoToggle: e}, i),
            e = Widget.create(e, t, n || widgets);
        return void 0 !== i.name && e.on("all", function (t) {
            var e = Array.prototype.slice.call(arguments, 1);
            this.trigger.apply(this, [i.name + ":" + t].concat(e))
        }.bind(this)), this.widgets.push(e), e
    }, onRemove: function () {
        util.invoke(this.widgets, "off"), util.invoke(this.widgets, "remove")
    }
});
let $$3 = mvc.$, TooltipPosition = {Left: "left", Top: "top", Bottom: "bottom", Right: "right"},
    TooltipArrowPosition = {Left: "left", Top: "top", Bottom: "bottom", Right: "right", Auto: "auto", Off: "off"},
    Tooltip = mvc.View.extend({
        className: "tooltip",
        options: {
            left: void 0,
            right: void 0,
            top: void 0,
            bottom: void 0,
            position: void 0,
            positionSelector: void 0,
            direction: "auto",
            minResizedWidth: 100,
            padding: 0,
            rootTarget: null,
            target: null,
            container: null,
            trigger: "hover",
            viewport: {selector: null, padding: 0},
            dataAttributePrefix: "tooltip",
            template: '<div class="tooltip-arrow"></div><div class="tooltip-arrow-mask"></div><div class="tooltip-content"></div>',
            animation: !1
        },
        init: function () {
            this.settings = {};
            var {animation: t = !1, container: e, template: i} = this.options;
            let n;
            if (e) {
                if ([n] = $$3(e), !n) throw new Error("ui.Tooltip: invalid container selector: " + e)
            } else n = document.body;
            this.container = n, util.bindAll(this, "render", "hide", "show", "toggle", "isVisible", "position"), this.enable(), t && this.animate(t), this.$el.append(i)
        },
        enable: function () {
            this.disable();
            let {trigger: t, rootTarget: e, target: i} = this.options;
            var n = t.split(" ");
            let o = this.getEventNamespace();
            e ? (this.$rootTarget = $$3(e), n.forEach(t => {
                switch (t) {
                    case"click":
                        this.$rootTarget.on("click" + o, i, this.toggle);
                        break;
                    case"hover":
                        this.$rootTarget.on("mouseover" + o, i, this.render);
                        break;
                    case"focus":
                        this.$rootTarget.on("focusin" + o, i, this.render)
                }
            })) : (this.$target = $$3(i), n.forEach(t => {
                switch (t) {
                    case"click":
                        this.$target.on("click" + o, this.toggle);
                        break;
                    case"hover":
                        this.$target.on("mouseover" + o, this.render);
                        break;
                    case"focus":
                        this.$target.on("focusin" + o, this.render)
                }
            }))
        },
        disable: function () {
            var t = this.getEventNamespace();
            this.$rootTarget?.off(t), this.$target?.off(t), this.$rootTarget = null, this.$target = null
        },
        isDisabled: function () {
            return !this.$rootTarget && !this.$target
        },
        animate: function ({duration: t = "500ms", delay: e = "400ms", timingFunction: i = "ease"} = {}) {
            this.$el.addClass("animated").css({animationDelay: e, animationDuration: t, animationTimingFunction: i})
        },
        onRemove: function () {
            this.disable(), this.unbindCurrentHideActions()
        },
        hide: function () {
            var t = this.settings;
            t && (this.unbindCurrentHideActions(), this.$el.removeClass(t.className), this.$el.remove(), this.trigger("close"))
        },
        show: function (t) {
            this.render(t || {target: this.options.target})
        },
        toggle: function (t) {
            this.isVisible() ? this.hide() : this.show(t)
        },
        isVisible: function () {
            return document.body.contains(this.el)
        },
        render: function (t) {
            let e = null, i = (void 0 !== t.x && void 0 !== t.y && (e = {x: t.x, y: t.y}), null);
            t.target && ([i] = $$3(t.target).closest(this.options.target));
            t = this.settings = this.getTooltipSettings(i);
            this.$(".tooltip-content").html(t.calculatedContent), i ? (t.currentTarget = i, this.bindHideActions(i)) : t.currentTarget = null;
            let n;
            n = e ? {
                x: e.x,
                y: e.y,
                width: 1,
                height: 1
            } : util.getElementBBox(i), this.el.style.display = "none", this.$el.removeClass("left right top bottom"), this.$el.addClass(t.className), t.shouldRender && $$3(this.container).append(this.$el);
            t = this.$("img");
            t.length ? t.on("load", function () {
                this.position(n), this.$el.addClass("rendered")
            }.bind(this)) : (this.position(n), this.$el.addClass("rendered"))
        },
        unbindHideActions: function (t) {
            var e = this.getEventNamespace() + ".remove";
            $$3(t).off(e), clearInterval(this.interval)
        },
        unbindCurrentHideActions: function () {
            this.settings?.currentTarget && this.unbindHideActions(this.settings.currentTarget)
        },
        bindHideOnRemoveTarget: function (t) {
            clearInterval(this.interval), this.interval = setInterval(function () {
                document !== t && document.contains(t) || (clearInterval(this.interval), this.hide())
            }.bind(this), 500)
        },
        bindHideActions: function (t) {
            var e = this.settings, i = $$3(t), n = this.getEventNamespace() + ".remove";
            this.bindHideOnRemoveTarget(t), this.options.trigger.split(" ").forEach(function (t) {
                t = {hover: ["mouseout", "mousedown"], focus: ["focusout"]}[t] || [];
                (t = e.hideTrigger ? e.hideTrigger.split(" ") || [] : t).forEach(function (t) {
                    i.on(t + n, this.hide)
                }, this)
            }, this)
        },
        getTooltipSettings: function (t) {
            var e = this.loadDefinitionFromElementData(t);
            return this.evaluateOptions(t, e)
        },
        evaluateOptions: function (n, o = {}) {
            let s = this.settings = util.assign({}, o, this.options), r = !0, a = s.dataAttributeContent;
            return util.forIn(s, (t, e) => {
                var i;
                "content" === e ? util.isFunction(t) ? null != (i = s.content.call(this, n, this)) && (!1 === i ? r = !1 : a = i) : a = t : (i = util.isFunction(t) ? t(n) : t, s[e] = null == i ? o[e] : i)
            }), s.shouldRender = r, s.calculatedContent = a, this.normalizePosition(s), s
        },
        loadDefinitionFromElementData: function (t) {
            var n;
            return t ? (t = this.getAllAttrs(t, "data-" + this.options.dataAttributePrefix), n = {}, util.forIn(t, function (t, e) {
                var i;
                "left" !== (i = e = "" === e ? "dataAttributeContent" : e) && "bottom" !== i && "top" !== i && "right" !== i && (n[e] = t)
            }), n) : {}
        },
        getAllAttrs: function (t, e) {
            for (var i = e || "", n = t.attributes, o = {}, s = 0, r = n.length; s < r; s++) {
                var a = n[s];
                a && a.name.startsWith(i) && (o[util.camelCase(a.name.slice(i.length))] = a.value)
            }
            return o
        },
        normalizePosition: function (t) {
            var e = t.left || t.right || t.top || t.bottom;
            !t.position && e && (t.left && (t.position = "left"), t.right && (t.position = "right"), t.top && (t.position = "top"), t.bottom) && (t.position = "bottom"), !t.positionSelector && e && (t.positionSelector = e)
        },
        position: function (t) {
            var e = this.settings,
                i = (this.el.style.display = "", this.$el.css("width", "auto"), util.getElementBBox(this.container)),
                n = this.getTooltipBBox(t, i), o = (this.$el.css({left: n.x, top: n.y, width: n.width || "auto"}), {});
            "left" !== e.position && "right" !== e.position && ("top" === e.position || "bottom" === e.position) ? o.left = t.x + t.width / 2 - n.x : o.top = t.y + t.height / 2 - n.y, o.top -= i.y, o.left -= i.x, this.$(".tooltip-arrow, .tooltip-arrow-mask").attr("style", null).css(o), e.direction && "off" !== e.direction && this.$el.addClass("auto" === e.direction ? e.position || "left" : e.direction)
        },
        getViewportViewBBox: function () {
            var t = this.settings, {selector: e, padding: i = 0} = t.viewport;
            let n;
            e ? [n] = $$3(t.currentTarget).closest(e) : n = document.documentElement;
            var o, t = util.getElementBBox(n);
            return e || ({
                clientWidth: e,
                clientHeight: o
            } = window.document.documentElement, t.width = e + window.scrollX, t.height = o + window.scrollY), t.x += i, t.y += i, t.width -= 2 * i, t.height -= 2 * i, t
        },
        basePositions: {
            left: function (t, e) {
                var i = {
                    x: e.positionedBBox.x + e.positionedBBox.width + e.padding,
                    y: e.targetBBox.y + e.targetBBox.height / 2 - e.tooltipBBox.height / 2
                };
                if (t) {
                    t = e.viewport.x + e.viewport.width - i.x;
                    if (e.minWidth < t && t < e.tooltipBBox.width + e.padding && (i.width = t), t < e.minWidth) return this.settings.position = "right", this.basePositions.right(!1, e)
                }
                return i
            }, right: function (t, e) {
                var i = {
                    x: e.positionedBBox.x - e.tooltipBBox.width - e.padding,
                    y: e.targetBBox.y + e.targetBBox.height / 2 - e.tooltipBBox.height / 2
                };
                if (t) {
                    t = e.positionedBBox.x - e.padding - e.viewport.x;
                    if (e.minWidth < t && t < e.tooltipBBox.width + e.padding && (i.width = t, i.x = e.viewport.x), t < e.minWidth) return this.settings.position = "left", this.basePositions.left(!1, e)
                }
                return i
            }, top: function (t, e) {
                var i = {
                    x: e.targetBBox.x + e.targetBBox.width / 2 - e.tooltipBBox.width / 2,
                    y: e.positionedBBox.y + e.positionedBBox.height + e.padding
                };
                if (t && e.viewport.y + e.viewport.height - (e.positionedBBox.y + e.positionedBBox.height + e.padding) < e.tooltipBBox.height) return this.settings.position = "bottom", this.basePositions.bottom(!1, e);
                return i
            }, bottom: function (t, e) {
                var i = {
                    x: e.targetBBox.x + e.targetBBox.width / 2 - e.tooltipBBox.width / 2,
                    y: e.positionedBBox.y - e.tooltipBBox.height - e.padding
                };
                if (t && e.positionedBBox.y - e.padding - e.viewport.y < e.tooltipBBox.height) return this.settings.position = "top", this.basePositions.top(!1, e);
                return i
            }
        },
        getTooltipBBox: function (t, e) {
            var i = this.settings, n = $$3(i.positionSelector), n = n[0] ? util.getElementBBox(n[0]) : t,
                o = this.measureTooltipElement(), s = this.getViewportViewBBox(), r = i.position || "left",
                a = i.padding, i = Math.min(i.minResizedWidth, o.width + a),
                r = this.basePositions[r].call(this, 0 < i, {
                    padding: a,
                    targetBBox: t,
                    positionedBBox: n,
                    tooltipBBox: o,
                    viewport: s,
                    minWidth: i
                });
            return r.x -= e.x, r.y -= e.y, r.y < s.y ? r.y = s.y : r.y + o.height > s.y + s.height && (r.y = s.y + s.height - o.height), r.x < s.x ? r.x = s.x : r.x + o.width > s.x + s.width && (r.x = s.x + s.width - o.width), r
        },
        measureTooltipElement: function () {
            var t = this.el.cloneNode(!0),
                e = (t.style.visibility = "hidden", t.style.left = "-1000px", t.style.top = "-500px", document.body.appendChild(t), {
                    width: t.offsetWidth,
                    height: t.offsetHeight
                });
            return document.body.removeChild(t), e
        }
    }, {TooltipPosition: TooltipPosition, TooltipArrowPosition: TooltipArrowPosition}), $$2 = mvc.$,
    TreeLayoutView = mvc.View.extend({
        MINIMAL_PREVIEW_SIZE: 10,
        DEFAULT_SNAP_TO_CLOSEST_ELEMENT_RADIUS: 100,
        className: "tree-layout",
        documentEvents: {
            mousemove: "onPointermove",
            touchmove: "onPointermove",
            mouseup: "onPointerup",
            touchend: "onPointerup"
        },
        options: {
            previewAttrs: {parent: {rx: 2, ry: 2}},
            useModelGeometry: !1,
            clone: function (t) {
                return t.clone()
            },
            canInteract: function () {
                return !0
            },
            validateConnection: null,
            validatePosition: null,
            fallbackToAncestor: !1,
            snapToClosestElement: !1,
            paperConstructor: dia$1.Paper,
            paperOptions: null,
            reconnectElements: null,
            translateElements: null,
            layoutFunction: null
        },
        init: function () {
            this.startListening(), this.render(), this.onSetTheme(null, this.theme)
        },
        startListening: function () {
            this.enable()
        },
        _isEnabled: !1,
        _onPointerdown: null,
        enable: function () {
            var t = this.options.paper, e = (this.disable(), this.canInteract(this.onPointerdown));
            this._isEnabled = !0, this.listenTo(t, "element:pointerdown", e), this._onPointerdown = e
        },
        disable: function () {
            var {_onPointerdown: t, options: e} = this, e = e.paper;
            this._isEnabled = !1, t && (this.stopListening(e, "element:pointerdown", t), this._onPointerdown = null)
        },
        isDisabled: function () {
            return !this._isEnabled
        },
        render: function () {
            var t = this.options.paper,
                e = (this.$activeBox = $$2("<div>").addClass("tree-layout-box active hidden").appendTo(this.el), this.options.paperOptions || {}),
                i = e.model || new dia$1.Graph({}, {cellNamespace: t.model.layerCollection.cellNamespace}),
                e = util.assign({cellViewNamespace: t.options.cellViewNamespace}, e, {
                    interactive: !1,
                    width: "100%",
                    height: "100%",
                    model: i
                });
            return this.draggingPaper = new this.options.paperConstructor(e), this.draggingPaper.undelegateEvents(), this.$translateBox = $$2("<div>").addClass("tree-layout-box translate hidden").append(this.draggingPaper.render().el).appendTo(this.el), this.$mask = $$2("<div>").addClass("tree-layout-mask"), this.svgViewport = V(t.cells), this.svgPreviewChild = V(this.renderChildPreview()).attr(this.options.previewAttrs.child || {}).addClass("tree-layout-preview child"), this.svgPreviewConnection = V(this.renderConnectionPreview()).attr(this.options.previewAttrs.link || {}).addClass("tree-layout-preview link"), this.svgPreviewParent = V(this.renderParentPreview()).attr(this.options.previewAttrs.parent || {}).addClass("tree-layout-preview parent"), this.svgPreview = V("g").addClass("tree-layout-preview-group").append([this.svgPreviewConnection, this.svgPreviewParent, this.svgPreviewChild]), this.$el.appendTo(t.el), this
        },
        renderChildPreview: function () {
            return V("circle")
        },
        renderParentPreview: function () {
            return V("rect")
        },
        renderConnectionPreview: function () {
            return V("path")
        },
        onSetTheme: function (e, i) {
            [this.svgPreview, this.$mask].forEach(function (t) {
                t && (e && t.removeClass(this.themeClassNamePrefix + e), t.addClass(this.themeClassNamePrefix + i))
            }, this)
        },
        onRemove: function () {
            this.svgPreview.remove(), this.$mask.remove()
        },
        toggleDropping: function (t) {
            this.$mask.toggleClass("dropping-not-allowed", !t), this.$translateBox.toggleClass("no-drop", !t)
        },
        canDrop: function () {
            return this.isActive() && !this.$translateBox.hasClass("no-drop")
        },
        isActive: function () {
            return !this.$translateBox.hasClass("hidden")
        },
        updateBox: function (t, e) {
            t.css({width: e.width, height: e.height, left: e.x, top: e.y})
        },
        positionTranslateBox: function (t) {
            t = V.transformPoint(t, this.ctm);
            this.$translateBox.css({left: t.x, top: t.y})
        },
        prepareDraggingPaper: function (t) {
            t = this.options.clone(t).position(0, 0);
            this.draggingPaper.scale(this.ctm.a, this.ctm.d), this.draggingPaper.model.resetCells([t])
        },
        dragstart: function (t, e, i) {
            var {$translateBox: n, $activeBox: o, options: s} = this, {
                paper: s,
                useModelGeometry: r
            } = s, [t] = (this.toggleDropping(!1), this.ctm = s.matrix(), t), s = t.findView(s);
            s ? (s = s.getBBox({useModelGeometry: r}), this.updateBox(n, util.defaults({
                x: e,
                y: i
            }, s)), this.updateBox(o, s), o.removeClass("external")) : (r = V.transformRect(t.getBBox(), this.ctm), this.updateBox(n, util.defaults({
                x: e,
                y: i
            }, r)), o.addClass("external")), this.positionTranslateBox({
                x: e,
                y: i
            }), this.show(), this.prepareDraggingPaper(t)
        },
        drag: function (o, i, n) {
            var t = this.model, s = {x: i, y: n},
                r = (this.candidate && (this.candidate = null, this.hidePreview()), this.positionTranslateBox(s), this.options).snapToClosestElement,
                a = Math.min(t.get("siblingGap"), t.get("gap")) / 2;
            if (r ? (r = r.radius || this.DEFAULT_SNAP_TO_CLOSEST_ELEMENT_RADIUS, (c = t.findClosestRootAreaByPoint(s, {expandBy: r})) && (c = c.findMinimalAreaByPoint(s, {expandBy: a}) || c, d = this.findClosestAreaByPointToRoot(c, s, r) || c)) : (r = t.getMinimalRootAreaByPoint(s)) && (d = r.findMinimalAreaByPoint(s, {expandBy: a})), d) {
                var l = this.findDirection(d, s), e = d.getLayoutSiblings(l), h = e.getSiblingRankByPoint(s);
                if (util.toArray(o).every(function (t) {
                    return this.isConnectionValid(t, e, h)
                }, this)) this.candidate = {
                    id: d.root.id,
                    direction: l,
                    siblingRank: h
                }, this.updatePreview(e, h), this.showPreview(), this.toggleDropping(!0); else {
                    var c = this.options.fallbackToAncestor;
                    let n = d.parentArea;
                    if (!0 === c && n) {
                        for (; n;) {
                            let t = this.findDirection(n, s), e = n.getLayoutSiblings(t),
                                i = e.getSiblingRankByPoint(s);
                            if (util.toArray(o).every(function (t) {
                                return this.isConnectionValid(t, e, i)
                            }, this)) return this.candidate = {
                                id: n.root.id,
                                direction: t,
                                siblingRank: i
                            }, this.updatePreview(e, i), this.showPreview(), void this.toggleDropping(!0);
                            n = n.parentArea
                        }
                        this.toggleDropping(!1)
                    } else if ("function" == typeof c) {
                        let e = c.call(this, o, d.root, h, l, this);
                        if (!e) return void this.toggleDropping(!1);
                        if (!util.toArray(o).every(function (t) {
                            return this.canReparent(t, e)
                        }, this)) throw new Error("ui.TreeLayoutView: Invalid candidate.");
                        var d, r = t.getLayoutArea(e);
                        if (r) return a = this.findDirection(r, s), d = (c = r.getLayoutSiblings(a)).getSiblingRankByPoint(s), this.candidate = {
                            id: e.id,
                            direction: a,
                            siblingRank: d
                        }, this.updatePreview(c, d), this.showPreview(), void this.toggleDropping(!0)
                    }
                    this.toggleDropping(!1)
                }
            } else {
                let t = !0, e = this.options.validatePosition;
                "function" == typeof e && (t = util.toArray(o).every(t => e.call(this, t, i, n, this))), this.toggleDropping(t)
            }
        },
        dragend: function (t, e, i) {
            var n, o = this.candidate, s = this.options;
            this.canDrop() && (o ? ("function" == typeof (n = s.reconnectElements) ? n.apply(this, [t, s.paper.getModelById(o.id), o.siblingRank, o.direction, this]) : this.reconnectElements(t, o), this.candidate = null) : "function" == typeof (n = s.translateElements) ? n.call(this, t, e, i, this) : this.translateElements(t, e, i)), this.hide()
        },
        show: function () {
            var {$mask: t, $activeBox: e, $translateBox: i, options: n} = this, [t] = t;
            t && !t.isConnected && n.paper.el.appendChild(t), e.toggleClass("hidden", e.hasClass("external")), i.removeClass("hidden")
        },
        hide: function () {
            this.$mask.remove().removeClass("dropping-not-allowed"), this.$activeBox.addClass("hidden"), this.$translateBox.addClass("hidden"), this.hidePreview()
        },
        cancelDrag: function () {
            this.candidate = null, this.undelegateDocumentEvents(), this.hide()
        },
        reconnectElement: function (t, e) {
            var i, {model: n, options: o} = this, s = n.graph,
                s = (s.getCell(t) || (s.addCell(t), n.layoutTree(t)), e.siblingRank + .5),
                r = {direction: e.direction, siblingRank: s, ui: !0, treeLayoutView: this.cid};
            n.reconnectElement(t, e.id, r) || ((i = (o = o.paper).getDefaultLink(t.findView(o))).set({
                source: {id: e.id},
                target: {id: t.id}
            }), i.addTo(o.model, r), n.changeSiblingRank(t, s, r), n.changeDirection(t, e.direction, r), i = n.getAttribute(t, "direction"), n.updateDirections(t, [i, e.direction], r))
        },
        reconnectElements: function (t, e) {
            t.forEach(function (t) {
                this.reconnectElement(t, e)
            }, this), this.layout()
        },
        translateElement: function (t, e, i) {
            var n = this.model, n = n.graph, o = n.getConnectedLinks(t, {inbound: !0}),
                o = (util.invoke(o, "remove"), t.get("size"));
            t.set("position", {x: e - o.width / 2, y: i - o.height / 2}, {
                ui: !0,
                treeLayoutView: this.cid
            }), n.getCell(t) || n.addCell(t, {ui: !0, treeLayoutView: this.cid})
        },
        translateElements: function (t, e, i) {
            t.forEach(function (t) {
                this.translateElement(t, e, i)
            }, this), this.layout()
        },
        layout: function () {
            util.isFunction(this.options.layoutFunction) ? this.options.layoutFunction.call(this, this) : this.model.layout({
                ui: !0,
                treeLayoutView: this.cid
            })
        },
        updatePreview: function (t, e) {
            var i = t.parentArea.root, n = Math.max(this.model.get("siblingGap") / 2, this.MINIMAL_PREVIEW_SIZE),
                n = {width: n, height: n}, e = t.getNeighborPointFromRank(e),
                o = t.getConnectionPoints(e, {ignoreSiblings: !0}), s = t.getParentConnectionPoint(),
                t = t.getChildConnectionPoint(e, n);
            this.updateParentPreview(i.position(), i.size(), i), this.updateChildPreview(e, n), this.updateConnectionPreview(s, t, o)
        },
        showPreview: function () {
            this.svgViewport.append(this.svgPreview)
        },
        hidePreview: function () {
            this.svgPreview.remove()
        },
        updateParentPreview: function (t, e) {
            this.svgPreviewParent.attr({x: t.x, y: t.y, width: e.width, height: e.height})
        },
        updateChildPreview: function (t, e) {
            this.svgPreviewChild.attr({cx: t.x, cy: t.y, r: e.width / 2})
        },
        updateConnectionPreview: function (t, e, i) {
            this.svgPreviewConnection.attr({d: connectors.rounded(t, e, i, {})})
        },
        findDirection: function (t, e) {
            var i, n = t.root.get("layout") || t.getType();
            switch (n) {
                case"BL-BR":
                case"TL-TR":
                case"L-R":
                    return i = n.split("-"), e.x > t.rootCX ? i[1] : i[0];
                case"BL-TL":
                case"BR-TR":
                case"B-T":
                    return i = n.split("-"), e.y > t.rootCY ? i[0] : i[1];
                case"L":
                case"R":
                case"T":
                case"B":
                case"TR":
                case"TL":
                case"BR":
                case"BL":
                    return n;
                default:
                    return t.direction
            }
        },
        isPointInSnapArea: function (t, e, i) {
            var n = e.getBBox();
            if (n.containsPoint(t)) return !0;
            switch (i) {
                case"B":
                    return t.y > n.bottomMiddle().y;
                case"T":
                    return t.y < n.topMiddle().y;
                case"L":
                    return t.x < n.leftMiddle().x;
                case"R":
                    return t.x > n.rightMiddle().x;
                case"BR":
                    return t.y > n.bottomMiddle().y && t.x > n.leftMiddle().x || t.x > n.rightMiddle().x && n.topMiddle().y < t.y;
                case"BL":
                    return t.y > n.bottomMiddle().y && t.x < n.rightMiddle().x || t.x < n.leftMiddle().x && n.topMiddle().y < t.y;
                case"TR":
                    return t.y < n.topMiddle().y && t.x > n.leftMiddle().x || t.x > n.rightMiddle().x && n.bottomMiddle().y > t.y;
                case"TL":
                    return t.y < n.topMiddle().y && t.x < n.rightMiddle().x || t.x < n.leftMiddle().x && n.bottomMiddle().y > t.y
            }
            return !1
        },
        findClosestAreaByPointToRoot: function (t, e, i) {
            let n = null, o = 1 / 0;
            if (!t.containsPoint(e, {expandBy: i})) return null;
            var s, r = t.root, a = r.getBBox().pointNearestToPoint(e), l = this.findDirection(t, e);
            if (!this.isPointInSnapArea(e, r, l)) return null;
            r.getBBox().inflate(i).containsPoint(e) && (n = t, o = a.squaredDistance(e));
            for (s of t.childAreas) {
                var h, c = this.findClosestAreaByPointToRoot(s, e, i);
                c && (h = c.root.getBBox().pointNearestToPoint(e).squaredDistance(e)) < o && (o = h, n = c)
            }
            return n
        },
        canReparent: function (t, e) {
            return t.id !== e.id && !this.model.graph.isSuccessor(t, e)
        },
        isConnectionValid: function (t, e, i) {
            var n = e.parentArea.root;
            if (!this.canReparent(t, n)) return !1;
            var o = this.model.getLayoutArea(t);
            if (o && o.parentArea && o.parentArea == e.parentArea && o.direction == e.direction) {
                o = o.siblingRank - i;
                if (0 == o || 1 == o) return !1
            }
            o = this.options.validateConnection;
            return "function" != typeof o || o.call(this, t, n, this, {
                siblingRank: i,
                direction: e.direction,
                level: e.parentArea.level + 1,
                siblings: e.layoutAreas.map(t => t.root)
            })
        },
        canInteract: function (i) {
            return function (t, e) {
                this.options.canInteract(t, e) && i.apply(this, arguments)
            }.bind(this)
        },
        startDragging: function (t) {
            t = Array.isArray(t) ? t : [t];
            util.isEmpty(t) || this.delegateDocumentEvents(null, {moveCounter: 0, draggedElements: t})
        },
        onPointerdown: function (t, e) {
            t.preventDefaultInteraction(e), this.startDragging(t.model)
        },
        onPointermove: function (t) {
            var t = util.normalizeEvent(t), e = t.data, i = this.options.paper,
                t = i.clientToLocalPoint({x: t.clientX, y: t.clientY});
            e.moveCounter === i.options.clickThreshold ? this.dragstart(e.draggedElements, t.x, t.y) : e.moveCounter > i.options.clickThreshold && this.drag(e.draggedElements, t.x, t.y), e.moveCounter++
        },
        onPointerup: function (t) {
            var t = util.normalizeEvent(t), e = t.data, i = this.options.paper;
            e.moveCounter >= i.options.clickThreshold && (i = i.clientToLocalPoint({
                x: t.clientX,
                y: t.clientY
            }), this.dragend(e.draggedElements, i.x, i.y)), this.undelegateDocumentEvents()
        }
    });

function constructTree(t, n = {}, o = null, s = []) {
    let {children: e, makeElement: r, makeLink: a} = n;
    var i = util.isFunction(e) ? e(t) : t[e || "children"];
    return o || (o = r(t, null, null), s.push(o)), util.toArray(i).forEach(function (t, e) {
        var e = r(t, o, e), i = a(o, e);
        s.push(e, i), constructTree(t, n, e, s)
    }), s
}

let PriorityQueue = function (t) {
    this.comparator = (t = t || {}).comparator || function (t, e) {
        return t - e
    }, this.index = {}, this.data = t.data || [], this.heapify()
}, Dijkstra = (PriorityQueue.prototype.isEmpty = function () {
    return 0 === this.data.length
}, PriorityQueue.prototype.insert = function (t, e, i) {
    t = {priority: t, value: e}, this.data.push(t), e = this.data.length - 1;
    i && (t.id = i, this.index[i] = e), this.bubbleUp(e)
}, PriorityQueue.prototype.peek = function () {
    return this.data[0] && this.data[0].value
}, PriorityQueue.prototype.peekPriority = function () {
    return this.data[0] && this.data[0].priority
}, PriorityQueue.prototype.updatePriority = function (t, e) {
    var i = this.index[t];
    if (null == i) throw new Error("Node with id " + t + " was not found in the heap.");
    var t = this.data, n = t[i].priority, n = this.comparator(e, n);
    n < 0 ? (t[i].priority = e, this.bubbleUp(i)) : 0 < n && (t[i].priority = e, this.bubbleDown(i))
}, PriorityQueue.prototype.remove = function () {
    var t = this.data, e = t[0], i = t.pop();
    return this.index[t.length] = null, 0 < t.length && ((t[0] = i).id && (this.index[i.id] = 0), this.bubbleDown(0)), e && e.value
}, PriorityQueue.prototype.heapify = function () {
    for (var t = 0; t < this.data.length; t++) this.bubbleUp(t)
}, PriorityQueue.prototype.bubbleUp = function (t) {
    for (var e, i, n = this.data; 0 < t && this.comparator(n[t].priority, n[e = t - 1 >>> 1].priority) < 0;) i = n[e], n[e] = n[t], n[t].id && (this.index[n[t].id] = e), n[t] = i, n[t].id && (this.index[n[t].id] = t), t = e
}, PriorityQueue.prototype.bubbleDown = function (t) {
    for (var e = this.data, i = e.length - 1; ;) {
        var n = 1 + (t << 1), o = 1 + n, s = t;
        if (n <= i && this.comparator(e[n].priority, e[s].priority) < 0 && (s = n), (s = o <= i && this.comparator(e[o].priority, e[s].priority) < 0 ? o : s) === t) break;
        n = e[s];
        e[s] = e[t], e[t].id && (this.index[e[t].id] = s), e[t] = n, e[t].id && (this.index[e[t].id] = t), t = s
    }
}, function (t, e, i) {
    i = i || function () {
        return 1
    };
    var n, o, s, r, a, l = {}, h = (l[e] = 0, {}), c = new PriorityQueue;
    for (n in t) n !== e && (l[n] = 1 / 0), c.insert(l[n], n, n);
    for (var d = {}; !c.isEmpty();) for (d[o = c.remove()] = !0, s = t[o] || [], r = 0; r < s.length; r++) d[n = s[r]] || (a = l[o] + i(o, n)) < l[n] && (l[n] = a, h[n] = o, c.updatePriority(n, a));
    return h
});

function shortestPath(t, e, i, n = {}) {
    let o = {};
    t.getLinks().forEach(function (t) {
        var e = t.get("source").id, t = (o[e] || (o[e] = []), t.get("target").id);
        o[t] || (o[t] = []), o[e].push(t), n.directed || o[t].push(e)
    });
    var s = Dijkstra(o, e.id || e, n.weight), r = [];
    let a = i.id || i;
    for (s[a] && r.push(a); a = s[a];) r.unshift(a);
    return r
}

function toAdjacencyList(i) {
    let n = {};
    return i.getElements().forEach(t => {
        let e = [];
        i.getNeighbors(t, {deep: !1, outbound: !0, indirect: !0}).forEach(t => {
            e.push(t.id)
        }), n[t.id] = e
    }), n
}

let Local = {
    prefix: "joint.storage", insert: function (t, e, i) {
        var n = e.id || util.uuid(), o = this.loadIndex(t);
        -1 === o.keys.indexOf(n) && o.keys.push(n), this.setItem(this.docKey(t, n), e), this.setItem(this.indexKey(t), o), this.callback(i, null, util.assign({}, e, {id: n}))
    }, find: function (i, t, n) {
        var e = this.loadIndex(i), o = [];
        util.isEmpty(t) ? (e.keys.forEach(function (t) {
            var e = this.getItem(this.docKey(i, t));
            e || this.callback(n, new Error("Storage inconsistency. No document found for an ID " + t + " from index.")), o.push(e)
        }, this), this.callback(n, null, o)) : t.id ? (e = this.getItem(this.docKey(i, t.id)), this.callback(n, null, e ? [e] : [])) : this.callback(n, null, [])
    }, remove: function (e, i, t) {
        var n = this.loadIndex(e);
        util.isEmpty(i) ? (n.keys.forEach(function (t) {
            localStorage.removeItem(this.docKey(e, t))
        }, this), localStorage.removeItem(this.indexKey(e)), this.callback(t, null)) : i.id && (n.keys = n.keys.filter(function (t) {
            return t !== i.id
        }), localStorage.removeItem(this.docKey(e, i.id)), this.setItem(this.indexKey(e), n), this.callback(t, null))
    }, callback: function (t, e, i) {
        t && setTimeout(function () {
            t(e, i)
        }, 1)
    }, setItem: function (t, e) {
        localStorage.setItem(t, JSON.stringify(e))
    }, getItem: function (t) {
        t = localStorage.getItem(t);
        return t && JSON.parse(t)
    }, loadIndex: function (t) {
        t = this.getItem(this.indexKey(t)) || {};
        return t.keys = t.keys || [], t
    }, docKey: function (t, e) {
        return this.prefix + "." + t + ".docs." + e
    }, indexKey: function (t) {
        return this.prefix + "." + t + ".index"
    }
}, $$1 = mvc.$, toSVG = (i, n, o) => {
    if (o = o || {}, void 0 === i) throw new Error("The the dia.Paper is a mandatory option.");
    i.trigger("beforeexport", o);
    var t = i.svg;
    let s = !1 !== o.fillFormControls;
    s && Array.from(t.getElementsByTagName("select")).forEach(t => V.ensureId(t));
    t = V(t).clone();
    let r = t.node;
    var e = t.findOne("." + util.addClassNamePrefix("layers")), a = o.area || i.getContentArea(),
        l = o.preserveDimensions, l = (l && t.attr({
            width: l.width || a.width,
            height: l.height || a.height
        }), t.removeAttr("style").attr("viewBox", [a.x, a.y, a.width, a.height].join(" ")), e.removeAttr("transform"), !1 !== o.useComputedStyles && copyExternalStyles(i.svg, r), o.grid || t.findOne("." + util.addClassNamePrefix("grid-layer")).remove(), o.stylesheet);
    util.isString(l) && addExternalStyles(t.node, l), i.trigger("afterexport", o);
    let h = t => {
        !1 != s && fillFormControls(r, i);
        var e = o.beforeSerialize;
        "function" == typeof e && (e = e.call(i, r, i)) instanceof SVGElement && (r = e), n(serialize(r), t)
    };
    o.convertImagesToDataUris ? convertImages(t.find("image,img")).then(() => h()).catch(t => {
        h(t)
    }) : h()
}, dataURIRegex = new RegExp(/^(data:)([\w\\+-]*)(;charset=[\w-]+|;base64){0,1},(.*)/gi);

function convertImages(t) {
    let i = {};
    return t.forEach(t => {
        let e = getImageURL(t);
        e && (e = e.trim(), dataURIRegex.test(e) || (e in i ? i[e].push(t) : i[e] = [t]))
    }), Promise.all(Object.keys(i).map(t => convertImageURL(t, i[t])))
}

function convertImageURL(t, o) {
    return new Promise((i, n) => {
        util.imageToDataUri(t, (t, e) => {
            t || !e ? n(t) : (o.forEach(t => setImageURL(t, e)), i())
        })
    })
}

function getImageURL(t) {
    return "IMAGE" !== t.tagName() ? t.attr("src") : t.attr("xlink:href") || t.attr("href")
}

function setImageURL(t, e) {
    "IMAGE" === t.tagName() ? (t.attr("xlink:href", e), t.attr("href") && t.attr("href", null)) : t.attr("src", e)
}

function fillFormControls(t, n) {
    Array.from(t.getElementsByTagName("input")).forEach(t => {
        switch (t.type) {
            case"checkbox":
            case"radio":
                t.checked ? t.setAttribute("checked", !0) : t.removeAttribute("checked");
                break;
            default:
                t.setAttribute("value", t.value)
        }
    }), Array.from(t.getElementsByTagName("textarea")).forEach(t => {
        t.textContent = t.value
    }), Array.from(t.getElementsByTagName("select")).forEach(t => {
        var e = t.id;
        if (e) {
            let i = n.svg.getElementById(e);
            i && Array.from(t.options).forEach((t, e) => {
                i.options[e].selected ? t.setAttribute("selected", !0) : t.removeAttribute("selected")
            })
        }
    })
}

function serialize(t) {
    return (new XMLSerializer).serializeToString(t).replace(/&nbsp;/g, "\xa0")
}

function addExternalStyles(t, e) {
    var i = t.ownerDocument.implementation.createDocument(null, "xml", null);
    V(t).prepend(V("style", {type: "text/css"}, [i.createCDATASection(e)]))
}

function copyExternalStyles(t, e) {
    var i = Array.from(t.querySelectorAll("*")), e = Array.from(e.querySelectorAll("*"));
    let n = t.ownerDocument;
    var o = n.styleSheets.length, s = [];
    for (let t = o - 1; 0 <= t; t--) s[t] = n.styleSheets[t], n.styleSheets[t].disabled = !0;
    let r = {};
    i.forEach((t, e) => {
        let i = window.getComputedStyle(t, null), n = {};
        util.forIn(i, t => {
            n[t] = i.getPropertyValue(t)
        }), r[e] = n
    }), o != n.styleSheets.length && s.forEach((t, e) => {
        n.styleSheets[e] = t
    });
    for (let t = 0; t < o; t++) n.styleSheets[t].disabled = !1;
    let a = {};
    i.forEach((t, e) => {
        let i = window.getComputedStyle(t, null), n = r[e], o = {};
        util.forIn(i, t => {
            isNaN(t) && i.getPropertyValue(t) !== n[t] && (o[t] = i.getPropertyValue(t))
        }), a[e] = o
    }), e.forEach((t, e) => {
        $$1(t).css(a[e])
    })
}

let openAsSVG = (t, e) => {
    let i = util.uniqueId("svg_output");
    toSVG(t, t => {
        var e = window.open("", i, "menubar=yes,location=yes,resizable=yes,scrollbars=yes,status=yes"),
            t = "data:image/svg+xml," + encodeURIComponent(t);
        e.document.write('<img src="' + t + '" style="max-height:100%" />')
    }, util.assign({convertImagesToDataUris: !0}, e))
};
var formatSVG = {__proto__: null, openAsSVG: openAsSVG, toSVG: toSVG};
let toDataURL = (t, l, h = {}) => {
    if (void 0 === t) throw new Error("The dia.Paper is a mandatory argument.");
    let c = h.canvg || ("undefined" != typeof canvg ? canvg : void 0);
    var e = createSVGViewBox(h.area || t.paperToLocalRect(t.getContentBBox()), h);
    let d = scaleRasterSize(util.isNumber(h.width) && util.isNumber(h.height) ? h : e, getScale(h.size));
    if (!isCanvasSizeAllowed(d.width, d.height)) throw new Error("dia.Paper: raster size exceeded.");
    let u = new Image, p, g;
    u.onload = function () {
        let n, o, s;

        function i() {
            (s = document.createElement("canvas")).width = d.width, s.height = d.height, (o = s.getContext("2d")).fillStyle = h.backgroundColor || "white", o.fillRect(0, 0, d.width, d.height)
        }

        function r() {
            var t = h.type, e = h.quality;
            if ("canvas" === t) {
                var i = o;
                try {
                    i.getImageData(0, 0, 1, 1)
                } catch (t) {
                }
                l(s, g)
            } else n = s.toDataURL(t, e), l(n, g);
            a()
        }

        function a() {
            s.svg && util.isFunction(s.svg.stop) && setTimeout(s.svg.stop, 1)
        }

        i();
        try {
            o.drawImage(u, 0, 0, d.width, d.height), r()
        } catch (t) {
            if (void 0 === c) console.error("Canvas tainted. Canvg library required."); else {
                i();
                let e = {
                    ignoreDimensions: !0,
                    ignoreClear: !0,
                    ignoreMouse: !0,
                    ignoreAnimation: !0,
                    offsetX: 0,
                    offsetY: 0,
                    useCORS: !0
                };
                c(s, p, util.assign(e, {
                    forceRedraw: function () {
                        return !this.called && (this.called = !0)
                    }.bind({called: !1}), renderCallback: function () {
                        try {
                            r()
                        } catch (t) {
                            a(), p = replaceSVGImagesWithSVGEmbedded(p), i(), c(s, p, util.assign(e, {renderCallback: r}))
                        }
                    }
                }))
            }
        }
    }, toSVG(t, (t, e) => {
        p = t, g = e, u.src = "data:image/svg+xml," + encodeURIComponent(t)
    }, {
        convertImagesToDataUris: !0,
        beforeSerialize: h.beforeSerialize,
        area: e,
        grid: h.grid,
        useComputedStyles: h.useComputedStyles,
        stylesheet: h.stylesheet,
        fillFormControls: h.fillFormControls,
        preserveDimensions: {width: d.width, height: d.height}
    })
}, toPNG = (t, e, i) => {
    (i = i || {}).type = "image/png", toDataURL(t, e, i)
}, toJPEG = (t, e, i) => {
    (i = i || {}).type = "image/jpeg", toDataURL(t, e, i)
}, toCanvas = (t, e, i) => {
    (i = i || {}).type = "canvas", toDataURL(t, e, i)
}, openAsPNG = (t, e) => {
    let i = util.uniqueId("png_output");
    toPNG(t, function (t) {
        window.open("", i, "menubar=yes,location=yes,resizable=yes,scrollbars=yes,status=yes").document.write('<img src="' + t + '"/>')
    }, util.assign({padding: 10}, e))
};

function isCanvasSizeAllowed(t, e) {
    var i = document.createElement("canvas"), t = (i.width = t) - 1, e = (i.height = e) - 1, i = i.getContext("2d");
    try {
        i.fillStyle = "rgb(1,1,1)", i.fillRect(t, e, 1, 1);
        var n = i.getImageData(t, e, 1, 1).data;
        if (1 !== n[0] || 1 !== n[1] || 1 !== n[2]) return !1
    } catch (t) {
        return !1
    }
    return !0
}

function createSVGViewBox(t, e) {
    var i, n = getPadding(e), o = g.Rect({x: -n.left, y: -n.top, width: n.left + n.right, height: n.top + n.bottom});
    return e.width && e.height && (i = t.width + n.left + n.right, n = t.height + n.top + n.bottom, o.scale(i / e.width, n / e.height)), g.Rect(t).moveAndExpand(o)
}

function getScale(t) {
    let e = 1;
    if (void 0 === t || (e = parseFloat(t), Number.isFinite(e) && 0 !== e)) return e;
    throw new Error("dia.Paper: invalid raster size (" + t + ")")
}

function scaleRasterSize(t, e) {
    return {width: Math.max(Math.round(t.width * e), 1), height: Math.max(Math.round(t.height * e), 1)}
}

function getPadding(t) {
    var e = util.normalizeSides(t.padding);
    return t.width && t.height && (e.left + e.right >= t.width && (e.left = e.right = 0), e.top + e.bottom >= t.height) && (e.top = e.bottom = 0), e
}

function replaceSVGImagesWithSVGEmbedded(t) {
    return t.replace(/<image[^>]*>/g, function (t) {
        var e = t.match(/href="([^"]*)"/), e = e && e[1], i = "data:image/svg+xml";
        return e && e.substr(0, i.length) === i ? (i = atob(e.substr(e.indexOf(",") + 1))).substr(i.indexOf("<svg")) : t
    })
}

var formatRaster = {
    __proto__: null,
    openAsPNG: openAsPNG,
    toCanvas: toCanvas,
    toDataURL: toDataURL,
    toJPEG: toJPEG,
    toPNG: toPNG
};
let toCellsArray = (t, r, i) => {
    t = (new DOMParser).parseFromString(t, "text/xml");
    if ("parsererror" == t.documentElement.nodeName) throw new Error("Error while parsing GEXF file.");
    var e = Array.from(t.documentElement.querySelectorAll("node")),
        t = Array.from(t.documentElement.querySelectorAll("edge"));
    let a = [];
    return e.forEach(function (t) {
        var e, i, n = {id: t.getAttribute("id"), label: t.getAttribute("label")}, o = t.querySelector("size"),
            o = (o && (o = parseFloat(o.getAttribute("value")), n.width = o, n.height = o), t.querySelector("position")),
            s = (o && (s = parseFloat(o.getAttribute("x")), e = parseFloat(o.getAttribute("y")), o = parseFloat(o.getAttribute("z")), n.x = s, n.y = e, n.z = o), t.querySelector("shape")),
            o = (s && (e = s.getAttribute("value"), n.shape = e), t.querySelector("color")),
            o = (o && (s = o.getAttribute("r"), e = o.getAttribute("g"), i = o.getAttribute("b"), o = o.getAttribute("a"), n.color = o ? `rgba(${s},${e},${i},${o})` : `rgb(${s},${e},${i})`), r(n, t));
        a.push(o)
    }), t.forEach(function (t) {
        var e = {source: t.getAttribute("source"), target: t.getAttribute("target")}, e = i(e, t);
        a.unshift(e)
    }), a
}, $ = mvc.$, MAX_ROWS = 200, MAX_COLUMNS = 200;

function print(e, i) {
    var t = resolveOptions(i), n = preparePages(e, t), o = {sheetSizePx: getSheetSizePx(t)};
    t.ready(n, function (t) {
        sendToPrinter(e, t, i)
    }, o)
}

var preparePrintArea = function (t, e, i) {
    t.trigger("beforeprint", i);
    var n = document.createElement("div"), o = (n.className = "printarea", document.createElement("div")),
        s = (o.classList.add(util.addClassNamePrefix("print-paper")), o.style.position = "relative", i.size && n.classList.add("printarea-size-" + i.size), V(t.svg).clone()),
        r = s.findOne("." + util.addClassNamePrefix("layers")),
        i = (i.grid || s.findOne("." + util.addClassNamePrefix("grid-layer")).remove(), o.appendChild(s.node), getSheetSizePx(i)),
        a = t.getArea(), {sx: l, sy: h} = t.scale(), {tx: t, ty: c} = t.translate(),
        t = V.createSVGMatrix().translate(t / l, c / h), {scaleToFit: l, bBox: c} = getViewBox(a, e, i);
    return o.style.left = "0", o.style.top = "0", s.attr({
        width: c.width * l,
        height: c.height * l,
        style: "position:relative",
        viewBox: [c.x, c.y, c.width, c.height].join(" ")
    }), r.attr("transform", V.matrixToTransformString(t)), o.appendChild(s.node), n.appendChild(o), n.classList.add("preview"), {
        el: n,
        sheetSizePx: i
    }
}, sendToPrinter = function (t, e, i) {
    var n, o, s, r;
    e && ((n = $(document.body)).addClass("joint-print"), o = t.$el.children().detach(), e.forEach(function (t) {
        t.classList.remove("preview"), t.classList.add("print-ready"), n.append(t)
    }), s = !1, r = function () {
        s || (s = !0, n.removeClass("joint-print"), e.forEach(function (t) {
            t.remove()
        }), t.$el.append(o), $("#print-styles").remove(), t.trigger("afterprint", i), $(window).off("afterprint", r))
    }, $(window).one("afterprint", r), setTimeout(r, 200), window.print())
}, preparePages = function (t, e) {
    var i, n = getArea(t, e), o = [];
    if (e.poster) for (var s = getPosterPieceSize(n, e.poster), r = splitArea(n, s), a = 0; a < r.length; a++) i = preparePrintArea(t, r[a], e), o.push(i.el); else i = preparePrintArea(t, n, e), o.push(i.el);
    return i && (s = {width: i.sheetSizePx.cssWidth, height: i.sheetSizePx.cssHeight}, injectPrintCss(s, e)), o
}, objectToCss = function (e) {
    return Object.keys(e).map(function (t) {
        return t + ":" + e[t]
    }).join(";") + ";"
}, getSheetSizePx = function (t) {
    var e = util.normalizeSides(t.margin), i = t.sheet,
        t = (e.unit = t.marginUnit, i.unit = t.sheetUnit, "calc(" + i.width + i.unit + " - " + (e.left + e.right) + e.unit + ")"),
        i = "calc(" + i.height + i.unit + " - " + (e.top + e.bottom) + e.unit + ")", e = convert.measure(t, i, "");
    return {cssWidth: t, cssHeight: i, width: e.width, height: e.height}
}, getViewBox = function (t, e, i) {
    var t = new g.Rect({x: e.x - t.x, y: e.y - t.y, width: e.width, height: e.height}), e = t.width / t.height,
        n = i.width / i.height, i = n < e ? i.width / t.width : i.height / t.height;
    return {bBox: t, scaleToFit: i, fitHorizontal: n < e}
}, resolveOptions = function (t) {
    t = util.defaultsDeep({}, t, {
        area: null,
        poster: !1,
        sheet: {width: 210, height: 297},
        sheetUnit: "mm",
        ready: function (t, e, i) {
            e(t)
        },
        margin: .4,
        marginUnit: "in",
        padding: 5
    });
    return t.area || (t.printingAll = !0), t
}, injectCss = function (t) {
    var e = $("#print-styles"), i = '<style type="text/css" id="print-styles">' + t + "</style>";
    e.length ? e.html(t) : $("head").append(i)
}, injectPrintCss = function (t, e) {
    var t = objectToCss(t), i = util.normalizeSides(e.margin), n = e.marginUnit,
        i = [i.top + n, i.right + n, i.bottom + n, i.left + n].join(" "),
        n = "size:" + (e.sheet.width + e.sheet.unit) + " " + (e.sheet.height + e.sheet.unit);
    injectCss(["@media print {", ".printarea.print-ready {", t, "}", "@page {", "margin:" + i + ";", n, "}", ".printarea.preview {", t, "}", "}"].join(""))
}, getArea = function (t, e) {
    var i = e.area;
    return i || (e = util.normalizeSides(e.padding), i = t.getContentArea().moveAndExpand({
        x: -e.left,
        y: -e.top,
        width: e.left + e.right,
        height: e.top + e.bottom
    })), i
}, splitArea = function (t, e) {
    for (var i, n = e.width, o = e.height, s = [], r = 0, a = 0, l = 0, h = 0; r < t.height;) {
        for (; a < t.width && (i = g.Rect(t.x + a, t.y + r, n, o), s.push(i), a += n, !(h > MAX_COLUMNS));) h++;
        if (h = a = 0, r += o, l > MAX_ROWS) break;
        l++
    }
    return s
}, getPosterPieceSize = function (t, e) {
    var i = {width: e.width, height: e.height};
    return i.width || (i.width = Math.ceil(t.width / (e.columns || 1))), i.height || (i.height = Math.ceil(t.height / (e.rows || 1))), i
}, convert = {
    supportedUnits: {
        px: function (t) {
            return t
        }, mm: function (t) {
            return this.millimeterSize * t
        }, cm: function (t) {
            return this.millimeterSize * t * 10
        }, in: function (t) {
            return this.millimeterSize * t * 25.4
        }, pt: function (t) {
            return this.millimeterSize * (25.4 * t / 72)
        }, pc: function (t) {
            return this.millimeterSize * (25.4 * t / 6)
        }
    }, measure: function (t, e, i) {
        i = i || "";
        t = $("<div/>").css({
            display: "inline-block",
            position: "absolute",
            left: -15e3,
            top: -15e3,
            width: t + i,
            height: e + i
        }).appendTo(document.body), e = {width: t.width(), height: t.height()};
        return t.remove(), e
    }, toPx: function (t, e) {
        if (this.millimeterSize || (this.millimeterSize = this.measure(1, 1, "mm").width), e = (e || "").toLowerCase(), this.supportedUnits[e]) return this.supportedUnits[e].call(this, t);
        throw new Error("Unsupported unit " + e)
    }
}, version = "4.2.1";
let standardJoint = shapes$1.standard, layoutRappid = {
        ForceDirected: ForceDirected,
        GridLayout: GridLayout,
        StackLayout: StackLayout,
        TreeLayout: TreeLayout
    }, elToolsRappid = {
        RecordScrollbar: RecordScrollbar,
        SwimlaneBoundary: SwimlaneBoundary,
        SwimlaneTransform: SwimlaneTransform
    }, diaRappid = {SearchGraph: SearchGraph, CommandManager: CommandManager, Validator: Validator},
    layout = util.assign({}, layout$1, layoutRappid), elementTools = util.assign({}, elementTools$1, elToolsRappid),
    standard = util.assign({}, standardJoint, standardRappid),
    shapes = {standard: standard, bpmn2: bpmn2, chart: chart, measurement: measurement},
    dia = util.assign({}, dia$1, diaRappid), ui = {
        BPMNFreeTransform: BPMNFreeTransform,
        Clipboard: Clipboard,
        ColorPalette: ColorPalette,
        ContextToolbar: ContextToolbar,
        Dialog: Dialog,
        FlashMessage: FlashMessage,
        FreeTransform: FreeTransform,
        Halo: Halo,
        Inspector: Inspector,
        Keyboard: Keyboard,
        Lightbox: Lightbox,
        Navigator: Navigator,
        PaperScroller: PaperScroller,
        PathDrawer: PathDrawer,
        PathEditor: PathEditor,
        Popup: Popup,
        RadioGroup: RadioGroup,
        SelectBox: SelectBox,
        SelectButtonGroup: SelectButtonGroup,
        Selection: Selection,
        SelectionFrameList: SelectionFrameList,
        OverlaySelectionFrameList: OverlaySelectionFrameList,
        HighlighterSelectionFrameList: HighlighterSelectionFrameList,
        SVGSelectionFrameList: SVGSelectionFrameList,
        HTMLSelectionFrameList: HTMLSelectionFrameList,
        SelectionWrapper: SelectionWrapper,
        HTMLSelectionWrapper: HTMLSelectionWrapper,
        SelectionRegion: SelectionRegion,
        RectangularSelectionRegion: RectangularSelectionRegion,
        PolygonalSelectionRegion: PolygonalSelectionRegion,
        RangeSelectionRegion: RangeSelectionRegion,
        Snaplines: Snaplines,
        StackLayoutView: StackLayoutView,
        Stencil: Stencil,
        TextEditor: TextEditor,
        Toolbar: Toolbar,
        Tooltip: Tooltip,
        TreeLayoutView: TreeLayoutView,
        Widget: Widget,
        widgets: widgets
    }, graphUtils = {constructTree: constructTree, shortestPath: shortestPath, toAdjacencyList: toAdjacencyList},
    storage = {Local: Local}, alg = {Dijkstra: Dijkstra, PriorityQueue: PriorityQueue},
    format = Object.assign({}, formatSVG, formatRaster, {gexf: {toCellsArray: toCellsArray}}, {print: print});
export {alg, dia, elementTools, format, graphUtils, layout, shapes, storage, ui, version as versionPlus};